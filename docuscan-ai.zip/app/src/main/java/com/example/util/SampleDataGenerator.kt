package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.example.data.database.DocumentDao
import com.example.data.model.CompressionLevel
import com.example.data.model.DocumentCategory
import com.example.data.model.ScannedDocument
import com.example.data.util.PdfGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object SampleDataGenerator {

    private const val COLOR_WHITE = 0xFFFFFFFF.toInt()
    private const val COLOR_PRIMARY_BLUE = 0xFF0D47A1.toInt()
    private const val COLOR_SECONDARY_BLUE = 0xFF1565C0.toInt()
    private const val COLOR_LIGHT_BLUE = 0xFFBBDEFB.toInt()
    private const val COLOR_TABLE_HEADER = 0xFFE3F2FD.toInt()
    private const val COLOR_TEXT_DARK = 0xFF212121.toInt()
    private const val COLOR_TEXT_MUTED = 0xFF757575.toInt()
    private const val COLOR_GREEN = 0xFF2E7D32.toInt()
    private const val COLOR_TEAL_DARK = 0xFF004D40.toInt()
    private const val COLOR_TEAL_LIGHT = 0xFF80CBC4.toInt()
    private const val COLOR_TEAL_BG = 0xFFE0F2F1.toInt()
    private const val COLOR_ORANGE_DARK = 0xFFE65100.toInt()
    private const val COLOR_ORANGE_BORDER = 0xFFFF9800.toInt()
    private const val COLOR_ORANGE_BG = 0xFFFFF3E0.toInt()
    private const val COLOR_PURPLE_DARK = 0xFF512DA8.toInt()
    private const val COLOR_PURPLE_BORDER = 0xFF7E57C2.toInt()
    private const val COLOR_PURPLE_BG = 0xFFEDE7F6.toInt()
    private const val COLOR_BG_GRAY = 0xFFFAFAFA.toInt()
    private const val COLOR_BORDER_GRAY = 0xFFE0E0E0.toInt()
    private const val COLOR_BAR_BG = 0xFFEEEEEE.toInt()

    /**
     * Purges and removes all sample PDFs and demo documents from Room database and local storage.
     */
    suspend fun purgeAllSampleDocuments(
        context: Context,
        dao: DocumentDao
    ) = withContext(Dispatchers.IO) {
        try {
            // Only clean old dummy sample_docs directory if present
            val officeDir = File(context.filesDir, "sample_docs")
            if (officeDir.exists()) {
                officeDir.deleteRecursively()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Seeds initial random sample documents for each category so user can immediately test all features.
     */
    suspend fun seedSampleDocuments(
        context: Context,
        dao: DocumentDao,
        force: Boolean = false
    ) = withContext(Dispatchers.IO) {
        if (!force) return@withContext
        try {
            val existing = dao.getAllPublicDocuments().first()
            val historyExists = existing.any { it.title.contains("मध्य पुरा पाषाण") }

            val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
            val imgDir = File(context.filesDir, "page_images").apply { mkdirs() }
            val officeDir = File(context.filesDir, "sample_docs").apply { mkdirs() }

            if (!historyExists || force) {
                // 0. Ancient History Notes PDF matching Screenshot 1: मध्य पुरा पाषाण कला संस्कृति
                val historyPdfFile = createHistoryNotesPdf(context, pdfDir)
                val historyDoc = ScannedDocument(
                    title = "मध्य पुरा पाषाण कला संस्कृति",
                    pdfFilePath = historyPdfFile.absolutePath,
                    pageCount = 2,
                    fileSizeFormatted = "216 KB",
                    fileSizeBytes = historyPdfFile.length(),
                    compressionLevel = CompressionLevel.LOW.name,
                    fileCategory = DocumentCategory.PDF.name,
                    isStarred = true,
                    tags = "#इतिहास,#पाषाण_काल,#Culture,#Notes",
                    watermarkText = "",
                    stampText = "",
                    aiSummary = "• विषय: मध्य पुरा पाषाण एवं उच्च पुरापाषाण कला संस्कृति अध्ययन\n• प्रमुख केंद्र: भीमबेटका, सोहन नदी घाटी, नेवासा, हथनोरा\n• पुरातात्विक साक्ष्य: मातृ देवी की मूर्ति, शुतुरमुर्ग के अंडे पर चित्रकला, प्राचीनतम चूल्हा।",
                    extractedText = "मध्य पुरा पाषाण कला संस्कृति\n\n> मध्य पुरा पाषाण कला संस्कृति काल में पत्थर के उपकरण में परिवर्तन देखा गया लेवालोइस जिसे फलक संस्कृति के नाम से भी जानते हैं पाषाण काल में इस संस्कृति के अवशेष मिले हैं पत्थर के औजारों का निर्माण और तकनीकी पर बल दिया गया\n> मध्य पुरा पाषाण कला संस्कृति को A. घोष ने फलक संस्कृति के नाम से पुकारा के .डी. बनर्जी ने इसे नेवशा संस्कृति के नाम से पुकारा एच. डी. संकलिया ने Sesies सेकंड के नाम से पुकारा\n> पत्थर फिलिप खुरचनी छेदनी के औजार बनाया गया मध्यप्रदेश में नर्मदा घाटी के हथनोरा नामक स्थान से मानव का कंकाल मिला है\n> इस कल के निम्नलिखित केंद्र हैं उत्तर पश्चिम में सोहन नदी घाटी उत्तर भारत में उत्तर प्रदेश में चकिया नामक स्थान पर ,मध्य प्रदेश में नर्मदा घाटी के पास रायसेन और भीमबेटका गुफा, राजस्थान में बागोर नामक स्थान ,महाराष्ट्र में नेवासा नामक स्थान, गुजरात में सौराष्ट्र और हिमाचल प्रदेश में व्यास गंगा घाटी ,सिरसा गंगा घाटी में पाषाण काल के केंद्र हमें प्राप्त होता है\n\nउच्च पुरापाषाण काल संस्कृति\n\n> इस काल में छोटे-छोटे और बारीक उपकरण बनाए गए हैं इस ब्लेड संस्कृति के नाम से भी पुकारा जाता है उच्च पूरा पाषाण काल को मेगदलेइन संस्कृति भी कहा जाता है इसमें उपकरणों पर विशेष ध्यान दिया गया ब्लेड उपकरण का अधिकतम उपयोग किया गया नए-नए चमक उद्योगों में इनका प्रयोग किया जाता था होमोसेपियन मानव का प्रदर्शन इसी काल में हुआ 35000 B.C.से 10000 B.C. का यह काल कहलाता है इलाहाबाद के लोहदनाला नामक स्थान पर हाथ से बनी हुई मातृ देवी की मूर्ति मिली है कहते हैं कि यह हड्डी से निर्मित है कुछ विद्वान मूर्ति नहीं मानते इसे भाला का रूप कहते हैं यह एक प्रकार का भाला है आंध्र प्रदेश में करनाल नामक गुफा से मुछतला के अवशेष प्राप्त हुए हैं बड़ी मात्रा में हड्डी के उपकरण मिले\n> महाराष्ट्र के पतणे नामक स्थान से शुतुरमुर्ग के अंडे के ऊपर चित्रकला का प्रारंभ माना जाता है\n> आंध्र प्रदेश के विलासुरम नामक स्थान की खोज रॉबर्ट ने की थी या प्राचीनतम चूल्हा प्राप्त हुआ है आंध्र प्रदेश के पेसारा नामक स्थान पर प्राचीनतम चूल्हा मिला\n> मध्य पाषाण काल में बिहार से चूल्हे के अवशेष प्राप्त हुए हैं\n> उच्च पुरापाषाण काल में मध्य प्रदेश के बाघोर नामक स्थान से पद चिन्ह प्राप्त हुए हैं यह पदचिह्न हिरण के थे\n> कहते हैं कि यहां से एक चबूतरा भी मिला है जिस पर वेदिका जो पूजा स्थल हुआ है"
                )
                val historyId = dao.insertDocument(historyDoc)
                savePlaceholderPages(imgDir, historyId, 2)
            }

            if (existing.isNotEmpty() && !force) {
                return@withContext
            }

            // 1. Multi-Page PDF: वार्षिक वित्तीय ऑडिट रिपोर्ट (Annual Financial Report)
            val reportPdfFile = createFinancialReportPdf(context, pdfDir)
            val reportDoc = ScannedDocument(
                title = "वार्षिक वित्तीय ऑडिट रिपोर्ट 2024-25",
                pdfFilePath = reportPdfFile.absolutePath,
                pageCount = 3,
                fileSizeFormatted = PdfGenerator.formatFileSize(reportPdfFile.length()),
                fileSizeBytes = reportPdfFile.length(),
                compressionLevel = CompressionLevel.LOW.name,
                fileCategory = DocumentCategory.PDF.name,
                isStarred = true,
                tags = "#वित्तीय,#Audit,#Reports,#2024",
                watermarkText = "प्रमाणित / VERIFIED",
                stampText = "APPROVED",
                aiSummary = "• शीर्षक: वार्षिक वित्तीय ऑडिट रिपोर्ट 2024-25\n• कुल राजस्व: ₹1,48,50,000 (18.5% वृद्धि)\n• शुद्ध लाभ: ₹32,40,000\n• स्थिति: सभी खातों का सत्यापन पूर्ण, टैक्स व जीएसटी अनुपालन अनुमोदित।",
                extractedText = "वार्षिक वित्तीय ऑडिट रिपोर्ट 2024-2025\nकंपनी नाम: भारत टेक सोल्यूशंस प्रा. लि.\nपंजीकरण क्रमांक: CIN-U72200DL2021PTC123456\nऑडिट दिनांक: 31 मार्च 2024\n\nमुख्य वित्तीय बिंदु:\n1. कुल परिचालन आय: ₹1,48,50,000\n2. कुल परिचालन व्यय: ₹1,16,10,000\n3. ईबीआईटीडीए (EBITDA): ₹32,40,000\n4. शुद्ध लाभ (PAT): ₹24,80,000\n5. जीएसटी व आयकर भुगतान: पूर्ण अनुपालन।"
            )
            val reportId = dao.insertDocument(reportDoc)
            savePlaceholderPages(imgDir, reportId, 3)

            // 2. ID Card A4 Scan: आधार व पहचान पत्र सत्यापन (Aadhaar & ID Card A4)
            val idCardPdfFile = createIdCardSamplePdf(context, pdfDir)
            val idCardDoc = ScannedDocument(
                title = "आईडी कार्ड सत्यापन - आधार व पैन A4",
                pdfFilePath = idCardPdfFile.absolutePath,
                pageCount = 1,
                fileSizeFormatted = PdfGenerator.formatFileSize(idCardPdfFile.length()),
                fileSizeBytes = idCardPdfFile.length(),
                compressionLevel = CompressionLevel.LOW.name,
                fileCategory = DocumentCategory.PDF.name,
                isStarred = true,
                tags = "#पहचान_पत्र,#Aadhaar,#Official",
                watermarkText = "सुरक्षित प्रति / SAFE COPY",
                stampText = "VERIFIED",
                aiSummary = "• प्रकार: भारतीय विशिष्ट पहचान (UIDAI) व पैन कार्ड सत्यापन A4\n• धारक का नाम: राहुल कुमार शर्मा\n• सत्यापन स्थिति: दोनों ओर (Front & Back) का एकल पृष्ठ A4 स्कैन तैयार।",
                extractedText = "भारत सरकार - GOVERNMENT OF INDIA\nविशिष्ट पहचान प्राधिकरण (UIDAI)\nनाम: राहुल कुमार शर्मा (Rahul Kumar Sharma)\nजन्म तिथि (DOB): 15/08/1995\nआधार क्रमांक: XXXX-XXXX-9842\nपैन कार्ड: ABCDE1234F\nसत्यापन: अधिकृत पहचान पत्र - दोनों भाग।"
            )
            val idCardId = dao.insertDocument(idCardDoc)
            savePlaceholderPages(imgDir, idCardId, 1)

            // 3. GST Tax Invoice / Bill: जीएसटी टैक्स बिल व रसीद (GST Tax Invoice PDF)
            val invoicePdfFile = createGstInvoicePdf(context, pdfDir)
            val invoiceDoc = ScannedDocument(
                title = "जीएसटी टैक्स चालान व बिल #INV-9821",
                pdfFilePath = invoicePdfFile.absolutePath,
                pageCount = 1,
                fileSizeFormatted = PdfGenerator.formatFileSize(invoicePdfFile.length()),
                fileSizeBytes = invoicePdfFile.length(),
                compressionLevel = CompressionLevel.LOW.name,
                fileCategory = DocumentCategory.PDF.name,
                tags = "#बिल,#GST,#Tax,#Receipt",
                stampText = "PAID",
                aiSummary = "• बिल क्रमांक: INV-9821\n• विक्रेता: हिन्दुस्तान ट्रेडर्स एंड सप्लायर्स\n• कुल राशि: ₹28,910 (जीएसटी 18% सहित)\n• भुगतान स्थिति: पूर्ण रूप से चुकता (PAID)",
                extractedText = "टैक्स इनवॉइस (TAX INVOICE)\nफर्म: हिन्दुस्तान ट्रेडर्स एंड सप्लायर्स\nजीएसटी नं: 07AAAAA0000A1Z5\nबिल सं.: INV-9821 | दिनांक: 10 अगस्त 2024\nग्राहक: मेसर्स डिजिटल इंडिया प्रा. लि.\n\nविवरण:\n1. कंप्यूटर उपकरण - ₹18,500\n2. प्रिंटर व स्कैनर कार्ट्रिज - ₹6,000\nउप-योग: ₹24,500\nCGST (9%): ₹2,205\nSGST (9%): ₹2,205\nकुल देय राशि: ₹28,910 (सफलतापूर्वक प्राप्त)।"
            )
            val invoiceId = dao.insertDocument(invoiceDoc)
            savePlaceholderPages(imgDir, invoiceId, 1)

            // 4. Word Document: रोजगार अनुबंध व सेवा शर्तें (Employment Agreement - Word)
            val wordFile = File(officeDir, "Employment_Agreement_2024.docx")
            wordFile.writeText("रोजगार अनुबंध पत्र (Employment Contract)")
            val wordDoc = ScannedDocument(
                title = "कंपनी सेवा अनुबंध व नियुक्ति पत्र",
                pdfFilePath = wordFile.absolutePath,
                pageCount = 2,
                fileSizeFormatted = "48.5 KB",
                fileSizeBytes = 49664,
                compressionLevel = CompressionLevel.LOW.name,
                fileCategory = DocumentCategory.WORD.name,
                isStarred = false,
                tags = "#अनुबंध,#Office,#Word,#HR",
                extractedText = "रोजगार अनुबंध एवं सेवा शर्तें (EMPLOYMENT AGREEMENT)\n\nयह समझौता दिनांक 01 मई 2024 को प्रथम पक्ष (कंपनी) और द्वितीय पक्ष (कर्मचारी) के मध्य निष्पादित हुआ:\n\n1. पद एवं दायित्व (Role & Responsibilities):\nकर्मचारी को 'सीनियर सॉफ्टवेयर इंजीनियर' पद पर नियुक्त किया जाता है। कर्मचारी कंपनी की तकनीकी विकास परियोजनाओं में योगदान देंगे।\n\n2. पारिश्रमिक एवं लाभ (Compensation):\nकर्मचारी को वार्षिक ₹12,00,000 का सकल पैकेज प्रदान किया जाएगा।\n\n3. गोपनीयता व गैर-प्रकटीकरण (Confidentiality & NDA):\nकर्मचारी कंपनी के किसी भी गोपनीय डेटा, कोड अथवा व्यावसायिक जानकारी को तीसरे पक्ष के साथ साझा नहीं करेंगे।"
            )
            dao.insertDocument(wordDoc)

            // 5. Excel Sheet: मासिक आय-व्यय व बजट बहीखाता (Monthly Budget Sheet - Excel)
            val excelFile = File(officeDir, "Monthly_Budget_Ledger.xlsx")
            excelFile.writeText("मासिक बजट एक्सेल शीट (Monthly Budget Excel)")
            val excelDoc = ScannedDocument(
                title = "मासिक आय-व्यय व बजट खाता 2024",
                pdfFilePath = excelFile.absolutePath,
                pageCount = 1,
                fileSizeFormatted = "32.0 KB",
                fileSizeBytes = 32768,
                compressionLevel = CompressionLevel.LOW.name,
                fileCategory = DocumentCategory.EXCEL.name,
                tags = "#बजट,#Excel,#खाता,#Finance",
                extractedText = "दिनांक\tविवरण\tश्रेणी\tजमा (Credit)\tनिकासी (Debit)\tशेष (Balance)\n01/08/2024\tमासिक वेतन प्राप्त\tआय\t₹85,000\t₹0\t₹85,000\n03/08/2024\tमकान किराया भुगतान\tआवास\t₹0\t₹22,000\t₹63,000\n05/08/2024\tराशन व किराना\tघरेलू\t₹0\t₹9,500\t₹53,500\n10/08/2024\tबिजली व इंटरनेट बिल\tबिल\t₹0\t₹3,200\t₹50,300\n12/08/2024\tफ्रीलांस परामर्श आय\tअतिरिक्त आय\t₹25,000\t₹0\t₹75,300\nकुल बचत शेष: ₹75,300"
            )
            dao.insertDocument(excelDoc)

            // 6. PowerPoint: प्रोजेक्ट प्रेजेंटेशन - AI DocuScan Pitch (PPT)
            val pptFile = File(officeDir, "Project_Presentation_DocuScan.pptx")
            pptFile.writeText("प्रोजेक्ट प्रेजेंटेशन (Pitch Deck)")
            val pptDoc = ScannedDocument(
                title = "प्रोजेक्ट प्रेजेंटेशन - AI डॉक्युमेंट स्कैनर",
                pdfFilePath = pptFile.absolutePath,
                pageCount = 3,
                fileSizeFormatted = "1.2 MB",
                fileSizeBytes = 1258291,
                compressionLevel = CompressionLevel.LOW.name,
                fileCategory = DocumentCategory.POWERPOINT.name,
                tags = "#Presentation,#PPT,#Pitch,#AI",
                extractedText = "स्लाइड 1: AI DocuScan प्रो - अगली पीढ़ी का दस्तावेज़ प्रबंधन समाधान\nप्रस्तुतकर्ता: कोर इंजीनियरिंग टीम\n\nस्लाइड 2: समस्या व हमारा समाधान\n• समस्या: भारी-भरकम स्कैनर व धीमा OCR\n• समाधान: ऑन-डिवाइस अल्ट्रा-फास्ट स्कैनिंग, जादुई रंग सुधार और बहुभाषी AI सहायता।\n\nस्लाइड 3: मुख्य फीचर्स व भविष्य की रूपरेखा\n• क्लाउडलेस 100% प्राइवेट वॉल्ट\n• वॉयस नोट, पीडीएफ प्रश्नोत्तरी, और वाटरमार्क स्टैंप।"
            )
            dao.insertDocument(pptDoc)

            // 7. Text Document: प्रतियोगी परीक्षा सामान्य ज्ञान नोट्स (Exam Study Notes - Text)
            val txtFile = File(officeDir, "Exam_GK_Notes_Hindi.txt")
            txtFile.writeText("प्रतियोगी परीक्षा नोट्स")
            val txtDoc = ScannedDocument(
                title = "प्रतियोगी परीक्षा सामान्य अध्ययन नोट्स",
                pdfFilePath = txtFile.absolutePath,
                pageCount = 1,
                fileSizeFormatted = "14.2 KB",
                fileSizeBytes = 14540,
                compressionLevel = CompressionLevel.LOW.name,
                fileCategory = DocumentCategory.TXT.name,
                isStarred = true,
                tags = "#अध्ययन,#GK,#Exams,#Notes",
                extractedText = "प्रतियोगी परीक्षा विशेष - भारतीय संविधान एवं इतिहास मुख्य तथ्य:\n\n1. भारतीय संविधान सभा की पहली बैठक 9 दिसंबर 1946 को हुई थी।\n2. संविधान प्रारूप समिति के अध्यक्ष डॉ. भीमराव अंबेडकर थे।\n3. भारत का संविधान 26 नवंबर 1949 को अंगीकृत किया गया तथा 26 जनवरी 1950 को पूर्ण रूप से लागू हुआ।\n4. नीति आयोग का गठन 1 जनवरी 2015 को योजना आयोग के स्थान पर किया गया था।\n5. भारतीय अंतरिक्ष अनुसंधान संगठन (ISRO) का मुख्यालय बेंगलुरु में स्थित है।"
            )
            dao.insertDocument(txtDoc)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createFinancialReportPdf(context: Context, pdfDir: File): File {
        val file = File(pdfDir, "Sample_Financial_Report_${System.currentTimeMillis()}.pdf")
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842

        // Page 1
        val p1Info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val p1 = doc.startPage(p1Info)
        drawReportPage1(p1.canvas, pageWidth, pageHeight)
        doc.finishPage(p1)

        // Page 2
        val p2Info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 2).create()
        val p2 = doc.startPage(p2Info)
        drawReportPage2(p2.canvas, pageWidth, pageHeight)
        doc.finishPage(p2)

        // Page 3
        val p3Info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 3).create()
        val p3 = doc.startPage(p3Info)
        drawReportPage3(p3.canvas, pageWidth, pageHeight)
        doc.finishPage(p3)

        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    private fun drawReportPage1(canvas: Canvas, w: Int, h: Int) {
        val paint = Paint().apply { isAntiAlias = true }

        // Background
        canvas.drawColor(COLOR_WHITE)

        // Header Banner
        paint.color = COLOR_PRIMARY_BLUE
        canvas.drawRect(Rect(0, 0, w, 110), paint)

        // Header Title
        paint.color = COLOR_WHITE
        paint.textSize = 20f
        paint.isFakeBoldText = true
        canvas.drawText("वार्षिक वित्तीय ऑडिट रिपोर्ट 2024-2025", 35f, 50f, paint)

        paint.textSize = 12f
        paint.isFakeBoldText = false
        paint.color = COLOR_LIGHT_BLUE
        canvas.drawText("भारत टेक सोल्यूशंस प्राइवेट लिमिटेड • CIN: U72200DL2021PTC123456", 35f, 75f, paint)
        canvas.drawText("दिनांक: 31 मार्च 2024 | दस्तावेज आईडी: FIN-REP-2024-884", 35f, 95f, paint)

        // Watermark
        val wmPaint = Paint().apply {
            color = 0x150D47A1.toInt()
            textSize = 55f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.save()
        canvas.rotate(-30f, (w / 2).toFloat(), (h / 2).toFloat())
        canvas.drawText("प्रमाणित / VERIFIED", (w / 2 - 180).toFloat(), (h / 2).toFloat(), wmPaint)
        canvas.restore()

        // Section: कार्यकारी सारांश (Executive Summary)
        paint.color = COLOR_SECONDARY_BLUE
        paint.textSize = 15f
        paint.isFakeBoldText = true
        canvas.drawText("1. कार्यकारी सारांश (Executive Summary)", 35f, 150f, paint)

        paint.color = COLOR_TEXT_DARK
        paint.textSize = 11f
        paint.isFakeBoldText = false
        val summaryLines = listOf(
            "वित्तीय वर्ष 2024-25 में कंपनी ने उत्कृष्ट वित्तीय प्रदर्शन किया है। परिचालन राजस्व में",
            "गत वर्ष की तुलना में 18.5% की स्वस्थ वृद्धि दर्ज की गई है।",
            "कंपनी का कुल संचयी राजस्व ₹1,48,50,000 रहा, जबकि शुद्ध लाभ ₹24,80,000 दर्ज हुआ।",
            "सभी वैधानिक कर, जीएसटी और पीएफ देनदारियों का समय पर अनुपालन सुनिश्चित किया गया है।"
        )
        var y = 175f
        summaryLines.forEach { line ->
            canvas.drawText(line, 35f, y, paint)
            y += 18f
        }

        // Section: मुख्य वित्तीय आंकड़े (Key Financial Metrics Table)
        paint.color = COLOR_SECONDARY_BLUE
        paint.textSize = 15f
        paint.isFakeBoldText = true
        canvas.drawText("2. प्रमुख वित्तीय संकेतक (Key Highlights Table)", 35f, y + 25f, paint)
        y += 45f

        // Table Header
        paint.color = COLOR_TABLE_HEADER
        canvas.drawRect(RectF(35f, y, (w - 35).toFloat(), y + 28f), paint)

        paint.color = COLOR_PRIMARY_BLUE
        paint.textSize = 11f
        paint.isFakeBoldText = true
        canvas.drawText("क्र.", 45f, y + 18f, paint)
        canvas.drawText("लेखा मद (Financial Head)", 80f, y + 18f, paint)
        canvas.drawText("FY 2023-24", 320f, y + 18f, paint)
        canvas.drawText("FY 2024-25", 440f, y + 18f, paint)

        val tableRows = listOf(
            Triple("कुल परिचालन राजस्व (Revenue)", "₹1,25,30,000", "₹1,48,50,000"),
            Triple("प्रत्यक्ष परिचालन व्यय (Direct Cost)", "₹82,40,000", "₹92,10,000"),
            Triple("सकल लाभ (Gross Profit)", "₹42,90,000", "₹56,40,000"),
            Triple("कर्मचारी व प्रशासनिक व्यय", "₹18,20,000", "₹24,00,000"),
            Triple("ब्याज व मूल्यह्रास (Depreciation)", "₹4,50,000", "₹7,60,000"),
            Triple("कर-पूर्व शुद्ध लाभ (PBT)", "₹20,20,000", "₹24,80,000")
        )

        paint.isFakeBoldText = false
        tableRows.forEachIndexed { idx, row ->
            y += 28f
            paint.color = if (idx % 2 == 0) COLOR_BG_GRAY else COLOR_WHITE
            canvas.drawRect(RectF(35f, y, (w - 35).toFloat(), y + 28f), paint)

            // Border line
            paint.color = COLOR_BORDER_GRAY
            paint.strokeWidth = 1f
            paint.style = Paint.Style.STROKE
            canvas.drawRect(RectF(35f, y, (w - 35).toFloat(), y + 28f), paint)
            paint.style = Paint.Style.FILL

            paint.color = COLOR_TEXT_DARK
            paint.textSize = 10.5f
            canvas.drawText("${idx + 1}.", 45f, y + 18f, paint)
            canvas.drawText(row.first, 80f, y + 18f, paint)
            canvas.drawText(row.second, 320f, y + 18f, paint)
            paint.color = COLOR_GREEN
            paint.isFakeBoldText = true
            canvas.drawText(row.third, 440f, y + 18f, paint)
            paint.isFakeBoldText = false
        }

        // Stamp Box
        y += 60f
        paint.color = COLOR_GREEN
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawRoundRect(RectF((w - 200).toFloat(), y, (w - 40).toFloat(), y + 60f), 12f, 12f, paint)

        paint.style = Paint.Style.FILL
        paint.textSize = 12f
        paint.isFakeBoldText = true
        canvas.drawText("★ AUDITED & APPROVED ★", (w - 190).toFloat(), y + 25f, paint)
        paint.textSize = 9.5f
        paint.isFakeBoldText = false
        canvas.drawText("सुरक्षित डिजिटल मोहर • DocuScan AI", (w - 185).toFloat(), y + 45f, paint)

        // Footer
        paint.color = COLOR_TEXT_MUTED
        paint.textSize = 9f
        canvas.drawText("पृष्ठ 1 / 3 • गोपनीय वित्तीय प्रतिवेदन", 35f, (h - 25).toFloat(), paint)
        canvas.drawText("DocuScan AI Engine Verified", (w - 160).toFloat(), (h - 25).toFloat(), paint)
    }

    private fun drawReportPage2(canvas: Canvas, w: Int, h: Int) {
        val paint = Paint().apply { isAntiAlias = true }
        canvas.drawColor(COLOR_WHITE)

        // Top mini-banner
        paint.color = COLOR_PRIMARY_BLUE
        canvas.drawRect(Rect(0, 0, w, 40), paint)
        paint.color = COLOR_WHITE
        paint.textSize = 12f
        paint.isFakeBoldText = true
        canvas.drawText("वार्षिक वित्तीय ऑडिट रिपोर्ट 2024-2025 • पन्ना 2", 35f, 25f, paint)

        var y = 70f
        paint.color = COLOR_SECONDARY_BLUE
        paint.textSize = 15f
        canvas.drawText("3. राजस्व विभाजन एवं विश्लेषण (Revenue Distribution)", 35f, y, paint)
        y += 30f

        paint.color = COLOR_TEXT_DARK
        paint.textSize = 11f
        paint.isFakeBoldText = false
        canvas.drawText("कंपनी का राजस्व मुख्य रूप से तीन प्रमुख क्षेत्रों से अर्जित हुआ है:", 35f, y, paint)
        y += 25f

        val bars = listOf(
            Pair("सॉफ्टवेयर सेवाएं व उत्पाद (62%)", 0.62f),
            Pair("क्लाउड इंफ्रास्ट्रक्चर व सुरक्षा (23%)", 0.23f),
            Pair("परामर्श एवं वार्षिक अनुरक्षण AMC (15%)", 0.15f)
        )

        bars.forEach { (label, ratio) ->
            paint.color = COLOR_TEXT_DARK
            paint.textSize = 10.5f
            canvas.drawText(label, 35f, y, paint)
            y += 10f

            // Progress bar background
            paint.color = COLOR_BAR_BG
            canvas.drawRoundRect(RectF(35f, y, (w - 35).toFloat(), y + 16f), 8f, 8f, paint)

            // Progress bar fill
            paint.color = COLOR_SECONDARY_BLUE
            val fillW = 35f + ((w - 70) * ratio)
            canvas.drawRoundRect(RectF(35f, y, fillW, y + 16f), 8f, 8f, paint)

            y += 32f
        }

        y += 20f
        paint.color = COLOR_SECONDARY_BLUE
        paint.textSize = 15f
        paint.isFakeBoldText = true
        canvas.drawText("4. वैधानिक अनुपालन व कर देयता (Tax Compliance)", 35f, y, paint)
        y += 25f

        paint.color = COLOR_TEXT_DARK
        paint.textSize = 11f
        paint.isFakeBoldText = false
        val taxLines = listOf(
            "• जीएसटी रिटर्न: वित्तीय वर्ष के सभी 12 महीनों के GSTR-1 व GSTR-3B समय पर दाखिल।",
            "• अग्रिम कर (Advance Tax): ₹6,20,000 की राशि चारों किस्तों में चुकता।",
            "• टीडीएस (TDS): सभी कटौती का समय पर ई-फाइलिंग व फॉर्म 16A जारी किया गया।",
            "• किसी भी प्रकार की वित्तीय अथवा कानूनी विसंगति नहीं पाई गई है।"
        )
        taxLines.forEach { line ->
            canvas.drawText(line, 35f, y, paint)
            y += 22f
        }

        // Footer
        paint.color = COLOR_TEXT_MUTED
        paint.textSize = 9f
        canvas.drawText("पृष्ठ 2 / 3 • गोपनीय वित्तीय प्रतिवेदन", 35f, (h - 25).toFloat(), paint)
        canvas.drawText("DocuScan AI Engine Verified", (w - 160).toFloat(), (h - 25).toFloat(), paint)
    }

    private fun drawReportPage3(canvas: Canvas, w: Int, h: Int) {
        val paint = Paint().apply { isAntiAlias = true }
        canvas.drawColor(COLOR_WHITE)

        // Top mini-banner
        paint.color = COLOR_PRIMARY_BLUE
        canvas.drawRect(Rect(0, 0, w, 40), paint)
        paint.color = COLOR_WHITE
        paint.textSize = 12f
        paint.isFakeBoldText = true
        canvas.drawText("वार्षिक वित्तीय ऑडिट रिपोर्ट 2024-2025 • पन्ना 3", 35f, 25f, paint)

        var y = 70f
        paint.color = COLOR_SECONDARY_BLUE
        paint.textSize = 15f
        canvas.drawText("5. स्वतंत्र ऑडिटर की राय एवं सत्यापन प्रमाण", 35f, y, paint)
        y += 30f

        paint.color = COLOR_TEXT_DARK
        paint.textSize = 11f
        paint.isFakeBoldText = false
        val certLines = listOf(
            "हमने 31 मार्च 2024 को समाप्त हुए वर्ष के लिए भारत टेक सोल्यूशंस प्रा. लि. के तुलन पत्र",
            "(Balance Sheet) और लाभ-हानि खाते की विधिवत जांच की है।",
            "हमारी राय में, ये वित्तीय विवरण भारतीय लेखा मानकों (Ind AS) के अनुसार सत्य और",
            "उचित स्थिति प्रस्तुत करते हैं।"
        )
        certLines.forEach { line ->
            canvas.drawText(line, 35f, y, paint)
            y += 20f
        }

        y += 40f

        // Signature and Seal Boxes
        val boxWidth = (w - 100) / 2f
        paint.color = COLOR_BG_GRAY
        canvas.drawRoundRect(RectF(35f, y, 35f + boxWidth, y + 130f), 10f, 10f, paint)
        canvas.drawRoundRect(RectF(w - 35f - boxWidth, y, (w - 35).toFloat(), y + 130f), 10f, 10f, paint)

        // Border
        paint.color = COLOR_BORDER_GRAY
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(RectF(35f, y, 35f + boxWidth, y + 130f), 10f, 10f, paint)
        canvas.drawRoundRect(RectF(w - 35f - boxWidth, y, (w - 35).toFloat(), y + 130f), 10f, 10f, paint)
        paint.style = Paint.Style.FILL

        // Left box text
        paint.color = COLOR_PRIMARY_BLUE
        paint.textSize = 11f
        paint.isFakeBoldText = true
        canvas.drawText("हस्ताक्षर: मुख्य वित्तीय अधिकारी (CFO)", 45f, y + 25f, paint)
        paint.color = COLOR_TEXT_MUTED
        paint.isFakeBoldText = false
        paint.textSize = 10f
        canvas.drawText("नाम: राजेश कुमार वर्मा", 45f, y + 50f, paint)
        canvas.drawText("स्थान: नई दिल्ली", 45f, y + 70f, paint)
        canvas.drawText("दिनांक: 15/04/2024", 45f, y + 90f, paint)
        paint.color = COLOR_GREEN
        paint.isFakeBoldText = true
        canvas.drawText("✓ डिजिटल रूप से हस्ताक्षरित", 45f, y + 115f, paint)

        // Right box text
        paint.color = COLOR_PRIMARY_BLUE
        paint.textSize = 11f
        paint.isFakeBoldText = true
        canvas.drawText("ऑडिटर: मेसर्स एस. के. एसोसिएट्स", (w - 25f - boxWidth), y + 25f, paint)
        paint.color = COLOR_TEXT_MUTED
        paint.isFakeBoldText = false
        paint.textSize = 10f
        canvas.drawText("चार्टर्ड एकाउंटेंट्स (ICAI Reg: 014892N)", (w - 25f - boxWidth), y + 50f, paint)
        canvas.drawText("सीए अमित गुप्ता (पार्टनर, M.No. 512398)", (w - 25f - boxWidth), y + 70f, paint)
        canvas.drawText("UDIN: 24512398BGHKLP8912", (w - 25f - boxWidth), y + 90f, paint)
        paint.color = COLOR_GREEN
        paint.isFakeBoldText = true
        canvas.drawText("✓ प्रमाणित व सत्यापित", (w - 25f - boxWidth), y + 115f, paint)

        // Footer
        paint.color = COLOR_TEXT_MUTED
        paint.textSize = 9f
        paint.isFakeBoldText = false
        canvas.drawText("पृष्ठ 3 / 3 • समाप्त • गोपनीय वित्तीय प्रतिवेदन", 35f, (h - 25).toFloat(), paint)
        canvas.drawText("DocuScan AI Engine Verified", (w - 160).toFloat(), (h - 25).toFloat(), paint)
    }

    private fun createIdCardSamplePdf(context: Context, pdfDir: File): File {
        val file = File(pdfDir, "Sample_IDCard_A4_${System.currentTimeMillis()}.pdf")
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842

        val pInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = doc.startPage(pInfo)
        val canvas = page.canvas
        val paint = Paint().apply { isAntiAlias = true }

        canvas.drawColor(COLOR_WHITE)

        // Header Title
        paint.color = COLOR_ORANGE_DARK
        paint.textSize = 18f
        paint.isFakeBoldText = true
        canvas.drawText("आईडी कार्ड सत्यापन - आधार व पहचान पत्र A4", 35f, 50f, paint)

        paint.color = COLOR_TEXT_MUTED
        paint.textSize = 11f
        paint.isFakeBoldText = false
        canvas.drawText("Front & Back Side Verification • All in Single A4 Document", 35f, 70f, paint)

        // Front Card Box
        paint.color = COLOR_ORANGE_BG
        canvas.drawRoundRect(RectF(35f, 100f, (pageWidth - 35).toFloat(), 420f), 16f, 16f, paint)

        paint.color = COLOR_ORANGE_BORDER
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawRoundRect(RectF(35f, 100f, (pageWidth - 35).toFloat(), 420f), 16f, 16f, paint)
        paint.style = Paint.Style.FILL

        // Front Card Header
        paint.color = COLOR_ORANGE_DARK
        canvas.drawRect(RectF(35f, 100f, (pageWidth - 35).toFloat(), 145f), paint)
        paint.color = COLOR_WHITE
        paint.textSize = 14f
        paint.isFakeBoldText = true
        canvas.drawText("भारत सरकार • GOVERNMENT OF INDIA", 50f, 128f, paint)

        // Photo box
        paint.color = COLOR_BORDER_GRAY
        canvas.drawRect(RectF(55f, 165f, 155f, 295f), paint)
        paint.color = COLOR_TEXT_MUTED
        paint.textSize = 10f
        paint.isFakeBoldText = false
        canvas.drawText("[फोटो / PHOTO]", 65f, 235f, paint)

        // Details
        paint.color = COLOR_TEXT_DARK
        paint.textSize = 13f
        paint.isFakeBoldText = true
        canvas.drawText("नाम: राहुल कुमार शर्मा", 175f, 185f, paint)
        paint.textSize = 11f
        paint.isFakeBoldText = false
        canvas.drawText("Name: Rahul Kumar Sharma", 175f, 205f, paint)
        canvas.drawText("जन्म तिथि / DOB: 15/08/1995", 175f, 230f, paint)
        canvas.drawText("लिंग / Gender: पुरुष / Male", 175f, 255f, paint)

        paint.color = COLOR_ORANGE_DARK
        paint.textSize = 15f
        paint.isFakeBoldText = true
        canvas.drawText("आधार सं.: XXXX  XXXX  9842", 175f, 290f, paint)

        // Front Card Label
        paint.color = COLOR_GREEN
        paint.textSize = 11f
        canvas.drawText("✓ सामने का भाग (Front Side Verified)", 55f, 395f, paint)

        // Back Card Box
        paint.color = COLOR_PURPLE_BG
        canvas.drawRoundRect(RectF(35f, 450f, (pageWidth - 35).toFloat(), 770f), 16f, 16f, paint)

        paint.color = COLOR_PURPLE_BORDER
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawRoundRect(RectF(35f, 450f, (pageWidth - 35).toFloat(), 770f), 16f, 16f, paint)
        paint.style = Paint.Style.FILL

        // Back Card Header
        paint.color = COLOR_PURPLE_DARK
        canvas.drawRect(RectF(35f, 450f, (pageWidth - 35).toFloat(), 495f), paint)
        paint.color = COLOR_WHITE
        paint.textSize = 14f
        paint.isFakeBoldText = true
        canvas.drawText("विशिष्ट पहचान प्राधिकरण (UIDAI) • पता / ADDRESS", 50f, 478f, paint)

        paint.color = COLOR_TEXT_DARK
        paint.textSize = 12f
        paint.isFakeBoldText = false
        val addrLines = listOf(
            "पता (Address):",
            "मकान नं. 42-B, विकास नगर, निकट शांति मंदिर,",
            "जयपुर, राजस्थान - 302015",
            "हेल्पलाइन: 1947 | ई-मेल: help@uidai.gov.in"
        )
        var by = 530f
        addrLines.forEach { line ->
            canvas.drawText(line, 55f, by, paint)
            by += 24f
        }

        paint.color = COLOR_GREEN
        paint.textSize = 11f
        paint.isFakeBoldText = true
        canvas.drawText("✓ पीछे का भाग (Back Side Verified)", 55f, 745f, paint)

        // Footer
        paint.color = COLOR_TEXT_MUTED
        paint.textSize = 9f
        paint.isFakeBoldText = false
        canvas.drawText("DocuScan AI Secure Identity Vault", 35f, (pageHeight - 20).toFloat(), paint)

        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    private fun createGstInvoicePdf(context: Context, pdfDir: File): File {
        val file = File(pdfDir, "Sample_GST_Invoice_${System.currentTimeMillis()}.pdf")
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842

        val pInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = doc.startPage(pInfo)
        val canvas = page.canvas
        val paint = Paint().apply { isAntiAlias = true }

        canvas.drawColor(COLOR_WHITE)

        // Header
        paint.color = COLOR_TEAL_DARK
        canvas.drawRect(Rect(0, 0, pageWidth, 90), paint)
        paint.color = COLOR_WHITE
        paint.textSize = 18f
        paint.isFakeBoldText = true
        canvas.drawText("टैक्स इनवॉइस / TAX INVOICE", 35f, 45f, paint)

        paint.textSize = 11f
        paint.color = COLOR_TEAL_LIGHT
        paint.isFakeBoldText = false
        canvas.drawText("हिन्दुस्थान ट्रेडर्स एंड सप्लायर्स • GSTIN: 07AAAAA0000A1Z5", 35f, 70f, paint)

        // Invoice Meta
        var y = 120f
        paint.color = COLOR_TEXT_DARK
        paint.textSize = 11f
        paint.isFakeBoldText = true
        canvas.drawText("बिल क्रमांक: INV-2024-9821", 35f, y, paint)
        canvas.drawText("दिनांक: 10 अगस्त 2024", 380f, y, paint)
        y += 20f
        paint.isFakeBoldText = false
        canvas.drawText("ग्राहक: मेसर्स डिजिटल इंडिया प्राइवेट लिमिटेड", 35f, y, paint)
        canvas.drawText("स्थान: दिल्ली NCR", 380f, y, paint)
        y += 35f

        // Table Header
        paint.color = COLOR_TEAL_BG
        canvas.drawRect(RectF(35f, y, (pageWidth - 35).toFloat(), y + 25f), paint)

        paint.color = COLOR_TEAL_DARK
        paint.textSize = 10.5f
        paint.isFakeBoldText = true
        canvas.drawText("क्र.", 45f, y + 17f, paint)
        canvas.drawText("सामग्री विवरण (Description)", 75f, y + 17f, paint)
        canvas.drawText("HSN कोड", 280f, y + 17f, paint)
        canvas.drawText("मात्रा", 360f, y + 17f, paint)
        canvas.drawText("दर (₹)", 420f, y + 17f, paint)
        canvas.drawText("कुल (₹)", 490f, y + 17f, paint)

        val items = listOf(
            Tuple4("1.", "डॉक्युमेंट स्कैनर हार्डवेयर Pro", "8471", "1", "18,500.00"),
            Tuple4("2.", "लेजर प्रिंटर कार्ट्रिज पैक", "8443", "2", "3,000.00"),
            Tuple4("3.", "A4 फोटोकॉपियर पेपर रिम (500)", "4802", "5", "300.00")
        )

        paint.isFakeBoldText = false
        items.forEachIndexed { idx, itm ->
            y += 25f
            paint.color = if (idx % 2 == 0) COLOR_BG_GRAY else COLOR_WHITE
            canvas.drawRect(RectF(35f, y, (pageWidth - 35).toFloat(), y + 25f), paint)

            paint.color = COLOR_TEXT_DARK
            paint.textSize = 10f
            canvas.drawText(itm.a, 45f, y + 17f, paint)
            canvas.drawText(itm.b, 75f, y + 17f, paint)
            canvas.drawText(itm.c, 280f, y + 17f, paint)
            canvas.drawText(itm.d, 360f, y + 17f, paint)
            canvas.drawText(itm.e, 420f, y + 17f, paint)

            val totalLine = when(idx) {
                0 -> "18,500.00"
                1 -> "6,000.00"
                else -> "1,500.00"
            }
            canvas.drawText(totalLine, 490f, y + 17f, paint)
        }

        y += 40f
        // Calculations box
        paint.color = COLOR_BG_GRAY
        canvas.drawRoundRect(RectF(300f, y, (pageWidth - 35).toFloat(), y + 110f), 8f, 8f, paint)

        paint.color = COLOR_TEXT_DARK
        paint.textSize = 10.5f
        canvas.drawText("उप-योग (Subtotal):", 315f, y + 25f, paint)
        canvas.drawText("₹26,000.00", 470f, y + 25f, paint)

        canvas.drawText("CGST (9%):", 315f, y + 48f, paint)
        canvas.drawText("₹2,340.00", 470f, y + 48f, paint)

        canvas.drawText("SGST (9%):", 315f, y + 71f, paint)
        canvas.drawText("₹2,340.00", 470f, y + 71f, paint)

        paint.color = COLOR_TEAL_DARK
        paint.textSize = 12f
        paint.isFakeBoldText = true
        canvas.drawText("कुल देय राशि (Total):", 315f, y + 98f, paint)
        canvas.drawText("₹30,680.00", 470f, y + 98f, paint)

        // Paid stamp
        paint.color = COLOR_GREEN
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawRoundRect(RectF(60f, y + 20f, 220f, y + 80f), 12f, 12f, paint)
        paint.style = Paint.Style.FILL
        paint.textSize = 20f
        paint.isFakeBoldText = true
        canvas.drawText("PAID / चुकता", 75f, y + 58f, paint)

        // Footer
        paint.color = COLOR_TEXT_MUTED
        paint.textSize = 9f
        paint.isFakeBoldText = false
        canvas.drawText("यह एक कंप्यूटर जनित वैध टैक्स बिल है। धन्यवाद!", 35f, (pageHeight - 25).toFloat(), paint)

        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun createHistoryNotesPdf(context: Context, pdfDir: File): File {
        val file = File(pdfDir, "Madhya_Pura_Pashan_Kala_Sanskriti.pdf")
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842

        // Page 1
        val p1Info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val p1 = doc.startPage(p1Info)
        val canvas1 = p1.canvas
        canvas1.drawColor(COLOR_WHITE)

        val greenPaint = Paint().apply {
            color = 0xFF008938.toInt()
            textSize = 17f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = 0xFF1C1C1C.toInt()
            textSize = 10.5f
            isAntiAlias = true
        }

        val arrowPaint = Paint().apply {
            color = 0xFF008938.toInt()
            textSize = 12f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val linePaint = Paint().apply {
            color = 0xFF008938.toInt()
            strokeWidth = 1.5f
        }

        var y = 50f

        // Section 1 Header
        canvas1.drawText("मध्य पुरा पाषाण कला संस्कृति", 40f, y, greenPaint)
        y += 8f
        canvas1.drawLine(40f, y, (pageWidth - 40).toFloat(), y, linePaint)
        y += 24f

        val b1Lines = listOf(
            "मध्य पुरा पाषाण कला संस्कृति काल में पत्थर के उपकरण में परिवर्तन देखा गया लेवालोइस जिसे फलक संस्कृति",
            "के नाम से भी जानते हैं पाषाण काल में इस संस्कृति के अवशेष मिले हैं पत्थर के औजारों का निर्माण और तकनीकी",
            "पर बल दिया गया।"
        )
        canvas1.drawText(">", 40f, y, arrowPaint)
        b1Lines.forEach { line ->
            canvas1.drawText(line, 55f, y, textPaint)
            y += 16f
        }
        y += 10f

        val b2Lines = listOf(
            "मध्य पुरा पाषाण कला संस्कृति को A. घोष ने फलक संस्कृति के नाम से पुकारा के .डी. बनर्जी ने इसे",
            "नेवशा संस्कृति के नाम से पुकारा एच. डी. संकलिया ने Sesies सेकंड के नाम से पुकारा।"
        )
        canvas1.drawText(">", 40f, y, arrowPaint)
        b2Lines.forEach { line ->
            canvas1.drawText(line, 55f, y, textPaint)
            y += 16f
        }
        y += 10f

        val b3Lines = listOf(
            "पत्थर फिलिप खुरचनी छेदनी के औजार बनाया गया मध्यप्रदेश में नर्मदा घाटी के हथनोरा नामक स्थान से",
            "मानव का कंकाल मिला है।"
        )
        canvas1.drawText(">", 40f, y, arrowPaint)
        b3Lines.forEach { line ->
            canvas1.drawText(line, 55f, y, textPaint)
            y += 16f
        }
        y += 10f

        val b4Lines = listOf(
            "इस कल के निम्नलिखित केंद्र हैं उत्तर पश्चिम में सोहन नदी घाटी उत्तर भारत में उत्तर प्रदेश में चकिया नामक",
            "स्थान पर ,मध्य प्रदेश में नर्मदा घाटी के पास रायसेन और भीमबेटका गुफा, राजस्थान में बागोर नामक स्थान,",
            "महाराष्ट्र में नेवासा नामक स्थान, गुजरात में सौराष्ट्र और हिमाचल प्रदेश में व्यास गंगा घाटी, सिरसा गंगा घाटी में",
            "पाषाण काल के केंद्र हमें प्राप्त होता है।"
        )
        canvas1.drawText(">", 40f, y, arrowPaint)
        b4Lines.forEach { line ->
            canvas1.drawText(line, 55f, y, textPaint)
            y += 16f
        }
        y += 26f

        // Section 2 Header
        canvas1.drawText("उच्च पुरापाषाण काल संस्कृति", 40f, y, greenPaint)
        y += 8f
        canvas1.drawLine(40f, y, (pageWidth - 40).toFloat(), y, linePaint)
        y += 24f

        val b5Lines = listOf(
            "इस काल में छोटे-छोटे और बारीक उपकरण बनाए गए हैं इस ब्लेड संस्कृति के नाम से भी पुकारा जाता है उच्च",
            "पूरा पाषाण काल को मेगदलेइन संस्कृति भी कहा जाता है इसमें उपकरणों पर विशेष ध्यान दिया गया ब्लेड",
            "उपकरण का अधिकतम उपयोग किया गया नए-नए चमक उद्योगों में इनका प्रयोग किया जाता था होमोसेपियन",
            "मानव का प्रदर्शन इसी काल में हुआ 35000 B.C. से 10000 B.C. का यह काल कहलाता है।"
        )
        canvas1.drawText(">", 40f, y, arrowPaint)
        b5Lines.forEach { line ->
            canvas1.drawText(line, 55f, y, textPaint)
            y += 16f
        }
        y += 10f

        val b6Lines = listOf(
            "इलाहाबाद के लोहदनाला नामक स्थान पर हाथ से बनी हुई मातृ देवी की मूर्ति मिली है कहते हैं कि यह",
            "हड्डी से निर्मित है कुछ विद्वान मूर्ति नहीं मानते इसे भाला का रूप कहते हैं यह एक प्रकार का भाला है।"
        )
        canvas1.drawText(">", 40f, y, arrowPaint)
        b6Lines.forEach { line ->
            canvas1.drawText(line, 55f, y, textPaint)
            y += 16f
        }

        doc.finishPage(p1)

        // Page 2
        val p2Info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 2).create()
        val p2 = doc.startPage(p2Info)
        val canvas2 = p2.canvas
        canvas2.drawColor(COLOR_WHITE)

        var y2 = 50f

        canvas2.drawText("उच्च पुरापाषाण काल संस्कृति (भाग 2)", 40f, y2, greenPaint)
        y2 += 8f
        canvas2.drawLine(40f, y2, (pageWidth - 40).toFloat(), y2, linePaint)
        y2 += 24f

        val p2Lines = listOf(
            "आंध्र प्रदेश में करनाल नामक गुफा से मुछतला के अवशेष प्राप्त हुए हैं बड़ी मात्रा में हड्डी के उपकरण मिले।",
            "महाराष्ट्र के पतणे नामक स्थान से शुतुरमुर्ग के अंडे के ऊपर चित्रकला का प्रारंभ माना जाता है।",
            "आंध्र प्रदेश के विलासुरम नामक स्थान की खोज रॉबर्ट ने की थी या प्राचीनतम चूल्हा प्राप्त हुआ है।",
            "आंध्र प्रदेश के पेसारा नामक स्थान पर प्राचीनतम चूल्हा मिला।",
            "मध्य पाषाण काल में बिहार से चूल्हे के अवशेष प्राप्त हुए हैं।",
            "उच्च पुरापाषाण काल में मध्य प्रदेश के बाघोर नामक स्थान से पद चिन्ह प्राप्त हुए हैं यह पदचिह्न हिरण के थे।",
            "कहते हैं कि यहां से एक चबूतरा भी मिला है जिस पर वेदिका जो पूजा स्थल हुआ है।"
        )

        p2Lines.forEach { item ->
            canvas2.drawText(">", 40f, y2, arrowPaint)
            canvas2.drawText(item, 55f, y2, textPaint)
            y2 += 24f
        }

        doc.finishPage(p2)

        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun savePlaceholderPages(imgDir: File, docId: Long, count: Int) {
        for (idx in 0 until count) {
            val file = File(imgDir, "doc_${docId}_page_${idx}.jpg")
            val bmp = Bitmap.createBitmap(400, 600, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.drawColor(COLOR_WHITE)
            val p = Paint().apply {
                color = COLOR_TEXT_MUTED
                textSize = 24f
                isAntiAlias = true
            }
            c.drawText("Page ${idx + 1}", 140f, 300f, p)
            FileOutputStream(file).use { out ->
                bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
            bmp.recycle()
        }
    }

    private data class Tuple4<A, B, C, D, E>(val a: A, val b: B, val c: C, val d: D, val e: E)
}
