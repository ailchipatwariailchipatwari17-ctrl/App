package com.example.util

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class LearnedMemoryItem(
    val id: String = UUID.randomUUID().toString(),
    val category: String, // e.g. "यूज़र प्रोफाइल", "सिखाया गया तथ्य", "भाषा व शैली", "नियम"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Manages persistent on-device self-learning and memory for the AI.
 * Automatically learns user names, preferences, facts taught in conversation,
 * corrections, and rules across sessions.
 */
object AiSelfLearningManager {

    private const val PREFS_NAME = "ai_self_learning_prefs"
    private const val KEY_MEMORIES_JSON = "learned_memories_json"
    private const val KEY_USER_NAME = "learned_user_name"
    private const val KEY_USER_LOCATION = "learned_user_location"
    private const val KEY_PREFERRED_STYLE = "learned_preferred_style"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Retrieves all memories learned by the AI.
     */
    fun getAllMemories(context: Context): List<LearnedMemoryItem> {
        val prefs = getPrefs(context)
        val jsonStr = prefs.getString(KEY_MEMORIES_JSON, "[]") ?: "[]"
        val list = mutableListOf<LearnedMemoryItem>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    LearnedMemoryItem(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        category = obj.optString("category", "सिखाया गया तथ्य"),
                        content = obj.optString("content", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun getMemoryCount(context: Context): Int {
        return getAllMemories(context).size
    }

    /**
     * Saves a new memory item.
     */
    fun addMemory(context: Context, category: String, content: String): LearnedMemoryItem {
        val trimmed = content.trim()
        val current = getAllMemories(context).toMutableList()
        // Avoid duplicate memories
        val existing = current.find { it.content.equals(trimmed, ignoreCase = true) }
        if (existing != null) {
            return existing
        }

        val newItem = LearnedMemoryItem(
            category = category,
            content = trimmed,
            timestamp = System.currentTimeMillis()
        )
        current.add(0, newItem)
        saveMemoriesList(context, current)
        return newItem
    }

    /**
     * Removes a specific memory item.
     */
    fun removeMemory(context: Context, id: String) {
        val current = getAllMemories(context).toMutableList()
        current.removeAll { it.id == id }
        saveMemoriesList(context, current)
    }

    /**
     * Clears all learned memories.
     */
    fun clearAllMemories(context: Context) {
        getPrefs(context).edit().clear().apply()
    }

    private fun saveMemoriesList(context: Context, list: List<LearnedMemoryItem>) {
        try {
            val arr = JSONArray()
            for (item in list.take(50)) { // keep up to 50 active learned memories
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("category", item.category)
                obj.put("content", item.content)
                obj.put("timestamp", item.timestamp)
                arr.put(obj)
            }
            getPrefs(context).edit().putString(KEY_MEMORIES_JSON, arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Analyzes incoming user prompt and automatically learns facts, names, rules, or preferences.
     * Returns a confirmation message if something explicit was learned, or null.
     */
    fun analyzeAndLearnFromPrompt(context: Context, prompt: String): String? {
        val trimmed = prompt.trim()
        val lower = trimmed.lowercase()

        // 1. Learn User Name
        val nameRegex = Regex("(?:मेरा नाम|my name is|call me|नाम है)\\s+([A-Za-z\\u0900-\\u097F]+)", RegexOption.IGNORE_CASE)
        val nameMatch = nameRegex.find(trimmed)
        if (nameMatch != null) {
            val name = nameMatch.groupValues[1].trim()
            if (name.length in 2..25 && !name.equals("क्या", ignoreCase = true) && !name.equals("बताओ", ignoreCase = true)) {
                getPrefs(context).edit().putString(KEY_USER_NAME, name).apply()
                addMemory(context, "यूज़र नाम", "उपयोगकर्ता का नाम: $name")
            }
        }

        // 2. Learn User Location
        val locationRegex = Regex("(?:मैं|रहता हूँ|रहती हूँ|आई लिव इन|from)\\s+([A-Za-z\\u0900-\\u097F]+)\\s*(?:में रहता|से हूँ|का निवासी|में)", RegexOption.IGNORE_CASE)
        val locMatch = locationRegex.find(trimmed)
        if (locMatch != null) {
            val loc = locMatch.groupValues[1].trim()
            if (loc.length in 2..25 && !loc.equals("घर", ignoreCase = true) && !loc.equals("कमरे", ignoreCase = true)) {
                getPrefs(context).edit().putString(KEY_USER_LOCATION, loc).apply()
                addMemory(context, "स्थान", "उपयोगकर्ता का स्थान: $loc")
            }
        }

        // 3. Explicit Teaching / Rules ("याद रखना कि...", "यह याद रखो...", "note karo...")
        val rememberRegex = Regex("(?:याद रखना|याद रखो|हमेशा याद रखना|नोट कर लो|remember that|keep in mind)\\s*(?:कि|that)?\\s*(.+)", RegexOption.IGNORE_CASE)
        val remMatch = rememberRegex.find(trimmed)
        if (remMatch != null) {
            val fact = remMatch.groupValues[1].trim()
            if (fact.length >= 4) {
                addMemory(context, "सिखाया गया नियम", fact)
                return "मैंने यह याद रख लिया है और आगे के लिए सीख लिया है: \"$fact\""
            }
        }

        // 4. Style & Language Preferences
        if (lower.contains("मारवाड़ी में") || lower.contains("राजस्थानी में")) {
            addMemory(context, "भाषा प्राथमिकता", "यूज़र मारवाड़ी / राजस्थानी भाषा में बातचीत पसंद करते हैं।")
        } else if (lower.contains("भोजपुरी में")) {
            addMemory(context, "भाषा प्राथमिकता", "यूज़र भोजपुरी भाषा पसंद करते हैं।")
        } else if (lower.contains("सरल हिंदी") || lower.contains("आसान भाषा")) {
            addMemory(context, "शैली प्राथमिकता", "सरल और स्पष्ट हिंदी में समझाएं।")
        } else if (lower.contains("संक्षेप में उत्तर") || lower.contains("शॉर्ट में बताओ")) {
            addMemory(context, "शैली प्राथमिकता", "टू-द-पॉइंट और संक्षेप में उत्तर दें।")
        } else if (lower.contains("विस्तार से बताओ") || lower.contains("डिटेल में समझाओ")) {
            addMemory(context, "शैली प्राथमिकता", "विस्तृत और गहराई से समझाएं।")
        }

        // 5. Corrections by user ("नहीं ऐसा नहीं है...", "गलत है, सही यह है...", "actually ...")
        val correctionRegex = Regex("(?:नहीं ऐसा नहीं|गलत है|सही यह है|सुधार करो|actually)\\s*[,:]?\\s*(.+)", RegexOption.IGNORE_CASE)
        val corrMatch = correctionRegex.find(trimmed)
        if (corrMatch != null) {
            val corr = corrMatch.groupValues[1].trim()
            if (corr.length >= 6) {
                addMemory(context, "सुधार व सही तथ्य", corr)
            }
        }

        return null
    }

    /**
     * Builds a concise, context-rich learned memory summary to empower Gemini's reasoning
     * without constricting its freedom.
     */
    fun buildLearnedMemoryContext(context: Context?): String {
        if (context == null) return ""
        val memories = getAllMemories(context)
        val userName = getPrefs(context).getString(KEY_USER_NAME, null)
        val userLoc = getPrefs(context).getString(KEY_USER_LOCATION, null)

        if (memories.isEmpty() && userName.isNullOrBlank() && userLoc.isNullOrBlank()) {
            return ""
        }

        val sb = StringBuilder()
        sb.append("\n[AI CONTINUOUS SELF-LEARNED MEMORY & USER CONTEXT]:\n")
        if (!userName.isNullOrBlank()) {
            sb.append("• User Name: $userName\n")
        }
        if (!userLoc.isNullOrBlank()) {
            sb.append("• User Location: $userLoc\n")
        }
        for (item in memories.take(12)) {
            sb.append("• [${item.category}]: ${item.content}\n")
        }
        sb.append("(Utilize this learned context naturally to personalize answers without repeating this block verbatim)\n")
        return sb.toString()
    }
}
