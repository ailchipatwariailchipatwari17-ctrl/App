package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.LocaleList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val flagEmoji: String
)

class LanguageManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_language_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SELECTED_LANGUAGE = "selected_language_code"
        private const val KEY_INITIAL_LANGUAGE_CHOSEN = "has_chosen_initial_language"

        private val _currentLanguageFlow = MutableStateFlow("hi")
        val currentLanguageFlow: StateFlow<String> = _currentLanguageFlow.asStateFlow()

        val SUPPORTED_LANGUAGES = listOf(
            AppLanguage("hi", "Hindi", "हिंदी", "🇮🇳"),
            AppLanguage("en", "English", "English", "🇺🇸"),
            AppLanguage("bn", "Bengali", "বাংলা", "🇧🇩"),
            AppLanguage("es", "Spanish", "Español", "🇪🇸"),
            AppLanguage("fr", "French", "Français", "🇫🇷"),
            AppLanguage("de", "German", "Deutsch", "🇩🇪"),
            AppLanguage("ar", "Arabic", "العربية", "🇸🇦"),
            AppLanguage("zh", "Chinese", "中文", "🇨🇳"),
            AppLanguage("ja", "Japanese", "日本語", "🇯🇵"),
            AppLanguage("ru", "Russian", "Русский", "🇷🇺"),
            AppLanguage("pt", "Portuguese", "Português", "🇵🇹"),
            AppLanguage("id", "Indonesian", "Bahasa Indonesia", "🇮🇩")
        )

        private val TRANSLATIONS: Map<String, Map<String, String>> = mapOf(
            "create_pdf_space" to mapOf(
                "hi" to "PDF स्पेस बनाएं",
                "en" to "Create a PDF Space",
                "bn" to "একটি পিডিএফ স্পেস তৈরি করুন",
                "es" to "Crear un espacio PDF",
                "fr" to "Créer un espace PDF",
                "de" to "PDF-Bereich erstellen",
                "ar" to "إنشاء مساحة PDF",
                "zh" to "创建PDF空间",
                "ja" to "PDFスペースを作成",
                "ru" to "Создать область PDF",
                "pt" to "Criar um espaço PDF",
                "id" to "Buat Ruang PDF"
            ),
            "open_file" to mapOf(
                "hi" to "फ़ाइल खोलें",
                "en" to "Open file",
                "bn" to "ফাইল খুলুন",
                "es" to "Abrir archivo",
                "fr" to "Ouvrir un fichier",
                "de" to "Datei öffnen",
                "ar" to "فتح ملف",
                "zh" to "打开文件",
                "ja" to "ファイルを開く",
                "ru" to "Открыть файл",
                "pt" to "Abrir arquivo",
                "id" to "Buka file"
            ),
            "get_adobe_scan" to mapOf(
                "hi" to "कैमरा स्कैन",
                "en" to "Get Adobe Scan",
                "bn" to "ক্যামেরা স্ক্যান",
                "es" to "Escanear documento",
                "fr" to "Numériser document",
                "de" to "Dokument scannen",
                "ar" to "مسح المستند",
                "zh" to "相机扫描",
                "ja" to "スキャン",
                "ru" to "Сканировать",
                "pt" to "Digitalizar",
                "id" to "Pindai Dokumen"
            ),
            "ask_ai_assistant" to mapOf(
                "hi" to "AI सहायक से पूछें",
                "en" to "Ask AI Assistant",
                "bn" to "এআই সহকারীকে জিজ্ঞাসা করুন",
                "es" to "Preguntar al Asistente IA",
                "fr" to "Demander à l'Assistant IA",
                "de" to "KI-Assistent fragen",
                "ar" to "اسأل مساعد الذكاء",
                "zh" to "向AI助手提问",
                "ja" to "AIアシスタントに質問",
                "ru" to "Спросить AI Ассистента",
                "pt" to "Perguntar ao Assistente IA",
                "id" to "Tanya Asisten AI"
            ),
            "generate_podcast" to mapOf(
                "hi" to "पॉडकास्ट बनाएं",
                "en" to "Generate podcast",
                "bn" to "পডকাস্ট তৈরি করুন",
                "es" to "Generar pódcast",
                "fr" to "Générer un podcast",
                "de" to "Podcast erstellen",
                "ar" to "إنشاء بودكاست",
                "zh" to "生成播客",
                "ja" to "ポッドキャストを生成",
                "ru" to "Создать подкаст",
                "pt" to "Gerar podcast",
                "id" to "Buat podcast"
            ),
            "create_from_template" to mapOf(
                "hi" to "टेम्पलेट से बनाएं",
                "en" to "Create from template",
                "bn" to "টেমপ্লেট থেকে তৈরি করুন",
                "es" to "Crear desde plantilla",
                "fr" to "Créer à partir d'un modèle",
                "de" to "Aus Vorlage erstellen",
                "ar" to "إنشاء من قالب",
                "zh" to "从模板创建",
                "ja" to "テンプレートから作成",
                "ru" to "Создать из шаблона",
                "pt" to "Criar a partir de modelo",
                "id" to "Buat dari templat"
            ),
            "edit_pdf" to mapOf(
                "hi" to "PDF संपादित करें",
                "en" to "Edit PDF",
                "bn" to "পিডিএফ সম্পাদনা করুন",
                "es" to "Editar PDF",
                "fr" to "Modifier le PDF",
                "de" to "PDF bearbeiten",
                "ar" to "تعديل PDF",
                "zh" to "编辑PDF",
                "ja" to "PDFを編集",
                "ru" to "Редактировать PDF",
                "pt" to "Editar PDF",
                "id" to "Edit PDF"
            ),
            "read_aloud" to mapOf(
                "hi" to "बोलकर पढ़ें",
                "en" to "Read aloud",
                "bn" to "পড়ে শোনান",
                "es" to "Leer en voz alta",
                "fr" to "Lecture à voix haute",
                "de" to "Vorlesen",
                "ar" to "قراءة بصوت عالٍ",
                "zh" to "大声朗读",
                "ja" to "音読",
                "ru" to "Читать вслух",
                "pt" to "Ler em voz alta",
                "id" to "Baca dengan suara"
            ),
            "create_pdf" to mapOf(
                "hi" to "PDF बनाएं",
                "en" to "Create PDF",
                "bn" to "পিডিএফ তৈরি করুন",
                "es" to "Crear PDF",
                "fr" to "Créer un PDF",
                "de" to "PDF erstellen",
                "ar" to "إنشاء PDF",
                "zh" to "创建PDF",
                "ja" to "PDFを作成",
                "ru" to "Создать PDF",
                "pt" to "Criar PDF",
                "id" to "Buat PDF"
            ),
            "export_pdf" to mapOf(
                "hi" to "PDF निर्यात करें",
                "en" to "Export PDF",
                "bn" to "পিডিএফ এক্সপোর্ট করুন",
                "es" to "Exportar PDF",
                "fr" to "Exporter le PDF",
                "de" to "PDF exportieren",
                "ar" to "تصدير PDF",
                "zh" to "导出PDF",
                "ja" to "PDFを書き出し",
                "ru" to "Экспортировать PDF",
                "pt" to "Exportar PDF",
                "id" to "Ekspor PDF"
            ),
            "podcast" to mapOf(
                "hi" to "पॉडकास्ट",
                "en" to "Podcast",
                "bn" to "পডকাস্ট",
                "es" to "Pódcast",
                "fr" to "Podcast",
                "de" to "Podcast",
                "ar" to "بودكاست",
                "zh" to "播客",
                "ja" to "ポッドキャスト",
                "ru" to "Подкаст",
                "pt" to "Podcast",
                "id" to "Podcast"
            ),
            "combine_files" to mapOf(
                "hi" to "फ़ाइलें जोड़ें",
                "en" to "Combine files",
                "bn" to "ফাইল একত্রিত করুন",
                "es" to "Combinar archivos",
                "fr" to "Combiner des fichiers",
                "de" to "Dateien zusammenfügen",
                "ar" to "دمج الملفات",
                "zh" to "合并文件",
                "ja" to "ファイルを結合",
                "ru" to "Объединить файлы",
                "pt" to "Combinar arquivos",
                "id" to "Gabungkan file"
            ),
            "organize_pages" to mapOf(
                "hi" to "पेज व्यवस्थित करें",
                "en" to "Organize pages",
                "bn" to "পৃষ্ঠা সাজান",
                "es" to "Organizar páginas",
                "fr" to "Organiser les pages",
                "de" to "Seiten organisieren",
                "ar" to "تنظيم الصفحات",
                "zh" to "组织页面",
                "ja" to "ページを整理",
                "ru" to "Упорядочить страницы",
                "pt" to "Organizar páginas",
                "id" to "Atur halaman"
            ),
            "compress_pdf" to mapOf(
                "hi" to "PDF कंप्रेस करें",
                "en" to "Compress PDF",
                "bn" to "পিডিএফ সংকুচিত করুন",
                "es" to "Comprimir PDF",
                "fr" to "Compresser le PDF",
                "de" to "PDF komprimieren",
                "ar" to "ضغط PDF",
                "zh" to "压缩PDF",
                "ja" to "PDFを圧縮",
                "ru" to "Сжать PDF",
                "pt" to "Comprimir PDF",
                "id" to "Kompres PDF"
            ),
            "set_password" to mapOf(
                "hi" to "पासवर्ड सेट करें",
                "en" to "Set password",
                "bn" to "পাসওয়ার্ড সেট করুন",
                "es" to "Establecer contraseña",
                "fr" to "Définir le mot de passe",
                "de" to "Passwort festlegen",
                "ar" to "تعيين كلمة المرور",
                "zh" to "设置密码",
                "ja" to "パスワードを設定",
                "ru" to "Установить пароль",
                "pt" to "Definir senha",
                "id" to "Atur kata sandi"
            ),
            "id_card" to mapOf(
                "hi" to "आईडी कार्ड A4",
                "en" to "ID Card A4",
                "bn" to "আইডি কার্ড A4",
                "es" to "Tarjeta de identidad A4",
                "fr" to "Carte d'identité A4",
                "de" to "Ausweis A4",
                "ar" to "بطاقة الهوية A4",
                "zh" to "证件扫描A4",
                "ja" to "身分証A4",
                "ru" to "ID карта A4",
                "pt" to "Cartão de ID A4",
                "id" to "Kartu Identitas A4"
            ),
            "ocr_text" to mapOf(
                "hi" to "OCR टेक्स्ट स्कैनर",
                "en" to "OCR Text Scanner",
                "bn" to "ওসিআর টেক্সট স্ক্যানার",
                "es" to "Escáner de texto OCR",
                "fr" to "Scanner de texte OCR",
                "de" to "OCR-Textscanner",
                "ar" to "ماسح النص الضوئي",
                "zh" to "OCR文字扫描",
                "ja" to "OCRテキストスキャナー",
                "ru" to "OCR Сканер текста",
                "pt" to "Scanner de texto OCR",
                "id" to "Pemindai Teks OCR"
            ),
            "repair_pdf" to mapOf(
                "hi" to "PDF रिपेयर करें",
                "en" to "Repair PDF",
                "bn" to "পিডিএফ মেরামত করুন",
                "es" to "Reparar PDF",
                "fr" to "Réparer le PDF",
                "de" to "PDF reparieren",
                "ar" to "إصلاح PDF",
                "zh" to "修复PDF",
                "ja" to "PDFを修復",
                "ru" to "Восстановить PDF",
                "pt" to "Reparar PDF",
                "id" to "Perbaiki PDF"
            ),
            "badge_new" to mapOf(
                "hi" to "New",
                "en" to "New",
                "bn" to "New",
                "es" to "Nuevo",
                "fr" to "Nouveau",
                "de" to "Neu",
                "ar" to "جديد",
                "zh" to "新",
                "ja" to "新",
                "ru" to "Новое",
                "pt" to "Novo",
                "id" to "Baru"
            ),
            "home" to mapOf(
                "hi" to "होम",
                "en" to "Home",
                "bn" to "হোম",
                "es" to "Inicio",
                "fr" to "Accueil",
                "de" to "Startseite",
                "ar" to "الرئيسية",
                "zh" to "首页",
                "ja" to "ホーム",
                "ru" to "Главная",
                "pt" to "Início",
                "id" to "Beranda"
            ),
            "create" to mapOf(
                "hi" to "बनाएं",
                "en" to "Create",
                "bn" to "তৈরি করুন",
                "es" to "Crear",
                "fr" to "Créer",
                "de" to "Erstellen",
                "ar" to "إنشاء",
                "zh" to "创建",
                "ja" to "作成",
                "ru" to "Создать",
                "pt" to "Criar",
                "id" to "Buat"
            ),
            "pdf_spaces" to mapOf(
                "hi" to "PDF स्पेस",
                "en" to "PDF Spaces",
                "bn" to "পিডিএফ স্পেস",
                "es" to "Espacios PDF",
                "fr" to "Espaces PDF",
                "de" to "PDF-Bereiche",
                "ar" to "مساحات PDF",
                "zh" to "PDF空间",
                "ja" to "PDFスペース",
                "ru" to "Области PDF",
                "pt" to "Espaços PDF",
                "id" to "Ruang PDF"
            ),
            "files" to mapOf(
                "hi" to "फ़ाइलें",
                "en" to "Files",
                "bn" to "ফাইল",
                "es" to "Archivos",
                "fr" to "Fichiers",
                "de" to "Dateien",
                "ar" to "الملفات",
                "zh" to "文件",
                "ja" to "ファイル",
                "ru" to "Файлы",
                "pt" to "Arquivos",
                "id" to "File"
            ),
            "tools" to mapOf(
                "hi" to "टूल्स",
                "en" to "Tools",
                "bn" to "টুলস",
                "es" to "Herramientas",
                "fr" to "Outils",
                "de" to "Werkzeuge",
                "ar" to "الأدوات",
                "zh" to "工具",
                "ja" to "ツール",
                "ru" to "Инструменты",
                "pt" to "Ferramentas",
                "id" to "Alat"
            ),
            "recent" to mapOf(
                "hi" to "हालिया",
                "en" to "Recent",
                "bn" to "সাম্প্রতিক",
                "es" to "Reciente",
                "fr" to "Récent",
                "de" to "Zuletzt",
                "ar" to "الأخيرة",
                "zh" to "最近",
                "ja" to "最近",
                "ru" to "Недавние",
                "pt" to "Recentes",
                "id" to "Terbaru"
            ),
            "starred" to mapOf(
                "hi" to "पसंदीदा",
                "en" to "Starred",
                "bn" to "পছন্দসই",
                "es" to "Destacados",
                "fr" to "Favoris",
                "de" to "Markiert",
                "ar" to "المميزة",
                "zh" to "已加星标",
                "ja" to "スター付き",
                "ru" to "Избранное",
                "pt" to "Favoritos",
                "id" to "Berbintang"
            ),
            "on_device" to mapOf(
                "hi" to "डिवाइस पर",
                "en" to "On device",
                "bn" to "ডিভাইসে",
                "es" to "En dispositivo",
                "fr" to "Sur l'appareil",
                "de" to "Auf dem Gerät",
                "ar" to "على الجهاز",
                "zh" to "在设备上",
                "ja" to "端末内",
                "ru" to "На устройстве",
                "pt" to "No dispositivo",
                "id" to "Di perangkat"
            ),
            "camera_scan" to mapOf(
                "hi" to "कैमरा स्कैन",
                "en" to "Camera Scan",
                "bn" to "ক্যামেরা স্ক্যান",
                "es" to "Escanear",
                "fr" to "Scanner",
                "de" to "Scannen",
                "ar" to "مسح الكاميرا",
                "zh" to "相机扫描",
                "ja" to "カメラでスキャン",
                "ru" to "Камера скан",
                "pt" to "Escanear câmera",
                "id" to "Pindai Kamera"
            ),
            "gallery_pick" to mapOf(
                "hi" to "गैलरी से चुनें",
                "en" to "Pick from Gallery",
                "bn" to "গ্যালারি",
                "es" to "Galería",
                "fr" to "Galerie",
                "de" to "Galerie",
                "ar" to "المعرض",
                "zh" to "从相册选取",
                "ja" to "ギャラリーから選択",
                "ru" to "Из галереи",
                "pt" to "Da galeria",
                "id" to "Dari Galeri"
            ),
            "crop_edges" to mapOf(
                "hi" to "एज क्रॉप",
                "en" to "Crop Edges",
                "bn" to "ক্রপ করুন",
                "es" to "Recortar",
                "fr" to "Rogner",
                "de" to "Zuschneiden",
                "ar" to "قص الحواف",
                "zh" to "边缘裁剪",
                "ja" to "エッジ切り抜き",
                "ru" to "Обрезать края",
                "pt" to "Recortar bordas",
                "id" to "Pangkas Tepi"
            ),
            "rotate" to mapOf(
                "hi" to "घुमाएँ",
                "en" to "Rotate",
                "bn" to "ঘোরান",
                "es" to "Rotar",
                "fr" to "Pivoter",
                "de" to "Drehen",
                "ar" to "تدوير",
                "zh" to "旋转",
                "ja" to "回転",
                "ru" to "Повернуть",
                "pt" to "Girar",
                "id" to "Putar"
            ),
            "filters" to mapOf(
                "hi" to "फ़िल्टर",
                "en" to "Filters",
                "bn" to "ফিল্টার",
                "es" to "Filtros",
                "fr" to "Filtres",
                "de" to "Filter",
                "ar" to "مرشحات",
                "zh" to "滤镜",
                "ja" to "フィルター",
                "ru" to "Фильтры",
                "pt" to "Filtros",
                "id" to "Filter"
            ),
            "share_pdf" to mapOf(
                "hi" to "PDF बनाएं और साझा करें",
                "en" to "Create & Share PDF",
                "bn" to "পিডিএফ তৈরি ও শেয়ার করুন",
                "es" to "Crear y compartir PDF",
                "fr" to "Créer et partager le PDF",
                "de" to "PDF erstellen & teilen",
                "ar" to "إنشاء ومشاركة PDF",
                "zh" to "创建并分享PDF",
                "ja" to "PDF作成・共有",
                "ru" to "Создать и поделиться PDF",
                "pt" to "Criar e compartilhar PDF",
                "id" to "Buat & Bagikan PDF"
            ),
            "select_language_title" to mapOf(
                "hi" to "अपनी भाषा चुनें",
                "en" to "Select Your Language",
                "bn" to "আপনার ভাষা নির্বাচন করুন",
                "es" to "Selecciona tu idioma",
                "fr" to "Choisissez votre langue",
                "de" to "Wählen Sie Ihre Sprache",
                "ar" to "اختر لغتك",
                "zh" to "选择您的语言",
                "ja" to "言語を選択",
                "ru" to "Выберите язык",
                "pt" to "Selecione seu idioma",
                "id" to "Pilih Bahasa Anda"
            ),
            "select_language_subtitle" to mapOf(
                "hi" to "संपूर्ण ऐप में यही भाषा दिखाई देगी",
                "en" to "The entire app will be displayed in this language",
                "bn" to "সম্পূর্ণ অ্যাপ এই ভাষায় প্রদর্শিত হবে",
                "es" to "Toda la aplicación se mostrará en este idioma",
                "fr" to "Toute l'application sera affichée dans cette langue",
                "de" to "Die gesamte App wird in dieser Sprache angezeigt",
                "ar" to "سيتم عرض التطبيق بأكمله بهذه اللغة",
                "zh" to "整个应用将以此语言显示",
                "ja" to "アプリ全体がこの言語で表示されます",
                "ru" to "Весь интерфейс приложения будет на этом языке",
                "pt" to "Todo o aplicativo será exibido neste idioma",
                "id" to "Seluruh aplikasi akan ditampilkan dalam bahasa ini"
            ),
            "confirm_continue" to mapOf(
                "hi" to "आगे बढ़ें",
                "en" to "Continue",
                "bn" to "এগিয়ে যান",
                "es" to "Continuar",
                "fr" to "Continuer",
                "de" to "Fortfahren",
                "ar" to "متابعة",
                "zh" to "继续",
                "ja" to "続行",
                "ru" to "Продолжить",
                "pt" to "Continuar",
                "id" to "Lanjutkan"
            ),
            "more_tools" to mapOf(
                "hi" to "अन्य सुविधाएं",
                "en" to "More Tools",
                "bn" to "আরও টুলস",
                "es" to "Más herramientas",
                "fr" to "Plus d'outils",
                "de" to "Weitere Werkzeuge",
                "ar" to "المزيد من الأدوات",
                "zh" to "更多工具",
                "ja" to "その他のツール",
                "ru" to "Другие инструменты",
                "pt" to "Mais ferramentas",
                "id" to "Alat Lainnya"
            ),
            "front_side" to mapOf(
                "hi" to "सामने का भाग",
                "en" to "Front",
                "bn" to "সামনের অংশ",
                "es" to "Frente",
                "fr" to "Recto",
                "de" to "Vorderseite",
                "ar" to "الجهة الأمامية",
                "zh" to "正面",
                "ja" to "表面",
                "ru" to "Лицевая сторона",
                "pt" to "Frente",
                "id" to "Bagian Depan"
            ),
            "back_side" to mapOf(
                "hi" to "पीछे का भाग",
                "en" to "Back",
                "bn" to "পিছনের অংশ",
                "es" to "Dorso",
                "fr" to "Verso",
                "de" to "Rückseite",
                "ar" to "الجهة الخلفية",
                "zh" to "背面",
                "ja" to "裏面",
                "ru" to "Оборотная сторона",
                "pt" to "Verso",
                "id" to "Bagian Belakang"
            ),
            "camera" to mapOf(
                "hi" to "कैमरा",
                "en" to "Camera",
                "bn" to "ক্যামেরা",
                "es" to "Cámara",
                "fr" to "Appareil photo",
                "de" to "Kamera",
                "ar" to "كاميرا",
                "zh" to "相机",
                "ja" to "カメラ",
                "ru" to "Камера",
                "pt" to "Câmera",
                "id" to "Kamera"
            ),
            "gallery" to mapOf(
                "hi" to "गैलरी",
                "en" to "Gallery",
                "bn" to "গ্যালারি",
                "es" to "Galería",
                "fr" to "Galerie",
                "de" to "Galerie",
                "ar" to "المعرض",
                "zh" to "相册",
                "ja" to "ギャラリー",
                "ru" to "Галерея",
                "pt" to "Galeria",
                "id" to "Galeri"
            ),
            "rotate" to mapOf(
                "hi" to "घुमाएं",
                "en" to "Rotate",
                "bn" to "ঘোরান",
                "es" to "Girar",
                "fr" to "Pivoter",
                "de" to "Drehen",
                "ar" to "تدوير",
                "zh" to "旋转",
                "ja" to "回転",
                "ru" to "Повернуть",
                "pt" to "Girar",
                "id" to "Putar"
            ),
            "clear" to mapOf(
                "hi" to "हटाएं",
                "en" to "Clear",
                "bn" to "মুছুন",
                "es" to "Borrar",
                "fr" to "Effacer",
                "de" to "Löschen",
                "ar" to "مسح",
                "zh" to "清除",
                "ja" to "クリア",
                "ru" to "Очистить",
                "pt" to "Limpar",
                "id" to "Hapus"
            ),
            "save_a4_pdf" to mapOf(
                "hi" to "A4 PDF सेव करें",
                "en" to "Save A4 PDF",
                "bn" to "A4 পিডিএফ সেভ করুন",
                "es" to "Guardar PDF A4",
                "fr" to "Enregistrer PDF A4",
                "de" to "A4-PDF speichern",
                "ar" to "حفظ كـ PDF A4",
                "zh" to "保存为A4 PDF",
                "ja" to "A4 PDFを保存",
                "ru" to "Сохранить A4 PDF",
                "pt" to "Salvar PDF A4",
                "id" to "Simpan PDF A4"
            ),
            "id_title_hint" to mapOf(
                "hi" to "दस्तावेज़ नाम",
                "en" to "Document name",
                "bn" to "নথির নাম",
                "es" to "Nombre del documento",
                "fr" to "Nom du document",
                "de" to "Dokumentname",
                "ar" to "اسم المستند",
                "zh" to "文档名称",
                "ja" to "文書名",
                "ru" to "Имя документа",
                "pt" to "Nome do documento",
                "id" to "Nama dokumen"
            ),
            "merge_pdf" to mapOf(
                "hi" to "मर्ज PDF",
                "en" to "Merge PDF",
                "bn" to "মার্জ পিডিএফ",
                "es" to "Combinar PDF",
                "fr" to "Fusionner PDF",
                "de" to "PDF zusammenführen",
                "ar" to "دمج PDF",
                "zh" to "合并PDF",
                "ja" to "PDF結合",
                "ru" to "Объединить PDF",
                "pt" to "Mesclar PDF",
                "id" to "Gabungkan PDF"
            ),
            "split_pdf" to mapOf(
                "hi" to "स्प्लिट PDF",
                "en" to "Split PDF",
                "bn" to "বিভক্ত পিডিএফ",
                "es" to "Dividir PDF",
                "fr" to "Diviser PDF",
                "de" to "PDF teilen",
                "ar" to "تقسيم PDF",
                "zh" to "拆分PDF",
                "ja" to "PDF分割",
                "ru" to "Разделить PDF",
                "pt" to "Dividir PDF",
                "id" to "Pisahkan PDF"
            ),
            "qr_scanner" to mapOf(
                "hi" to "QR स्कैनर",
                "en" to "QR Scanner",
                "bn" to "কিউআর স্ক্যানার",
                "es" to "Escáner QR",
                "fr" to "Scanner QR",
                "de" to "QR-Scanner",
                "ar" to "ماسح QR",
                "zh" to "QR扫描",
                "ja" to "QRスキャナー",
                "ru" to "QR Сканер",
                "pt" to "Scanner QR",
                "id" to "Pemindai QR"
            ),
            "compare_pdf" to mapOf(
                "hi" to "PDF तुलना",
                "en" to "Compare PDF",
                "bn" to "পিডিএফ তুলনা",
                "es" to "Comparar PDF",
                "fr" to "Comparer PDF",
                "de" to "PDF vergleichen",
                "ar" to "مقارنة PDF",
                "zh" to "比较PDF",
                "ja" to "PDF比較",
                "ru" to "Сравнить PDF",
                "pt" to "Comparar PDF",
                "id" to "Bandingkan PDF"
            ),
            "clean_notes" to mapOf(
                "hi" to "हस्तलेखन डिजिटाइज",
                "en" to "Digitize Notes",
                "bn" to "নোট ডিজিটাইজ",
                "es" to "Digitalizar notas",
                "fr" to "Numériser notes",
                "de" to "Notizen digitalisieren",
                "ar" to "رقمنة الملاحظات",
                "zh" to "手写数字化",
                "ja" to "手書きデジタル化",
                "ru" to "Оцифровать заметки",
                "pt" to "Digitalizar notas",
                "id" to "Digitalisasi Catatan"
            ),
            "omr_scanner" to mapOf(
                "hi" to "OMR शीट स्कैनर",
                "en" to "OMR Scanner",
                "bn" to "ওএমআর স্ক্যানার",
                "es" to "Escáner OMR",
                "fr" to "Scanner OMR",
                "de" to "OMR-Scanner",
                "ar" to "ماسح OMR",
                "zh" to "OMR扫描",
                "ja" to "OMRスキャナー",
                "ru" to "OMR Сканер",
                "pt" to "Scanner OMR",
                "id" to "Pemindai OMR"
            ),
            "formula_extractor" to mapOf(
                "hi" to "फॉर्मूला एक्सट्रैक्टर",
                "en" to "Formula Extractor",
                "bn" to "সূত্র এক্সট্র্যাক্টর",
                "es" to "Extractor de fórmulas",
                "fr" to "Extracteur de formules",
                "de" to "Formel-Extraktor",
                "ar" to "مستخرج الصيغ",
                "zh" to "公式提取器",
                "ja" to "数式抽出",
                "ru" to "Извлечение формул",
                "pt" to "Extrator de fórmulas",
                "id" to "Pengekstrak Rumus"
            ),
            "podcast_mode" to mapOf(
                "hi" to "AI ऑडियो पॉडकास्ट",
                "en" to "AI Podcast",
                "bn" to "এআই পডকাস্ট",
                "es" to "Podcast IA",
                "fr" to "Podcast IA",
                "de" to "KI-Podcast",
                "ar" to "بودكاست ذكي",
                "zh" to "AI播客",
                "ja" to "AIポッドキャスト",
                "ru" to "AI Подкаст",
                "pt" to "Podcast de IA",
                "id" to "Podcast AI"
            ),
            "quiz_flashcards" to mapOf(
                "hi" to "क्विज़ व फ़्लैशकार्ड",
                "en" to "Quiz & Flashcards",
                "bn" to "কুইজ ও ফ্ল্যাশকার্ড",
                "es" to "Cuestionario y tarjetas",
                "fr" to "Quiz et flashcards",
                "de" to "Quiz & Karteikarten",
                "ar" to "اختبار وبطاقات",
                "zh" to "测验与抽认卡",
                "ja" to "クイズ＆単語カード",
                "ru" to "Викторина и карточки",
                "pt" to "Quiz e flashcards",
                "id" to "Kuis & Flashcard"
            ),
            "watermark_stamp" to mapOf(
                "hi" to "वाटरमार्क व स्टैम्प",
                "en" to "Watermark & Stamp",
                "bn" to "জলছাপ ও স্ট্যাম্প",
                "es" to "Marca de agua y sello",
                "fr" to "Filigrane et tampon",
                "de" to "Wasserzeichen & Stempel",
                "ar" to "علامة مائية وختم",
                "zh" to "水印与印章",
                "ja" to "透かし＆スタンプ",
                "ru" to "Водяной знак и штамп",
                "pt" to "Marca d'água e carimbo",
                "id" to "Watermark & Cap"
            ),
            "audio_notes" to mapOf(
                "hi" to "वॉइस नोट",
                "en" to "Voice Note",
                "bn" to "ভয়েস নোট",
                "es" to "Nota de voz",
                "fr" to "Note vocale",
                "de" to "Sprachnotiz",
                "ar" to "ملاحظة صوتية",
                "zh" to "语音笔记",
                "ja" to "音声メモ",
                "ru" to "Голосовая заметка",
                "pt" to "Nota de voz",
                "id" to "Catatan Suara"
            ),
            "signature_pad" to mapOf(
                "hi" to "डिजिटल सिग्नेचर",
                "en" to "Digital Signature",
                "bn" to "ডিজিটাল স্বাক্ষর",
                "es" to "Firma digital",
                "fr" to "Signature numérique",
                "de" to "Digitale Signatur",
                "ar" to "توقيع رقمي",
                "zh" to "电子签名",
                "ja" to "電子署名",
                "ru" to "Цифровая подпись",
                "pt" to "Assinatura digital",
                "id" to "Tanda Tangan Digital"
            )
        )
    }

    init {
        val code = prefs.getString(KEY_SELECTED_LANGUAGE, "hi") ?: "hi"
        _currentLanguageFlow.value = code
    }

    var hasChosenInitialLanguage: Boolean
        get() = prefs.getBoolean(KEY_INITIAL_LANGUAGE_CHOSEN, false)
        set(value) = prefs.edit().putBoolean(KEY_INITIAL_LANGUAGE_CHOSEN, value).apply()

    var selectedLanguageCode: String
        get() = prefs.getString(KEY_SELECTED_LANGUAGE, "hi") ?: "hi"
        set(value) {
            prefs.edit().putString(KEY_SELECTED_LANGUAGE, value).apply()
            _currentLanguageFlow.value = value
        }

    fun getSelectedLanguage(): AppLanguage {
        val currentCode = selectedLanguageCode
        return SUPPORTED_LANGUAGES.find { it.code == currentCode } ?: SUPPORTED_LANGUAGES.first()
    }

    fun t(key: String): String {
        val lang = selectedLanguageCode
        val translations = TRANSLATIONS[key] ?: return key
        return translations[lang] ?: translations["en"] ?: key
    }

    fun applyLanguageLocale(context: Context, languageCode: String): Context {
        selectedLanguageCode = languageCode
        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val config = context.resources.configuration
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(LocaleList(locale))
        } else {
            @Suppress("DEPRECATION")
            config.locale = locale
        }

        return context.createConfigurationContext(config)
    }
}
