package com.example.data.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.CompressionLevel
import com.example.util.LanguageManager
import java.io.File
import java.io.FileOutputStream
import java.text.DecimalFormat

object PdfGenerator {

    data class PdfResult(
        val file: File,
        val pageCount: Int,
        val fileSizeBytes: Long,
        val fileSizeFormatted: String
    )

    /**
     * Generates a PDF file from a list of page Bitmaps with compression support.
     */
    fun createPdf(
        context: Context,
        pageBitmaps: List<Bitmap>,
        documentTitle: String,
        compressionLevel: CompressionLevel
    ): PdfResult {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = documentTitle.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()

        pageBitmaps.forEachIndexed { index, rawBitmap ->
            // Scale and compress bitmap according to compression level
            val scaledBitmap = scaleBitmapForCompression(rawBitmap, compressionLevel)

            // Standard A4 dimensions in PDF points (595 x 842 points)
            val pageWidth = 595
            val pageHeight = 842

            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint().apply { isFilterBitmap = true; isAntiAlias = true }

            // Draw image fitted on A4 canvas
            val destRect = Rect(20, 20, pageWidth - 20, pageHeight - 50)
            canvas.drawBitmap(scaledBitmap, null, destRect, paint)

            // Draw footer page counter & watermark
            val footerPaint = Paint().apply {
                color = android.graphics.Color.GRAY
                textSize = 12f
                isAntiAlias = true
            }
            canvas.drawText("Page ${index + 1} of ${pageBitmaps.size}", 20f, pageHeight - 20f, footerPaint)

            val rightText = "DocuScan AI"
            val textWidth = footerPaint.measureText(rightText)
            canvas.drawText(rightText, pageWidth - 20f - textWidth, pageHeight - 20f, footerPaint)

            pdfDocument.finishPage(page)

            if (scaledBitmap != rawBitmap) {
                scaledBitmap.recycle()
            }
        }

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        val fileSize = pdfFile.length()
        return PdfResult(
            file = pdfFile,
            pageCount = pageBitmaps.size,
            fileSizeBytes = fileSize,
            fileSizeFormatted = formatFileSize(fileSize)
        )
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val formatted = DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble()))
        return "$formatted ${units[digitGroups]}"
    }

    private fun scaleBitmapForCompression(bitmap: Bitmap, level: CompressionLevel): Bitmap {
        val scaleFactor = when (level) {
            CompressionLevel.LOW -> 1.0f
            CompressionLevel.MEDIUM -> 0.75f
            CompressionLevel.HIGH -> 0.50f
        }

        if (scaleFactor == 1.0f) return bitmap

        val newW = (bitmap.width * scaleFactor).toInt().coerceAtLeast(100)
        val newH = (bitmap.height * scaleFactor).toInt().coerceAtLeast(100)

        val scaled = Bitmap.createScaledBitmap(bitmap, newW, newH, true)

        // Compress stream
        val compressedBytes = ImageProcessor.compressBitmapToBytes(scaled, level.quality)
        return BitmapFactory.decodeByteArray(compressedBytes, 0, compressedBytes.size)
    }

    /**
     * Generates an ID Card PDF combining Front and Back photos onto a single A4 page.
     */
    fun createIdCardPdf(
        context: Context,
        frontBitmap: Bitmap,
        backBitmap: Bitmap,
        title: String
    ): PdfResult {
        val languageManager = LanguageManager(context)
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "ID_Card_" + title.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Draw header title
        val headerPaint = Paint().apply {
            color = android.graphics.Color.rgb(20, 20, 30)
            textSize = 18f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText(title.ifBlank { languageManager.t("id_card") }, 40f, 55f, headerPaint)

        val subHeaderPaint = Paint().apply {
            color = android.graphics.Color.rgb(120, 120, 140)
            textSize = 10f
            isAntiAlias = true
        }
        canvas.drawText("A4 Single Page Verification", 40f, 75f, subHeaderPaint)

        val paint = Paint().apply { isFilterBitmap = true; isAntiAlias = true }

        val borderPaint = Paint().apply {
            color = android.graphics.Color.rgb(210, 210, 220)
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }

        // Draw Front Side
        val frontLabelPaint = Paint().apply {
            color = android.graphics.Color.rgb(250, 15, 0)
            textSize = 13f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("1. " + languageManager.t("front_side"), 40f, 115f, frontLabelPaint)
        val frontRect = Rect(40, 125, pageWidth - 40, 420)
        canvas.drawBitmap(frontBitmap, null, frontRect, paint)
        canvas.drawRect(frontRect, borderPaint)

        // Draw Back Side
        canvas.drawText("2. " + languageManager.t("back_side"), 40f, 460f, frontLabelPaint)
        val backRect = Rect(40, 470, pageWidth - 40, 765)
        canvas.drawBitmap(backBitmap, null, backRect, paint)
        canvas.drawRect(backRect, borderPaint)

        // Footer
        canvas.drawText("Adobe Acrobat Suite • Verified ID Document", 40f, 810f, subHeaderPaint)

        pdfDocument.finishPage(page)

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        val fileSize = pdfFile.length()
        return PdfResult(
            file = pdfFile,
            pageCount = 1,
            fileSizeBytes = fileSize,
            fileSizeFormatted = formatFileSize(fileSize)
        )
    }

    /**
     * Creates a clean digital PDF for handwritten notes.
     */
    fun createCleanedHandwritingPdf(
        context: Context,
        title: String,
        content: String
    ): File {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "CleanNotes_" + title.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = android.graphics.Color.rgb(230, 81, 0)
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 13f
            isAntiAlias = true
        }

        canvas.drawText(title, 40f, 50f, titlePaint)
        var y = 90f

        content.lines().forEach { line ->
            if (y < 800f) {
                canvas.drawText(line, 40f, y, textPaint)
                y += 22f
            }
        }

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }

    /**
     * Creates a formula sheet PDF for math/physics equations.
     */
    fun createFormulaSheetPdf(
        context: Context,
        title: String,
        content: String
    ): File {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "Formulas_" + title.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = android.graphics.Color.rgb(255, 143, 0)
            textSize = 22f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 13f
            isAntiAlias = true
        }

        canvas.drawText("⚡ $title (Math & Physics Formulas)", 40f, 50f, titlePaint)
        var y = 95f

        content.lines().forEach { line ->
            if (y < 800f) {
                canvas.drawText(line, 40f, y, textPaint)
                y += 24f
            }
        }

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }

    /**
     * Share PDF file via Android Share Sheet (WhatsApp, Drive, Email, etc.).
     */
    fun sharePdf(context: Context, pdfFile: File, title: String) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, pdfFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "Shared via DocuScan AI: $title")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share PDF Document (पीडीएफ शेयर करें)"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Creates an Invoice PDF from structured input.
     */
    fun createInvoicePdf(
        context: Context,
        invoiceNumber: String,
        businessName: String,
        customerName: String,
        date: String,
        items: List<Pair<String, Double>>,
        taxRatePercent: Double,
        notes: String
    ): File {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "Invoice_${invoiceNumber.replace(Regex("[^a-zA-Z0-9_]"), "_")}_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Header Background
        val headerPaint = Paint().apply {
            color = android.graphics.Color.rgb(250, 15, 0) // Adobe Acrobat Red
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, 595f, 90f, headerPaint)

        // Header Text
        val headerTitlePaint = Paint().apply {
            color = android.graphics.Color.WHITE
            textSize = 24f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("TAX INVOICE / बिल", 36f, 50f, headerTitlePaint)

        val headerSubPaint = Paint().apply {
            color = android.graphics.Color.WHITE
            textSize = 12f
            isAntiAlias = true
        }
        canvas.drawText("Invoice #: $invoiceNumber  |  Date: $date", 36f, 75f, headerSubPaint)

        val boldPaint = Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 13f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val normalPaint = Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 12f
            isAntiAlias = true
        }

        // Billed From & Billed To
        canvas.drawText("FROM:", 36f, 130f, boldPaint)
        canvas.drawText(businessName, 36f, 150f, normalPaint)

        canvas.drawText("BILLED TO:", 320f, 130f, boldPaint)
        canvas.drawText(customerName, 320f, 150f, normalPaint)

        // Table Header
        val tableHeaderPaint = Paint().apply {
            color = android.graphics.Color.rgb(240, 240, 240)
            style = Paint.Style.FILL
        }
        canvas.drawRect(36f, 180f, 559f, 210f, tableHeaderPaint)

        val colHeaderPaint = Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 12f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("#", 46f, 200f, colHeaderPaint)
        canvas.drawText("Item / Description", 80f, 200f, colHeaderPaint)
        canvas.drawText("Amount (₹)", 470f, 200f, colHeaderPaint)

        var y = 235f
        var subtotal = 0.0

        items.forEachIndexed { idx, item ->
            canvas.drawText("${idx + 1}.", 46f, y, normalPaint)
            canvas.drawText(item.first, 80f, y, normalPaint)
            canvas.drawText(String.format("₹ %.2f", item.second), 470f, y, normalPaint)
            subtotal += item.second
            y += 24f
        }

        // Dividers & Totals
        val linePaint = Paint().apply {
            color = android.graphics.Color.LTGRAY
            strokeWidth = 1f
        }
        canvas.drawLine(36f, y + 10f, 559f, y + 10f, linePaint)
        y += 35f

        val taxAmount = subtotal * (taxRatePercent / 100.0)
        val grandTotal = subtotal + taxAmount

        canvas.drawText("Subtotal:", 350f, y, normalPaint)
        canvas.drawText(String.format("₹ %.2f", subtotal), 470f, y, normalPaint)
        y += 22f

        canvas.drawText("GST/Tax (${taxRatePercent}%):", 350f, y, normalPaint)
        canvas.drawText(String.format("₹ %.2f", taxAmount), 470f, y, normalPaint)
        y += 25f

        val grandTotalPaint = Paint().apply {
            color = android.graphics.Color.rgb(250, 15, 0)
            textSize = 15f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("GRAND TOTAL:", 330f, y, grandTotalPaint)
        canvas.drawText(String.format("₹ %.2f", grandTotal), 470f, y, grandTotalPaint)

        // Notes / Terms
        if (notes.isNotBlank()) {
            val notesY = 650f
            canvas.drawText("Notes & Payment Terms:", 36f, notesY, boldPaint)
            var ny = notesY + 20f
            notes.lines().forEach { nLine ->
                canvas.drawText(nLine, 36f, ny, normalPaint)
                ny += 18f
            }
        }

        // Signature Box
        canvas.drawLine(400f, 750f, 540f, 750f, linePaint)
        canvas.drawText("Authorized Signatory", 420f, 768f, normalPaint)

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }

    /**
     * Creates an Academic Assignment Cover Sheet / Project Front Page PDF.
     */
    fun createAssignmentCoverPdf(
        context: Context,
        institutionName: String,
        projectTitle: String,
        subjectName: String,
        submittedBy: String,
        rollNumber: String,
        semester: String,
        submittedTo: String,
        date: String
    ): File {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "Assignment_${projectTitle.replace(Regex("[^a-zA-Z0-9_]"), "_")}_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Decorative Double Border
        val borderPaint = Paint().apply {
            color = android.graphics.Color.rgb(10, 50, 120)
            style = Paint.Style.STROKE
            strokeWidth = 3f
            isAntiAlias = true
        }
        canvas.drawRect(25f, 25f, 570f, 817f, borderPaint)

        val innerBorderPaint = Paint().apply {
            color = android.graphics.Color.rgb(200, 160, 40)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        canvas.drawRect(30f, 30f, 565f, 812f, innerBorderPaint)

        // Institution
        val instPaint = Paint().apply {
            color = android.graphics.Color.rgb(10, 50, 120)
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(institutionName.uppercase(), 297.5f, 100f, instPaint)

        // Assignment Heading
        val assignHeadingPaint = Paint().apply {
            color = android.graphics.Color.rgb(200, 160, 40)
            textSize = 14f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("PROJECT REPORT / ASSIGNMENT", 297.5f, 150f, assignHeadingPaint)

        // Project Title
        val titlePaint = Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 22f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(projectTitle, 297.5f, 260f, titlePaint)

        // Subject
        val subPaint = Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 15f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Subject: $subjectName", 297.5f, 300f, subPaint)

        // Details Section
        val leftLabelPaint = Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 13f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val leftValuePaint = Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 13f
            isAntiAlias = true
        }

        val yStart = 450f
        canvas.drawText("SUBMITTED BY:", 70f, yStart, leftLabelPaint)
        canvas.drawText("Name: $submittedBy", 70f, yStart + 28f, leftValuePaint)
        canvas.drawText("Roll No / ID: $rollNumber", 70f, yStart + 52f, leftValuePaint)
        canvas.drawText("Semester / Class: $semester", 70f, yStart + 76f, leftValuePaint)

        canvas.drawText("SUBMITTED TO:", 340f, yStart, leftLabelPaint)
        canvas.drawText("Faculty: $submittedTo", 340f, yStart + 28f, leftValuePaint)
        canvas.drawText("Submission Date: $date", 340f, yStart + 52f, leftValuePaint)

        // Signature lines
        val sigLinePaint = Paint().apply {
            color = android.graphics.Color.GRAY
            strokeWidth = 1f
        }
        canvas.drawLine(70f, 720f, 210f, 720f, sigLinePaint)
        canvas.drawText("Student Signature", 85f, 740f, leftValuePaint)

        canvas.drawLine(340f, 720f, 480f, 720f, sigLinePaint)
        canvas.drawText("Faculty Signature & Seal", 340f, 740f, leftValuePaint)

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }

    /**
     * Creates a Certificate of Completion or Achievement PDF.
     */
    fun createCertificatePdf(
        context: Context,
        recipientName: String,
        certificateTitle: String,
        reason: String,
        issuingOrganization: String,
        date: String
    ): File {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "Certificate_${recipientName.replace(Regex("[^a-zA-Z0-9_]"), "_")}_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        // Landscape A4 (842 x 595)
        val pageInfo = PdfDocument.PageInfo.Builder(842, 595, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Gold & Dark Blue Border
        val borderOuter = Paint().apply {
            color = android.graphics.Color.rgb(180, 140, 30)
            style = Paint.Style.STROKE
            strokeWidth = 6f
            isAntiAlias = true
        }
        canvas.drawRect(25f, 25f, 817f, 570f, borderOuter)

        val borderInner = Paint().apply {
            color = android.graphics.Color.rgb(15, 30, 60)
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawRect(33f, 33f, 809f, 562f, borderInner)

        // Organization
        val orgPaint = Paint().apply {
            color = android.graphics.Color.rgb(15, 30, 60)
            textSize = 18f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(issuingOrganization.uppercase(), 421f, 80f, orgPaint)

        // Title
        val certTitlePaint = Paint().apply {
            color = android.graphics.Color.rgb(180, 140, 30)
            textSize = 32f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(certificateTitle.uppercase(), 421f, 150f, certTitlePaint)

        // Presented to text
        val presPaint = Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 15f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("THIS CERTIFICATE IS PROUDLY PRESENTED TO", 421f, 205f, presPaint)

        // Recipient Name
        val namePaint = Paint().apply {
            color = android.graphics.Color.rgb(250, 15, 0)
            textSize = 30f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(recipientName, 421f, 265f, namePaint)

        val linePaint = Paint().apply {
            color = android.graphics.Color.LTGRAY
            strokeWidth = 1.5f
        }
        canvas.drawLine(200f, 280f, 642f, 280f, linePaint)

        // Reason / Description
        val reasonPaint = Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 14f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        var ry = 330f
        reason.lines().forEach { line ->
            canvas.drawText(line, 421f, ry, reasonPaint)
            ry += 22f
        }

        // Date & Signature
        canvas.drawLine(100f, 490f, 280f, 490f, linePaint)
        canvas.drawText("Date: $date", 190f, 515f, presPaint)

        canvas.drawLine(560f, 490f, 740f, 490f, linePaint)
        canvas.drawText("Authorized Signature", 650f, 515f, presPaint)

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }

    /**
     * Translates document text into a new clean PDF.
     */
    fun createTranslatedDocumentPdf(
        context: Context,
        originalTitle: String,
        targetLanguageName: String,
        translatedContent: String
    ): File {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "Translated_${targetLanguageName}_" + originalTitle.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val headerPaint = Paint().apply {
            color = android.graphics.Color.rgb(0, 150, 136) // Teal
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val subPaint = Paint().apply {
            color = android.graphics.Color.GRAY
            textSize = 11f
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 13f
            isAntiAlias = true
        }

        canvas.drawText("🌐 $originalTitle ($targetLanguageName Translation)", 40f, 50f, headerPaint)
        canvas.drawText("Translated by DocuScan AI Engine", 40f, 70f, subPaint)

        var y = 105f
        translatedContent.lines().forEach { line ->
            if (y < 800f) {
                canvas.drawText(line, 40f, y, textPaint)
                y += 22f
            }
        }

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }
}
