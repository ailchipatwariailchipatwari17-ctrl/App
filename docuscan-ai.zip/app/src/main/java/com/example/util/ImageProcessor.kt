package com.example.data.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PointF
import com.example.data.model.ScanFilter
import java.io.ByteArrayOutputStream
import kotlin.math.max

object ImageProcessor {

    /**
     * Estimates default 4 document corners for edge detection cropping.
     */
    fun getDefaultEdges(width: Float, height: Float): List<PointF> {
        val marginX = width * 0.08f
        val marginY = height * 0.08f
        return listOf(
            PointF(marginX, marginY),
            PointF(width - marginX, marginY),
            PointF(width - marginX, height - marginY),
            PointF(marginX, height - marginY)
        )
    }

    /**
     * Applies document scan filters to a Bitmap.
     */
    fun applyFilter(src: Bitmap, filter: ScanFilter): Bitmap {
        val width = src.width
        val height = src.height
        val output = Bitmap.createBitmap(width, height, src.config ?: Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint()

        val cm = ColorMatrix()
        when (filter) {
            ScanFilter.ORIGINAL -> {
                return src
            }
            ScanFilter.VIVID_LIGHT -> {
                // Vivid Light: Enhanced brightness and dynamic crisp contrast
                cm.set(floatArrayOf(
                    1.25f, 0f, 0f, 0f, 15f,
                    0f, 1.25f, 0f, 0f, 15f,
                    0f, 0f, 1.25f, 0f, 15f,
                    0f, 0f, 0f, 1f, 0f
                ))
            }
            ScanFilter.MAGIC_COLOR -> {
                // High contrast, vivid document color
                cm.set(floatArrayOf(
                    1.2f, 0f, 0f, 0f, -10f,
                    0f, 1.2f, 0f, 0f, -10f,
                    0f, 0f, 1.2f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                ))
            }
            ScanFilter.COLOR -> {
                // Natural boosted color saturation
                cm.set(floatArrayOf(
                    1.1f, 0f, 0f, 0f, 0f,
                    0f, 1.1f, 0f, 0f, 0f,
                    0f, 0f, 1.1f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                ))
            }
            ScanFilter.BLACK_WHITE -> {
                // High-contrast crisp B&W document scan mode
                val grayscale = ColorMatrix()
                grayscale.setSaturation(0f)
                val contrast = ColorMatrix(floatArrayOf(
                    2.2f, 0f, 0f, 0f, -140f,
                    0f, 2.2f, 0f, 0f, -140f,
                    0f, 0f, 2.2f, 0f, -140f,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(grayscale)
                cm.postConcat(contrast)
            }
            ScanFilter.GRAYSCALE -> {
                cm.setSaturation(0f)
                val contrast = ColorMatrix(floatArrayOf(
                    1.2f, 0f, 0f, 0f, -10f,
                    0f, 1.2f, 0f, 0f, -10f,
                    0f, 0f, 1.2f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(contrast)
            }
            ScanFilter.BRIGHTEN -> {
                cm.set(floatArrayOf(
                    1.1f, 0f, 0f, 0f, 30f,
                    0f, 1.1f, 0f, 0f, 30f,
                    0f, 0f, 1.1f, 0f, 30f,
                    0f, 0f, 0f, 1f, 0f
                ))
            }
        }

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return output
    }

    /**
     * Crops bitmap to specified 4 corners (or rectangle bounds).
     */
    fun cropToCorners(src: Bitmap, points: List<PointF>): Bitmap {
        if (points.size < 4) return src

        val minX = max(0f, points.minOf { it.x })
        val minY = max(0f, points.minOf { it.y })
        val maxX = points.maxOf { it.x }.coerceAtMost(src.width.toFloat())
        val maxY = points.maxOf { it.y }.coerceAtMost(src.height.toFloat())

        val cropW = (maxX - minX).toInt().coerceAtLeast(10)
        val cropH = (maxY - minY).toInt().coerceAtLeast(10)

        return Bitmap.createBitmap(src, minX.toInt(), minY.toInt(), cropW, cropH)
    }

    /**
     * Rotates bitmap by specified angle.
     */
    fun rotateBitmap(src: Bitmap, degrees: Float): Bitmap {
        if (degrees == 0f) return src
        val matrix = android.graphics.Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    /**
     * Compresses bitmap byte array according to quality percentage.
     */
    fun compressBitmapToBytes(bitmap: Bitmap, quality: Int): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 100), stream)
        return stream.toByteArray()
    }

    /**
     * Overlays signature bitmap onto document page bitmap.
     */
    fun applySignature(src: Bitmap, signature: Bitmap): Bitmap {
        val output = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val sigWidth = (src.width * 0.35f).toInt()
        val sigHeight = (sigWidth * (signature.height.toFloat() / signature.width.toFloat())).toInt()
        val scaledSig = Bitmap.createScaledBitmap(signature, sigWidth, sigHeight, true)
        val x = (src.width - sigWidth - (src.width * 0.05f))
        val y = (src.height - sigHeight - (src.height * 0.05f))
        canvas.drawBitmap(scaledSig, x, y, Paint())
        return output
    }

    /**
     * Overlays watermark or stamp text across document page bitmap.
     */
    fun applyWatermark(src: Bitmap, watermarkText: String, stampText: String = ""): Bitmap {
        val output = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(65, 120, 120, 130)
            textSize = (src.width * 0.07f).coerceAtLeast(24f)
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        if (watermarkText.isNotBlank()) {
            canvas.save()
            canvas.rotate(-35f, src.width / 2f, src.height / 2f)
            canvas.drawText(watermarkText, src.width / 2f, src.height / 2f, paint)
            canvas.restore()
        }

        if (stampText.isNotBlank() && stampText != "NONE") {
            val stampPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(120, 220, 20, 60)
                textSize = (src.width * 0.08f).coerceAtLeast(28f)
                textAlign = Paint.Align.RIGHT
                isFakeBoldText = true
            }
            canvas.drawText("[$stampText]", src.width * 0.92f, src.height * 0.15f, stampPaint)
        }

        return output
    }
}

