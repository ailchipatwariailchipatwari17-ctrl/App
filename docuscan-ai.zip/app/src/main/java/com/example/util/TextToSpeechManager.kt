package com.example.util

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Universal High-Reliability Text-To-Speech (TTS) Manager.
 * Supports long text chunking, real-time sentence tracking, speed controls,
 * fallback language support (Hindi & English), and playback state management.
 */
class TextToSpeechManager(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _currentSpokenText = MutableStateFlow("")
    val currentSpokenText: StateFlow<String> = _currentSpokenText.asStateFlow()

    private val _currentChunkIndex = MutableStateFlow(0)
    val currentChunkIndex: StateFlow<Int> = _currentChunkIndex.asStateFlow()

    private val _totalChunks = MutableStateFlow(0)
    val totalChunks: StateFlow<Int> = _totalChunks.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _isHindiSupported = MutableStateFlow(true)
    val isHindiSupported: StateFlow<Boolean> = _isHindiSupported.asStateFlow()

    private var textChunks: List<String> = emptyList()
    private var activeIndex = 0
    private val coroutineScope = CoroutineScope(Dispatchers.Main)

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                // Try Hindi first, then default, then US
                val hindiLocale = Locale("hi", "IN")
                val result = tts?.setLanguage(hindiLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    _isHindiSupported.value = false
                    val defaultLocale = Locale.getDefault()
                    val defResult = tts?.setLanguage(defaultLocale)
                    if (defResult == TextToSpeech.LANG_MISSING_DATA || defResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.setLanguage(Locale.US)
                    }
                } else {
                    _isHindiSupported.value = true
                }

                tts?.setSpeechRate(_speechRate.value)
                setupUtteranceListener()
            } else {
                isInitialized = false
            }
        }
    }

    private fun setupUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                coroutineScope.launch {
                    _isPlaying.value = true
                    _isPaused.value = false
                }
            }

            override fun onDone(utteranceId: String?) {
                coroutineScope.launch {
                    val nextIdx = activeIndex + 1
                    if (nextIdx < textChunks.size) {
                        activeIndex = nextIdx
                        _currentChunkIndex.value = activeIndex
                        _currentSpokenText.value = textChunks.getOrElse(activeIndex) { "" }
                        speakCurrentChunk()
                    } else {
                        _isPlaying.value = false
                        _isPaused.value = false
                        _currentSpokenText.value = ""
                        _currentChunkIndex.value = 0
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                coroutineScope.launch {
                    _isPlaying.value = false
                    _isPaused.value = false
                }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                coroutineScope.launch {
                    _isPlaying.value = false
                    _isPaused.value = false
                }
            }
        })
    }

    /**
     * Splits full text into natural sentences/paragraphs so Android TTS never truncates.
     */
    fun splitTextIntoChunks(fullText: String): List<String> {
        val clean = fullText.trim()
        if (clean.isBlank()) return emptyList()

        // Split by newlines or sentence boundaries (।, ., ?, !)
        val rawParts = clean.split(Regex("(?<=[।\\n\\.\\?\\!])\\s*"))
        val result = mutableListOf<String>()
        var currentBuilder = StringBuilder()

        for (part in rawParts) {
            val p = part.trim()
            if (p.isEmpty()) continue

            if (currentBuilder.length + p.length > 250) {
                if (currentBuilder.isNotEmpty()) {
                    result.add(currentBuilder.toString().trim())
                    currentBuilder = StringBuilder()
                }
            }

            if (p.length > 250) {
                // Large chunk without punctuation, break by words
                val words = p.split(" ")
                for (w in words) {
                    if (currentBuilder.length + w.length > 250) {
                        result.add(currentBuilder.toString().trim())
                        currentBuilder = StringBuilder()
                    }
                    currentBuilder.append(w).append(" ")
                }
            } else {
                currentBuilder.append(p).append(" ")
            }
        }

        if (currentBuilder.isNotEmpty()) {
            result.add(currentBuilder.toString().trim())
        }

        return if (result.isNotEmpty()) result else listOf(clean)
    }

    /**
     * Start reading text aloud from beginning or specific chunk.
     */
    fun startSpeaking(fullText: String, startFromChunk: Int = 0) {
        if (!isInitialized) {
            initTts()
        }

        val chunks = splitTextIntoChunks(fullText)
        if (chunks.isEmpty()) {
            Toast.makeText(context, "पढ़ने के लिए कोई टेक्स्ट उपलब्ध नहीं है", Toast.LENGTH_SHORT).show()
            return
        }

        textChunks = chunks
        activeIndex = startFromChunk.coerceIn(0, chunks.size - 1)
        _totalChunks.value = chunks.size
        _currentChunkIndex.value = activeIndex
        _currentSpokenText.value = chunks[activeIndex]

        speakCurrentChunk()
    }

    private fun speakCurrentChunk() {
        if (activeIndex in textChunks.indices) {
            val text = textChunks[activeIndex]
            _currentSpokenText.value = text
            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "CHUNK_$activeIndex")
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "CHUNK_$activeIndex")
            _isPlaying.value = true
            _isPaused.value = false
        }
    }

    fun pause() {
        tts?.stop()
        _isPlaying.value = false
        _isPaused.value = true
    }

    fun resume() {
        if (_isPaused.value && textChunks.isNotEmpty()) {
            speakCurrentChunk()
        }
    }

    fun stop() {
        tts?.stop()
        _isPlaying.value = false
        _isPaused.value = false
        _currentSpokenText.value = ""
        _currentChunkIndex.value = 0
    }

    fun nextChunk() {
        if (activeIndex + 1 < textChunks.size) {
            activeIndex++
            _currentChunkIndex.value = activeIndex
            speakCurrentChunk()
        }
    }

    fun previousChunk() {
        if (activeIndex > 0) {
            activeIndex--
            _currentChunkIndex.value = activeIndex
            speakCurrentChunk()
        }
    }

    fun setSpeechRate(rate: Float) {
        _speechRate.value = rate
        tts?.setSpeechRate(rate)
    }

    fun toggleLanguage() {
        if (_isHindiSupported.value) {
            tts?.setLanguage(Locale.US)
            _isHindiSupported.value = false
            Toast.makeText(context, "English Voice Selected", Toast.LENGTH_SHORT).show()
        } else {
            val res = tts?.setLanguage(Locale("hi", "IN"))
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(context, "हिंदी वॉइस डेटा डिवाइस पर उपलब्ध नहीं है, डिफ़ॉल्ट आवाज़ सक्रिय है", Toast.LENGTH_SHORT).show()
            } else {
                _isHindiSupported.value = true
                Toast.makeText(context, "हिंदी आवाज़ सक्रिय की गई 🗣️", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
