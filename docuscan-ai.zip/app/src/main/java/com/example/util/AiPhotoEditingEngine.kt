package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class AiPhotoFilterType(val displayName: String, val hindiName: String) {
    ORIGINAL("Original", "मूल फ़ोटो"),
    MAGIC_COLOR("Magic Color HDR", "मैजिक कलर एचडी"),
    DOCUMENT_CLEANUP("Doc Paper Whitener", "दस्तावेज़ साफ़ करें"),
    BW_HIGH_CONTRAST("B&W Scan Contrast", "ब्लैक & व्हाइट"),
    SHADOW_REMOVER("Shadow Remover", "परछाई हटाएं"),
    VINTAGE_SEPIA("Vintage Warmth", "विंटेज टोन"),
    SHARPEN_CLEAR("Ultra Sharpen", "अल्ट्रा शार्प"),
    INVERT_NEGATIVE("Invert / Dark Tone", "डार्क/नेगेटिव")
}

object AiPhotoEditingEngine {

    suspend fun applyFilter(
        source: Bitmap,
        filterType: AiPhotoFilterType,
        brightness: Float = 0f, // -100 to +100
        contrast: Float = 1f    // 0.5 to 2.0
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = source.width
        val height = source.height
        val output = Bitmap.createBitmap(width, height, source.config ?: Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val cm = ColorMatrix()

        when (filterType) {
            AiPhotoFilterType.ORIGINAL -> {
                cm.reset()
            }
            AiPhotoFilterType.MAGIC_COLOR -> {
                // Boost saturation and dynamic contrast
                cm.setSaturation(1.4f)
                val contrastMatrix = ColorMatrix(floatArrayOf(
                    1.25f * contrast, 0f, 0f, 0f, 15f + brightness,
                    0f, 1.25f * contrast, 0f, 0f, 15f + brightness,
                    0f, 0f, 1.25f * contrast, 0f, 15f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(contrastMatrix)
            }
            AiPhotoFilterType.DOCUMENT_CLEANUP -> {
                // High contrast white paper effect
                cm.setSaturation(0.2f)
                val docMatrix = ColorMatrix(floatArrayOf(
                    1.6f * contrast, 0f, 0f, 0f, 35f + brightness,
                    0f, 1.6f * contrast, 0f, 0f, 35f + brightness,
                    0f, 0f, 1.6f * contrast, 0f, 35f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(docMatrix)
            }
            AiPhotoFilterType.BW_HIGH_CONTRAST -> {
                // Pure grayscale high contrast scan
                cm.setSaturation(0f)
                val bwMatrix = ColorMatrix(floatArrayOf(
                    1.8f * contrast, 0f, 0f, 0f, -20f + brightness,
                    0f, 1.8f * contrast, 0f, 0f, -20f + brightness,
                    0f, 0f, 1.8f * contrast, 0f, -20f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(bwMatrix)
            }
            AiPhotoFilterType.SHADOW_REMOVER -> {
                // Lift shadows and equalize highlights
                cm.setSaturation(1.1f)
                val shadowMatrix = ColorMatrix(floatArrayOf(
                    1.2f * contrast, 0f, 0f, 0f, 40f + brightness,
                    0f, 1.2f * contrast, 0f, 0f, 40f + brightness,
                    0f, 0f, 1.2f * contrast, 0f, 40f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(shadowMatrix)
            }
            AiPhotoFilterType.VINTAGE_SEPIA -> {
                val sepiaMatrix = ColorMatrix(floatArrayOf(
                    0.393f * contrast, 0.769f * contrast, 0.189f * contrast, 0f, 20f + brightness,
                    0.349f * contrast, 0.686f * contrast, 0.168f * contrast, 0f, 10f + brightness,
                    0.272f * contrast, 0.534f * contrast, 0.131f * contrast, 0f, 0f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.set(sepiaMatrix)
            }
            AiPhotoFilterType.SHARPEN_CLEAR -> {
                cm.setSaturation(1.2f)
                val sharpMatrix = ColorMatrix(floatArrayOf(
                    1.35f * contrast, 0f, 0f, 0f, 10f + brightness,
                    0f, 1.35f * contrast, 0f, 0f, 10f + brightness,
                    0f, 0f, 1.35f * contrast, 0f, 10f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(sharpMatrix)
            }
            AiPhotoFilterType.INVERT_NEGATIVE -> {
                val invertMatrix = ColorMatrix(floatArrayOf(
                    -1f * contrast, 0f, 0f, 0f, 255f + brightness,
                    0f, -1f * contrast, 0f, 0f, 255f + brightness,
                    0f, 0f, -1f * contrast, 0f, 255f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.set(invertMatrix)
            }
        }

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(source, 0f, 0f, paint)

        return@withContext output
    }

    suspend fun rotateBitmap(source: Bitmap, angle: Float): Bitmap = withContext(Dispatchers.Default) {
        val matrix = android.graphics.Matrix().apply {
            postRotate(angle)
        }
        return@withContext Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    suspend fun saveBitmapToCache(context: Context, bitmap: Bitmap, name: String = "ai_photo_${System.currentTimeMillis()}"): String = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, "ai_photos").apply { mkdirs() }
        val file = File(dir, "$name.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        return@withContext file.absolutePath
    }
}
