package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class AiPhotoFilterType(val displayName: String, val hindiName: String) {
    ORIGINAL("Original", "मूल फ़ोटो"),
    MAGIC_COLOR("Magic Color HDR", "मैजिक कलर एचडी"),
    STUDIO_PORTRAIT("Studio Portrait Pro", "स्टूडियो पोर्ट्रेट ग्लो"),
    CINEMATIC_TEAL("Cinematic Teal & Orange", "सिनेमैटिक हॉलीवुड"),
    DOCUMENT_CLEANUP("Doc Paper Whitener", "दस्तावेज़ साफ़ करें"),
    BW_HIGH_CONTRAST("B&W Scan Contrast", "ब्लैक & व्हाइट"),
    SHADOW_REMOVER("Shadow Remover", "परछाई हटाएं"),
    VINTAGE_SEPIA("Vintage Warmth", "विंटेज टोन"),
    SHARPEN_CLEAR("Ultra Sharpen", "अल्ट्रा शार्प"),
    CYBERPUNK_NEON("Cyberpunk Neon", "नियॉन वाइब"),
    INVERT_NEGATIVE("Invert / Dark Tone", "डार्क/नेगेटिव")
}

object AiPhotoEditingEngine {

    suspend fun applyFilter(
        source: Bitmap,
        filterType: AiPhotoFilterType,
        brightness: Float = 0f,   // -100 to +100
        contrast: Float = 1f,      // 0.5 to 2.5
        saturationBoost: Float = 1f, // 0.0 to 2.5
        warmth: Float = 0f,       // -50 (Cool Blue) to +50 (Warm Golden)
        vignette: Boolean = false
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = source.width
        val height = source.height
        val output = Bitmap.createBitmap(width, height, source.config ?: Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val cm = ColorMatrix()

        when (filterType) {
            AiPhotoFilterType.ORIGINAL -> {
                cm.reset()
            }
            AiPhotoFilterType.MAGIC_COLOR -> {
                // Vibrant dynamic range HDR
                cm.setSaturation(1.45f * saturationBoost)
                val contrastMatrix = ColorMatrix(floatArrayOf(
                    1.25f * contrast, 0f, 0f, 0f, 15f + brightness + warmth * 0.4f,
                    0f, 1.25f * contrast, 0f, 0f, 15f + brightness + warmth * 0.2f,
                    0f, 0f, 1.25f * contrast, 0f, 15f + brightness - warmth * 0.4f,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(contrastMatrix)
            }
            AiPhotoFilterType.STUDIO_PORTRAIT -> {
                // Soft portrait glow with enhanced skin tone
                cm.setSaturation(1.15f * saturationBoost)
                val portraitMatrix = ColorMatrix(floatArrayOf(
                    1.18f * contrast, 0f, 0f, 0f, 22f + brightness + 15f,
                    0f, 1.15f * contrast, 0f, 0f, 18f + brightness + 10f,
                    0f, 0f, 1.10f * contrast, 0f, 12f + brightness - 5f,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(portraitMatrix)
            }
            AiPhotoFilterType.CINEMATIC_TEAL -> {
                // Hollywood blockbuster Teal & Orange split tone
                cm.setSaturation(1.3f * saturationBoost)
                val tealMatrix = ColorMatrix(floatArrayOf(
                    1.35f * contrast, 0.1f, -0.2f, 0f, 25f + brightness,
                    -0.1f, 1.2f * contrast, 0.1f, 0f, 10f + brightness,
                    -0.2f, 0.1f, 1.4f * contrast, 0f, 30f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(tealMatrix)
            }
            AiPhotoFilterType.DOCUMENT_CLEANUP -> {
                // High contrast white paper effect
                cm.setSaturation(0.1f)
                val docMatrix = ColorMatrix(floatArrayOf(
                    1.65f * contrast, 0f, 0f, 0f, 40f + brightness,
                    0f, 1.65f * contrast, 0f, 0f, 40f + brightness,
                    0f, 0f, 1.65f * contrast, 0f, 40f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(docMatrix)
            }
            AiPhotoFilterType.BW_HIGH_CONTRAST -> {
                // Pure grayscale high contrast scan
                cm.setSaturation(0f)
                val bwMatrix = ColorMatrix(floatArrayOf(
                    1.85f * contrast, 0f, 0f, 0f, -20f + brightness,
                    0f, 1.85f * contrast, 0f, 0f, -20f + brightness,
                    0f, 0f, 1.85f * contrast, 0f, -20f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(bwMatrix)
            }
            AiPhotoFilterType.SHADOW_REMOVER -> {
                // Lift shadows and equalize highlights
                cm.setSaturation(1.15f * saturationBoost)
                val shadowMatrix = ColorMatrix(floatArrayOf(
                    1.2f * contrast, 0f, 0f, 0f, 45f + brightness,
                    0f, 1.2f * contrast, 0f, 0f, 45f + brightness,
                    0f, 0f, 1.2f * contrast, 0f, 45f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(shadowMatrix)
            }
            AiPhotoFilterType.VINTAGE_SEPIA -> {
                val sepiaMatrix = ColorMatrix(floatArrayOf(
                    0.393f * contrast, 0.769f * contrast, 0.189f * contrast, 0f, 25f + brightness,
                    0.349f * contrast, 0.686f * contrast, 0.168f * contrast, 0f, 15f + brightness,
                    0.272f * contrast, 0.534f * contrast, 0.131f * contrast, 0f, 5f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.set(sepiaMatrix)
            }
            AiPhotoFilterType.SHARPEN_CLEAR -> {
                cm.setSaturation(1.25f * saturationBoost)
                val sharpMatrix = ColorMatrix(floatArrayOf(
                    1.4f * contrast, 0f, 0f, 0f, 12f + brightness,
                    0f, 1.4f * contrast, 0f, 0f, 12f + brightness,
                    0f, 0f, 1.4f * contrast, 0f, 12f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(sharpMatrix)
            }
            AiPhotoFilterType.CYBERPUNK_NEON -> {
                cm.setSaturation(1.8f * saturationBoost)
                val neonMatrix = ColorMatrix(floatArrayOf(
                    1.5f * contrast, -0.2f, 0.2f, 0f, 30f + brightness,
                    -0.1f, 0.9f * contrast, 0.3f, 0f, 10f + brightness,
                    0.4f, -0.1f, 1.6f * contrast, 0f, 40f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(neonMatrix)
            }
            AiPhotoFilterType.INVERT_NEGATIVE -> {
                val invertMatrix = ColorMatrix(floatArrayOf(
                    -1f * contrast, 0f, 0f, 0f, 255f + brightness,
                    0f, -1f * contrast, 0f, 0f, 255f + brightness,
                    0f, 0f, -1f * contrast, 0f, 255f + brightness,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.set(invertMatrix)
            }
        }

        // Apply warmth / coolness shift if set manually
        if (warmth != 0f && filterType == AiPhotoFilterType.ORIGINAL) {
            val warmthMatrix = ColorMatrix(floatArrayOf(
                contrast, 0f, 0f, 0f, warmth * 0.5f + brightness,
                0f, contrast, 0f, 0f, warmth * 0.2f + brightness,
                0f, 0f, contrast, 0f, -warmth * 0.5f + brightness,
                0f, 0f, 0f, 1f, 0f
            ))
            cm.postConcat(warmthMatrix)
        }

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(source, 0f, 0f, paint)

        // Draw Vignette if enabled
        if (vignette) {
            val radius = Math.max(width, height) * 0.7f
            val vignettePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    width / 2f, height / 2f, radius,
                    intArrayOf(android.graphics.Color.TRANSPARENT, android.graphics.Color.argb(160, 0, 0, 0)),
                    floatArrayOf(0.4f, 1.0f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vignettePaint)
        }

        return@withContext output
    }

    suspend fun rotateBitmap(source: Bitmap, angle: Float): Bitmap = withContext(Dispatchers.Default) {
        val matrix = android.graphics.Matrix().apply {
            postRotate(angle)
        }
        return@withContext Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    suspend fun flipBitmap(source: Bitmap, horizontal: Boolean = true): Bitmap = withContext(Dispatchers.Default) {
        val matrix = android.graphics.Matrix().apply {
            if (horizontal) postScale(-1f, 1f, source.width / 2f, source.height / 2f)
            else postScale(1f, -1f, source.width / 2f, source.height / 2f)
        }
        return@withContext Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    suspend fun saveBitmapToCache(context: Context, bitmap: Bitmap, name: String = "ai_photo_${System.currentTimeMillis()}"): String = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, "ai_photos").apply { mkdirs() }
        val file = File(dir, "$name.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        return@withContext file.absolutePath
    }

    /**
     * Determines if prompt requests editing/changing an attached image.
     */
    fun isMediaEditRequest(prompt: String): Boolean {
        val p = prompt.lowercase()
        return p.contains("edit") || p.contains("बदलाव") || p.contains("बदलो") || p.contains("change") ||
                p.contains("सुधार") || p.contains("filter") || p.contains("रंग") || p.contains("color") ||
                p.contains("black") || p.contains("white") || p.contains("काला") || p.contains("सफेद") ||
                p.contains("light") || p.contains("dark") || p.contains("bright") || p.contains("रोशनी") ||
                p.contains("crop") || p.contains("rotate") || p.contains("घुमाओ") || p.contains("sharp") ||
                p.contains("hdr") || p.contains("vintage") || p.contains("sepia") || p.contains("साफ") ||
                p.contains("clean") || p.contains("shadow") || p.contains("परछाई") || p.contains("watermark") ||
                p.contains("text") || p.contains("लिखो") || p.contains("invert") || p.contains("negative") ||
                p.contains("सुंदर") || p.contains("enhance") || p.contains("make it") || p.contains("कर दो") ||
                p.contains("portrait") || p.contains("पोर्ट्रेट") || p.contains("glow") || p.contains("चमक")
    }

    /**
     * Executes the requested image transformation according to user's instructions.
     */
    suspend fun processMediaModification(
        context: Context,
        source: Bitmap,
        prompt: String
    ): Pair<String, String> = withContext(Dispatchers.Default) {
        val p = prompt.lowercase()

        var currentBitmap = source
        var appliedActionText = "फोटो में बदलाव किया गया"

        // Check rotation
        if (p.contains("rotate") || p.contains("घुमाओ") || p.contains("90") || p.contains("उल्टा")) {
            val angle = if (p.contains("180")) 180f else if (p.contains("270")) 270f else 90f
            currentBitmap = rotateBitmap(currentBitmap, angle)
            appliedActionText = "फोटो को ${angle.toInt()}° घुमाया गया"
        }

        // Determine filter & tone adjustments
        val filterType: AiPhotoFilterType
        var brightness = 0f
        var contrast = 1f
        var warmth = 0f
        var saturation = 1f
        var vignette = false

        when {
            p.contains("portrait") || p.contains("पोर्ट्रेट") || p.contains("चेहरा") || p.contains("glow") -> {
                filterType = AiPhotoFilterType.STUDIO_PORTRAIT
                warmth = 15f
                appliedActionText = "✨ Studio Portrait Pro (सॉफ्ट स्किन ग्लो) इफेक्ट लागू किया गया"
            }
            p.contains("cinematic") || p.contains("सिनेमैटिक") || p.contains("film") || p.contains("हॉलीवुड") -> {
                filterType = AiPhotoFilterType.CINEMATIC_TEAL
                appliedActionText = "✨ Cinematic Teal & Orange (हॉलीवुड लुक) लागू किया गया"
            }
            p.contains("black") || p.contains("white") || p.contains("काला") || p.contains("सफेद") || p.contains("b&w") || p.contains("श्वेत") -> {
                filterType = AiPhotoFilterType.BW_HIGH_CONTRAST
                appliedActionText = "✨ ब्लैक & व्हाइट (B&W High Contrast) इफेक्ट लागू किया गया"
            }
            p.contains("vintage") || p.contains("sepia") || p.contains("पुराना") || p.contains("विंटेज") || p.contains("retro") -> {
                filterType = AiPhotoFilterType.VINTAGE_SEPIA
                appliedActionText = "✨ विंटेज / सेपिया (Vintage Warmth) टोन लागू किया गया"
            }
            p.contains("clean") || p.contains("साफ") || p.contains("whitener") || p.contains("दस्तावेज़") || p.contains("paper") -> {
                filterType = AiPhotoFilterType.DOCUMENT_CLEANUP
                appliedActionText = "✨ बैकग्राउंड साफ़ कर क्रिस्प डॉक्युमेंट मोड में बदला गया"
            }
            p.contains("shadow") || p.contains("परछाई") || p.contains("छाया") -> {
                filterType = AiPhotoFilterType.SHADOW_REMOVER
                appliedActionText = "✨ परछाई हटाकर ब्राइटनेस संतुलित की गई"
            }
            p.contains("sharp") || p.contains("शार्प") || p.contains("बारीक") || p.contains("clarity") -> {
                filterType = AiPhotoFilterType.SHARPEN_CLEAR
                appliedActionText = "✨ अल्ट्रा शार्प और हाई डेफिनिशन क्लैरिटी बढ़ाई गई"
            }
            p.contains("neon") || p.contains("नियॉन") || p.contains("cyberpunk") -> {
                filterType = AiPhotoFilterType.CYBERPUNK_NEON
                appliedActionText = "✨ Cyberpunk Neon वाइब्रेंट इफेक्ट लागू किया गया"
            }
            p.contains("invert") || p.contains("negative") || p.contains("नेगेटिव") -> {
                filterType = AiPhotoFilterType.INVERT_NEGATIVE
                appliedActionText = "✨ डार्क / नेगेटिव इन्वर्ट मोड लागू किया गया"
            }
            p.contains("bright") || p.contains("लाइट") || p.contains("रोशनी") || p.contains("उजाला") -> {
                filterType = AiPhotoFilterType.MAGIC_COLOR
                brightness = 35f
                appliedActionText = "✨ ब्राइटनेस और लाइट बढ़ाई गई"
            }
            p.contains("dark") || p.contains("अंधेरा") || p.contains("गहरा") -> {
                filterType = AiPhotoFilterType.ORIGINAL
                brightness = -30f
                contrast = 1.25f
                vignette = true
                appliedActionText = "✨ डार्क टोन और विगनेट कंट्रास्ट समायोजित किया गया"
            }
            else -> {
                filterType = AiPhotoFilterType.MAGIC_COLOR
                saturation = 1.3f
                contrast = 1.2f
                appliedActionText = "✨ Magic Color HDR और मास्टर क्वालिटी ऑटो-एन्हांस की गई"
            }
        }

        val filteredBmp = applyFilter(currentBitmap, filterType, brightness, contrast, saturation, warmth, vignette)

        // Check if text / watermark was asked
        val finalBmp = if (p.contains("watermark") || p.contains("लिखो") || p.contains("नाम")) {
            val textToDraw = prompt.substringAfter("लिखो").substringAfter("watermark").substringAfter("नाम").trim().take(30).ifBlank { "ALL PDF AI" }
            drawWatermarkOnBitmap(filteredBmp, textToDraw)
        } else {
            filteredBmp
        }

        val savedPath = saveBitmapToCache(context, finalBmp)
        return@withContext Pair(savedPath, appliedActionText)
    }

    private fun drawWatermarkOnBitmap(source: Bitmap, text: String): Bitmap {
        val output = source.copy(source.config ?: Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = (source.width * 0.05f).coerceIn(24f, 72f)
            setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val x = source.width * 0.08f
        val y = source.height * 0.92f
        canvas.drawText(text, x, y, paint)
        return output
    }
}
