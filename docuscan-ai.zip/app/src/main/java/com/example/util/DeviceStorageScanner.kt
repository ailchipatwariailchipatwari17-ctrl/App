package com.example.util

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.util.ImportedOfficeDoc
import com.example.data.util.OfficeDocumentHelper
import com.example.data.util.PdfGenerator
import java.io.File

object DeviceStorageScanner {

    fun scanDeviceForPdfAndDocs(context: Context): List<ImportedOfficeDoc> {
        val results = mutableListOf<ImportedOfficeDoc>()
        val seenPaths = mutableSetOf<String>()

        try {
            val resolver: ContentResolver = context.contentResolver
            val uri: Uri = MediaStore.Files.getContentUri("external")

            val projection = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.DATE_MODIFIED
            )

            // Search for PDF, Word, Excel, PowerPoint, Text files
            val selection = "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.pdf' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.doc' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.docx' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.xls' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.xlsx' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.ppt' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.pptx' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.txt'"

            val sortOrder = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"

            resolver.query(uri, projection, selection, null, sortOrder)?.use { cursor ->
                val idColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns._ID)
                val nameColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                val dataColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val fileName = cursor.getString(nameColumn) ?: continue
                    val fileSize = cursor.getLong(sizeColumn)
                    val filePath = if (dataColumn != -1) cursor.getString(dataColumn) else null

                    val fileUri = ContentUris.withAppendedId(uri, id)

                    if (filePath != null && seenPaths.contains(filePath)) continue
                    if (filePath != null) seenPaths.add(filePath)

                    val category = OfficeDocumentHelper.determineCategoryFromFileName(fileName)

                    val actualPath = if (filePath != null && File(filePath).exists()) {
                        filePath
                    } else {
                        fileUri.toString()
                    }

                    results.add(
                        ImportedOfficeDoc(
                            title = fileName.substringBeforeLast("."),
                            filePath = actualPath,
                            fileSizeBytes = fileSize,
                            fileSizeFormatted = PdfGenerator.formatFileSize(fileSize),
                            category = category,
                            extractedTextContent = "फोन डिवाइस फ़ाइल: $fileName"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Direct directory scanning fallback (WhatsApp, Downloads, Documents, Telegram, Bluetooth, etc.)
        val externalStorage = Environment.getExternalStorageDirectory()
        val commonDirs = listOfNotNull(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            File(externalStorage, "WhatsApp/Media/WhatsApp Documents"),
            File(externalStorage, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Documents"),
            File(externalStorage, "WhatsApp Business/Media/WhatsApp Business Documents"),
            File(externalStorage, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Documents"),
            File(externalStorage, "Telegram/Telegram Documents"),
            File(externalStorage, "Download"),
            File(externalStorage, "Documents"),
            File(externalStorage, "Bluetooth"),
            File(externalStorage, "CamScanner"),
            File(externalStorage, "DocuScan")
        )

        for (dir in commonDirs) {
            if (dir.exists() && dir.isDirectory) {
                try {
                    dir.walkTopDown().maxDepth(3).forEach { file ->
                        if (file.isFile) {
                            val ext = file.extension.lowercase()
                            if (ext in listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt")) {
                                if (!seenPaths.contains(file.absolutePath)) {
                                    seenPaths.add(file.absolutePath)
                                    val category = OfficeDocumentHelper.determineCategoryFromFileName(file.name)
                                    results.add(
                                        ImportedOfficeDoc(
                                            title = file.name.substringBeforeLast("."),
                                            filePath = file.absolutePath,
                                            fileSizeBytes = file.length(),
                                            fileSizeFormatted = PdfGenerator.formatFileSize(file.length()),
                                            category = category,
                                            extractedTextContent = "फोन डिवाइस फ़ाइल: ${file.name}"
                                        )
                                    )
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        return results
    }
}
