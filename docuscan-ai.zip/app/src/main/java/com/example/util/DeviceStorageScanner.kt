package com.example.util

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.model.DocumentCategory
import com.example.data.util.ImportedOfficeDoc
import com.example.data.util.OfficeDocumentHelper
import com.example.data.util.PdfGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.io.File

object DeviceStorageScanner {

    // In-memory cache to prevent redundant heavy scans
    private var cachedDocs: List<ImportedOfficeDoc>? = null
    private var lastScanTimeMillis: Long = 0L

    suspend fun scanDeviceForPdfAndDocs(
        context: Context,
        forceRefresh: Boolean = false
    ): List<ImportedOfficeDoc> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!forceRefresh && cachedDocs != null && (now - lastScanTimeMillis < 30_000)) {
            return@withContext cachedDocs!!
        }

        val results = mutableListOf<ImportedOfficeDoc>()
        val seenPaths = mutableSetOf<String>()

        try {
            val resolver: ContentResolver = context.contentResolver
            val uri: Uri = MediaStore.Files.getContentUri("external")

            val projection = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.DATE_MODIFIED
            )

            // Efficient mime/extension filtering
            val selection = "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.pdf' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.doc' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.docx' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.xls' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.xlsx' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.ppt' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.pptx' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.txt'"

            val sortOrder = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC LIMIT 50"

            resolver.query(uri, projection, selection, null, sortOrder)?.use { cursor ->
                val idColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns._ID)
                val nameColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                val dataColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)

                var count = 0
                while (cursor.moveToNext() && count < 50) {
                    if (count % 10 == 0) yield()
                    val id = if (idColumn != -1) cursor.getLong(idColumn) else 0L
                    val fileName = if (nameColumn != -1) cursor.getString(nameColumn) else null ?: continue
                    val fileSize = if (sizeColumn != -1) cursor.getLong(sizeColumn) else 0L
                    val filePath = if (dataColumn != -1) cursor.getString(dataColumn) else null

                    val fileUri = ContentUris.withAppendedId(uri, id)

                    if (filePath != null && seenPaths.contains(filePath)) continue
                    if (filePath != null) seenPaths.add(filePath)

                    val category = OfficeDocumentHelper.determineCategoryFromFileName(fileName)
                    val actualPath = if (filePath != null && File(filePath).exists()) {
                        filePath
                    } else {
                        fileUri.toString()
                    }

                    val docTitle = fileName.substringBeforeLast(".")
                    val initialText = if (category == DocumentCategory.PDF && filePath != null && File(filePath).exists()) {
                        PdfTextExtractor.extractText(File(filePath), docTitle)
                    } else {
                        PdfTextExtractor.generateRichFallbackText(docTitle, 1)
                    }

                    results.add(
                        ImportedOfficeDoc(
                            title = docTitle,
                            filePath = actualPath,
                            fileSizeBytes = if (fileSize > 0) fileSize else 1024L,
                            fileSizeFormatted = PdfGenerator.formatFileSize(if (fileSize > 0) fileSize else 1024L),
                            category = category,
                            extractedTextContent = initialText
                        )
                    )
                    count++
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Lightweight single-level direct scan only if MediaStore returned very few
        if (results.size < 10) {
            yield()
            val candidateDirs = listOfNotNull(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            )

            for (dir in candidateDirs) {
                if (results.size >= 30) break
                if (dir.exists() && dir.isDirectory) {
                    try {
                        val files = dir.listFiles { f ->
                            f.isFile && !f.isHidden && f.extension.lowercase() in listOf(
                                "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt"
                            )
                        }?.take(20)

                        files?.forEach { file ->
                            if (results.size >= 30) return@forEach
                            if (!seenPaths.contains(file.absolutePath)) {
                                seenPaths.add(file.absolutePath)
                                val category = OfficeDocumentHelper.determineCategoryFromFileName(file.name)
                                val docTitle = file.name.substringBeforeLast(".")
                                val initialText = if (category == DocumentCategory.PDF) {
                                    PdfTextExtractor.extractText(file, docTitle)
                                } else {
                                    PdfTextExtractor.generateRichFallbackText(docTitle, 1)
                                }
                                results.add(
                                    ImportedOfficeDoc(
                                        title = docTitle,
                                        filePath = file.absolutePath,
                                        fileSizeBytes = file.length(),
                                        fileSizeFormatted = PdfGenerator.formatFileSize(file.length()),
                                        category = category,
                                        extractedTextContent = initialText
                                    )
                                )
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        cachedDocs = results
        lastScanTimeMillis = now
        return@withContext results
    }
}
