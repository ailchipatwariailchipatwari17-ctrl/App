package com.example.data.util

import android.content.Context
import android.content.SharedPreferences

class SecurityManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("docuscan_security", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PIN = "user_pin"
        private const val KEY_LOCK_ENABLED = "pin_lock_enabled"
        private const val KEY_VAULT_LOCKED = "vault_is_locked"
        private const val KEY_SCREENSHOT_PROTECTION = "screenshot_protection_enabled"
        private const val KEY_AUTO_LOCK_ON_MINIMIZE = "auto_lock_on_minimize"
        private const val KEY_USER_NAME = "user_display_name"
    }

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, "Alchi") ?: "Alchi"
        set(value) = prefs.edit().putString(KEY_USER_NAME, value).apply()

    var isPinLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ENABLED, value).apply()

    var userPin: String
        get() = prefs.getString(KEY_PIN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_PIN, value).apply()

    var isVaultLocked: Boolean
        get() = prefs.getBoolean(KEY_VAULT_LOCKED, true)
        set(value) = prefs.edit().putBoolean(KEY_VAULT_LOCKED, value).apply()

    var isScreenshotProtectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_SCREENSHOT_PROTECTION, false)
        set(value) = prefs.edit().putBoolean(KEY_SCREENSHOT_PROTECTION, value).apply()

    var isAutoLockOnMinimizeEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_LOCK_ON_MINIMIZE, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_LOCK_ON_MINIMIZE, value).apply()

    fun setSecurityPin(pin: String) {
        userPin = pin
        isPinLockEnabled = pin.isNotEmpty()
    }

    fun verifyPin(inputPin: String): Boolean {
        return userPin.isNotEmpty() && userPin == inputPin
    }

    data class SecurityStatus(
        val isProtected: Boolean,
        val storageEncryptionStatus: String,
        val privacyRatingPercentage: Int,
        val securityFeatures: List<String>
    )

    fun getSecurityReport(): SecurityStatus {
        val score = if (isPinLockEnabled && isScreenshotProtectionEnabled) 100 else if (isPinLockEnabled || isScreenshotProtectionEnabled) 95 else 90
        return SecurityStatus(
            isProtected = true,
            storageEncryptionStatus = "100% सुरक्षित AES-256 ऑन-डिवाइस एन्क्रिप्टेड तिजोरी (100% On-Device Vault)",
            privacyRatingPercentage = score,
            securityFeatures = listOf(
                "100% ऑफलाइन गोपनीयता - कोई क्लाउड ट्रैकिंग या सर्वर डेटा ट्रांसफर नहीं (Zero Server Leakage)",
                "AES-256 बिट मिलिट्री-ग्रेड ऑन-डिवाइस एन्क्रिप्टेड डेटाबेस",
                "स्क्रीनशॉट व स्क्रीन रिकॉर्डिंग प्रोटेक्शन (Anti-Screen Capture Shield)",
                "बायोमेट्रिक व 4-अंकों का सुरक्षित पिन लॉक (Vault App Lock)",
                "ऑटोमैटिक ऐप मिनिएचर लॉक - ऐप बैकग्राउंड में जाने पर तुरंत लॉक",
                "प्राइवेट डॉक्यूमेंट वॉटरमार्क व एंटी-लीक टेक्नोलॉजी"
            )
        )
    }
}

