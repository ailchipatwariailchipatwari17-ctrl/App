package com.example.util

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalConfiguration
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppDisplayMode(val titleHi: String, val titleEn: String, val iconDesc: String) {
    NORMAL_MOBILE("नॉर्मल मोड (मोबाइल)", "Normal Mode (Mobile)", "Single-column compact layout optimized for mobile touch"),
    STANDARD_DESKTOP("स्टैंडर्ड मोड (डेस्कटॉप / प्रो)", "Standard Mode (Desktop / Pro)", "Multi-pane desktop workspace with Adobe, Foxit, Xodo & PDFgear toolbars"),
    AUTO_DETECT("ऑटो-डिटेक्ट (स्क्रीन अनुसार)", "Auto Detect (Responsive)", "Automatically switches to Desktop mode on wide screens/tablets/Chromebooks")
}

object AppModeManager {
    private const val PREFS_NAME = "docu_app_mode_prefs"
    private const val KEY_DISPLAY_MODE = "key_app_display_mode"

    private val _displayModeFlow = MutableStateFlow(AppDisplayMode.NORMAL_MOBILE)
    val displayModeFlow: StateFlow<AppDisplayMode> = _displayModeFlow.asStateFlow()

    private var sharedPrefs: SharedPreferences? = null

    fun init(context: Context) {
        if (sharedPrefs == null) {
            sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val savedName = sharedPrefs?.getString(KEY_DISPLAY_MODE, AppDisplayMode.NORMAL_MOBILE.name) ?: AppDisplayMode.NORMAL_MOBILE.name
            val mode = try {
                AppDisplayMode.valueOf(savedName)
            } catch (e: Exception) {
                AppDisplayMode.NORMAL_MOBILE
            }
            _displayModeFlow.value = mode
        }
    }

    fun setDisplayMode(mode: AppDisplayMode) {
        _displayModeFlow.value = mode
        sharedPrefs?.edit()?.putString(KEY_DISPLAY_MODE, mode.name)?.apply()
    }

    @Composable
    fun isDesktopModeActive(): Boolean {
        val currentMode by _displayModeFlow.collectAsStateWithLifecycle()
        if (currentMode == AppDisplayMode.STANDARD_DESKTOP) return true
        if (currentMode == AppDisplayMode.NORMAL_MOBILE) return false

        // Auto-detect based on screen width (tablet / foldable / desktop >= 600dp)
        val configuration = LocalConfiguration.current
        return configuration.screenWidthDp >= 600
    }
}
