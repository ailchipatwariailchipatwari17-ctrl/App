package com.example.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages safety filter, compliance with IT Rules (Deepfakes/Misinformation/Hate Speech/Copyright),
 * data privacy policies, and 24-hour bans for violations.
 */
object AiSafetyManager {

    private const val PREFS_NAME = "ai_safety_prefs"
    private const val KEY_BAN_UNTIL = "ai_ban_until_timestamp"
    private const val KEY_WARNING_COUNT = "ai_warning_count"
    private const val KEY_LAST_WARNING_TIME = "ai_last_warning_time"

    const val MAIN_DISCLAIMER = "यह AI द्वारा जनरेट किया गया उत्तर है, महत्वपूर्ण जानकारी को दोबारा जाँच लें।"
    const val AI_MISTAKES_DISCLAIMER = "AI से गलतियाँ हो सकती है"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // List of abusive, profane, or inappropriate words/terms in Hindi and English
    private val abusiveKeywords = listOf(
        // Severe profanities only (avoiding common words like dog/donkey/pig in animal contexts)
        "मादरचोद", "बहनचोद", "भोसड़ीके", "chutiya", "madarchod", "bhenchod", "bhosdike", "gandu", "randi",
        "lodu", "lauda", "choot", "bhosdi", "lund", "tatte", "chut",
        // English profanities
        "fuck", "motherfucker", "cunt"
    )

    // Deepfake, Synthetic harm, obscenity, and misinformation keywords
    private val deepfakeAndHarmKeywords = listOf(
        "deepfake", "डीपफेक", "face swap", "nude", "nudes", "porn", "pornography", "xxx", "अश्लील", "नग्न",
        "fake aadhar", "fake pan", "fake certificate", "नकली आधार", "नकली दस्तावेज", "जाली प्रमाण", "forged document",
        "hate speech", "दंगा", "bomb", "बम्ब", "terrorist", "आतंकवाद", "communal violence"
    )

    // Copyright piracy / infringement keywords
    private val copyrightInfringementKeywords = listOf(
        "pirated book", "paid book free pdf", "crack software key", "keygen", "copyright bypass", "download pirated"
    )

    /**
     * Checks if the message contains abusive/inappropriate language.
     */
    fun containsAbusiveLanguage(text: String): Boolean {
        val lower = text.lowercase().trim()
        return abusiveKeywords.any { keyword ->
            val regex = "\\b${Regex.escape(keyword)}\\b".toRegex(RegexOption.IGNORE_CASE)
            lower.contains(regex) || lower.contains(keyword)
        }
    }

    /**
     * Checks if the message violates IT Rules (Deepfakes, Obscenity, Misinformation, Fake Docs, Communal Violence).
     */
    fun isDeepfakeOrSyntheticHarm(text: String): Boolean {
        val lower = text.lowercase().trim()
        return deepfakeAndHarmKeywords.any { keyword ->
            lower.contains(keyword)
        }
    }

    /**
     * Checks if the message requests illegal copyright piracy.
     */
    fun isCopyrightInfringementRequest(text: String): Boolean {
        val lower = text.lowercase().trim()
        return copyrightInfringementKeywords.any { keyword ->
            lower.contains(keyword)
        }
    }

    /**
     * Comprehensive safety check. Returns null if safe, or a polite refusal message if unsafe.
     */
    fun checkPromptSafety(text: String): String? {
        if (containsAbusiveLanguage(text)) {
            return "⚠️ **अशोभनीय भाषा अस्वीकरण (Safety Warning):**\n" +
                    "कृपया शालीन और मर्यादित भाषा का प्रयोग करें। अभद्र भाषा नियमों के विरुद्ध है।"
        }
        if (isDeepfakeOrSyntheticHarm(text)) {
            return "🛡️ **IT नियम व सुरक्षा अस्वीकरण (IT Rules & Safety Compliance):**\n\n" +
                    "सरकारी IT नियमों और सुरक्षा नीतियों के तहत **डीपफेक (Synthetic Content)**, भ्रामक जानकारी, अश्लील सामग्री, जाली दस्तावेज़ या नफ़रत फैलाने वाले कंटेंट के निर्माण पर सख्त प्रतिबंध है।\n\n" +
                    "यह AI सहायक ऐसे किसी भी अनुरोध को पूरा करने में असमर्थ है।"
        }
        if (isCopyrightInfringementRequest(text)) {
            return "⚖️ **कॉपीराइट और बौद्धिक संपदा नीति (Copyright Protection):**\n\n" +
                    "हम बौद्धिक संपदा और कॉपीराइट का पूर्ण सम्मान करते हैं। कॉपीराइटेड पुस्तकें, पेड सामग्री या पाइरेटेड सॉफ्टवेयर प्रदान करने की अनुमति नहीं है।"
        }
        return null
    }

    /**
     * Returns true if user is currently banned.
     */
    fun isUserBanned(context: Context): Boolean {
        val banUntil = getPrefs(context).getLong(KEY_BAN_UNTIL, 0L)
        return System.currentTimeMillis() < banUntil
    }

    /**
     * Returns remaining ban time in milliseconds.
     */
    fun getRemainingBanTimeMillis(context: Context): Long {
        val banUntil = getPrefs(context).getLong(KEY_BAN_UNTIL, 0L)
        val diff = banUntil - System.currentTimeMillis()
        return if (diff > 0) diff else 0L
    }

    /**
     * Formats remaining ban time to HH:mm:ss.
     */
    fun formatRemainingBanTime(millis: Long): String {
        val hours = millis / (1000 * 60 * 60)
        val minutes = (millis % (1000 * 60 * 60)) / (1000 * 60)
        val seconds = (millis % (1000 * 60)) / 1000
        return String.format("%02d घंटे %02d मिनट %02d सेकंड", hours, minutes, seconds)
    }

    /**
     * Handles violation. Returns:
     * - "WARNING" for first violation
     * - "BANNED" for repeat violation (locks for 24 hours)
     */
    fun recordViolation(context: Context): ViolationResult {
        val prefs = getPrefs(context)
        val currentWarnings = prefs.getInt(KEY_WARNING_COUNT, 0)
        val newWarningCount = currentWarnings + 1

        if (newWarningCount >= 2) {
            // Ban for 24 hours (24 * 60 * 60 * 1000 ms)
            val banUntil = System.currentTimeMillis() + (24 * 60 * 60 * 1000L)
            prefs.edit()
                .putLong(KEY_BAN_UNTIL, banUntil)
                .putInt(KEY_WARNING_COUNT, newWarningCount)
                .apply()
            return ViolationResult.Banned(banUntil)
        } else {
            // First warning
            prefs.edit()
                .putInt(KEY_WARNING_COUNT, newWarningCount)
                .putLong(KEY_LAST_WARNING_TIME, System.currentTimeMillis())
                .apply()
            return ViolationResult.Warning(
                "⚠️ **सख्त चेतावनी (Safety Warning):**\n" +
                "कृपया AI सहायक के साथ अभद्र, अशोभनीय या गैर-कानूनी भाषा का प्रयोग न करें।\n\n" +
                "यदि आपने दोबारा ऐसी भाषा का प्रयोग किया, तो AI सुविधा आपके लिए **24 घंटे (1 दिन) के लिए पूरी तरह बैन (Lock)** कर दी जाएगी।"
            )
        }
    }

    /**
     * Admin or development reset for ban (for testing purposes).
     */
    fun resetBan(context: Context) {
        getPrefs(context).edit().clear().apply()
    }
}

sealed class ViolationResult {
    data class Warning(val message: String) : ViolationResult()
    data class Banned(val banUntilTimestamp: Long) : ViolationResult()
}

