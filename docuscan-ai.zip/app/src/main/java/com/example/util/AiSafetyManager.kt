package com.example.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages safety filter, warnings, and 24-hour ban for abusive/inappropriate language.
 */
object AiSafetyManager {

    private const val PREFS_NAME = "ai_safety_prefs"
    private const val KEY_BAN_UNTIL = "ai_ban_until_timestamp"
    private const val KEY_WARNING_COUNT = "ai_warning_count"
    private const val KEY_LAST_WARNING_TIME = "ai_last_warning_time"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // List of abusive, profane, or inappropriate words/terms in Hindi and English
    private val abusiveKeywords = listOf(
        // Hindi transliterations & Hindi script terms
        "गाली", "कुत्ता", "कमीना", "साला", "हरामी", "चूतिया", "मादरचोद", "बहनचोद", "भोसड़ीके", "रांड", "गधा", "सूअर",
        "chutiya", "madarchod", "bhenchod", "bhosdike", "harami", "kamina", "saala", "kutta", "gandu", "randi",
        "suar", "lodu", "lauda", "choot", "bhosdi", "bc", "mc", "lund", "tatte", "chut",
        // English profanities
        "fuck", "shit", "bitch", "bastard", "asshole", "dick", "pussy", "cunt", "motherfucker", "whore", "slut"
    )

    /**
     * Checks if the message contains abusive/inappropriate language.
     */
    fun containsAbusiveLanguage(text: String): Boolean {
        val lower = text.lowercase().trim()
        return abusiveKeywords.any { keyword ->
            val regex = "\\b${Regex.escape(keyword)}\\b".toRegex(RegexOption.IGNORE_CASE)
            lower.contains(regex) || lower.contains(keyword)
        }
    }

    /**
     * Returns true if user is currently banned.
     */
    fun isUserBanned(context: Context): Boolean {
        val banUntil = getPrefs(context).getLong(KEY_BAN_UNTIL, 0L)
        return System.currentTimeMillis() < banUntil
    }

    /**
     * Returns remaining ban time in milliseconds.
     */
    fun getRemainingBanTimeMillis(context: Context): Long {
        val banUntil = getPrefs(context).getLong(KEY_BAN_UNTIL, 0L)
        val diff = banUntil - System.currentTimeMillis()
        return if (diff > 0) diff else 0L
    }

    /**
     * Formats remaining ban time to HH:mm:ss.
     */
    fun formatRemainingBanTime(millis: Long): String {
        val hours = millis / (1000 * 60 * 60)
        val minutes = (millis % (1000 * 60 * 60)) / (1000 * 60)
        val seconds = (millis % (1000 * 60)) / 1000
        return String.format("%02d घंटे %02d मिनट %02d सेकंड", hours, minutes, seconds)
    }

    /**
     * Handles violation. Returns:
     * - "WARNING" for first violation
     * - "BANNED" for repeat violation (locks for 24 hours)
     */
    fun recordViolation(context: Context): ViolationResult {
        val prefs = getPrefs(context)
        val currentWarnings = prefs.getInt(KEY_WARNING_COUNT, 0)
        val newWarningCount = currentWarnings + 1

        if (newWarningCount >= 2) {
            // Ban for 24 hours (24 * 60 * 60 * 1000 ms)
            val banUntil = System.currentTimeMillis() + (24 * 60 * 60 * 1000L)
            prefs.edit()
                .putLong(KEY_BAN_UNTIL, banUntil)
                .putInt(KEY_WARNING_COUNT, newWarningCount)
                .apply()
            return ViolationResult.Banned(banUntil)
        } else {
            // First warning
            prefs.edit()
                .putInt(KEY_WARNING_COUNT, newWarningCount)
                .putLong(KEY_LAST_WARNING_TIME, System.currentTimeMillis())
                .apply()
            return ViolationResult.Warning(
                "⚠️ **सख्त चेतावनी (Safety Warning):**\n" +
                "कृपया AI सहायक के साथ अभद्र, अशोभनीय या गाली-गलौज वाली भाषा का प्रयोग न करें।\n\n" +
                "यदि आपने दोबारा ऐसी भाषा का प्रयोग किया, तो AI सुविधा आपके लिए **24 घंटे (1 दिन) के लिए पूरी तरह बैन (Lock)** कर दी जाएगी।"
            )
        }
    }

    /**
     * Admin or development reset for ban (for testing purposes).
     */
    fun resetBan(context: Context) {
        getPrefs(context).edit().clear().apply()
    }
}

sealed class ViolationResult {
    data class Warning(val message: String) : ViolationResult()
    data class Banned(val banUntilTimestamp: Long) : ViolationResult()
}
