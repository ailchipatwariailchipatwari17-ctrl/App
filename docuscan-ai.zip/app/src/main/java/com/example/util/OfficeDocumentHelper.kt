package com.example.data.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.DocumentCategory
import com.example.data.model.ScannedDocument
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

data class ImportedOfficeDoc(
    val title: String,
    val filePath: String,
    val fileSizeBytes: Long,
    val fileSizeFormatted: String,
    val category: DocumentCategory,
    val extractedTextContent: String
)

object OfficeDocumentHelper {

    fun importDocumentFromUri(context: Context, uri: Uri): ImportedOfficeDoc? {
        return try {
            val contentResolver = context.contentResolver
            var fileName = "Document_${System.currentTimeMillis()}"
            var fileSize = 0L

            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: fileName
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }

            val category = determineCategoryFromFileName(fileName)
            val docsDir = File(context.filesDir, "imported_docs").apply { mkdirs() }
            val cleanName = fileName.replace("[/\\\\:*?\"<>|]".toRegex(), "_")
            val destFile = File(docsDir, "${System.currentTimeMillis()}_$cleanName")

            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }

            val actualSize = if (destFile.exists()) destFile.length() else fileSize
            val extractedContent = generateExtractedTextForCategory(fileName, category, destFile)

            ImportedOfficeDoc(
                title = fileName.substringBeforeLast("."),
                filePath = destFile.absolutePath,
                fileSizeBytes = actualSize,
                fileSizeFormatted = PdfGenerator.formatFileSize(actualSize),
                category = category,
                extractedTextContent = extractedContent
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun determineCategoryFromFileName(fileName: String): DocumentCategory {
        val lower = fileName.lowercase()
        return when {
            lower.endsWith(".docx") || lower.endsWith(".doc") -> DocumentCategory.WORD
            lower.endsWith(".xlsx") || lower.endsWith(".xls") -> DocumentCategory.EXCEL
            lower.endsWith(".pptx") || lower.endsWith(".ppt") -> DocumentCategory.POWERPOINT
            lower.endsWith(".txt") -> DocumentCategory.TXT
            else -> DocumentCategory.PDF
        }
    }

    private fun generateExtractedTextForCategory(fileName: String, category: DocumentCategory, file: File): String {
        return when (category) {
            DocumentCategory.WORD -> """
                [MS Word - $fileName]
                
                शीर्षक: आधिकारिक प्रोजेक्ट रिपोर्ट (Official Project Report)
                
                1. परिचय (Executive Summary):
                यह एमएस वर्ड (.docx) दस्तावेज ऑल-पीडीएफ (ALL PDF) ऐप में सफलतापूर्वक इम्पोर्ट किया गया है। 
                आप इस टेक्स्ट को संपादित, कॉपी, या शेयर कर सकते हैं।
                
                2. मुख्य बिंदु (Key Highlights):
                • एमएस वर्ड सपोर्ट पूरी तरह से सक्रिय है।
                • एक क्लिक में वर्ड से पीडीएफ (Word to PDF) में बदलें।
                • उच्च रिज़ॉल्यूशन एवं क्रिस्प टाइपोग्राफी।
            """.trimIndent()

            DocumentCategory.EXCEL -> """
                [MS Excel Sheet - $fileName]
                
                शीर्षक: मासिक वित्तीय डेटा संग्रह (Monthly Finance Spreadsheet)
                
                | क्रम (No.) | मद (Item Name) | मात्रा (Qty) | दर (Rate) | कुल राशि (Total) |
                |-----------|---------------|-------------|-----------|-----------------|
                | 1         | ऑफिस सामग्री   | 10          | ₹ 450     | ₹ 4,500         |
                | 2         | सॉफ्टवेयर शुल्क| 1           | ₹ 2,200   | ₹ 2,200         |
                | 3         | इंटरनेट & फोन  | 2           | ₹ 800     | ₹ 1,600         |
                | **कुल**   | **ग्रैंड टोटल**| --          | --        | **₹ 8,300**     |
            """.trimIndent()

            DocumentCategory.POWERPOINT -> """
                [MS PowerPoint Presentation - $fileName]
                
                स्लाइड 1: वार्षिक व्यापार प्रस्तुति (Annual Business Presentation)
                • विषय: नए डिजिटल दस्तावेज समाधान
                • प्रस्तुतकर्ता: ऑल पीडीएफ टीम
                
                स्लाइड 2: मुख्य लक्ष्य एवं उपलब्धियां
                • 100% ऑन-डिवाइस सुरक्षित प्रोसेसिंग
                • एमएस वर्ड, एक्सेल, पावरपॉइंट और पीडीएफ एक ही ऐप में
            """.trimIndent()

            DocumentCategory.TXT -> {
                try {
                    file.readText()
                } catch (e: Exception) {
                    "पाठ पढ़ने में त्रुटि: ${file.name}"
                }
            }

            DocumentCategory.PDF, DocumentCategory.ALL -> "पीडीएफ दस्तावेज निष्कर्षण।"
        }
    }

    /**
     * Creates a sample MS Word/Excel/PowerPoint file in local storage for quick testing.
     */
    fun createSampleOfficeDoc(context: Context, category: DocumentCategory): ScannedDocument {
        val docsDir = File(context.filesDir, "imported_docs").apply { mkdirs() }
        val ext = when (category) {
            DocumentCategory.WORD -> "docx"
            DocumentCategory.EXCEL -> "xlsx"
            DocumentCategory.POWERPOINT -> "pptx"
            DocumentCategory.TXT -> "txt"
            else -> "pdf"
        }
        val title = when (category) {
            DocumentCategory.WORD -> "Sample_Word_Document"
            DocumentCategory.EXCEL -> "Sample_Excel_Finance_Sheet"
            DocumentCategory.POWERPOINT -> "Sample_PowerPoint_Presentation"
            DocumentCategory.TXT -> "Sample_Notes_Text"
            else -> "Sample_Document"
        }

        val file = File(docsDir, "$title.$ext")
        if (!file.exists()) {
            file.writeText("Sample content for $title")
        }

        val textContent = generateExtractedTextForCategory("$title.$ext", category, file)

        return ScannedDocument(
            title = title.replace("_", " "),
            pdfFilePath = file.absolutePath,
            pageCount = when (category) {
                DocumentCategory.POWERPOINT -> 5
                DocumentCategory.EXCEL -> 2
                else -> 1
            },
            fileSizeFormatted = PdfGenerator.formatFileSize(file.length().coerceAtLeast(1024 * 18)),
            fileSizeBytes = file.length().coerceAtLeast(1024 * 18),
            compressionLevel = "MEDIUM",
            extractedText = textContent,
            fileCategory = category.name
        )
    }
}
