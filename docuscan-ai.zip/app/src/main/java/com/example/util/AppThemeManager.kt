package com.example.util

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppThemePalette(
    val id: String,
    val nameHindi: String,
    val nameEnglish: String,
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val darkBackground: Color,
    val darkSurface: Color,
    val darkSurfaceVariant: Color,
    val lightBackground: Color = Color(0xFFF8FAFC),
    val lightSurface: Color = Color(0xFFFFFFFF),
    val lightSurfaceVariant: Color = Color(0xFFF1F5F9)
) {
    ACROBAT_RED(
        id = "acrobat_red",
        nameHindi = "ऐक्रोबैट रेड (Classic Red)",
        nameEnglish = "Acrobat Classic Red",
        primaryAccent = Color(0xFFFA0F00),
        secondaryAccent = Color(0xFFFF5252),
        darkBackground = Color(0xFF0A0A0A),
        darkSurface = Color(0xFF141414),
        darkSurfaceVariant = Color(0xFF1F1F1F)
    ),
    CRIMSON_RUBY(
        id = "crimson_ruby",
        nameHindi = "क्रिम्सन रूबी (Ruby Red)",
        nameEnglish = "Crimson Ruby",
        primaryAccent = Color(0xFFDC2626),
        secondaryAccent = Color(0xFFEF4444),
        darkBackground = Color(0xFF120507),
        darkSurface = Color(0xFF1E0A0D),
        darkSurfaceVariant = Color(0xFF2C0F14)
    ),
    ROSE_PINK(
        id = "rose_pink",
        nameHindi = "रोज़ पिंक (Rose Pink)",
        nameEnglish = "Rose Blossom Pink",
        primaryAccent = Color(0xFFF43F5E),
        secondaryAccent = Color(0xFFFB7185),
        darkBackground = Color(0xFF12050A),
        darkSurface = Color(0xFF1F0B13),
        darkSurfaceVariant = Color(0xFF2E111D)
    ),
    NEON_MAGENTA(
        id = "neon_magenta",
        nameHindi = "नियोन मैजेंटा (Neon Magenta)",
        nameEnglish = "Neon Vibrant Magenta",
        primaryAccent = Color(0xFFD946EF),
        secondaryAccent = Color(0xFFE879F9),
        darkBackground = Color(0xFF110414),
        darkSurface = Color(0xFF1F0A24),
        darkSurfaceVariant = Color(0xFF2F1037)
    ),
    PURPLE_AMETHYST(
        id = "purple_amethyst",
        nameHindi = "शाही जामुनी (Royal Purple)",
        nameEnglish = "Amethyst Royal Violet",
        primaryAccent = Color(0xFFA855F7),
        secondaryAccent = Color(0xFFC084FC),
        darkBackground = Color(0xFF0D061A),
        darkSurface = Color(0xFF190C31),
        darkSurfaceVariant = Color(0xFF261348)
    ),
    DEEP_VIOLET(
        id = "deep_violet",
        nameHindi = "डीप वॉयलेट (Deep Violet)",
        nameEnglish = "Deep Electric Violet",
        primaryAccent = Color(0xFF7C3AED),
        secondaryAccent = Color(0xFFA78BFA),
        darkBackground = Color(0xFF0A0416),
        darkSurface = Color(0xFF150A2C),
        darkSurfaceVariant = Color(0xFF201042)
    ),
    NAVY_BLUE(
        id = "navy_blue",
        nameHindi = "रॉयल नेवी ब्लू (Royal Navy)",
        nameEnglish = "Royal Navy Sapphire",
        primaryAccent = Color(0xFF2563EB),
        secondaryAccent = Color(0xFF60A5FA),
        darkBackground = Color(0xFF070B14),
        darkSurface = Color(0xFF0F172A),
        darkSurfaceVariant = Color(0xFF1E293B)
    ),
    SKY_AZURE(
        id = "sky_azure",
        nameHindi = "स्काई अज़्योर (Sky Azure Blue)",
        nameEnglish = "Sky Azure Blue",
        primaryAccent = Color(0xFF0284C7),
        secondaryAccent = Color(0xFF38BDF8),
        darkBackground = Color(0xFF040E17),
        darkSurface = Color(0xFF0A1B2C),
        darkSurfaceVariant = Color(0xFF112942)
    ),
    CYBER_TEAL(
        id = "cyber_teal",
        nameHindi = "साइबर टील (Cyber Teal)",
        nameEnglish = "Cyber Cyan Teal",
        primaryAccent = Color(0xFF06B6D4),
        secondaryAccent = Color(0xFF22D3EE),
        darkBackground = Color(0xFF031418),
        darkSurface = Color(0xFF08272F),
        darkSurfaceVariant = Color(0xFF0E3B46)
    ),
    EMERALD_GREEN(
        id = "emerald_green",
        nameHindi = "एमराल्ड ग्रीन (Emerald Jade)",
        nameEnglish = "Emerald Jade Green",
        primaryAccent = Color(0xFF10B981),
        secondaryAccent = Color(0xFF34D399),
        darkBackground = Color(0xFF021510),
        darkSurface = Color(0xFF06281E),
        darkSurfaceVariant = Color(0xFF0E3D2F)
    ),
    FOREST_LIME(
        id = "forest_lime",
        nameHindi = "फॉरेस्ट लाइम (Forest Lime)",
        nameEnglish = "Fresh Forest Lime",
        primaryAccent = Color(0xFF65A30D),
        secondaryAccent = Color(0xFFA3E635),
        darkBackground = Color(0xFF081203),
        darkSurface = Color(0xFF122406),
        darkSurfaceVariant = Color(0xFF1C360A)
    ),
    ELECTRIC_YELLOW(
        id = "electric_yellow",
        nameHindi = "इलेक्ट्रिक यलो (Electric Yellow)",
        nameEnglish = "Electric Sunflower Yellow",
        primaryAccent = Color(0xFFEAB308),
        secondaryAccent = Color(0xFFFACC15),
        darkBackground = Color(0xFF141002),
        darkSurface = Color(0xFF261F05),
        darkSurfaceVariant = Color(0xFF3B300A)
    ),
    SUNSET_AMBER(
        id = "sunset_amber",
        nameHindi = "गोल्डन सनसेट (Sunset Amber)",
        nameEnglish = "Sunset Gold Amber",
        primaryAccent = Color(0xFFF59E0B),
        secondaryAccent = Color(0xFFFBBF24),
        darkBackground = Color(0xFF120B02),
        darkSurface = Color(0xFF221505),
        darkSurfaceVariant = Color(0xFF34220A)
    ),
    ORANGE_FIRE(
        id = "orange_fire",
        nameHindi = "वाइब्रेंट ऑरेंज (Orange Fire)",
        nameEnglish = "Vibrant Flame Orange",
        primaryAccent = Color(0xFFEA580C),
        secondaryAccent = Color(0xFFFB923C),
        darkBackground = Color(0xFF140803),
        darkSurface = Color(0xFF261107),
        darkSurfaceVariant = Color(0xFF3A1C0D)
    ),
    CORAL_PEACH(
        id = "coral_peach",
        nameHindi = "कोरल पीच (Coral Peach)",
        nameEnglish = "Tropical Coral Peach",
        primaryAccent = Color(0xFFFF6F61),
        secondaryAccent = Color(0xFFFFA07A),
        darkBackground = Color(0xFF140807),
        darkSurface = Color(0xFF261210),
        darkSurfaceVariant = Color(0xFF3A1D1A)
    ),
    GRAPHITE_SLATE(
        id = "graphite_slate",
        nameHindi = "मॉडर्न स्लेट (Graphite Slate)",
        nameEnglish = "Graphite Platinum Slate",
        primaryAccent = Color(0xFF64748B),
        secondaryAccent = Color(0xFF94A3B8),
        darkBackground = Color(0xFF0B0F14),
        darkSurface = Color(0xFF151D26),
        darkSurfaceVariant = Color(0xFF202A36)
    ),
    AMOLED_BLACK(
        id = "amoled_black",
        nameHindi = "AMOLED प्योर ब्लैक (Pitch Black)",
        nameEnglish = "AMOLED Pure Black",
        primaryAccent = Color(0xFFE11D48),
        secondaryAccent = Color(0xFFFB7185),
        darkBackground = Color(0xFF000000),
        darkSurface = Color(0xFF0A0A0A),
        darkSurfaceVariant = Color(0xFF141414)
    )
}

object AppThemeManager {
    private const val PREFS_NAME = "docu_scan_theme_prefs"
    private const val KEY_PALETTE_ID = "selected_palette_id"
    private const val KEY_DARK_MODE = "is_dark_mode"

    private val _currentPalette = MutableStateFlow(AppThemePalette.ACROBAT_RED)
    val currentPaletteFlow: StateFlow<AppThemePalette> = _currentPalette.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkThemeFlow: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedPaletteId = prefs.getString(KEY_PALETTE_ID, AppThemePalette.ACROBAT_RED.id)
        val palette = AppThemePalette.values().find { it.id == savedPaletteId } ?: AppThemePalette.ACROBAT_RED
        val isDark = prefs.getBoolean(KEY_DARK_MODE, true)

        _currentPalette.value = palette
        _isDarkTheme.value = isDark
    }

    fun setPalette(context: Context, palette: AppThemePalette) {
        _currentPalette.value = palette
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PALETTE_ID, palette.id)
            .apply()
    }

    fun setDarkTheme(context: Context, isDark: Boolean) {
        _isDarkTheme.value = isDark
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_DARK_MODE, isDark)
            .apply()
    }

    fun toggleDarkTheme(context: Context) {
        setDarkTheme(context, !_isDarkTheme.value)
    }

    fun getColorScheme(palette: AppThemePalette, isDark: Boolean): ColorScheme {
        return if (isDark) {
            darkColorScheme(
                primary = palette.primaryAccent,
                onPrimary = Color.White,
                primaryContainer = palette.darkSurfaceVariant,
                onPrimaryContainer = Color.White,
                secondary = palette.secondaryAccent,
                onSecondary = Color.Black,
                background = palette.darkBackground,
                onBackground = Color.White,
                surface = palette.darkSurface,
                onSurface = Color.White,
                surfaceVariant = palette.darkSurfaceVariant,
                onSurfaceVariant = Color(0xFFB0B0C0),
                outline = palette.primaryAccent.copy(alpha = 0.5f),
                outlineVariant = Color(0xFF262635)
            )
        } else {
            lightColorScheme(
                primary = palette.primaryAccent,
                onPrimary = Color.White,
                primaryContainer = palette.lightSurfaceVariant,
                onPrimaryContainer = Color.Black,
                secondary = palette.secondaryAccent,
                onSecondary = Color.White,
                background = palette.lightBackground,
                onBackground = Color(0xFF0F172A),
                surface = palette.lightSurface,
                onSurface = Color(0xFF0F172A),
                surfaceVariant = palette.lightSurfaceVariant,
                onSurfaceVariant = Color(0xFF475569),
                outline = palette.primaryAccent.copy(alpha = 0.4f),
                outlineVariant = Color(0xFFE2E8F0)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeSelectionDialog(
    currentPalette: AppThemePalette,
    isDarkMode: Boolean,
    onSelectPalette: (AppThemePalette) -> Unit,
    onToggleDarkMode: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.ColorLens,
                    contentDescription = null,
                    tint = currentPalette.primaryAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "रंग व थीम कस्टमाइज़ करें (Theme Colors)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "होम स्क्रीन और AI असिस्टेंट का पसंदीदा रंग चुनें:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Dark/Light Mode Switch Row
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleDarkMode() },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDarkMode) Color(0xFF1E1E28) else Color(0xFFE2E8F0)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                                contentDescription = null,
                                tint = currentPalette.primaryAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isDarkMode) "डार्क मोड (Dark Theme)" else "लाइट मोड (Light Theme)",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.5.sp
                            )
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { onToggleDarkMode() }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "त्वरित रंग चयन (Quick Swatches):",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Quick Color Swatches Row (1-Tap Change)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    items(AppThemePalette.values().toList()) { palette ->
                        val isSelected = palette == currentPalette
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(palette.primaryAccent)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.4f),
                                    shape = CircleShape
                                )
                                .clickable { onSelectPalette(palette) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                Text(
                    text = "सभी रंग व थीम शैलियाँ (${AppThemePalette.values().size} Colors Available):",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)
                ) {
                    items(AppThemePalette.values()) { palette ->
                        val isSelected = palette == currentPalette
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectPalette(palette) },
                            shape = RoundedCornerShape(12.dp),
                            border = if (isSelected) {
                                BorderStroke(2.dp, palette.primaryAccent)
                            } else {
                                BorderStroke(1.dp, Color(0xFF334155))
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDarkMode) palette.darkSurface else palette.lightSurfaceVariant
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(26.dp)
                                        .background(palette.primaryAccent, CircleShape)
                                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = palette.nameHindi.substringBefore(" ("),
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) palette.primaryAccent else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = palette.nameEnglish.substringBefore(" "),
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = currentPalette.primaryAccent)
            ) {
                Text("लागू करें (Done)", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = if (isDarkMode) Color(0xFF14141E) else Color.White,
        shape = RoundedCornerShape(20.dp)
    )
}
