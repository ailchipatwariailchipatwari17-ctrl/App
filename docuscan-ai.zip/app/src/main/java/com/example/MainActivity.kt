package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.model.ScannedDocument
import com.example.ui.DocumentViewModel
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.CameraCaptureScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OcrDigitizerScreen
import com.example.ui.screens.OfficeDocumentViewerScreen
import com.example.ui.screens.PdfViewerScreen
import com.example.ui.screens.ScanEditorScreen
import com.example.ui.screens.SecuritySettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AppThemeManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {

    private var incomingUriState = mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        AppThemeManager.init(this)

        // Ensure FLAG_SECURE is cleared so streaming emulator preview is visible
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)

        handleIncomingIntent(intent)

        enableEdgeToEdge()
        setContent {
            val isDarkMode by AppThemeManager.isDarkThemeFlow.collectAsStateWithLifecycle()
            val currentPalette by AppThemeManager.currentPaletteFlow.collectAsStateWithLifecycle()

            MyApplicationTheme(palette = currentPalette, darkTheme = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DocuScanApp(
                        incomingUri = incomingUriState.value,
                        onUriProcessed = { incomingUriState.value = null },
                        isDarkMode = isDarkMode,
                        onToggleDarkMode = { AppThemeManager.toggleDarkTheme(this@MainActivity) },
                        onToggleScreenshotProtection = { enable ->
                            if (enable) {
                                window.setFlags(
                                    WindowManager.LayoutParams.FLAG_SECURE,
                                    WindowManager.LayoutParams.FLAG_SECURE
                                )
                            } else {
                                window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action

        val uri: Uri? = when {
            action == Intent.ACTION_VIEW || action == Intent.ACTION_EDIT -> intent.data
            action == Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_STREAM) ?: intent.clipData?.getItemAt(0)?.uri
            }
            action == Intent.ACTION_SEND_MULTIPLE -> {
                intent.clipData?.getItemAt(0)?.uri
            }
            else -> intent.data
        }

        if (uri != null) {
            incomingUriState.value = uri
        }
    }
}

@Composable
fun DocuScanApp(
    incomingUri: Uri?,
    onUriProcessed: () -> Unit,
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onToggleScreenshotProtection: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val viewModel: DocumentViewModel = viewModel()

    var selectedDocumentForView by remember { mutableStateOf<ScannedDocument?>(null) }
    var isHandwritingOcrMode by remember { mutableStateOf(false) }

    LaunchedEffect(incomingUri) {
        if (incomingUri != null) {
            viewModel.importOfficeFileFromUri(context, incomingUri) { importedDoc ->
                selectedDocumentForView = importedDoc
                onUriProcessed()
                if (importedDoc.categoryEnum == com.example.data.model.DocumentCategory.PDF) {
                    navController.navigate("pdf_viewer")
                } else {
                    navController.navigate("office_viewer")
                }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                viewModel = viewModel,
                isDarkMode = isDarkMode,
                onToggleDarkMode = onToggleDarkMode,
                onNavigateToScanEditor = { navController.navigate("camera_scan") },
                onNavigateToOcrDigitizer = { isHandwriting ->
                    isHandwritingOcrMode = isHandwriting
                    navController.navigate("ocr_digitizer")
                },
                onNavigateToSecuritySettings = { navController.navigate("security_settings") },
                onNavigateToAi = { navController.navigate("ai_assistant") },
                onViewDocument = { doc ->
                    selectedDocumentForView = doc
                    if (doc.categoryEnum == com.example.data.model.DocumentCategory.PDF) {
                        navController.navigate("pdf_viewer")
                    } else {
                        navController.navigate("office_viewer")
                    }
                }
            )
        }

        composable("camera_scan") {
            CameraCaptureScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToPointOverlay = { navController.navigate("scan_editor") }
            )
        }

        composable("ai_assistant") {
            AiAssistantScreen(
                initialDocument = selectedDocumentForView,
                onBack = { navController.popBackStack() }
            )
        }

        composable("scan_editor") {
            ScanEditorScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToCamera = {
                    val popped = navController.popBackStack("camera_scan", inclusive = false)
                    if (!popped) {
                        navController.navigate("camera_scan")
                    }
                },
                onSavedAndShared = { savedDoc ->
                    selectedDocumentForView = savedDoc
                    navController.navigate("pdf_viewer")
                },
                onNavigateToOcr = { isHandwriting ->
                    isHandwritingOcrMode = isHandwriting
                    navController.navigate("ocr_digitizer")
                }
            )
        }

        composable("ocr_digitizer") {
            OcrDigitizerScreen(
                viewModel = viewModel,
                isHandwritingMode = isHandwritingOcrMode,
                onBack = { navController.popBackStack() }
            )
        }

        composable("security_settings") {
            SecuritySettingsScreen(
                viewModel = viewModel,
                isDarkMode = isDarkMode,
                onToggleDarkMode = onToggleDarkMode,
                onToggleScreenshotProtection = onToggleScreenshotProtection,
                onBack = { navController.popBackStack() }
            )
        }

        composable("pdf_viewer") {
            val publicDocs by viewModel.publicDocuments.collectAsStateWithLifecycle()
            val vaultDocs by viewModel.vaultDocuments.collectAsStateWithLifecycle()
            val doc = selectedDocumentForView ?: publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()

            if (doc != null) {
                PdfViewerScreen(
                    doc = doc,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onNavigateToAi = { navController.navigate("ai_assistant") },
                    onNavigateToScan = { navController.navigate("camera_scan") },
                    onNavigateToOcr = { isHandwriting ->
                        isHandwritingOcrMode = isHandwriting
                        navController.navigate("ocr_digitizer")
                    }
                )
            } else {
                LaunchedEffect(Unit) {
                    navController.popBackStack()
                }
            }
        }

        composable("office_viewer") {
            val publicDocs by viewModel.publicDocuments.collectAsStateWithLifecycle()
            val vaultDocs by viewModel.vaultDocuments.collectAsStateWithLifecycle()
            val doc = selectedDocumentForView ?: publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()

            if (doc != null) {
                OfficeDocumentViewerScreen(
                    doc = doc,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            } else {
                LaunchedEffect(Unit) {
                    navController.popBackStack()
                }
            }
        }
    }
}

