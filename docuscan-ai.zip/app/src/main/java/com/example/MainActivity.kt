package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.model.ScannedDocument
import com.example.ui.DocumentViewModel
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OcrDigitizerScreen
import com.example.ui.screens.OfficeDocumentViewerScreen
import com.example.ui.screens.PdfViewerScreen
import com.example.ui.screens.ScanEditorScreen
import com.example.ui.screens.SecuritySettingsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Ensure FLAG_SECURE is cleared so streaming emulator preview is visible
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)

        enableEdgeToEdge()
        setContent {
            var isDarkMode by remember { mutableStateOf(false) }

            MyApplicationTheme(darkTheme = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DocuScanApp(
                        isDarkMode = isDarkMode,
                        onToggleDarkMode = { isDarkMode = !isDarkMode },
                        onToggleScreenshotProtection = { enable ->
                            if (enable) {
                                window.setFlags(
                                    WindowManager.LayoutParams.FLAG_SECURE,
                                    WindowManager.LayoutParams.FLAG_SECURE
                                )
                            } else {
                                window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DocuScanApp(
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onToggleScreenshotProtection: (Boolean) -> Unit
) {
    val navController = rememberNavController()
    val viewModel: DocumentViewModel = viewModel()

    var selectedDocumentForView by remember { mutableStateOf<ScannedDocument?>(null) }
    var isHandwritingOcrMode by remember { mutableStateOf(false) }

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                viewModel = viewModel,
                isDarkMode = isDarkMode,
                onToggleDarkMode = onToggleDarkMode,
                onNavigateToScanEditor = { navController.navigate("scan_editor") },
                onNavigateToOcrDigitizer = { isHandwriting ->
                    isHandwritingOcrMode = isHandwriting
                    navController.navigate("ocr_digitizer")
                },
                onNavigateToSecuritySettings = { navController.navigate("security_settings") },
                onViewDocument = { doc ->
                    selectedDocumentForView = doc
                    if (doc.categoryEnum == com.example.data.model.DocumentCategory.PDF) {
                        navController.navigate("pdf_viewer")
                    } else {
                        navController.navigate("office_viewer")
                    }
                }
            )
        }

        composable("scan_editor") {
            ScanEditorScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onSavedAndShared = { navController.popBackStack("home", inclusive = false) },
                onNavigateToOcr = { isHandwriting ->
                    isHandwritingOcrMode = isHandwriting
                    navController.navigate("ocr_digitizer")
                }
            )
        }

        composable("ocr_digitizer") {
            OcrDigitizerScreen(
                viewModel = viewModel,
                isHandwritingMode = isHandwritingOcrMode,
                onBack = { navController.popBackStack() }
            )
        }

        composable("security_settings") {
            SecuritySettingsScreen(
                viewModel = viewModel,
                isDarkMode = isDarkMode,
                onToggleDarkMode = onToggleDarkMode,
                onToggleScreenshotProtection = onToggleScreenshotProtection,
                onBack = { navController.popBackStack() }
            )
        }

        composable("pdf_viewer") {
            selectedDocumentForView?.let { doc ->
                PdfViewerScreen(
                    doc = doc,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }

        composable("office_viewer") {
            selectedDocumentForView?.let { doc ->
                OfficeDocumentViewerScreen(
                    doc = doc,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

