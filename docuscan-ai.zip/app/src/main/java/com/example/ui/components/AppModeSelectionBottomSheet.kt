package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AppDisplayMode
import com.example.util.AppModeManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppModeSelectionBottomSheet(
    currentMode: AppDisplayMode,
    onSelectMode: (AppDisplayMode) -> Unit,
    onDismissRequest: () -> Unit,
    onOpenBlankPdfCreator: () -> Unit = {},
    onOpenAllTools: () -> Unit = {}
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = Color(0xFF14141E),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .background(Color(0xFF3E3E52), RoundedCornerShape(2.dp))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF38BDF8)))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Laptop, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        "वर्कस्पेस मोड",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "मोबाइल या स्टैंडर्ड डेस्कटॉप लेआउट चुनें",
                        color = Color(0xFFA5B4FC),
                        fontSize = 11.sp
                    )
                }
            }

            Divider(color = Color(0xFF262638))

            // Option 1: Normal Mobile Mode
            ModeCardItem(
                title = "📱 मोबाइल मोड",
                subtitle = "स्मार्टफोन के लिए आसान व तीव्र सिंगल-कॉलम लेआउट",
                icon = Icons.Default.Smartphone,
                accentColor = Color(0xFF10B981),
                isSelected = currentMode == AppDisplayMode.NORMAL_MOBILE,
                onClick = {
                    onSelectMode(AppDisplayMode.NORMAL_MOBILE)
                    onDismissRequest()
                }
            )

            // Option 2: Standard Desktop Pro Mode
            ModeCardItem(
                title = "💻 स्टैंडर्ड मोड",
                subtitle = "Adobe & Foxit स्टाइल रिबन टूलबार व फुल वर्कस्पेस",
                icon = Icons.Default.Laptop,
                accentColor = Color(0xFF38BDF8),
                isSelected = currentMode == AppDisplayMode.STANDARD_DESKTOP,
                badge = "PRO",
                onClick = {
                    onSelectMode(AppDisplayMode.STANDARD_DESKTOP)
                    onDismissRequest()
                }
            )

            // Option 3: Auto Detect Mode
            ModeCardItem(
                title = "🔄 ऑटो मोड",
                subtitle = "बड़ी स्क्रीन पर डेस्कटॉप व फोन पर स्वतः मोबाइल मोड",
                icon = Icons.Default.Autorenew,
                accentColor = Color(0xFFF59E0B),
                isSelected = currentMode == AppDisplayMode.AUTO_DETECT,
                onClick = {
                    onSelectMode(AppDisplayMode.AUTO_DETECT)
                    onDismissRequest()
                }
            )

            Divider(color = Color(0xFF262638))

            // Quick Pro Action Buttons
            Text("⚡ क्विक टूल्स:", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            onDismissRequest()
                            onOpenBlankPdfCreator()
                        },
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AddBox, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("🎨 नया PDF", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            onDismissRequest()
                            onOpenAllTools()
                        },
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.GridView, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("🧰 सभी टूल्स", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ModeCardItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    isSelected: Boolean,
    badge: String? = null,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) Color(0xFF1E293B) else Color(0xFF181824),
        border = androidx.compose.foundation.BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) accentColor else Color(0xFF2C2C3E)
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    if (badge != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = accentColor.copy(alpha = 0.2f)
                        ) {
                            Text(
                                badge,
                                color = accentColor,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(subtitle, color = Color(0xFF94A3B8), fontSize = 11.sp, lineHeight = 14.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = accentColor,
                    unselectedColor = Color.Gray
                )
            )
        }
    }
}
