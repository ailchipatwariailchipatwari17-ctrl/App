package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

data class VideoScene(
    val title: String,
    val caption: String,
    val narrationText: String,
    val durationSeconds: Int = 3,
    val imageBitmap: Bitmap? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiVideoStudioDialog(
    initialBitmaps: List<Bitmap> = emptyList(),
    docTitle: String = "ALL PDF Video Story",
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var scenes by remember {
        mutableStateOf(
            if (initialBitmaps.isNotEmpty()) {
                initialBitmaps.mapIndexed { idx, bmp ->
                    VideoScene(
                        title = "Scene ${idx + 1}",
                        caption = "Page ${idx + 1}: ${docTitle.take(20)}",
                        narrationText = "यह दस्तावेज़ का पन्ना संख्या ${idx + 1} है। मुख्य बिंदु यहाँ प्रदर्शित हैं।",
                        imageBitmap = bmp
                    )
                }
            } else {
                listOf(
                    VideoScene("Scene 1: Intro", "🚀 Welcome to ALL PDF", "नमस्कार, ALL PDF में आपका स्वागत है।", 3),
                    VideoScene("Scene 2: Key Points", "📑 Document Summary & Insights", "इस दस्तावेज़ में सभी महत्वपूर्ण बिंदु संक्षेप में दिए गए हैं।", 4),
                    VideoScene("Scene 3: Conclusion", "✅ Verified & Exported", "यह दस्तावेज़ सुरक्षित व प्रमाणित किया गया है।", 3)
                )
            }
        )
    }

    var currentSceneIndex by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var playProgress by remember { mutableFloatStateOf(0f) }
    var isTtsEnabled by remember { mutableStateOf(true) }
    var isGeneratingVideo by remember { mutableStateOf(false) }

    // Aspect ratio: 0 = 9:16 (Shorts/Reels), 1 = 16:9 (Landscape), 2 = 1:1 (Square)
    var selectedAspectRatio by remember { mutableIntStateOf(0) }

    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        var ttsInstance: TextToSpeech? = null
        ttsInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsInstance?.language = Locale("hi", "IN")
            }
        }
        ttsEngine = ttsInstance
        onDispose {
            ttsInstance.stop()
            ttsInstance.shutdown()
        }
    }

    // Playback loop
    LaunchedEffect(isPlaying, currentSceneIndex) {
        if (isPlaying && scenes.isNotEmpty()) {
            val scene = scenes[currentSceneIndex]
            if (isTtsEnabled && scene.narrationText.isNotBlank()) {
                ttsEngine?.speak(scene.narrationText, TextToSpeech.QUEUE_FLUSH, null, "scene_$currentSceneIndex")
            }

            val totalSteps = 30
            val stepDelay = (scene.durationSeconds * 1000L) / totalSteps

            for (i in 1..totalSteps) {
                if (!isPlaying) break
                playProgress = i.toFloat() / totalSteps
                delay(stepDelay)
            }

            if (isPlaying) {
                if (currentSceneIndex < scenes.size - 1) {
                    currentSceneIndex++
                    playProgress = 0f
                } else {
                    isPlaying = false
                    currentSceneIndex = 0
                    playProgress = 0f
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF09090E)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Top App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        ttsEngine?.stop()
                        onDismissRequest()
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI Video Studio (वीडियो व रील्स क्रिएटर)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "PDF to Video Stories & Animated Reels",
                            fontSize = 12.sp,
                            color = TealAccent
                        )
                    }

                    // Ratio Switcher
                    Row(
                        modifier = Modifier
                            .background(Color(0xFF191924), RoundedCornerShape(8.dp))
                            .padding(2.dp)
                    ) {
                        listOf("9:16", "16:9", "1:1").forEachIndexed { idx, label ->
                            val isSel = selectedAspectRatio == idx
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) TealAccent else Color.Transparent)
                                    .clickable { selectedAspectRatio = idx }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    label,
                                    color = if (isSel) Color.Black else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Video Player Area
                val aspectModifier = when (selectedAspectRatio) {
                    0 -> Modifier
                        .height(300.dp)
                        .aspectRatio(9f / 16f)
                    1 -> Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                    else -> Modifier
                        .height(280.dp)
                        .aspectRatio(1f)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = aspectModifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFF1E1B4B), Color(0xFF0F172A), Color(0xFF020617))
                                )
                            )
                            .border(1.5.dp, Color(0xFF312E81), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        val currentScene = scenes.getOrNull(currentSceneIndex)

                        if (currentScene?.imageBitmap != null) {
                            val animatedScale by animateFloatAsState(
                                targetValue = if (isPlaying) 1.08f else 1.0f,
                                animationSpec = tween(durationMillis = 3000, easing = LinearEasing),
                                label = "scale"
                            )
                            Image(
                                bitmap = currentScene.imageBitmap.asImageBitmap(),
                                contentDescription = "Video Frame",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .scale(animatedScale)
                            )
                        } else {
                            // Animated decorative graphic
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(20.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Movie,
                                    contentDescription = null,
                                    tint = TealAccent,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = currentScene?.title ?: "Scene",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        // Subtitle Overlay at Bottom
                        if (currentScene != null && currentScene.caption.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 14.dp, start = 12.dp, end = 12.dp)
                                    .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = currentScene.caption,
                                    color = Color.Yellow,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        // Play/Pause Overlay Indicator
                        if (!isPlaying) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .clickable { isPlaying = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Timeline Progress Bar
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    LinearProgressIndicator(
                        progress = { playProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = TealAccent,
                        trackColor = Color(0xFF222230)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Scene ${currentSceneIndex + 1} of ${scenes.size}",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                        Text(
                            "${scenes.getOrNull(currentSceneIndex)?.durationSeconds ?: 3}s per scene",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }

                // Controls & Scene Customization List
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // Playback Controls Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            isPlaying = !isPlaying
                            if (!isPlaying) ttsEngine?.stop()
                        }) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = TealAccent,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Voiceover TTS Toggle
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isTtsEnabled) Color(0xFF1D283A) else Color(0xFF14141B))
                                .clickable { isTtsEnabled = !isTtsEnabled }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = if (isTtsEnabled) EmeraldGreen else Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "AI Voiceover: ${if (isTtsEnabled) "ON" else "OFF"}",
                                color = if (isTtsEnabled) Color.White else Color.Gray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("सीन और सबटाइटल्स (Scenes & Captions)", color = Color.LightGray, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    // Scene Cards
                    scenes.forEachIndexed { index, scene ->
                        val isCurrent = currentSceneIndex == index
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    currentSceneIndex = index
                                    playProgress = 0f
                                    isPlaying = true
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isCurrent) Color(0xFF1A2234) else Color(0xFF12121A)
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isCurrent) TealAccent else Color(0xFF222230)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        scene.title,
                                        color = if (isCurrent) TealAccent else Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text("${scene.durationSeconds}s", color = Color.Gray, fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "💬 Subtitle: ${scene.caption}",
                                    color = Color.LightGray,
                                    fontSize = 12.sp
                                )
                                Text(
                                    "🗣️ Voice: ${scene.narrationText}",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // Export Video Story Action Button
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF101018),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E2A))
                ) {
                    Button(
                        onClick = {
                            isGeneratingVideo = true
                            coroutineScope.launch {
                                delay(1200)
                                isGeneratingVideo = false
                                Toast.makeText(context, "🎬 AI Video Story सफलतापूर्वक एक्सपोर्ट और सेव की गई!", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFA0F00)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .height(50.dp)
                    ) {
                        if (isGeneratingVideo) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("वीडियो तैयार हो रहा है...", color = Color.White, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI Video Story एक्सपोर्ट करें (Export Video)", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
