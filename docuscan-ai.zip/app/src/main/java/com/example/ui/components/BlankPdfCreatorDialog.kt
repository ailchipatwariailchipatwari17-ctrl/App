package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.TealAccent
import com.example.data.util.PdfGenerator

data class PaperTemplateOption(
    val id: String,
    val title: String,
    val iconDesc: String,
    val previewBg: Color,
    val previewBorder: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlankPdfCreatorDialog(
    onDismissRequest: () -> Unit,
    onPdfCreated: (title: String, subtitle: String, body: String, paperStyle: String, pageSize: String, isLandscape: Boolean, stamp: String?) -> Unit
) {
    val context = LocalContext.current
    var docTitle by remember { mutableStateOf("New Document") }
    var docSubtitle by remember { mutableStateOf("") }
    var docBodyText by remember { mutableStateOf("") }
    var selectedPaperStyle by remember { mutableStateOf("BLANK") }
    var selectedPageSize by remember { mutableStateOf("A4") }
    var isLandscape by remember { mutableStateOf(false) }
    var selectedStamp by remember { mutableStateOf<String?>(null) }
    var includeHeaderFooter by remember { mutableStateOf(true) }

    val paperTemplates = listOf(
        PaperTemplateOption("BLANK", "सादा (Blank)", "📄", Color.White, Color(0xFFCBD5E1)),
        PaperTemplateOption("RULED", "लाइनदार (Ruled)", "📝", Color(0xFFF0FDF4), Color(0xFF86EFAC)),
        PaperTemplateOption("GRID", "ग्रिड (Grid)", "📐", Color(0xFFF8FAFC), Color(0xFF93C5FD)),
        PaperTemplateOption("DOTTED", "डॉटेड (Dots)", "🔘", Color(0xFFFDF4FF), Color(0xFFF472B6)),
        PaperTemplateOption("DARK", "डार्क (Dark)", "🌑", Color(0xFF1E1E28), Color(0xFF6366F1)),
        PaperTemplateOption("VINTAGE", "विंटेज (Sepia)", "📜", Color(0xFFFEF3C7), Color(0xFFF59E0B))
    )

    val pageSizes = listOf("A4", "LETTER", "LEGAL", "A5")
    val stampOptions = listOf(null, "APPROVED", "CONFIDENTIAL", "URGENT", "OFFICIAL", "DRAFT")

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF13131A),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E2E40))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF38BDF8)))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AddBox, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                "नया ब्लैंक PDF डिज़ाइनर",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "100% No Watermark",
                                color = Color(0xFF38BDF8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    IconButton(onClick = onDismissRequest) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Divider(color = Color(0xFF262636), modifier = Modifier.padding(vertical = 10.dp))

                // Content scrollable
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Document Title Input
                    OutlinedTextField(
                        value = docTitle,
                        onValueChange = { docTitle = it },
                        label = { Text("दस्तावेज़ का नाम (Title)", color = Color.LightGray, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF3A3A4C),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Subtitle / Header (Optional)
                    OutlinedTextField(
                        value = docSubtitle,
                        onValueChange = { docSubtitle = it },
                        label = { Text("उप-शीर्षक (वैकल्पिक Subtitle)", color = Color.LightGray, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF3A3A4C),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Paper Pattern Selector
                    Text("1. कागज़ का प्रकार (Paper Style):", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(paperTemplates) { item ->
                            val isSelected = selectedPaperStyle == item.id
                            Surface(
                                modifier = Modifier
                                    .width(115.dp)
                                    .clickable { selectedPaperStyle = item.id },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) Color(0xFF1E293B) else Color(0xFF1A1A24),
                                border = androidx.compose.foundation.BorderStroke(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) Color(0xFF38BDF8) else Color(0xFF2D2D3D)
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(item.previewBg)
                                            .border(1.dp, item.previewBorder, RoundedCornerShape(8.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(item.iconDesc, fontSize = 15.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        item.title,
                                        color = if (isSelected) Color(0xFF38BDF8) else Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }

                    // Page Orientation & Size
                    Text("2. पेज साइज़ व ओरिएंटेशन:", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Orientation Chips
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { isLandscape = false },
                            shape = RoundedCornerShape(10.dp),
                            color = if (!isLandscape) Color(0xFF0F3E5C) else Color(0xFF1A1A24),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (!isLandscape) Color(0xFF38BDF8) else Color(0xFF2D2D3D))
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.Smartphone, contentDescription = null, tint = if (!isLandscape) Color(0xFF38BDF8) else Color.Gray, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("पोर्ट्रेट", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { isLandscape = true },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isLandscape) Color(0xFF0F3E5C) else Color(0xFF1A1A24),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isLandscape) Color(0xFF38BDF8) else Color(0xFF2D2D3D))
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.TabletAndroid, contentDescription = null, tint = if (isLandscape) Color(0xFF38BDF8) else Color.Gray, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("लैंडस्केप", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Size Selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        pageSizes.forEach { size ->
                            val isSel = selectedPageSize == size
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedPageSize = size },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) Color(0xFF0284C7) else Color(0xFF1E1E28),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) Color(0xFF38BDF8) else Color(0xFF2E2E40))
                            ) {
                                Text(
                                    size,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    // Document Body Text (Optional starter content)
                    OutlinedTextField(
                        value = docBodyText,
                        onValueChange = { docBodyText = it },
                        label = { Text("सामग्री / नोट्स (Content)", color = Color.LightGray, fontSize = 12.sp) },
                        placeholder = { Text("यहाँ टेक्स्ट, नोट्स या लिस्ट लिखें...", color = Color.Gray, fontSize = 12.sp) },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF3A3A4C),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Stamp / Seal Badge
                    Text("3. स्टैम्प (Optional Stamp):", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(stampOptions) { stamp ->
                            val isSel = selectedStamp == stamp
                            Surface(
                                modifier = Modifier.clickable { selectedStamp = stamp },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) Color(0xFF1E293B) else Color(0xFF1A1A24),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) Color(0xFF10B981) else Color(0xFF2D2D3D))
                            ) {
                                Text(
                                    stamp ?: "कोई नहीं",
                                    color = if (isSel) Color(0xFF10B981) else Color.LightGray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Action Button
                Button(
                    onClick = {
                        onPdfCreated(
                            docTitle,
                            docSubtitle,
                            docBodyText,
                            selectedPaperStyle,
                            selectedPageSize,
                            isLandscape,
                            selectedStamp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "PDF बनाएं (100% Free)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
