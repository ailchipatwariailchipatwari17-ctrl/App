package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ILoveToolItem
import com.example.ui.theme.TealAccent
import com.example.util.AiPhotoEditingEngine
import com.example.util.AiPhotoFilterType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ILoveImageStudioDialog(
    initialBitmap: Bitmap,
    initialToolId: String = "photo_editor",
    onSaveImage: (Bitmap, String) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var activeTab by remember { mutableStateOf(initialToolId) }
    var currentBitmap by remember { mutableStateOf(initialBitmap) }
    var originalBitmap by remember { mutableStateOf(initialBitmap) }
    var isProcessing by remember { mutableStateOf(false) }

    // Compress Tool States
    var compressQuality by remember { mutableFloatStateOf(75f) }
    var estimatedKb by remember { mutableStateOf(initialBitmap.byteCount / 1024 / 4) }

    // Resize Tool States
    var resizeScalePercent by remember { mutableFloatStateOf(100f) }
    var targetWidthInput by remember { mutableStateOf(initialBitmap.width.toString()) }
    var targetHeightInput by remember { mutableStateOf(initialBitmap.height.toString()) }
    var maintainAspect by remember { mutableStateOf(true) }

    // Crop Tool States
    var selectedCropRatio by remember { mutableStateOf("FREE") } // FREE, 1:1, 4:3, 16:9, 9:16, 3:2

    // Filter & Adjust States
    var selectedFilter by remember { mutableStateOf(AiPhotoFilterType.ORIGINAL) }
    var brightnessVal by remember { mutableFloatStateOf(0f) }
    var contrastVal by remember { mutableFloatStateOf(1f) }
    var saturationVal by remember { mutableFloatStateOf(1f) }
    var warmthVal by remember { mutableFloatStateOf(0f) }
    var vignetteVal by remember { mutableStateOf(false) }

    // Watermark States
    var watermarkText by remember { mutableStateOf("iLoveIMG Watermark") }
    var watermarkOpacity by remember { mutableFloatStateOf(0.7f) }
    var watermarkPosition by remember { mutableStateOf("BOTTOM_RIGHT") } // TOP_LEFT, CENTER, BOTTOM_RIGHT

    // Meme Generator States
    var memeTopText by remember { mutableStateOf("TOP TEXT") }
    var memeBottomText by remember { mutableStateOf("BOTTOM TEXT") }

    // Blur / Censor States
    var blurIntensity by remember { mutableFloatStateOf(25f) }

    // Upscale & AI States
    var upscaleFactor by remember { mutableStateOf(2) }

    fun refreshImageTransformation() {
        isProcessing = true
        coroutineScope.launch {
            try {
                var processed = originalBitmap

                when (activeTab) {
                    "photo_editor" -> {
                        processed = AiPhotoEditingEngine.applyFilter(
                            source = originalBitmap,
                            filterType = selectedFilter,
                            brightness = brightnessVal,
                            contrast = contrastVal,
                            saturationBoost = saturationVal,
                            warmth = warmthVal,
                            vignette = vignetteVal
                        )
                    }
                    "remove_background" -> {
                        processed = AiPhotoEditingEngine.applyFilter(
                            source = originalBitmap,
                            filterType = AiPhotoFilterType.BACKGROUND_CLEAN_WHITE
                        )
                    }
                    "upscale_image" -> {
                        val factor = upscaleFactor.coerceIn(1, 4)
                        val scaled = Bitmap.createScaledBitmap(
                            originalBitmap,
                            (originalBitmap.width * factor).coerceAtMost(3000),
                            (originalBitmap.height * factor).coerceAtMost(3000),
                            true
                        )
                        processed = AiPhotoEditingEngine.applyFilter(
                            source = scaled,
                            filterType = AiPhotoFilterType.SHARPEN_CLEAR,
                            contrast = 1.25f,
                            saturationBoost = 1.15f
                        )
                    }
                    "watermark_image" -> {
                        val out = Bitmap.createBitmap(originalBitmap.width, originalBitmap.height, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(out)
                        canvas.drawBitmap(originalBitmap, 0f, 0f, null)
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = AndroidColor.WHITE
                            alpha = (watermarkOpacity * 255).toInt().coerceIn(20, 255)
                            textSize = (originalBitmap.width * 0.055f).coerceAtLeast(24f)
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            setShadowLayer(6f, 2f, 2f, AndroidColor.argb(180, 0, 0, 0))
                        }
                        val bounds = Rect()
                        paint.getTextBounds(watermarkText, 0, watermarkText.length, bounds)
                        val margin = originalBitmap.width * 0.05f

                        val (x, y) = when (watermarkPosition) {
                            "TOP_LEFT" -> Pair(margin, margin + bounds.height())
                            "CENTER" -> Pair((originalBitmap.width - bounds.width()) / 2f, (originalBitmap.height + bounds.height()) / 2f)
                            else -> Pair(originalBitmap.width - bounds.width() - margin, originalBitmap.height - margin)
                        }
                        canvas.drawText(watermarkText, x, y, paint)
                        processed = out
                    }
                    "meme_generator" -> {
                        val out = Bitmap.createBitmap(originalBitmap.width, originalBitmap.height, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(out)
                        canvas.drawBitmap(originalBitmap, 0f, 0f, null)
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = AndroidColor.WHITE
                            textSize = (originalBitmap.width * 0.085f).coerceAtLeast(32f)
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            textAlign = Paint.Align.CENTER
                        }
                        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = AndroidColor.BLACK
                            textSize = paint.textSize
                            typeface = paint.typeface
                            textAlign = Paint.Align.CENTER
                            style = Paint.Style.STROKE
                            strokeWidth = paint.textSize * 0.12f
                        }
                        val cx = originalBitmap.width / 2f
                        // Top text
                        if (memeTopText.isNotBlank()) {
                            val topY = paint.textSize * 1.2f
                            canvas.drawText(memeTopText.uppercase(), cx, topY, strokePaint)
                            canvas.drawText(memeTopText.uppercase(), cx, topY, paint)
                        }
                        // Bottom text
                        if (memeBottomText.isNotBlank()) {
                            val botY = originalBitmap.height - paint.textSize * 0.5f
                            canvas.drawText(memeBottomText.uppercase(), cx, botY, strokePaint)
                            canvas.drawText(memeBottomText.uppercase(), cx, botY, paint)
                        }
                        processed = out
                    }
                    "blur_face" -> {
                        val out = originalBitmap.copy(Bitmap.Config.ARGB_8888, true)
                        val canvas = Canvas(out)
                        val w = out.width
                        val h = out.height
                        val blurBoxW = (w * 0.35f).toInt()
                        val blurBoxH = (h * 0.35f).toInt()
                        val left = (w - blurBoxW) / 2
                        val top = (h - blurBoxH) / 3
                        val faceSub = Bitmap.createBitmap(originalBitmap, left, top, blurBoxW, blurBoxH)
                        val tiny = Bitmap.createScaledBitmap(faceSub, 12, 12, true)
                        val pixelated = Bitmap.createScaledBitmap(tiny, blurBoxW, blurBoxH, false)
                        canvas.drawBitmap(pixelated, left.toFloat(), top.toFloat(), null)
                        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = AndroidColor.CYAN
                            style = Paint.Style.STROKE
                            strokeWidth = 4f
                        }
                        canvas.drawRect(left.toFloat(), top.toFloat(), (left + blurBoxW).toFloat(), (top + blurBoxH).toFloat(), borderPaint)
                        processed = out
                    }
                    "compress_image" -> {
                        val baos = ByteArrayOutputStream()
                        originalBitmap.compress(Bitmap.CompressFormat.JPEG, compressQuality.toInt(), baos)
                        estimatedKb = baos.size() / 1024
                        processed = originalBitmap
                    }
                    "resize_image" -> {
                        val factor = (resizeScalePercent / 100f).coerceIn(0.1f, 3.0f)
                        val targetW = (originalBitmap.width * factor).toInt().coerceAtLeast(10)
                        val targetH = (originalBitmap.height * factor).toInt().coerceAtLeast(10)
                        processed = Bitmap.createScaledBitmap(originalBitmap, targetW, targetH, true)
                    }
                    "crop_image" -> {
                        val w = originalBitmap.width
                        val h = originalBitmap.height
                        when (selectedCropRatio) {
                            "1:1" -> {
                                val size = Math.min(w, h)
                                processed = Bitmap.createBitmap(originalBitmap, (w - size) / 2, (h - size) / 2, size, size)
                            }
                            "4:3" -> {
                                val targetH = (w * 3) / 4
                                if (targetH <= h) {
                                    processed = Bitmap.createBitmap(originalBitmap, 0, (h - targetH) / 2, w, targetH)
                                }
                            }
                            "16:9" -> {
                                val targetH = (w * 9) / 16
                                if (targetH <= h) {
                                    processed = Bitmap.createBitmap(originalBitmap, 0, (h - targetH) / 2, w, targetH)
                                }
                            }
                            "9:16" -> {
                                val targetW = (h * 9) / 16
                                if (targetW <= w) {
                                    processed = Bitmap.createBitmap(originalBitmap, (w - targetW) / 2, 0, targetW, h)
                                }
                            }
                            else -> processed = originalBitmap
                        }
                    }
                }

                currentBitmap = processed
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isProcessing = false
            }
        }
    }

    LaunchedEffect(
        activeTab,
        selectedFilter,
        brightnessVal,
        contrastVal,
        saturationVal,
        warmthVal,
        vignetteVal,
        compressQuality,
        resizeScalePercent,
        selectedCropRatio,
        watermarkText,
        watermarkOpacity,
        watermarkPosition,
        memeTopText,
        memeBottomText,
        upscaleFactor
    ) {
        refreshImageTransformation()
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0F172A)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // 1. Top Bar with brand and controls
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E293B))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismissRequest) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("iLoveIMG फोटो स्टूडियो", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Text("${currentBitmap.width} × ${currentBitmap.height} px • ${(currentBitmap.byteCount / 1024 / 1024f).let { "%.2f MB".format(it) }}", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }

                    // Rotate Quick Actions
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                val rotated = AiPhotoEditingEngine.rotateBitmap(originalBitmap, 90f)
                                originalBitmap = rotated
                                refreshImageTransformation()
                            }
                        }
                    ) {
                        Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = Color.White)
                    }

                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                val flipped = AiPhotoEditingEngine.flipBitmap(originalBitmap, horizontal = true)
                                originalBitmap = flipped
                                refreshImageTransformation()
                            }
                        }
                    ) {
                        Icon(Icons.Default.Flip, contentDescription = "Flip", tint = Color.White)
                    }

                    // Save / Export Button
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val fileName = "iLoveIMG_${activeTab}_${System.currentTimeMillis()}"
                                onSaveImage(currentBitmap, fileName)
                                Toast.makeText(context, "✨ फ़ोटो सफलतापूर्वक सेव हो गई!", Toast.LENGTH_SHORT).show()
                                onDismissRequest()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("सेव करें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                // 2. Interactive Tool Switcher Tab Ribbon (Horizontal)
                val toolsRibbon = listOf(
                    Triple("photo_editor", "फोटो संपादक", Icons.Default.Edit),
                    Triple("compress_image", "कंप्रेस", Icons.Default.Compress),
                    Triple("resize_image", "रीसाइज़", Icons.Default.PhotoSizeSelectLarge),
                    Triple("crop_image", "क्रॉप", Icons.Default.Crop),
                    Triple("upscale_image", "अपस्केल (AI)", Icons.Default.AutoFixHigh),
                    Triple("remove_background", "बैकग्राउंड हटाएं", Icons.Default.HideImage),
                    Triple("watermark_image", "वॉटरमार्क", Icons.Default.BrandingWatermark),
                    Triple("meme_generator", "मीम जनरेटर", Icons.Default.SentimentVerySatisfied),
                    Triple("blur_face", "चेहरा धुंधला", Icons.Default.BlurOn)
                )

                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E293B).copy(alpha = 0.6f))
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(toolsRibbon) { (id, label, icon) ->
                        val isSelected = activeTab == id
                        Surface(
                            onClick = { activeTab = id },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(0xFF0284C7) else Color(0xFF334155),
                            border = BorderStroke(1.dp, if (isSelected) Color(0xFF38BDF8) else Color(0xFF475569))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, contentDescription = null, tint = if (isSelected) Color.White else Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, color = Color.White)
                            }
                        }
                    }
                }

                // 3. Central Canvas Image Display
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(12.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF020617)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = currentBitmap.asImageBitmap(),
                        contentDescription = "Edited Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )

                    if (isProcessing) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.4f)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = Color(0xFF38BDF8))
                        }
                    }
                }

                // 4. Dynamic Bottom Control Panel based on selected tool
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF1E293B),
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    border = BorderStroke(1.dp, Color(0xFF334155))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        when (activeTab) {
                            "photo_editor" -> {
                                Text("🎨 प्रो फोटो फ़िल्टर और टोन एडजस्टमेंट", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(8.dp))

                                // Filter Chips
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(AiPhotoFilterType.values().take(10)) { filter ->
                                        val isSel = selectedFilter == filter
                                        FilterChip(
                                            selected = isSel,
                                            onClick = { selectedFilter = filter },
                                            label = { Text(filter.hindiName, fontSize = 11.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFF0284C7),
                                                selectedLabelColor = Color.White,
                                                containerColor = Color(0xFF334155),
                                                labelColor = Color(0xFFCBD5E1)
                                            )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("ब्राइटनेस", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.width(65.dp))
                                    Slider(value = brightnessVal, onValueChange = { brightnessVal = it }, valueRange = -50f..50f, modifier = Modifier.weight(1f))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("कंट्रास्ट", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.width(65.dp))
                                    Slider(value = contrastVal, onValueChange = { contrastVal = it }, valueRange = 0.5f..2.0f, modifier = Modifier.weight(1f))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("सैचुरेशन", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.width(65.dp))
                                    Slider(value = saturationVal, onValueChange = { saturationVal = it }, valueRange = 0f..2.5f, modifier = Modifier.weight(1f))
                                }
                            }

                            "compress_image" -> {
                                Text("⚡ इमेज कंप्रेस क्वालिटी व साइज़", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text("अनुमानित साइज़: ~$estimatedKb KB (${(100 - compressQuality).toInt()}% कंप्रेस)", fontSize = 12.sp, color = Color(0xFF38BDF8))
                                Spacer(modifier = Modifier.height(8.dp))
                                Slider(
                                    value = compressQuality,
                                    onValueChange = { compressQuality = it },
                                    valueRange = 15f..95f,
                                    colors = SliderDefaults.colors(thumbColor = Color(0xFF10B981), activeTrackColor = Color(0xFF10B981))
                                )
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("अधिक कंप्रेस (छोटा साइज़)", fontSize = 10.sp, color = Color.Gray)
                                    Text("सर्वोत्तम क्वालिटी", fontSize = 10.sp, color = Color.Gray)
                                }
                            }

                            "resize_image" -> {
                                Text("📐 आयाम व प्रतिशत रीसाइज़", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(25f, 50f, 75f, 100f, 150f, 200f).forEach { pct ->
                                        OutlinedButton(
                                            onClick = { resizeScalePercent = pct },
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (resizeScalePercent == pct) Color(0xFF06B6D4) else Color.Transparent
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text("${pct.toInt()}%", fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }

                            "crop_image" -> {
                                Text("✂️ क्रॉप अनुपात (Aspect Ratio)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("FREE" to "मूल", "1:1" to "1:1 वर्ग", "4:3" to "4:3", "16:9" to "16:9", "9:16" to "9:16 स्टोरी").forEach { (ratio, label) ->
                                        OutlinedButton(
                                            onClick = { selectedCropRatio = ratio },
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (selectedCropRatio == ratio) Color(0xFF0284C7) else Color.Transparent
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(label, fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }

                            "upscale_image" -> {
                                Text("✨ AI सुपर-रेज़ॉल्यूशन अपस्केल", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text("क्वालिटी को बिना खोए पिक्सेल डेन्सिटी और शार्पनेस 2x / 4x बढ़ाएं", fontSize = 11.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    listOf(2 to "2x HD अपस्केल", 4 to "4x अल्ट्रा 4K अपस्केल").forEach { (f, lbl) ->
                                        Button(
                                            onClick = { upscaleFactor = f },
                                            colors = ButtonDefaults.buttonColors(containerColor = if (upscaleFactor == f) Color(0xFF10B981) else Color(0xFF334155)),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(lbl, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            "remove_background" -> {
                                Text("🪄 AI बैकग्राउंड रिमूवल व स्टूडियो बैकड्रॉप", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(
                                        AiPhotoFilterType.BACKGROUND_CLEAN_WHITE to "सफेद स्टूडियो",
                                        AiPhotoFilterType.BACKGROUND_STUDIO_GLOW to "ग्लैम स्पॉटलाइट",
                                        AiPhotoFilterType.BACKGROUND_NATURE_GREENERY to "नेचर ग्रीन",
                                        AiPhotoFilterType.BACKGROUND_SUNSET_GOLDEN to "गोल्डन सनसेट"
                                    ).forEach { (bgFilter, name) ->
                                        OutlinedButton(
                                            onClick = { selectedFilter = bgFilter },
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (selectedFilter == bgFilter) Color(0xFF22C55E) else Color.Transparent
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(name, fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }

                            "watermark_image" -> {
                                Text("🏷️ कस्टम वॉटरमार्क टेक्स्ट व स्थिति", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = watermarkText,
                                    onValueChange = { watermarkText = it },
                                    label = { Text("वॉटरमार्क टेक्स्ट") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("TOP_LEFT" to "ऊपर बाएँ", "CENTER" to "मध्य (Center)", "BOTTOM_RIGHT" to "नीचे दाएँ").forEach { (pos, posLabel) ->
                                        OutlinedButton(
                                            onClick = { watermarkPosition = pos },
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (watermarkPosition == pos) Color(0xFF3B82F6) else Color.Transparent
                                            ),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(posLabel, fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }

                            "meme_generator" -> {
                                Text("🎭 मीम जनरेटर (शीर्षक व बॉटम टेक्स्ट)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = memeTopText,
                                    onValueChange = { memeTopText = it },
                                    label = { Text("शीर्ष टेक्स्ट (Top Text)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = memeBottomText,
                                    onValueChange = { memeBottomText = it },
                                    label = { Text("निचला टेक्स्ट (Bottom Text)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            "blur_face" -> {
                                Text("🔒 चेहरा व सेंसिटिव जानकारी धुंधला करें", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text("गोपनीयता के लिए चेहरा, नंबर प्लेट या निजी डेटा पर ब्लर मास्क लगाएं", fontSize = 11.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(8.dp))
                                Slider(
                                    value = blurIntensity,
                                    onValueChange = { blurIntensity = it },
                                    valueRange = 10f..60f,
                                    colors = SliderDefaults.colors(thumbColor = Color(0xFF0284C7), activeTrackColor = Color(0xFF0284C7))
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
