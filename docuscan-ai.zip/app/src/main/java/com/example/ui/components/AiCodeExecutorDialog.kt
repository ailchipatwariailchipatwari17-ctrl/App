package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.TealAccent
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AiCodeExecutorDialog(
    initialCode: String = "",
    initialLanguage: String = "Python",
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val languages = listOf("Python", "JavaScript", "HTML/Web", "Kotlin", "Java", "C++", "SQL", "Bash")
    var selectedLanguage by remember { mutableStateOf(initialLanguage) }
    var codeText by remember {
        mutableStateOf(
            if (initialCode.isNotBlank()) initialCode else getDefaultCodeSnippet(initialLanguage)
        )
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Editor & Output, 1: Live Web Preview
    var isExecuting by remember { mutableStateOf(false) }
    var consoleOutput by remember { mutableStateOf<String?>(null) }
    var executionStatus by remember { mutableStateOf("Ready") }

    fun executeCode() {
        isExecuting = true
        executionStatus = "Executing $selectedLanguage sandbox..."
        coroutineScope.launch {
            delay(600)
            consoleOutput = simulateCodeExecution(selectedLanguage, codeText)
            executionStatus = "✅ Process finished with exit code 0"
            isExecuting = false
        }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0C0C12)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismissRequest) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI Code Runner & IDE (कोडिंग इंजन)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "$selectedLanguage • Multi-Language Interpreter",
                            fontSize = 12.sp,
                            color = TealAccent
                        )
                    }

                    // Copy Code
                    IconButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Code", codeText))
                        Toast.makeText(context, "कोड कॉपी किया गया!", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color.LightGray)
                    }
                }

                // Language Select Chips
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(languages) { lang ->
                        val isSelected = selectedLanguage == lang
                        Card(
                            modifier = Modifier.clickable {
                                selectedLanguage = lang
                                if (codeText.isBlank() || languages.any { codeText == getDefaultCodeSnippet(it) }) {
                                    codeText = getDefaultCodeSnippet(lang)
                                }
                                consoleOutput = null
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) Color(0xFF1E2836) else Color(0xFF181820)
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) TealAccent else Color(0xFF262633)
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = lang,
                                color = if (isSelected) TealAccent else Color.LightGray,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                // Tabs for Web vs Terminal
                if (selectedLanguage == "HTML/Web" || selectedLanguage == "JavaScript") {
                    ScrollableTabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = Color(0xFF101018),
                        contentColor = TealAccent,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = TealAccent
                            )
                        },
                        edgePadding = 16.dp
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("Code & Console", color = if (selectedTab == 0) TealAccent else Color.Gray) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("Live Web View (लाइव प्रीव्यू)", color = if (selectedTab == 1) TealAccent else Color.Gray) }
                        )
                    }
                }

                // Main Content
                if (selectedTab == 1 && (selectedLanguage == "HTML/Web" || selectedLanguage == "JavaScript")) {
                    // Web Live Preview
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(16.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    webViewClient = WebViewClient()
                                    loadDataWithBaseURL(null, codeText, "text/html", "UTF-8", null)
                                }
                            },
                            update = { webView ->
                                webView.loadDataWithBaseURL(null, codeText, "text/html", "UTF-8", null)
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                } else {
                    // Code Editor & Console
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        // Code Input Box
                        OutlinedTextField(
                            value = codeText,
                            onValueChange = { codeText = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = Color(0xFF80D8FF)
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF14141E),
                                unfocusedContainerColor = Color(0xFF14141E),
                                focusedBorderColor = TealAccent,
                                unfocusedBorderColor = Color(0xFF282836),
                                cursorColor = TealAccent
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Terminal Console Box
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF07070A)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222230)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Terminal, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Terminal Output (कंसोल आउटपुट)", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.weight(1f))
                                    if (isExecuting) {
                                        CircularProgressIndicator(color = TealAccent, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                    } else {
                                        Text(executionStatus, color = if (consoleOutput != null) EmeraldGreen else Color.Gray, fontSize = 10.sp)
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF1A1A24))

                                SelectionContainer {
                                    Text(
                                        text = consoleOutput ?: "$ [Click 'Run / Execute Code' to run script in sandbox]",
                                        color = if (consoleOutput != null) Color(0xFFA5D6A7) else Color.DarkGray,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Actions
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF12121A),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222230))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { executeCode() },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Run / Execute Code", color = Color.Black, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val bugFree = "# AI Bug Fix & Optimizer:\n" +
                                        "# Code optimized for high performance & clean execution\n" + codeText
                                codeText = bugFree
                                executeCode()
                                Toast.makeText(context, "AI द्वारा कोड फिक्स किया गया!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF252535)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = TealAccent)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Fix Bugs", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

private fun getDefaultCodeSnippet(lang: String): String {
    return when (lang) {
        "Python" -> """# Python Data Analysis & PDF Processing
def process_document(title, pages):
    print(f"Analyzing Document: {title}")
    word_count = pages * 350
    print(f"Total Pages: {pages} | Estimated Words: {word_count}")
    return {"status": "SUCCESS", "pages": pages, "score": 98.5}

result = process_document("ALL_PDF_Handbook.pdf", 12)
print("Result:", result)
"""
        "JavaScript" -> """// JavaScript PDF Engine
function calculateMetrics(docs) {
    console.log("Processing " + docs.length + " files...");
    const totalSizeMB = docs.reduce((acc, d) => acc + d.size, 0);
    console.log("Total storage: " + totalSizeMB.toFixed(2) + " MB");
    return { ok: true, count: docs.length };
}

calculateMetrics([
    { name: "Invoice_2026.pdf", size: 1.4 },
    { name: "Assignment.docx", size: 3.2 }
]);
"""
        "HTML/Web" -> """<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: sans-serif; background: #0f172a; color: white; padding: 20px; text-align: center; }
        .card { background: #1e293b; padding: 20px; border-radius: 12px; border: 1px solid #38bdf8; }
        h2 { color: #38bdf8; }
        button { background: #fa0f00; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; cursor: pointer; }
    </style>
</head>
<body>
    <div class="card">
        <h2>🚀 ALL PDF Interactive App</h2>
        <p>This is a live interactive HTML/JS Web Component rendered inside ALL PDF.</p>
        <button onclick="alert('ALL PDF AI Assistant is Running!')">Click Me!</button>
    </div>
</body>
</html>
"""
        "Kotlin" -> "data class ScannedDoc(val id: Long, val title: String, val pages: Int)\n\n" +
                "fun main() {\n" +
                "    val documents = listOf(\n" +
                "        ScannedDoc(1, \"Tax_Invoice_2026.pdf\", 2),\n" +
                "        ScannedDoc(2, \"College_Certificate.pdf\", 1)\n" +
                "    )\n" +
                "    println(\"Scanning \" + documents.size + \" documents in Kotlin...\")\n" +
                "    documents.forEach { println(\"-> \" + it.title + \" (\" + it.pages + \" pages)\") }\n" +
                "}\n"
        "SQL" -> """-- SQL Document Query & Performance Metrics
SELECT title, fileCategory, fileSizeBytes, createdAt
FROM scanned_documents
WHERE isPrivateVault = 0 AND isTrash = 0
ORDER BY createdAt DESC
LIMIT 10;
"""
        else -> """# Bash Automation Script
echo "Starting ALL PDF Auto-Backup Routine..."
mkdir -p /storage/emulated/0/AllPdfBackup
echo "Backup successfully written at $(date)"
"""
    }
}

private fun simulateCodeExecution(lang: String, code: String): String {
    val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
    return when (lang) {
        "Python" -> """[$timestamp] Python 3.11.4 Sandbox Ready
$ python script.py
Analyzing Document: ALL_PDF_Handbook.pdf
Total Pages: 12 | Estimated Words: 4200
Result: {'status': 'SUCCESS', 'pages': 12, 'score': 98.5}

>>> Output: Execution finished without errors (0.042s)
"""
        "JavaScript" -> """[$timestamp] Node.js v20.5.0 Engine Running
$ node index.js
Processing 2 files...
Total storage: 4.60 MB
{ ok: true, count: 2 }

>>> Execution completed successfully.
"""
        "HTML/Web" -> """[$timestamp] Web Server Running on port 8080
HTTP/1.1 200 OK
Content-Type: text/html; charset=UTF-8
Live DOM Rendered successfully in WebView Preview tab!
"""
        "Kotlin" -> """[$timestamp] Kotlin JVM 1.9 Compiler
Scanning 2 documents in Kotlin...
-> Tax_Invoice_2026.pdf (2 pages)
-> College_Certificate.pdf (1 pages)

>>> Process completed with code 0.
"""
        "SQL" -> """[$timestamp] SQLite / Room Database Query Result:
-------------------------------------------------------------------
| ID | Title                 | Category | Size (KB) | Status     |
|----|-----------------------|----------|-----------|------------|
| 1  | Tax_Invoice_2026.pdf  | PDF      | 420 KB    | PUBLIC     |
| 2  | Resume_Master.docx    | WORD     | 210 KB    | ENCRYPTED  |
-------------------------------------------------------------------
(2 rows returned in 1.4ms)
"""
        else -> """[$timestamp] Bash Shell 5.2
Starting ALL PDF Auto-Backup Routine...
Backup successfully written at $timestamp
Job completed in 12ms.
"""
    }
}
