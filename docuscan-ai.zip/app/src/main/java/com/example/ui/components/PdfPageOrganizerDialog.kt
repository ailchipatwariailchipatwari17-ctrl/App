package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CompressionLevel
import com.example.data.model.ScannedDocument
import com.example.data.util.PdfGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class PageItem(
    var id: Long = System.currentTimeMillis() + (0..99999).random(),
    var bitmap: Bitmap,
    var rotationAngle: Float = 0f
)

@Composable
fun PdfPageOrganizerDialog(
    document: ScannedDocument,
    onSaveReorganizedPdf: (File, String) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isLoading by remember { mutableStateOf(true) }
    val pagesList = remember { mutableStateListOf<PageItem>() }
    var selectedIndex by remember { mutableStateOf(0) }
    var isSaving by remember { mutableStateOf(false) }

    LaunchedEffect(document) {
        withContext(Dispatchers.IO) {
            try {
                val pdfFile = File(document.pdfFilePath)
                if (pdfFile.exists()) {
                    val pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                    val renderer = PdfRenderer(pfd)
                    val list = mutableListOf<PageItem>()

                    for (i in 0 until renderer.pageCount) {
                        val page = renderer.openPage(i)
                        val w = page.width * 2
                        val h = page.height * 2
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        list.add(PageItem(bitmap = bmp))
                        page.close()
                    }
                    renderer.close()
                    pfd.close()

                    withContext(Dispatchers.Main) {
                        pagesList.clear()
                        pagesList.addAll(list)
                        selectedIndex = 0
                        isLoading = false
                    }
                } else {
                    withContext(Dispatchers.Main) { isLoading = false }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) { isLoading = false }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0A0A0A)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismissRequest) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Organize Pages (पेज रीऑर्डर व रोटेट)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${document.title} • ${pagesList.size} Total Pages",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }

                if (isLoading) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color(0xFFFA0F00))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Loading document pages...", color = Color.LightGray, fontSize = 13.sp)
                        }
                    }
                } else if (pagesList.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No pages left in this document", color = Color.Gray)
                    }
                } else {
                    // Quick Action Control Bar for Selected Page
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        color = Color(0xFF161616),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF262626))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Selected: Page ${selectedIndex + 1}",
                                color = Color(0xFFFA0F00),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                // Rotate 90 deg
                                IconButton(
                                    onClick = {
                                        if (selectedIndex in pagesList.indices) {
                                            val current = pagesList[selectedIndex]
                                            val matrix = Matrix().apply { postRotate(90f) }
                                            val rotated = Bitmap.createBitmap(current.bitmap, 0, 0, current.bitmap.width, current.bitmap.height, matrix, true)
                                            pagesList[selectedIndex] = current.copy(bitmap = rotated)
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = Color.White)
                                }

                                // Move Left / Up
                                IconButton(
                                    onClick = {
                                        if (selectedIndex > 0) {
                                            val item = pagesList.removeAt(selectedIndex)
                                            pagesList.add(selectedIndex - 1, item)
                                            selectedIndex -= 1
                                        }
                                    },
                                    enabled = selectedIndex > 0,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.ArrowBack,
                                        contentDescription = "Move Prev",
                                        tint = if (selectedIndex > 0) Color.White else Color.DarkGray
                                    )
                                }

                                // Move Right / Down
                                IconButton(
                                    onClick = {
                                        if (selectedIndex < pagesList.size - 1) {
                                            val item = pagesList.removeAt(selectedIndex)
                                            pagesList.add(selectedIndex + 1, item)
                                            selectedIndex += 1
                                        }
                                    },
                                    enabled = selectedIndex < pagesList.size - 1,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.ArrowForward,
                                        contentDescription = "Move Next",
                                        tint = if (selectedIndex < pagesList.size - 1) Color.White else Color.DarkGray
                                    )
                                }

                                // Duplicate
                                IconButton(
                                    onClick = {
                                        if (selectedIndex in pagesList.indices) {
                                            val current = pagesList[selectedIndex]
                                            val copyBmp = current.bitmap.copy(current.bitmap.config ?: Bitmap.Config.ARGB_8888, true)
                                            pagesList.add(selectedIndex + 1, PageItem(bitmap = copyBmp))
                                            Toast.makeText(context, "पेज डुप्लीकेट किया गया", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = Color(0xFF2196F3))
                                }

                                // Delete
                                IconButton(
                                    onClick = {
                                        if (pagesList.size > 1 && selectedIndex in pagesList.indices) {
                                            pagesList.removeAt(selectedIndex)
                                            if (selectedIndex >= pagesList.size) selectedIndex = pagesList.size - 1
                                        } else {
                                            Toast.makeText(context, "कम से कम 1 पेज होना चाहिए", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    enabled = pagesList.size > 1,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = if (pagesList.size > 1) Color(0xFFFF5252) else Color.DarkGray
                                    )
                                }
                            }
                        }
                    }

                    // Grid of Pages
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .weight(1f)
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        itemsIndexed(pagesList) { index, item ->
                            val isSelected = selectedIndex == index
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedIndex = index },
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF181818)),
                                border = androidx.compose.foundation.BorderStroke(
                                    2.dp,
                                    if (isSelected) Color(0xFFFA0F00) else Color(0xFF2A2A2A)
                                )
                            ) {
                                Box {
                                    Image(
                                        bitmap = item.bitmap.asImageBitmap(),
                                        contentDescription = "Page ${index + 1}",
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .aspectRatio(0.7f),
                                        contentScale = ContentScale.Fit
                                    )
                                    Surface(
                                        color = if (isSelected) Color(0xFFFA0F00) else Color(0xCC000000),
                                        shape = RoundedCornerShape(bottomEnd = 6.dp),
                                        modifier = Modifier.align(Alignment.TopStart)
                                    ) {
                                        Text(
                                            text = "${index + 1}",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Save Action
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF121212),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242424))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = {
                                if (pagesList.isEmpty()) return@Button
                                scope.launch(Dispatchers.IO) {
                                    isSaving = true
                                    try {
                                        val bitmaps = pagesList.map { it.bitmap }
                                        val result = PdfGenerator.createPdf(
                                            context = context,
                                            pageBitmaps = bitmaps,
                                            documentTitle = "${document.title}_Organized",
                                            compressionLevel = CompressionLevel.LOW
                                        )
                                        withContext(Dispatchers.Main) {
                                            isSaving = false
                                            onSaveReorganizedPdf(result.file, "${document.title} (Organized)")
                                            onDismissRequest()
                                        }
                                    } catch (e: Exception) {
                                        withContext(Dispatchers.Main) {
                                            isSaving = false
                                            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFA0F00)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            enabled = !isSaving && pagesList.isNotEmpty()
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("नया PDF सेव करें (Save Reorganized PDF)", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
