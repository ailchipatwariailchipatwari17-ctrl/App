package com.example.ui.components

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddHome
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument

/**
 * Authentic 3-Dots / More Document Options Bottom Sheet matching Screenshots 6 & 7:
 *
 * 1. Top Header:
 *    - Circular Document Thumbnail
 *    - Document Title + Blue circle Edit pencil icon
 *    - Subtitle: "1 File | 288 kB | 11 minutes ago"
 *
 * 2. 6 Round Quick Action Buttons:
 *    - 1. PDF / JPG (Red circle)
 *    - 2. Share (Orange circle)
 *    - 3. Send to Email (Blue circle)
 *    - 4. Compress (Green circle)
 *    - 5. Lock (Yellow/Gold circle)
 *    - 6. Delete (Red circle)
 *
 * 3. Categorized Action List:
 *    - Save to Cloud
 *    - Save to Gallery
 *    - Edit (Expandable Accordion):
 *        - Manual Edit ("Edit single/multiple documents one at a time.")
 *        - Batch Edit ("Edit multiple documents at once")
 *    - Move
 *    - MultiSide Doc/Collage
 *    - More (Expandable Accordion):
 *        - Favourite
 *        - Pin Document
 *        - OCR Text
 *        - Copy
 *        - Split
 *        - Rename
 *        - Tags
 *        - Add to Home Screen
 *        - Date and Time setting
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentOptionsBottomSheet(
    doc: ScannedDocument,
    thumbnailBitmap: Bitmap? = null,
    isStarred: Boolean = doc.isStarred,
    isPinned: Boolean = false,
    onDismiss: () -> Unit,
    onOpenPdfJpg: () -> Unit,
    onShare: () -> Unit,
    onSendEmail: () -> Unit,
    onCompress: () -> Unit,
    onLockToggle: () -> Unit,
    onDelete: () -> Unit,
    onSaveToCloud: () -> Unit,
    onSaveToGallery: () -> Unit,
    onManualEdit: () -> Unit,
    onBatchEdit: () -> Unit,
    onMove: () -> Unit,
    onCollage: () -> Unit,
    onToggleFavourite: () -> Unit,
    onTogglePin: () -> Unit,
    onOcrText: () -> Unit,
    onCopyDocument: () -> Unit,
    onSplit: () -> Unit,
    onRename: () -> Unit,
    onTags: () -> Unit,
    onAddToHomeScreen: () -> Unit,
    onDateTimeSetting: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var isEditExpanded by remember { mutableStateOf(true) }
    var isMoreExpanded by remember { mutableStateOf(true) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF141418),
        contentColor = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // 1. TOP HEADER (Screenshots 6 & 7)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Round Circular Thumbnail
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF242430))
                        .border(1.5.dp, Color(0xFF383846), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (thumbnailBitmap != null) {
                        Image(
                            bitmap = thumbnailBitmap.asImageBitmap(),
                            contentDescription = "Document Thumbnail",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = Color(0xFFFA0F00),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                // Title & Subtitle Info
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = doc.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        // Blue edit pencil circle icon
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .background(Color(0xFF00A2E8).copy(alpha = 0.2f), CircleShape)
                                .clickable {
                                    onDismiss()
                                    onRename()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Rename",
                                tint = Color(0xFF00A2E8),
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = "${doc.pageCount} File | ${doc.fileSizeFormatted} | ${doc.formattedDate}",
                        fontSize = 11.sp,
                        color = Color(0xFF9E9EA8)
                    )
                }
            }

            // 2. 6 CIRCULAR QUICK ACTION BUTTONS (Screenshots 6 & 7)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E1E26), RoundedCornerShape(16.dp))
                    .padding(vertical = 14.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. PDF / JPG (Red)
                CircularSheetQuickAction(
                    icon = Icons.Default.PictureAsPdf,
                    label = "PDF / JPG",
                    backgroundColor = Color(0xFFE53935),
                    onClick = {
                        onDismiss()
                        onOpenPdfJpg()
                    }
                )

                // 2. Share (Orange)
                CircularSheetQuickAction(
                    icon = Icons.Default.Share,
                    label = "Share",
                    backgroundColor = Color(0xFFFF9800),
                    onClick = {
                        onDismiss()
                        onShare()
                    }
                )

                // 3. Send to Email (Blue)
                CircularSheetQuickAction(
                    icon = Icons.Default.Email,
                    label = "Send to Email",
                    backgroundColor = Color(0xFF1E88E5),
                    onClick = {
                        onDismiss()
                        onSendEmail()
                    }
                )

                // 4. Compress (Green)
                CircularSheetQuickAction(
                    icon = Icons.Default.AutoAwesome,
                    label = "Compress",
                    backgroundColor = Color(0xFF43A047),
                    onClick = {
                        onDismiss()
                        onCompress()
                    }
                )

                // 5. Lock (Gold/Yellow)
                CircularSheetQuickAction(
                    icon = if (doc.isPrivateVault) Icons.Default.Lock else Icons.Default.LockOpen,
                    label = if (doc.isPrivateVault) "Locked" else "Lock",
                    backgroundColor = Color(0xFFFBC02D),
                    onClick = {
                        onDismiss()
                        onLockToggle()
                    }
                )

                // 6. Delete (Red)
                CircularSheetQuickAction(
                    icon = Icons.Default.Delete,
                    label = "Delete",
                    backgroundColor = Color(0xFFD32F2F),
                    onClick = {
                        onDismiss()
                        onDelete()
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = Color(0xFF262632))
            Spacer(modifier = Modifier.height(6.dp))

            // 3. CATEGORIZED DETAILED ACTIONS LIST (Screenshots 6 & 7)

            // Save to Cloud
            SheetListActionRow(
                icon = Icons.Default.CloudUpload,
                title = "Save to Cloud",
                onClick = {
                    onDismiss()
                    onSaveToCloud()
                }
            )

            // Save to Gallery
            SheetListActionRow(
                icon = Icons.Default.SaveAlt,
                title = "Save to Gallery",
                onClick = {
                    onDismiss()
                    onSaveToGallery()
                }
            )

            // Edit (Expandable Accordion)
            SheetAccordionHeader(
                icon = Icons.Default.Edit,
                title = "Edit",
                isExpanded = isEditExpanded,
                onToggle = { isEditExpanded = !isEditExpanded }
            )

            AnimatedVisibility(visible = isEditExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 32.dp, bottom = 4.dp)
                ) {
                    SheetSubListActionRow(
                        title = "Manual Edit",
                        subtitle = "Edit single/multiple documents one at a time.",
                        onClick = {
                            onDismiss()
                            onManualEdit()
                        }
                    )
                    SheetSubListActionRow(
                        title = "Batch Edit",
                        subtitle = "Edit multiple documents at once",
                        onClick = {
                            onDismiss()
                            onBatchEdit()
                        }
                    )
                }
            }

            // Move
            SheetListActionRow(
                icon = Icons.Default.OpenWith,
                title = "Move",
                onClick = {
                    onDismiss()
                    onMove()
                }
            )

            // MultiSide Doc/Collage
            SheetListActionRow(
                icon = Icons.Default.ViewCarousel,
                title = "MultiSide Doc/Collage",
                onClick = {
                    onDismiss()
                    onCollage()
                }
            )

            // More (Expandable Accordion)
            SheetAccordionHeader(
                icon = Icons.Default.FolderOpen,
                title = "More",
                isExpanded = isMoreExpanded,
                onToggle = { isMoreExpanded = !isMoreExpanded }
            )

            AnimatedVisibility(visible = isMoreExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 32.dp, bottom = 8.dp)
                ) {
                    // Favourite
                    SheetSubListActionRow(
                        title = if (isStarred) "Remove from Favourite" else "Favourite",
                        subtitle = if (isStarred) "Starred document" else "Add to favourite documents",
                        leadingIcon = if (isStarred) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        iconTint = if (isStarred) Color(0xFFFA0F00) else Color(0xFFA0A0AB),
                        onClick = {
                            onDismiss()
                            onToggleFavourite()
                        }
                    )

                    // Pin Document
                    SheetSubListActionRow(
                        title = if (isPinned) "Unpin Document" else "Pin Document",
                        subtitle = "Keep document on top of the list",
                        leadingIcon = Icons.Default.PushPin,
                        onClick = {
                            onDismiss()
                            onTogglePin()
                        }
                    )

                    // OCR Text
                    SheetSubListActionRow(
                        title = "OCR Text",
                        subtitle = "Extract text from image or document",
                        leadingIcon = Icons.Default.TextFields,
                        onClick = {
                            onDismiss()
                            onOcrText()
                        }
                    )

                    // Copy
                    SheetSubListActionRow(
                        title = "Copy",
                        subtitle = "Duplicate this document",
                        leadingIcon = Icons.Default.ContentCopy,
                        onClick = {
                            onDismiss()
                            onCopyDocument()
                        }
                    )

                    // Split
                    SheetSubListActionRow(
                        title = "Split",
                        subtitle = "Extract pages or split into parts",
                        leadingIcon = Icons.Default.GridView,
                        onClick = {
                            onDismiss()
                            onSplit()
                        }
                    )

                    // Rename
                    SheetSubListActionRow(
                        title = "Rename",
                        subtitle = "Change file name",
                        leadingIcon = Icons.Default.Edit,
                        onClick = {
                            onDismiss()
                            onRename()
                        }
                    )

                    // Tags
                    SheetSubListActionRow(
                        title = "Tags",
                        subtitle = "Categorize with custom color tags",
                        leadingIcon = Icons.Default.Label,
                        onClick = {
                            onDismiss()
                            onTags()
                        }
                    )

                    // Add to Home Screen
                    SheetSubListActionRow(
                        title = "Add to Home Screen",
                        subtitle = "Create 1-tap desktop shortcut",
                        leadingIcon = Icons.Default.AddHome,
                        onClick = {
                            onDismiss()
                            onAddToHomeScreen()
                        }
                    )

                    // Date and Time setting
                    SheetSubListActionRow(
                        title = "Date and Time setting",
                        subtitle = "Modify creation timestamp",
                        leadingIcon = Icons.Default.DateRange,
                        onClick = {
                            onDismiss()
                            onDateTimeSetting()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun CircularSheetQuickAction(
    icon: ImageVector,
    label: String,
    backgroundColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .background(backgroundColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 9.5.sp,
            color = Color(0xFFD0D0DA),
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
private fun SheetListActionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = Color(0xFFB0B0C0),
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White
        )
    }
}

@Composable
private fun SheetAccordionHeader(
    icon: ImageVector,
    title: String,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color(0xFFB0B0C0),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        }
        Icon(
            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
            contentDescription = if (isExpanded) "Collapse" else "Expand",
            tint = Color(0xFF888898),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun SheetSubListActionRow(
    title: String,
    subtitle: String,
    leadingIcon: ImageVector? = null,
    iconTint: Color = Color(0xFF00A2E8),
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leadingIcon != null) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFE8E8F0)
            )
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    fontSize = 10.5.sp,
                    color = Color(0xFF888898),
                    lineHeight = 13.sp
                )
            }
        }
    }
}
