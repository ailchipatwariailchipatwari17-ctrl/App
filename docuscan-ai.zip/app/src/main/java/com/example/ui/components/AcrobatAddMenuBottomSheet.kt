package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BrandingWatermark
import androidx.compose.material.icons.filled.CallMerge
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.LanguageManager

enum class AcrobatActionBadge {
    NONE,
    NEW,
    CROWN
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AcrobatAddMenuBottomSheet(
    onDismissRequest: () -> Unit,
    onScanDocument: () -> Unit = {},
    onIdCardScan: () -> Unit = {},
    onMergeSplitPdf: () -> Unit = {},
    onQrBarcodeScan: () -> Unit = {},
    onPdfRepair: () -> Unit = {},
    onComparePdf: () -> Unit = {},
    onCleanHandwriting: () -> Unit = {},
    onOmrScanner: () -> Unit = {},
    onFormulaExtractor: () -> Unit = {},
    onGeneratePodcast: () -> Unit = {},
    onFlashcardQuiz: () -> Unit = {},
    onWatermarkStamp: () -> Unit = {},
    onAudioNotes: () -> Unit = {},
    onSignaturePad: () -> Unit = {},
    onSelectFiles: () -> Unit = {},
    onEditPdf: () -> Unit = {},
    onCreateFromTemplate: () -> Unit = {},
    onCreatePdf: () -> Unit = {},
    onCombineFiles: () -> Unit = onMergeSplitPdf,
    onSeeAllTools: () -> Unit = {},
    onCreatePdfSpace: () -> Unit = {},
    onOpenFile: () -> Unit = onSelectFiles,
    onGetAdobeScan: () -> Unit = onScanDocument,
    onAskAiAssistant: () -> Unit = {},
    onOrganizePages: () -> Unit = onMergeSplitPdf,
    onCompressPdf: () -> Unit = {},
    onOcrScan: () -> Unit = {},
    onRepairPdf: () -> Unit = onPdfRepair,
    onSetPassword: () -> Unit = {},
    onConvertToImages: () -> Unit = {},
    onTranslateDocument: () -> Unit = {},
    onTemplateCreator: () -> Unit = onCreateFromTemplate,
    onCreateBlankPdf: () -> Unit = {},
    onSwitchDisplayMode: () -> Unit = {}
) {
    val context = LocalContext.current
    val languageManager = remember { LanguageManager(context) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = Color(0xFF14141B),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .background(Color(0xFF3A3A4C), RoundedCornerShape(2.dp))
            )
        }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Group 1: AI Actions (Acrobat Dark Theme with Red Accents)
            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Chat,
                    label = languageManager.t("chat_with_pdf"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onAskAiAssistant()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Headphones,
                    label = languageManager.t("generate_podcast"),
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onGeneratePodcast()
                    }
                )
            }

            // Divider Line matching screenshot
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Divider(
                    color = Color(0xFF262634),
                    thickness = 1.dp,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
            }

            // Group 2: Creation & Pro Tools from Adobe Acrobat Screenshot
            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Edit,
                    label = languageManager.t("edit_pdf"),
                    badge = AcrobatActionBadge.CROWN,
                    onClick = {
                        onDismissRequest()
                        onEditPdf()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Bolt,
                    label = languageManager.t("create_from_template"),
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onCreateFromTemplate()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Add,
                    label = "ज़ीरो से नया ब्लैंक PDF बनाएं (Blank Designer)",
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onCreateBlankPdf()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Settings,
                    label = "मोड बदलें (मोबाइल ⟷ डेस्कटॉप स्टैंडर्ड मोड)",
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onSwitchDisplayMode()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.PictureAsPdf,
                    label = languageManager.t("create_pdf"),
                    badge = AcrobatActionBadge.CROWN,
                    onClick = {
                        onDismissRequest()
                        onCreatePdf()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.CallMerge,
                    label = languageManager.t("combine_files"),
                    badge = AcrobatActionBadge.CROWN,
                    onClick = {
                        onDismissRequest()
                        onCombineFiles()
                    }
                )
            }

            // Divider Line before Extended Tools
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Divider(
                    color = Color(0xFF262634),
                    thickness = 1.dp,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
            }

            // Group 3: Extended Tools (Added seamlessly to complete app features)
            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.GridView,
                    label = languageManager.t("see_all_tools"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onSeeAllTools()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.CreditCard,
                    label = languageManager.t("id_card_scan"),
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onIdCardScan()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.QrCodeScanner,
                    label = languageManager.t("qr_barcode_scan"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onQrBarcodeScan()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.AutoFixHigh,
                    label = languageManager.t("clean_handwriting"),
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onCleanHandwriting()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.FactCheck,
                    label = languageManager.t("omr_sheet_evaluator"),
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onOmrScanner()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Functions,
                    label = languageManager.t("formula_extractor"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onFormulaExtractor()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.School,
                    label = languageManager.t("quiz_flashcards"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onFlashcardQuiz()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.BrandingWatermark,
                    label = languageManager.t("watermark_stamp"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onWatermarkStamp()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Mic,
                    label = languageManager.t("voice_audio_notes"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onAudioNotes()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Edit,
                    label = languageManager.t("digital_signature_pad"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onSignaturePad()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Compare,
                    label = languageManager.t("compare_pdf_diff"),
                    badge = AcrobatActionBadge.NONE,
                    onClick = {
                        onDismissRequest()
                        onComparePdf()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.AutoAwesome,
                    label = "AI Document Translator (दस्तावेज़ अनुवाद)",
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onTranslateDocument()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.GridView,
                    label = "PDF to Image Converter (पीडीएफ से फोटो)",
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onConvertToImages()
                    }
                )
            }

            item {
                AcrobatMenuItemRow(
                    icon = Icons.Default.Edit,
                    label = "Invoice & Template Creator (टेम्पलेट से PDF)",
                    badge = AcrobatActionBadge.NEW,
                    onClick = {
                        onDismissRequest()
                        onTemplateCreator()
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(36.dp).navigationBarsPadding())
            }
        }
    }
}

@Composable
fun AcrobatMenuItemRow(
    icon: ImageVector,
    label: String,
    badge: AcrobatActionBadge = AcrobatActionBadge.NONE,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Text(
                text = label,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )

            when (badge) {
                AcrobatActionBadge.NEW -> {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF388E3C), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "New",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                AcrobatActionBadge.CROWN -> {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "Pro",
                        tint = Color(0xFFFFB300),
                        modifier = Modifier.size(20.dp)
                    )
                }
                AcrobatActionBadge.NONE -> {}
            }
        }
    }
}
