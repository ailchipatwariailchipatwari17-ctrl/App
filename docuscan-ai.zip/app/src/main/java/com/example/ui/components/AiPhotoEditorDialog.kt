package com.example.ui.components

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import com.example.util.AiPhotoEditingEngine
import com.example.util.AiPhotoFilterType
import kotlinx.coroutines.launch

@Composable
fun AiPhotoEditorDialog(
    initialBitmap: Bitmap,
    onSaveEditedPhoto: (Bitmap, String) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentBitmap by remember { mutableStateOf(initialBitmap) }
    var selectedFilter by remember { mutableStateOf(AiPhotoFilterType.MAGIC_COLOR) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1.2f) }
    var warmth by remember { mutableFloatStateOf(0f) }
    var vignette by remember { mutableStateOf(false) }
    var showOriginalPreview by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }

    fun reapplyFilters() {
        isProcessing = true
        coroutineScope.launch {
            val edited = AiPhotoEditingEngine.applyFilter(
                source = initialBitmap,
                filterType = selectedFilter,
                brightness = brightness,
                contrast = contrast,
                saturationBoost = saturation,
                warmth = warmth,
                vignette = vignette
            )
            currentBitmap = edited
            isProcessing = false
        }
    }

    LaunchedEffect(selectedFilter, brightness, contrast, saturation, warmth, vignette) {
        reapplyFilters()
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0D0D11)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismissRequest) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI Photo Master (प्रो फोटो एडिटर)",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "HDR Filters • Color Grading • Retouch",
                            fontSize = 11.sp,
                            color = TealAccent
                        )
                    }

                    // Auto-Enhance Button
                    IconButton(
                        onClick = {
                            selectedFilter = AiPhotoFilterType.MAGIC_COLOR
                            brightness = 10f
                            contrast = 1.25f
                            saturation = 1.35f
                            warmth = 5f
                            vignette = false
                            Toast.makeText(context, "✨ AI Master Auto-Enhanced!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Auto Enhance", tint = Color(0xFFFFD700))
                    }

                    // Rotate 90
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                val rotated = AiPhotoEditingEngine.rotateBitmap(currentBitmap, 90f)
                                currentBitmap = rotated
                            }
                        }
                    ) {
                        Icon(Icons.Default.RotateRight, contentDescription = "Rotate 90", tint = Color.White)
                    }

                    // Flip Horizontal
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                val flipped = AiPhotoEditingEngine.flipBitmap(currentBitmap, horizontal = true)
                                currentBitmap = flipped
                            }
                        }
                    ) {
                        Icon(Icons.Default.Flip, contentDescription = "Flip", tint = Color.White)
                    }

                    // Compare Hold Button
                    IconButton(
                        onClick = { showOriginalPreview = !showOriginalPreview }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Compare,
                            contentDescription = "Compare",
                            tint = if (showOriginalPreview) TealAccent else Color.Gray
                        )
                    }
                }

                // Image Preview Canvas
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF16161D)),
                    contentAlignment = Alignment.Center
                ) {
                    val displayBmp = if (showOriginalPreview) initialBitmap else currentBitmap
                    Image(
                        bitmap = displayBmp.asImageBitmap(),
                        contentDescription = "Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )

                    if (isProcessing) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.4f)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = TealAccent)
                        }
                    }

                    if (showOriginalPreview) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                                .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("मूल फ़ोटो (Original)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Editing Controls Bottom Panel
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF14141B))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    // Filter Chips Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("AI मास्टर फ़िल्टर्स (Master Filters)", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (vignette) "Vignette: ON" else "Vignette: OFF",
                            color = if (vignette) TealAccent else Color.Gray,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .clickable { vignette = !vignette }
                                .padding(4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(AiPhotoFilterType.values()) { filter ->
                            val isSelected = selectedFilter == filter
                            Card(
                                modifier = Modifier
                                    .clickable { selectedFilter = filter }
                                    .border(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) TealAccent else Color(0xFF2A2A36),
                                        shape = RoundedCornerShape(10.dp)
                                    ),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) Color(0xFF1E2836) else Color(0xFF1B1B24)
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = TealAccent,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }
                                    Column {
                                        Text(
                                            text = filter.displayName,
                                            color = if (isSelected) TealAccent else Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Text(
                                            text = filter.hindiName,
                                            color = Color.Gray,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Sliders
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("चमक (Light)", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(85.dp))
                        Slider(
                            value = brightness,
                            onValueChange = { brightness = it },
                            valueRange = -60f..60f,
                            colors = SliderDefaults.colors(
                                thumbColor = TealAccent,
                                activeTrackColor = TealAccent,
                                inactiveTrackColor = Color(0xFF2C2C38)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("कंट्रास्ट (Depth)", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(85.dp))
                        Slider(
                            value = contrast,
                            onValueChange = { contrast = it },
                            valueRange = 0.6f..2.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFA0F00),
                                activeTrackColor = Color(0xFFFA0F00),
                                inactiveTrackColor = Color(0xFF2C2C38)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("रंग (Vibrance)", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(85.dp))
                        Slider(
                            value = saturation,
                            onValueChange = { saturation = it },
                            valueRange = 0.0f..2.2f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFFB300),
                                activeTrackColor = Color(0xFFFFB300),
                                inactiveTrackColor = Color(0xFF2C2C38)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Save Button
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val path = AiPhotoEditingEngine.saveBitmapToCache(context, currentBitmap)
                                onSaveEditedPhoto(currentBitmap, path)
                                Toast.makeText(context, "✅ मास्टर फोटो सफलतापूर्वक सेव की गई!", Toast.LENGTH_SHORT).show()
                                onDismissRequest()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFA0F00)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("मास्टर फ़ोटो सेव करें (Save Master Photo)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
