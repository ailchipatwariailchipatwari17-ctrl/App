package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import com.example.util.AppThemeManager
import com.example.util.AppThemePalette

@Composable
fun MyApplicationTheme(
    palette: AppThemePalette = AppThemePalette.ACROBAT_RED,
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = AppThemeManager.getColorScheme(palette, darkTheme)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

