package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ToolMainType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ILoveDrawerBottomSheet(
    onDismissRequest: () -> Unit,
    onSelectMainMode: (ToolMainType) -> Unit,
    onSwitchAppDisplayMode: () -> Unit,
    onOpenLanguageDialog: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenAiSpaces: () -> Unit,
    onOpenBlankPdf: () -> Unit,
    onOpenFiles: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        containerColor = Color(0xFF0F172A),
        contentColor = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("i", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                    Text("PDF & IMG सुइट", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                IconButton(onClick = onDismissRequest) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                }
            }

            Text(
                text = "सभी टूल्स, फोटो एडिटर और PDF टूल्स सुइट",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Main Primary Sections
            Text("मुख्य टूल्स वर्ग (Main Suites)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
            Spacer(modifier = Modifier.height(8.dp))

            DrawerNavMenuItem(
                title = "iLovePDF टूल्स (मर्ज, स्प्लिट, कंप्रेस, कन्वर्ट)",
                subtitle = "PDF फाइलों को जोड़ें, काटें, कंप्रेस व प्रोटेक्ट करें",
                icon = Icons.Default.PictureAsPdf,
                accentColor = Color(0xFFEF4444),
                onClick = {
                    onSelectMainMode(ToolMainType.PDF)
                    onDismissRequest()
                }
            )

            DrawerNavMenuItem(
                title = "iLoveIMG फोटो एडिटर (फोटो एडिट अलग)",
                subtitle = "कंप्रेस, रीसाइज़, क्रॉप, बैकग्राउंड रिमूवल, मीम व अपस्केल",
                icon = Icons.Default.Image,
                accentColor = Color(0xFF0284C7),
                onClick = {
                    onSelectMainMode(ToolMainType.IMAGE)
                    onDismissRequest()
                }
            )

            DrawerNavMenuItem(
                title = "क्रिएटर्स व AI को-पायलट (Workflows)",
                subtitle = "ब्लैंक डिज़ाइनर, ID कार्ड 2-इन-1, इनवॉइस व AI स्पेसेज",
                icon = Icons.Default.AutoAwesome,
                accentColor = Color(0xFF8B5CF6),
                onClick = {
                    onSelectMainMode(ToolMainType.WORKFLOW)
                    onDismissRequest()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Actions
            Text("त्वरित कार्य (Quick Utilities)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
            Spacer(modifier = Modifier.height(8.dp))

            DrawerNavMenuItem(
                title = "कागजी दस्तावेज़ स्कैन करें (Camera Scanner)",
                subtitle = "HD ऑटो-एज डिटेक्शन और OCR",
                icon = Icons.Default.DocumentScanner,
                accentColor = Color(0xFF10B981),
                onClick = {
                    onDismissRequest()
                    onOpenScanner()
                }
            )

            DrawerNavMenuItem(
                title = "नया ब्लैंक PDF डिज़ाइन करें (Blank PDF)",
                subtitle = "शून्य से अपनी पसंद का कैनवास बनाएं",
                icon = Icons.Default.NoteAdd,
                accentColor = Color(0xFFF97316),
                onClick = {
                    onDismissRequest()
                    onOpenBlankPdf()
                }
            )

            DrawerNavMenuItem(
                title = "फाइल मैनेजर / डिवाइस से खोलें (Open File)",
                subtitle = "PDF, Word, Excel, PPT, Images",
                icon = Icons.Default.FolderOpen,
                accentColor = Color(0xFF3B82F6),
                onClick = {
                    onDismissRequest()
                    onOpenFiles()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Settings & Workspace Switch
            Text("वर्कस्पेस व सेटिंग्स (Preferences)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
            Spacer(modifier = Modifier.height(8.dp))

            DrawerNavMenuItem(
                title = "डेस्कटॉप रिबन ⟷ मोबाइल मोड स्विच करें",
                subtitle = "स्टैंडर्ड डेस्कटॉप वर्कस्पेस और मोबाइल व्यू बदलें",
                icon = Icons.Default.LaptopMac,
                accentColor = Color(0xFF10B981),
                onClick = {
                    onDismissRequest()
                    onSwitchAppDisplayMode()
                }
            )

            DrawerNavMenuItem(
                title = "भाषा बदलें (Language Settings)",
                subtitle = "हिंदी, English, मराठी, गुजराती, आदि",
                icon = Icons.Default.Language,
                accentColor = Color(0xFFF59E0B),
                onClick = {
                    onDismissRequest()
                    onOpenLanguageDialog()
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DrawerNavMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1E293B),
        border = BorderStroke(1.dp, Color(0xFF334155)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = accentColor.copy(alpha = 0.2f),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(subtitle, fontSize = 11.sp, color = Color(0xFF94A3B8), maxLines = 1)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
        }
    }
}
