package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryNavy = Color(0xFF0F172A)
val PrimaryNavyLight = Color(0xFF1E293B)
val TealAccent = Color(0xFF0D9488)
val TealAccentLight = Color(0xFF14B8A6)
val SoftCyan = Color(0xFFE0F2FE)
val EmeraldGreen = Color(0xFF10B981)
val VaultAmber = Color(0xFFF59E0B)

// MS Office & Document Format Colors
val WordBlue = Color(0xFF185ABD)
val ExcelGreen = Color(0xFF107C41)
val PptOrange = Color(0xFFC43E1C)
val PdfRed = Color(0xFFE11D48)
val TextNavy = Color(0xFF334155)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF161E2E)
val DarkSurfaceVariant = Color(0xFF1F293D)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
