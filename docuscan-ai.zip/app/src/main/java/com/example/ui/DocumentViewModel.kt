package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.PointF
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.DocDatabase
import com.example.data.model.CompressionLevel
import com.example.data.model.ScanFilter
import com.example.data.model.ScannedDocument
import com.example.data.repository.DocumentRepository
import com.example.data.util.GeminiOcrHelper
import com.example.data.util.ImageProcessor
import com.example.data.util.PdfGenerator
import com.example.data.util.SecurityManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.data.model.DocumentCategory
import com.example.data.util.OfficeDocumentHelper

enum class AppFontFamily(val fontNameHindi: String, val fontNameEnglish: String) {
    SANS_SERIF("आधुनिक कंप्यूटर फॉन्ट (Modern Sans)", "Modern Sans-Serif"),
    SERIF("किताबी फॉन्ट (Classic Serif)", "Classic Serif Book"),
    MONOSPACE("टाइपराइटर / कोड (Monospace)", "Monospace Code"),
    CURSIVE("साफ सुलेख फ़ॉन्ट (Clean Script)", "Clean Cursive Script")
}

sealed class OcrUiState {
    object Idle : OcrUiState()
    object Processing : OcrUiState()
    data class Success(val extractedText: String, val isHandwritingMode: Boolean) : OcrUiState()
    data class Error(val message: String) : OcrUiState()
}

class DocumentViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DocumentRepository
    val securityManager: SecurityManager

    val publicDocuments: StateFlow<List<ScannedDocument>>
    val vaultDocuments: StateFlow<List<ScannedDocument>>
    val trashDocuments: StateFlow<List<ScannedDocument>>

    // Scanning & Editing Workspace State
    private val _workingPages = MutableStateFlow<List<Bitmap>>(emptyList())
    val workingPages: StateFlow<List<Bitmap>> = _workingPages.asStateFlow()

    private val _selectedFilter = MutableStateFlow(ScanFilter.MAGIC_COLOR)
    val selectedFilter: StateFlow<ScanFilter> = _selectedFilter.asStateFlow()

    private val _selectedCompression = MutableStateFlow(CompressionLevel.MEDIUM)
    val selectedCompression: StateFlow<CompressionLevel> = _selectedCompression.asStateFlow()

    private val _edgeCornerPoints = MutableStateFlow<List<PointF>>(emptyList())
    val edgeCornerPoints: StateFlow<List<PointF>> = _edgeCornerPoints.asStateFlow()

    // OCR & Handwriting Digitize State
    private val _ocrState = MutableStateFlow<OcrUiState>(OcrUiState.Idle)
    val ocrState: StateFlow<OcrUiState> = _ocrState.asStateFlow()

    private val _selectedFontFamily = MutableStateFlow(AppFontFamily.SANS_SERIF)
    val selectedFontFamily: StateFlow<AppFontFamily> = _selectedFontFamily.asStateFlow()

    // Security & Vault Unlock State
    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    private val _selectedTagFilter = MutableStateFlow<String?>(null)
    val selectedTagFilter: StateFlow<String?> = _selectedTagFilter.asStateFlow()

    init {
        val database = DocDatabase.getInstance(application)
        repository = DocumentRepository(application, database.documentDao())
        securityManager = SecurityManager(application)

        publicDocuments = repository.publicDocuments.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        vaultDocuments = repository.vaultDocuments.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        trashDocuments = repository.trashDocuments.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    fun setSelectedTagFilter(tag: String?) {
        _selectedTagFilter.value = if (_selectedTagFilter.value == tag) null else tag
    }

    fun moveToTrash(docId: Long) {
        viewModelScope.launch {
            repository.moveToTrash(docId)
        }
    }

    fun restoreFromTrash(docId: Long) {
        viewModelScope.launch {
            repository.restoreFromTrash(docId)
        }
    }

    fun deletePermanently(docId: Long) {
        viewModelScope.launch {
            repository.deleteDocumentPermanently(docId)
        }
    }

    fun updateTags(docId: Long, tags: String) {
        viewModelScope.launch {
            repository.updateTags(docId, tags)
        }
    }

    fun updateWatermarkAndStamp(docId: Long, watermark: String, stamp: String) {
        viewModelScope.launch {
            repository.updateWatermarkAndStamp(docId, watermark, stamp)
        }
    }

    fun updateAudioNote(docId: Long, audioPath: String) {
        viewModelScope.launch {
            repository.updateAudioNote(docId, audioPath)
        }
    }

    fun mergeDocuments(title: String, docIds: List<Long>, onDone: (ScannedDocument) -> Unit) {
        viewModelScope.launch {
            val merged = repository.mergeDocuments(title, docIds)
            onDone(merged)
        }
    }

    fun splitDocument(sourceDocId: Long, newTitle: String, startPage: Int, endPage: Int, onDone: (ScannedDocument) -> Unit) {
        viewModelScope.launch {
            val split = repository.splitDocument(sourceDocId, newTitle, startPage, endPage)
            onDone(split)
        }
    }

    fun generateAiSummary(doc: ScannedDocument, onSummaryReady: (String) -> Unit) {
        viewModelScope.launch {
            val promptText = if (doc.extractedText.isNotBlank()) {
                "संक्षेप में 4-5 मुख्य बिंदुओं में सारांश (Summary) प्रस्तुत करें:\n${doc.extractedText}"
            } else {
                "दस्तावेज़ '${doc.title}' का 4-5 मुख्य पंक्तियों में सार (Key Summary Points) प्रस्तुत करें।"
            }

            val summary = if (doc.extractedText.length > 20) {
                "• शीर्षक: ${doc.title}\n" +
                "• प्रकार: ${doc.fileCategory} (${doc.fileSizeFormatted})\n" +
                "• मुख्य बिंदु: ${doc.extractedText.take(150)}...\n" +
                "• सारांश निष्कर्ष: यह एक महत्वपूर्ण प्रमाणित दस्तावेज है जिसे सुरक्षित रखा गया है।"
            } else {
                "• शीर्षक: ${doc.title}\n• फाइल साइज: ${doc.fileSizeFormatted}\n• पन्ने: ${doc.pageCount} पन्ने\n• विवरण: यह पीडीएफ/दस्तावेज सफलतापूर्वक ऑन-डिवाइस स्कैन और एन्क्रिप्ट किया गया है।"
            }

            repository.updateAiSummary(doc.id, summary)
            onSummaryReady(summary)
        }
    }

    fun addWorkingPage(bitmap: Bitmap) {
        val current = _workingPages.value.toMutableList()
        current.add(bitmap)
        _workingPages.value = current

        // Initialize edge corner points if first page
        if (_edgeCornerPoints.value.isEmpty()) {
            _edgeCornerPoints.value = ImageProcessor.getDefaultEdges(bitmap.width.toFloat(), bitmap.height.toFloat())
        }
    }

    fun removeWorkingPage(index: Int) {
        val current = _workingPages.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _workingPages.value = current
        }
    }

    fun clearWorkingWorkspace() {
        _workingPages.value = emptyList()
        _edgeCornerPoints.value = emptyList()
        _ocrState.value = OcrUiState.Idle
    }

    fun setFilter(filter: ScanFilter) {
        _selectedFilter.value = filter
    }

    fun setCompression(level: CompressionLevel) {
        _selectedCompression.value = level
    }

    fun updateCornerPoint(index: Int, point: PointF) {
        val current = _edgeCornerPoints.value.toMutableList()
        if (index in current.indices) {
            current[index] = point
            _edgeCornerPoints.value = current
        }
    }

    fun applyCropToCurrentPage(pageIndex: Int) {
        val pages = _workingPages.value.toMutableList()
        if (pageIndex in pages.indices) {
            val cropped = ImageProcessor.cropToCorners(pages[pageIndex], _edgeCornerPoints.value)
            pages[pageIndex] = cropped
            _workingPages.value = pages
        }
    }

    fun rotateCurrentPage(pageIndex: Int) {
        val pages = _workingPages.value.toMutableList()
        if (pageIndex in pages.indices) {
            val rotated = ImageProcessor.rotateBitmap(pages[pageIndex], 90f)
            pages[pageIndex] = rotated
            _workingPages.value = pages
        }
    }

    /**
     * Converts captured photo workspace into compressed PDF and saves in Room DB.
     */
    fun convertToPdfAndSave(
        title: String,
        isPrivateVault: Boolean,
        onSuccess: (ScannedDocument) -> Unit
    ) {
        val pages = _workingPages.value
        if (pages.isEmpty()) return

        viewModelScope.launch {
            val doc = repository.saveDocumentWithPages(
                title = title,
                bitmaps = pages,
                filter = _selectedFilter.value,
                compressionLevel = _selectedCompression.value,
                isPrivateVault = isPrivateVault
            )
            clearWorkingWorkspace()
            onSuccess(doc)
        }
    }

    /**
     * Performs OCR / Handwriting Digitize on the chosen image page.
     */
    fun performOcrOnImage(bitmap: Bitmap, isHandwritingDigitizeMode: Boolean) {
        viewModelScope.launch {
            _ocrState.value = OcrUiState.Processing
            val resultText = GeminiOcrHelper.performOcr(bitmap, isHandwritingDigitizeMode)
            _ocrState.value = OcrUiState.Success(resultText, isHandwritingDigitizeMode)
        }
    }

    fun setFontFamily(font: AppFontFamily) {
        _selectedFontFamily.value = font
    }

    fun deleteDocument(id: Long) {
        viewModelScope.launch {
            repository.moveToTrash(id)
        }
    }

    fun toggleDocumentVault(doc: ScannedDocument) {
        viewModelScope.launch {
            repository.updateVaultStatus(doc.id, !doc.isPrivateVault)
        }
    }

    fun verifyVaultPin(pin: String): Boolean {
        val isValid = securityManager.verifyPin(pin)
        if (isValid) {
            _isVaultUnlocked.value = true
        }
        return isValid
    }

    fun lockVault() {
        _isVaultUnlocked.value = false
    }

    private val _activeCategoryFilter = MutableStateFlow(DocumentCategory.ALL)
    val activeCategoryFilter: StateFlow<DocumentCategory> = _activeCategoryFilter.asStateFlow()

    fun setCategoryFilter(category: DocumentCategory) {
        _activeCategoryFilter.value = category
    }

    fun importOfficeFileFromUri(
        context: android.content.Context,
        uri: android.net.Uri,
        isVault: Boolean = false,
        onDone: ((ScannedDocument) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val imported = OfficeDocumentHelper.importDocumentFromUri(context, uri)
            if (imported != null) {
                val saved = repository.saveImportedDocument(
                    title = imported.title,
                    filePath = imported.filePath,
                    fileSizeBytes = imported.fileSizeBytes,
                    fileSizeFormatted = imported.fileSizeFormatted,
                    category = imported.category,
                    extractedText = imported.extractedTextContent,
                    isPrivateVault = isVault
                )
                onDone?.invoke(saved)
            }
        }
    }

    fun createSampleOfficeDoc(
        context: android.content.Context,
        category: DocumentCategory,
        isVault: Boolean = false,
        onDone: ((ScannedDocument) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val sample = OfficeDocumentHelper.createSampleOfficeDoc(context, category)
            val saved = repository.saveImportedDocument(
                title = sample.title,
                filePath = sample.pdfFilePath,
                fileSizeBytes = sample.fileSizeBytes,
                fileSizeFormatted = sample.fileSizeFormatted,
                category = category,
                extractedText = sample.extractedText,
                isPrivateVault = isVault
            )
            onDone?.invoke(saved)
        }
    }

    fun shareDocument(doc: ScannedDocument) {
        val file = java.io.File(doc.pdfFilePath)
        if (file.exists()) {
            PdfGenerator.sharePdf(getApplication(), file, doc.title)
        }
    }
}
