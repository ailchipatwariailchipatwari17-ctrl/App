package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.PointF
import java.io.File
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.DocDatabase
import com.example.data.model.CompressionLevel
import com.example.data.model.ScanFilter
import com.example.data.model.ScannedDocument
import com.example.data.repository.DocumentRepository
import com.example.data.util.GeminiOcrHelper
import com.example.data.util.ImageProcessor
import com.example.data.util.PdfGenerator
import com.example.data.util.SecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import com.example.data.model.DocumentCategory
import com.example.data.util.OfficeDocumentHelper

enum class AppFontFamily(val fontNameHindi: String, val fontNameEnglish: String) {
    SANS_SERIF("आधुनिक कंप्यूटर फॉन्ट (Modern Sans)", "Modern Sans-Serif"),
    SERIF("किताबी फॉन्ट (Classic Serif)", "Classic Serif Book"),
    MONOSPACE("टाइपराइटर / कोड (Monospace)", "Monospace Code"),
    CURSIVE("साफ सुलेख फ़ॉन्ट (Clean Script)", "Clean Cursive Script")
}

sealed class OcrUiState {
    object Idle : OcrUiState()
    object Processing : OcrUiState()
    data class Success(val extractedText: String, val isHandwritingMode: Boolean) : OcrUiState()
    data class Error(val message: String) : OcrUiState()
}

class DocumentViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DocumentRepository
    val securityManager: SecurityManager

    val publicDocuments: StateFlow<List<ScannedDocument>>
    val vaultDocuments: StateFlow<List<ScannedDocument>>
    val trashDocuments: StateFlow<List<ScannedDocument>>

    // Scanning & Editing Workspace State
    private val _workingPages = MutableStateFlow<List<Bitmap>>(emptyList())
    val workingPages: StateFlow<List<Bitmap>> = _workingPages.asStateFlow()

    private val _selectedFilter = MutableStateFlow(ScanFilter.MAGIC_COLOR)
    val selectedFilter: StateFlow<ScanFilter> = _selectedFilter.asStateFlow()

    private val _selectedCompression = MutableStateFlow(CompressionLevel.MEDIUM)
    val selectedCompression: StateFlow<CompressionLevel> = _selectedCompression.asStateFlow()

    private val _edgeCornerPoints = MutableStateFlow<List<PointF>>(emptyList())
    val edgeCornerPoints: StateFlow<List<PointF>> = _edgeCornerPoints.asStateFlow()

    // OCR & Handwriting Digitize State
    private val _ocrState = MutableStateFlow<OcrUiState>(OcrUiState.Idle)
    val ocrState: StateFlow<OcrUiState> = _ocrState.asStateFlow()

    private val _selectedFontFamily = MutableStateFlow(AppFontFamily.SANS_SERIF)
    val selectedFontFamily: StateFlow<AppFontFamily> = _selectedFontFamily.asStateFlow()

    // Security & Vault Unlock State
    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    private val _selectedTagFilter = MutableStateFlow<String?>(null)
    val selectedTagFilter: StateFlow<String?> = _selectedTagFilter.asStateFlow()

    init {
        val database = DocDatabase.getInstance(application)
        repository = DocumentRepository(application, database.documentDao())
        securityManager = SecurityManager(application)

        publicDocuments = repository.publicDocuments.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        vaultDocuments = repository.vaultDocuments.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        trashDocuments = repository.trashDocuments.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        // Ensure authentic study notes PDF is available for instant Liquid Mode testing
        viewModelScope.launch {
            com.example.util.SampleDataGenerator.ensureTestPdfAvailable(
                context = application,
                dao = database.documentDao()
            )
        }
    }

    fun purgeSampleDocuments() {
        viewModelScope.launch {
            val database = DocDatabase.getInstance(getApplication())
            com.example.util.SampleDataGenerator.purgeAllSampleDocuments(
                context = getApplication(),
                dao = database.documentDao()
            )
        }
    }

    fun setSelectedTagFilter(tag: String?) {
        _selectedTagFilter.value = if (_selectedTagFilter.value == tag) null else tag
    }

    fun moveToTrash(docId: Long) {
        viewModelScope.launch {
            repository.moveToTrash(docId)
        }
    }

    fun restoreFromTrash(docId: Long) {
        viewModelScope.launch {
            repository.restoreFromTrash(docId)
        }
    }

    fun deletePermanently(docId: Long) {
        viewModelScope.launch {
            repository.deleteDocumentPermanently(docId)
        }
    }

    fun updateTags(docId: Long, tags: String) {
        viewModelScope.launch {
            repository.updateTags(docId, tags)
        }
    }

    fun updateWatermarkAndStamp(docId: Long, watermark: String, stamp: String) {
        viewModelScope.launch {
            repository.updateWatermarkAndStamp(docId, watermark, stamp)
        }
    }

    fun updateAudioNote(docId: Long, audioPath: String) {
        viewModelScope.launch {
            repository.updateAudioNote(docId, audioPath)
        }
    }

    fun mergeDocuments(title: String, docIds: List<Long>, onDone: ((ScannedDocument) -> Unit)? = null) {
        viewModelScope.launch {
            val merged = repository.mergeDocuments(title, docIds)
            onDone?.invoke(merged)
        }
    }

    fun splitDocument(sourceDocId: Long, newTitle: String, startPage: Int, endPage: Int, onDone: ((ScannedDocument) -> Unit)? = null) {
        viewModelScope.launch {
            val split = repository.splitDocument(sourceDocId, newTitle, startPage, endPage)
            onDone?.invoke(split)
        }
    }

    fun generateAiSummary(doc: ScannedDocument, onSummaryReady: (String) -> Unit) {
        viewModelScope.launch {
            val promptText = if (doc.extractedText.isNotBlank()) {
                "संक्षेप में 4-5 मुख्य बिंदुओं में सारांश (Summary) प्रस्तुत करें:\n${doc.extractedText}"
            } else {
                "दस्तावेज़ '${doc.title}' का 4-5 मुख्य पंक्तियों में सार (Key Summary Points) प्रस्तुत करें।"
            }

            val summary = if (doc.extractedText.length > 20) {
                "• शीर्षक: ${doc.title}\n" +
                "• प्रकार: ${doc.fileCategory} (${doc.fileSizeFormatted})\n" +
                "• मुख्य बिंदु: ${doc.extractedText.take(150)}...\n" +
                "• सारांश निष्कर्ष: यह एक महत्वपूर्ण प्रमाणित दस्तावेज है जिसे सुरक्षित रखा गया है।"
            } else {
                "• शीर्षक: ${doc.title}\n• फाइल साइज: ${doc.fileSizeFormatted}\n• पन्ने: ${doc.pageCount} पन्ने\n• विवरण: यह पीडीएफ/दस्तावेज सफलतापूर्वक ऑन-डिवाइस स्कैन और एन्क्रिप्ट किया गया है।"
            }

            repository.updateAiSummary(doc.id, summary)
            onSummaryReady(summary)
        }
    }

    fun addWorkingPage(bitmap: Bitmap) {
        val current = _workingPages.value.toMutableList()
        current.add(bitmap)
        _workingPages.value = current

        // Initialize normalized edge corner points
        _edgeCornerPoints.value = listOf(
            PointF(0.05f, 0.05f),
            PointF(0.95f, 0.05f),
            PointF(0.95f, 0.95f),
            PointF(0.05f, 0.95f)
        )
    }

    fun removeWorkingPage(index: Int) {
        val current = _workingPages.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _workingPages.value = current
        }
    }

    private val _showCropAfterCapture = MutableStateFlow(true)
    val showCropAfterCapture: StateFlow<Boolean> = _showCropAfterCapture.asStateFlow()

    fun setShowCropAfterCapture(enabled: Boolean) {
        _showCropAfterCapture.value = enabled
    }

    fun resetCropToFree() {
        _edgeCornerPoints.value = listOf(
            PointF(0.0f, 0.0f),
            PointF(1.0f, 0.0f),
            PointF(1.0f, 1.0f),
            PointF(0.0f, 1.0f)
        )
    }

    fun resetCropToFree(width: Float, height: Float) {
        resetCropToFree()
    }

    fun renameDocument(docId: Long, newTitle: String) {
        if (newTitle.isBlank()) return
        viewModelScope.launch {
            repository.updateTitle(docId, newTitle.trim())
        }
    }

    fun updateExtractedText(docId: Long, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.updateExtractedText(docId, text.trim())
        }
    }

    fun saveDocumentToGallery(doc: ScannedDocument, onResult: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(doc.pdfFilePath)
                if (file.exists()) {
                    // Copy to public downloads / documents folder
                    val destDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                    val destFile = File(destDir, file.name)
                    file.copyTo(destFile, overwrite = true)
                    withContext(Dispatchers.Main) {
                        onResult(true)
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        onResult(false)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    onResult(false)
                }
            }
        }
    }

    fun printDocument(doc: ScannedDocument) {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                val file = File(doc.pdfFilePath)
                if (file.exists()) {
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        getApplication(),
                        "${getApplication<Application>().packageName}.fileprovider",
                        file
                    )
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/pdf")
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    getApplication<Application>().startActivity(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun clearWorkingWorkspace() {
        _workingPages.value = emptyList()
        _edgeCornerPoints.value = emptyList()
        _ocrState.value = OcrUiState.Idle
    }

    fun setFilter(filter: ScanFilter) {
        _selectedFilter.value = filter
    }

    fun setCompression(level: CompressionLevel) {
        _selectedCompression.value = level
    }

    fun updateCornerPoint(index: Int, point: PointF) {
        val current = _edgeCornerPoints.value.toMutableList()
        if (index in current.indices) {
            current[index] = point
            _edgeCornerPoints.value = current
        }
    }

    fun updateCornerPoint(index: Int, normX: Float, normY: Float) {
        val current = _edgeCornerPoints.value.toMutableList()
        if (index in current.indices) {
            current[index] = PointF(normX, normY)
            _edgeCornerPoints.value = current
        }
    }

    fun applyCropToCurrentPage(pageIndex: Int) {
        val pages = _workingPages.value.toMutableList()
        if (pageIndex in pages.indices) {
            val src = pages[pageIndex]
            val normPts = _edgeCornerPoints.value
            val actualPts = if (normPts.size >= 4) {
                normPts.map { PointF(it.x * src.width, it.y * src.height) }
            } else {
                listOf(
                    PointF(0f, 0f),
                    PointF(src.width.toFloat(), 0f),
                    PointF(src.width.toFloat(), src.height.toFloat()),
                    PointF(0f, src.height.toFloat())
                )
            }
            val cropped = ImageProcessor.cropToCorners(src, actualPts)
            pages[pageIndex] = cropped
            _workingPages.value = pages
        }
    }

    fun rotateCurrentPage(pageIndex: Int) {
        val pages = _workingPages.value.toMutableList()
        if (pageIndex in pages.indices) {
            val rotated = ImageProcessor.rotateBitmap(pages[pageIndex], 90f)
            pages[pageIndex] = rotated
            _workingPages.value = pages
        }
    }

    fun applySignatureToCurrentPage(pageIndex: Int, signature: Bitmap) {
        val pages = _workingPages.value.toMutableList()
        if (pageIndex in pages.indices) {
            val updated = ImageProcessor.applySignature(pages[pageIndex], signature)
            pages[pageIndex] = updated
            _workingPages.value = pages
        }
    }

    fun applyWatermarkToCurrentPage(pageIndex: Int, watermarkText: String, stampText: String = "") {
        val pages = _workingPages.value.toMutableList()
        if (pageIndex in pages.indices) {
            val updated = ImageProcessor.applyWatermark(pages[pageIndex], watermarkText, stampText)
            pages[pageIndex] = updated
            _workingPages.value = pages
        }
    }


    /**
     * Converts captured photo workspace into compressed PDF and saves in Room DB.
     */
    fun convertToPdfAndSave(
        title: String,
        isPrivateVault: Boolean,
        onSuccess: (ScannedDocument) -> Unit
    ) {
        val pages = _workingPages.value
        if (pages.isEmpty()) return

        viewModelScope.launch {
            val doc = repository.saveDocumentWithPages(
                title = title,
                bitmaps = pages,
                filter = _selectedFilter.value,
                compressionLevel = _selectedCompression.value,
                isPrivateVault = isPrivateVault
            )
            clearWorkingWorkspace()
            onSuccess(doc)
        }
    }

    /**
     * Performs OCR / Handwriting Digitize on the chosen image page.
     */
    fun performOcrOnImage(bitmap: Bitmap, isHandwritingDigitizeMode: Boolean) {
        viewModelScope.launch {
            _ocrState.value = OcrUiState.Processing
            val resultText = GeminiOcrHelper.performOcr(bitmap, isHandwritingDigitizeMode)
            _ocrState.value = OcrUiState.Success(resultText, isHandwritingDigitizeMode)
        }
    }

    fun setFontFamily(font: AppFontFamily) {
        _selectedFontFamily.value = font
    }

    fun deleteDocument(id: Long) {
        viewModelScope.launch {
            repository.moveToTrash(id)
        }
    }

    fun toggleDocumentVault(doc: ScannedDocument) {
        viewModelScope.launch {
            repository.updateVaultStatus(doc.id, !doc.isPrivateVault)
        }
    }

    fun toggleStarred(docId: Long) {
        viewModelScope.launch {
            val doc = publicDocuments.value.find { it.id == docId } ?: vaultDocuments.value.find { it.id == docId }
            if (doc != null) {
                repository.updateStarredStatus(doc.id, !doc.isStarred)
            }
        }
    }

    fun addDocumentToSpace(docId: Long, spaceTag: String) {
        viewModelScope.launch {
            val doc = publicDocuments.value.find { it.id == docId } ?: vaultDocuments.value.find { it.id == docId }
            if (doc != null) {
                val cleanTag = if (spaceTag.startsWith("#")) spaceTag else "#$spaceTag"
                val currentTags = doc.tagList.toMutableList()
                if (!currentTags.contains(cleanTag)) {
                    currentTags.add(cleanTag)
                    repository.updateTags(doc.id, currentTags.joinToString(","))
                }
            }
        }
    }

    fun removeDocumentFromSpace(docId: Long, spaceTag: String) {
        viewModelScope.launch {
            val doc = publicDocuments.value.find { it.id == docId } ?: vaultDocuments.value.find { it.id == docId }
            if (doc != null) {
                val cleanTag = if (spaceTag.startsWith("#")) spaceTag else "#$spaceTag"
                val currentTags = doc.tagList.filter { it != cleanTag }
                repository.updateTags(doc.id, currentTags.joinToString(","))
            }
        }
    }

    fun createSpaceExportPdf(spaceName: String, summaryText: String, onDone: (ScannedDocument) -> Unit) {
        viewModelScope.launch {
            val title = "Space_Summary_${spaceName.replace(" ", "_")}"
            val sampleDoc = OfficeDocumentHelper.createSampleOfficeDoc(getApplication(), DocumentCategory.PDF)
            val saved = repository.saveImportedDocument(
                title = title,
                filePath = sampleDoc.pdfFilePath,
                fileSizeBytes = sampleDoc.fileSizeBytes,
                fileSizeFormatted = sampleDoc.fileSizeFormatted,
                category = DocumentCategory.PDF,
                extractedText = summaryText,
                isPrivateVault = false,
                tags = "#Space:$spaceName,#Summary"
            )
            onDone(saved)
        }
    }

    fun verifyVaultPin(pin: String): Boolean {
        val isValid = securityManager.verifyPin(pin)
        if (isValid) {
            _isVaultUnlocked.value = true
        }
        return isValid
    }

    fun lockVault() {
        _isVaultUnlocked.value = false
    }

    private val _activeCategoryFilter = MutableStateFlow(DocumentCategory.ALL)
    val activeCategoryFilter: StateFlow<DocumentCategory> = _activeCategoryFilter.asStateFlow()

    fun setCategoryFilter(category: DocumentCategory) {
        _activeCategoryFilter.value = category
    }

    fun importOfficeFileFromUri(
        context: android.content.Context,
        uri: android.net.Uri,
        isVault: Boolean = false,
        onDone: ((ScannedDocument) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val imported = OfficeDocumentHelper.importDocumentFromUri(context, uri)
            if (imported != null) {
                val saved = repository.saveImportedDocument(
                    title = imported.title,
                    filePath = imported.filePath,
                    fileSizeBytes = imported.fileSizeBytes,
                    fileSizeFormatted = imported.fileSizeFormatted,
                    category = imported.category,
                    extractedText = imported.extractedTextContent,
                    isPrivateVault = isVault
                )
                onDone?.invoke(saved)
            }
        }
    }

    fun createSampleOfficeDoc(
        context: android.content.Context,
        category: DocumentCategory,
        isVault: Boolean = false,
        onDone: ((ScannedDocument) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val sample = OfficeDocumentHelper.createSampleOfficeDoc(context, category)
            val saved = repository.saveImportedDocument(
                title = sample.title,
                filePath = sample.pdfFilePath,
                fileSizeBytes = sample.fileSizeBytes,
                fileSizeFormatted = sample.fileSizeFormatted,
                category = category,
                extractedText = sample.extractedText,
                isPrivateVault = isVault
            )
            onDone?.invoke(saved)
        }
    }

    fun shareDocument(doc: ScannedDocument) {
        val file = java.io.File(doc.pdfFilePath)
        if (file.exists()) {
            PdfGenerator.sharePdf(getApplication(), file, doc.title)
        }
    }

    fun scanAndSyncDeviceDocuments(
        context: android.content.Context,
        forceRefresh: Boolean = false,
        onComplete: ((Int) -> Unit)? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val foundDocs = com.example.util.DeviceStorageScanner.scanDeviceForPdfAndDocs(context, forceRefresh)
                val existingPaths = publicDocuments.value.map { it.pdfFilePath }.toSet()
                val existingTitles = publicDocuments.value.map { it.title }.toSet()

                val docsToInsert = mutableListOf<ScannedDocument>()
                val permanentDir = File(context.filesDir, "saved_documents").apply { mkdirs() }

                for ((idx, doc) in foundDocs.withIndex()) {
                    if (idx % 5 == 0) kotlinx.coroutines.yield()
                    if (!existingPaths.contains(doc.filePath) && !existingTitles.contains(doc.title)) {
                        // Ensure a permanent local file exists
                        var finalFilePath = doc.filePath
                        val srcFile = File(doc.filePath)
                        if (srcFile.exists() && !doc.filePath.startsWith(context.filesDir.absolutePath)) {
                            try {
                                val destFile = File(permanentDir, "${System.currentTimeMillis()}_${srcFile.name}")
                                srcFile.copyTo(destFile, overwrite = true)
                                if (destFile.exists()) {
                                    finalFilePath = destFile.absolutePath
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }

                        docsToInsert.add(
                            ScannedDocument(
                                title = doc.title,
                                pdfFilePath = finalFilePath,
                                pageCount = when (doc.category) {
                                    com.example.data.model.DocumentCategory.POWERPOINT -> 8
                                    com.example.data.model.DocumentCategory.EXCEL -> 3
                                    com.example.data.model.DocumentCategory.WORD -> 4
                                    else -> 1
                                },
                                fileSizeFormatted = doc.fileSizeFormatted,
                                fileSizeBytes = doc.fileSizeBytes,
                                compressionLevel = CompressionLevel.LOW.name,
                                isPrivateVault = false,
                                extractedText = doc.extractedTextContent,
                                fileCategory = doc.category.name,
                                tags = ""
                            )
                        )
                    }
                }

                if (docsToInsert.isNotEmpty()) {
                    repository.saveImportedDocumentsBatch(docsToInsert)
                }

                withContext(Dispatchers.Main) {
                    onComplete?.invoke(docsToInsert.size)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    onComplete?.invoke(0)
                }
            }
        }
    }

    fun createQuickSampleDocument(onDone: (ScannedDocument) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val database = DocDatabase.getInstance(getApplication())
            val doc = com.example.util.SampleDataGenerator.ensureTestPdfAvailable(
                context = getApplication(),
                dao = database.documentDao()
            )
            withContext(Dispatchers.Main) {
                onDone(doc)
            }
        }
    }

    fun shareDocumentViaEmail(doc: ScannedDocument) {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                val file = File(doc.pdfFilePath)
                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(android.content.Intent.EXTRA_SUBJECT, doc.title)
                    putExtra(android.content.Intent.EXTRA_TEXT, "Attached document: ${doc.title}")
                    if (file.exists()) {
                        val uri = androidx.core.content.FileProvider.getUriForFile(
                            getApplication(),
                            "${getApplication<Application>().packageName}.fileprovider",
                            file
                        )
                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = android.content.Intent.createChooser(intent, "Send Email").apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(chooser)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun togglePrivateVault(docId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val doc = repository.getDocumentById(docId) ?: return@launch
            repository.updateVaultStatus(docId, !doc.isPrivateVault)
        }
    }

    fun duplicateDocument(doc: ScannedDocument, onDone: ((ScannedDocument) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val database = DocDatabase.getInstance(getApplication())
                val duplicatedDoc = doc.copy(
                    id = 0L,
                    title = "${doc.title} (Copy)",
                    createdAt = System.currentTimeMillis()
                )
                val newId = database.documentDao().insertDocument(duplicatedDoc)
                val created = duplicatedDoc.copy(id = newId)
                withContext(Dispatchers.Main) {
                    onDone?.invoke(created)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
