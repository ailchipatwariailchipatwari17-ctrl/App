package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ILoveToolItem
import com.example.data.model.ILoveToolsCatalog
import com.example.data.model.ToolMainType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ILovePortalView(
    onSelectPdfTool: (ILoveToolItem) -> Unit,
    onSelectImageTool: (ILoveToolItem) -> Unit,
    onSelectWorkflowTool: (ILoveToolItem) -> Unit,
    onOpenThreeLineMenu: () -> Unit,
    onSwitchMode: () -> Unit,
    onOpenLanguageSettings: () -> Unit,
    initialMainType: ToolMainType = ToolMainType.PDF
) {
    val context = LocalContext.current
    var selectedMainType by remember { mutableStateOf(initialMainType) }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }

    // Categories for PDF Mode
    val pdfCategories = listOf(
        "ALL" to "All (सभी)",
        "WORKFLOWS" to "Workflows",
        "ORGANIZE" to "Organize PDF",
        "OPTIMIZE" to "Optimize PDF",
        "CONVERT" to "Convert PDF",
        "EDIT" to "Edit PDF",
        "SECURITY" to "PDF Security",
        "AI" to "PDF Intelligence"
    )

    // Categories for Photo / Image Mode (iLoveIMG)
    val imageCategories = listOf(
        "ALL" to "सभी",
        "OPTIMIZE" to "ऑप्टिमाइज़ करें",
        "CREATE" to "बनाएँ",
        "MODIFY" to "एडिट करें",
        "CONVERT" to "कन्वर्ट करें",
        "SECURITY" to "सुरक्षा"
    )

    val currentCategories = if (selectedMainType == ToolMainType.PDF) pdfCategories else imageCategories

    val toolsList = remember(selectedMainType) {
        ILoveToolsCatalog.getAllTools(selectedMainType)
    }

    val filteredTools = remember(toolsList, selectedCategoryFilter, searchQuery) {
        toolsList.filter { tool ->
            val matchCat = when (selectedCategoryFilter) {
                "ALL" -> true
                "WORKFLOWS" -> tool.category == "CREATE" || tool.category == "ORGANIZE"
                else -> tool.category.equals(selectedCategoryFilter, ignoreCase = true)
            }
            val matchSearch = if (searchQuery.isBlank()) true else {
                tool.titleHindi.contains(searchQuery, ignoreCase = true) ||
                tool.titleEn.contains(searchQuery, ignoreCase = true) ||
                tool.descriptionHindi.contains(searchQuery, ignoreCase = true) ||
                tool.descriptionEn.contains(searchQuery, ignoreCase = true)
            }
            matchCat && matchSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC)) // Clean airy light background
    ) {
        // =====================================================================
        // 1. TOP BRAND HEADER (Matching iLovePDF & iLoveIMG exactly)
        // =====================================================================
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color.White,
            shadowElevation = 2.dp
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // 3-Line Hamburger Menu Button (तीन लाइन मेन्यू)
                    IconButton(
                        onClick = onOpenThreeLineMenu,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "तीन लाइन मेन्यू (Menu)",
                            tint = Color(0xFF0F172A),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Brand Logo Title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            selectedMainType = if (selectedMainType == ToolMainType.PDF) ToolMainType.IMAGE else ToolMainType.PDF
                        }
                    ) {
                        Text(
                            text = "i",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A)
                        )
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Heart",
                            tint = if (selectedMainType == ToolMainType.PDF) Color(0xFFEF4444) else Color(0xFF0284C7),
                            modifier = Modifier
                                .size(22.dp)
                                .padding(horizontal = 1.dp)
                        )
                        Text(
                            text = if (selectedMainType == ToolMainType.PDF) "PDF" else "IMG",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A)
                        )
                    }

                    // Quick Mode & Settings Buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onSwitchMode, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Default.LaptopMac, contentDescription = "Desktop Workspace", tint = Color(0xFF475569), modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = onOpenLanguageSettings, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Default.Language, contentDescription = "Language", tint = Color(0xFF475569), modifier = Modifier.size(20.dp))
                        }
                    }
                }

                // Main Type Tabs: [ 📄 PDF टूल्स ]  [ 🖼️ फोटो एडिट (iLoveIMG) ]  [ ⚡ वर्कफ्लो व क्रिएटर्स ]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // PDF Tab
                    Surface(
                        modifier = Modifier.weight(1f),
                        onClick = {
                            selectedMainType = ToolMainType.PDF
                            selectedCategoryFilter = "ALL"
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedMainType == ToolMainType.PDF) Color(0xFFEF4444).copy(alpha = 0.12f) else Color(0xFFF1F5F9),
                        border = BorderStroke(1.dp, if (selectedMainType == ToolMainType.PDF) Color(0xFFEF4444) else Color.Transparent)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = if (selectedMainType == ToolMainType.PDF) Color(0xFFEF4444) else Color(0xFF64748B),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "PDF टूल्स",
                                fontSize = 12.sp,
                                fontWeight = if (selectedMainType == ToolMainType.PDF) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedMainType == ToolMainType.PDF) Color(0xFFEF4444) else Color(0xFF64748B)
                            )
                        }
                    }

                    // Photo / Image Tab (फोटो एडिट अलग)
                    Surface(
                        modifier = Modifier.weight(1f),
                        onClick = {
                            selectedMainType = ToolMainType.IMAGE
                            selectedCategoryFilter = "ALL"
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedMainType == ToolMainType.IMAGE) Color(0xFF0284C7).copy(alpha = 0.12f) else Color(0xFFF1F5F9),
                        border = BorderStroke(1.dp, if (selectedMainType == ToolMainType.IMAGE) Color(0xFF0284C7) else Color.Transparent)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Image,
                                contentDescription = null,
                                tint = if (selectedMainType == ToolMainType.IMAGE) Color(0xFF0284C7) else Color(0xFF64748B),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "फोटो एडिट",
                                fontSize = 12.sp,
                                fontWeight = if (selectedMainType == ToolMainType.IMAGE) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedMainType == ToolMainType.IMAGE) Color(0xFF0284C7) else Color(0xFF64748B)
                            )
                        }
                    }

                    // Workflow & Creator Tab
                    Surface(
                        modifier = Modifier.weight(1f),
                        onClick = {
                            selectedMainType = ToolMainType.WORKFLOW
                            selectedCategoryFilter = "ALL"
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedMainType == ToolMainType.WORKFLOW) Color(0xFF8B5CF6).copy(alpha = 0.12f) else Color(0xFFF1F5F9),
                        border = BorderStroke(1.dp, if (selectedMainType == ToolMainType.WORKFLOW) Color(0xFF8B5CF6) else Color.Transparent)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = if (selectedMainType == ToolMainType.WORKFLOW) Color(0xFF8B5CF6) else Color(0xFF64748B),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "AI व क्रिएटर्स",
                                fontSize = 12.sp,
                                fontWeight = if (selectedMainType == ToolMainType.WORKFLOW) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedMainType == ToolMainType.WORKFLOW) Color(0xFF8B5CF6) else Color(0xFF64748B)
                            )
                        }
                    }
                }
            }
        }

        // =====================================================================
        // 2. CATEGORY PILLS & INSTANT SEARCH
        // =====================================================================
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
            // Category Filter Pills (Exact Pill Shape from screenshots)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(currentCategories) { (catKey, catLabel) ->
                    val isSelected = selectedCategoryFilter == catKey
                    Surface(
                        onClick = { selectedCategoryFilter = catKey },
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) Color(0xFF0F172A) else Color.White,
                        border = BorderStroke(1.dp, if (isSelected) Color(0xFF0F172A) else Color(0xFFE2E8F0)),
                        shadowElevation = if (isSelected) 2.dp else 0.dp
                    ) {
                        Text(
                            text = catLabel,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else Color(0xFF334155),
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }

        // =====================================================================
        // 3. MASTER CARD GRID (Matching Screenshot 1 & 2 Card Style)
        // =====================================================================
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredTools, key = { it.id }) { tool ->
                ILoveToolCard(
                    tool = tool,
                    onClick = {
                        when (tool.toolType) {
                            ToolMainType.PDF -> onSelectPdfTool(tool)
                            ToolMainType.IMAGE -> onSelectImageTool(tool)
                            ToolMainType.WORKFLOW -> onSelectWorkflowTool(tool)
                        }
                    }
                )
            }

            // =================================================================
            // 4. "Work your way / अपने तरीके से काम करें" Section
            // =================================================================
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp, bottom = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "अपने तरीके से काम करें",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "Work your way • All professional tools unified",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // 3 Feature Cards matching Screenshot 2 & 3
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        WorkWayFeatureCard(
                            title = "दस्तावेज़ मोड में स्विच करें",
                            description = "जब आपका काम इमेज से आगे बढ़े, तो PDF एडिटिंग और कन्वर्शन को आसान बनाने के लिए PDF टूल्स का इस्तेमाल करें।",
                            icon = Icons.Default.Description,
                            accentColor = Color(0xFFEF4444),
                            buttonText = "PDF टूल्स खोलें",
                            onClick = {
                                selectedMainType = ToolMainType.PDF
                                selectedCategoryFilter = "ALL"
                            }
                        )

                        WorkWayFeatureCard(
                            title = "कभी भी, कहीं भी स्कैन करें, एडिट करें",
                            description = "कागजी दस्तावेज़ तुरंत स्कैन करें और कभी भी मोबाइल में क्विक इमेज व PDF टूल्स का इस्तेमाल करें।",
                            icon = Icons.Default.DocumentScanner,
                            accentColor = Color(0xFF10B981),
                            buttonText = "स्कैनर खोलें",
                            onClick = {
                                onSelectPdfTool(ILoveToolsCatalog.pdfTools.first { it.id == "scan_to_pdf" })
                            }
                        )

                        WorkWayFeatureCard(
                            title = "AI व स्मार्ट टूल्स के साथ काम को बढ़ाएँ",
                            description = "अपने वर्कफ़्लो में Gemini AI को जोड़कर इमेज व PDF टास्क, समरी, क्विज़ और ट्रांसलेशन को पूरी तरह ऑटोमेट करें।",
                            icon = Icons.Default.AutoAwesome,
                            accentColor = Color(0xFF8B5CF6),
                            buttonText = "AI को-पायलट",
                            onClick = {
                                selectedMainType = ToolMainType.WORKFLOW
                                selectedCategoryFilter = "AI"
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Exact replica card matching the uploaded screenshots:
 * - Rounded white card with clean subtle border
 * - Top-left colored square badge with tool icon
 * - Bold Hindi / English Title
 * - Clean descriptive text
 * - "New!" badge if applicable
 */
@Composable
fun ILoveToolCard(
    tool: ILoveToolItem,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 160.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    // Top-Left Rounded Colored Icon Box
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = tool.iconBgColor,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = tool.icon,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Optional "New!" / "नया!" Badge
                    if (tool.isNew || tool.badge != null) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFE0F2FE)
                        ) {
                            Text(
                                text = tool.badge ?: "नया!",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0284C7),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Title (Bold Hindi Title)
                Text(
                    text = tool.titleHindi,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // English Subtitle
                Text(
                    text = tool.titleEn,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Description
                Text(
                    text = tool.descriptionHindi,
                    fontSize = 11.sp,
                    color = Color(0xFF64748B),
                    lineHeight = 15.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun WorkWayFeatureCard(
    title: String,
    description: String,
    icon: ImageVector,
    accentColor: Color,
    buttonText: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = accentColor.copy(alpha = 0.12f),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(24.dp))
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = description, fontSize = 11.sp, color = Color(0xFF64748B), lineHeight = 15.sp)
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp))
        }
    }
}
