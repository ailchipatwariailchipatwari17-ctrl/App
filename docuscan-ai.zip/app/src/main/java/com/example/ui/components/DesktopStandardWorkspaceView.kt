package com.example.ui.components

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MasterPdfTool
import com.example.data.model.MasterPdfToolsCatalog
import com.example.data.model.PdfAppSuite
import com.example.data.model.ScannedDocument
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DesktopStandardWorkspaceView(
    documents: List<ScannedDocument>,
    onViewDocument: (ScannedDocument) -> Unit,
    onOpenBlankPdfCreator: () -> Unit,
    onScanDocument: () -> Unit,
    onOpenFiles: () -> Unit,
    onMergeFiles: () -> Unit,
    onNavigateToAi: () -> Unit,
    onOpenTools: () -> Unit,
    onSwitchToMobileMode: () -> Unit,
    onWatermark: (ScannedDocument) -> Unit = {},
    onPdfToImage: (ScannedDocument) -> Unit = {},
    onOrganizePages: (ScannedDocument) -> Unit = {},
    onTranslate: (ScannedDocument) -> Unit = {},
    onPodcast: (ScannedDocument) -> Unit = {},
    onQuiz: (ScannedDocument) -> Unit = {},
    onAudioNote: (ScannedDocument) -> Unit = {},
    onProtect: (ScannedDocument) -> Unit = {},
    onShareDoc: (ScannedDocument) -> Unit = {},
    onDeleteDoc: (ScannedDocument) -> Unit = {},
    onToggleStarDoc: (ScannedDocument) -> Unit = {},
    onOcrScan: () -> Unit = {},
    onRepairPdf: () -> Unit = {},
    onComparePdf: () -> Unit = {},
    onIdCardScan: () -> Unit = {},
    onOpenPhotoStudio: () -> Unit = {}
) {
    val context = LocalContext.current
    var selectedDocument by remember(documents) { mutableStateOf(documents.firstOrNull()) }
    var selectedSuite by remember { mutableStateOf(PdfAppSuite.ALL) }
    var selectedRibbonTab by remember { mutableStateOf("ALL") } // ALL, ORGANIZE, OPTIMIZE, TO_PDF, FROM_PDF, EDIT, SECURITY, AI, CREATE, BATCH
    var searchInput by remember { mutableStateOf("") }
    var selectedNavFilter by remember { mutableStateOf("ALL") } // ALL, STARRED, RECENT, OFFICE, PDF, TOOLS_GRID
    var isGridView by remember { mutableStateOf(true) } // Grid vs Table List View
    var isBatchMode by remember { mutableStateOf(false) }
    val selectedDocIds = remember { mutableStateListOf<Long>() }
    var showMobileInspectorSheet by remember { mutableStateOf(false) }
    var showAllToolsGrid by remember { mutableStateOf(false) }

    var showDesktopNavMenu by remember { mutableStateOf(false) }

    val allMasterTools = remember { MasterPdfToolsCatalog.allTools }

    fun handleToolClick(tool: MasterPdfTool) {
        when (tool.id) {
            // Merge & Organize
            "ilove_merge", "merge" -> onMergeFiles()
            "ilove_split", "ilove_organize", "split", "organize", "remove_pages", "extract_pages", "rotate" -> {
                selectedDocument?.let { onOrganizePages(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onOrganizePages(documents.first())
                    } else {
                        onOpenFiles()
                    }
                }
            }

            // Scanner & ID Card
            "ilove_img_to_pdf", "foxit_cam_scan", "scan", "jpg_to_pdf" -> onScanDocument()
            "foxit_id_card", "id_card" -> onIdCardScan()

            // Compression & Optimization
            "ilove_compress", "pdfgear_batch_compress", "compress" -> {
                selectedDocument?.let {
                    onViewDocument(it)
                    Toast.makeText(context, "PDF व्यूअर में 'Export' मेनू से कंप्रेशन चुनें", Toast.LENGTH_SHORT).show()
                } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onViewDocument(documents.first())
                    } else {
                        onOpenFiles()
                    }
                }
            }
            "ilove_repair", "repair" -> onRepairPdf()
            "ilove_ocr", "ocr", "pdfgear_txt_extract", "pdf_to_text" -> onOcrScan()

            // Creation & Templates
            "adobe_create", "foxit_blank_creator", "xodo_blank_notepad", "creator_zero_design", "creator_custom_sizes", "blank_pdf" -> onOpenBlankPdfCreator()
            "creator_templates" -> onOpenBlankPdfCreator()

            // Document View, Annotations, E-Sign & Drawing
            "adobe_view", "adobe_sign", "xodo_notes_pen", "xodo_highlighter", "xodo_shapes", "foxit_form_edit", "edit_pdf", "sign" -> {
                selectedDocument?.let { onViewDocument(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onViewDocument(documents.first())
                    } else {
                        onOpenBlankPdfCreator()
                    }
                }
            }

            // PDF to Images / Formats
            "ilove_pdf_to_jpg", "pdf_to_jpg" -> {
                selectedDocument?.let { onPdfToImage(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onPdfToImage(documents.first())
                    } else onOpenFiles()
                }
            }
            "ilove_pdf_to_word", "ilove_pdf_to_excel", "word_to_pdf", "ppt_to_pdf", "excel_to_pdf" -> {
                selectedDocument?.let {
                    onViewDocument(it)
                    Toast.makeText(context, "व्यूअर में 'Export' दबाकर कनवर्ट करें", Toast.LENGTH_SHORT).show()
                } ?: onOpenFiles()
            }

            // Watermark & Audio Notes
            "ilove_watermark", "watermark", "page_numbers" -> {
                selectedDocument?.let { onWatermark(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onWatermark(documents.first())
                    } else onOpenFiles()
                }
            }
            "xodo_audio_note", "audio_note" -> {
                selectedDocument?.let { onAudioNote(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onAudioNote(documents.first())
                    } else onOpenFiles()
                }
            }

            // Security & Comparison
            "adobe_protect", "protect", "unlock" -> {
                selectedDocument?.let { onProtect(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onProtect(documents.first())
                    } else onOpenFiles()
                }
            }
            "pdfgear_compare", "compare" -> onComparePdf()
            "pdfgear_no_watermark" -> {
                Toast.makeText(context, "✨ 100% बिना वॉटरमार्क PDF निर्माण व संपादन सक्रिय है", Toast.LENGTH_SHORT).show()
                onOpenBlankPdfCreator()
            }

            // AI Co-Pilot
            "ai_chat_summary", "ai_summary" -> onNavigateToAi()
            "ai_translator", "ai_translate" -> {
                selectedDocument?.let { onTranslate(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onTranslate(documents.first())
                    } else onOpenFiles()
                }
            }
            "ai_quiz_generator", "ai_quiz" -> {
                selectedDocument?.let { onQuiz(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onQuiz(documents.first())
                    } else onOpenFiles()
                }
            }
            "adobe_read_aloud", "ai_podcast_audio", "ai_podcast" -> {
                selectedDocument?.let { onPodcast(it) } ?: run {
                    if (documents.isNotEmpty()) {
                        selectedDocument = documents.first()
                        onPodcast(documents.first())
                    } else onOpenFiles()
                }
            }
            "ai_formula_extractor", "ai_handwriting_clean" -> onOcrScan()
            else -> onOpenBlankPdfCreator()
        }
    }

    // Filter documents based on search, format, and navigation
    val displayedList = remember(documents, searchInput, selectedNavFilter) {
        documents.filter { doc ->
            val matchSearch = if (searchInput.isBlank()) true else {
                doc.title.contains(searchInput, ignoreCase = true) || doc.extractedText.contains(searchInput, ignoreCase = true)
            }
            val matchNav = when (selectedNavFilter) {
                "STARRED" -> doc.isStarred
                "OFFICE" -> doc.title.endsWith(".docx", true) || doc.title.endsWith(".xlsx", true) || doc.title.endsWith(".pptx", true)
                "PDF" -> !doc.title.endsWith(".docx", true) && !doc.title.endsWith(".xlsx", true) && !doc.title.endsWith(".pptx", true)
                else -> true
            }
            matchSearch && matchNav
        }
    }

    val filteredToolsByTab = remember(selectedRibbonTab, selectedSuite, allMasterTools, searchInput) {
        allMasterTools.filter { tool ->
            val matchSuite = if (selectedSuite == PdfAppSuite.ALL) true else tool.suite == selectedSuite
            val matchCategory = if (selectedRibbonTab == "ALL" || selectedRibbonTab == "BATCH") true else tool.category == selectedRibbonTab
            val matchSearch = if (searchInput.isBlank()) true else {
                tool.titleHindi.contains(searchInput, ignoreCase = true) ||
                tool.titleEn.contains(searchInput, ignoreCase = true) ||
                tool.description.contains(searchInput, ignoreCase = true)
            }
            matchSuite && matchCategory && matchSearch
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0F15))
    ) {
        val isWideScreen = maxWidth >= 680.dp

        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Desktop Top Ribbon Bar (Complete 6 Apps Suite: Adobe Acrobat, iLovePDF, Xodo, Foxit, PDFgear, PDF Creator)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding(),
                color = Color(0xFF151822),
                border = BorderStroke(1.dp, Color(0xFF222736))
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    // Top App Header & Desktop Mode Switch Bar with 3-line hamburger menu
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // 3-line Hamburger Menu
                            Box {
                                IconButton(
                                    onClick = { showDesktopNavMenu = true },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Menu,
                                        contentDescription = "Menu",
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                DropdownMenu(
                                    expanded = showDesktopNavMenu,
                                    onDismissRequest = { showDesktopNavMenu = false },
                                    modifier = Modifier.background(Color(0xFF1E2230))
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("📱 मोबाइल मोड पर स्विच करें", color = Color(0xFF10B981), fontWeight = FontWeight.Bold) },
                                        leadingIcon = { Icon(Icons.Default.Smartphone, contentDescription = null, tint = Color(0xFF10B981)) },
                                        onClick = {
                                            showDesktopNavMenu = false
                                            onSwitchToMobileMode()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("🗂️ सभी 6-एप टूल्स ग्रिड", color = Color.White) },
                                        leadingIcon = { Icon(Icons.Default.Apps, contentDescription = null, tint = Color(0xFFEF4444)) },
                                        onClick = {
                                            showDesktopNavMenu = false
                                            showAllToolsGrid = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("📁 मास्टर फ़ाइल एक्सप्लोरर", color = Color.White) },
                                        leadingIcon = { Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Color(0xFF38BDF8)) },
                                        onClick = {
                                            showDesktopNavMenu = false
                                            showAllToolsGrid = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("📄 नया ब्लैंक PDF बनाएं", color = Color.White) },
                                        leadingIcon = { Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFFF59E0B)) },
                                        onClick = {
                                            showDesktopNavMenu = false
                                            onOpenBlankPdfCreator()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("📷 कैमरा स्कैनर", color = Color.White) },
                                        leadingIcon = { Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color(0xFF3B82F6)) },
                                        onClick = {
                                            showDesktopNavMenu = false
                                            onScanDocument()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("🤖 Gemini AI असिस्टेंट", color = Color(0xFF38BDF8)) },
                                        leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF38BDF8)) },
                                        onClick = {
                                            showDesktopNavMenu = false
                                            onNavigateToAi()
                                        }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF1E293B),
                                border = BorderStroke(1.dp, Color(0xFFEF4444))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.LaptopMac,
                                        contentDescription = null,
                                        tint = Color(0xFFEF4444),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        "मास्टर PDF कंप्यूटर वर्कस्पेस (6-इन-1 ऐप सुइट)",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            if (isWideScreen) {
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    "Adobe Acrobat • iLovePDF • Xodo • Foxit • PDFgear • PDF Creator Pro",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Right Top Controls
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // View Switcher (Tools Grid vs My Files Explorer)
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF1E2230),
                                border = BorderStroke(1.dp, Color(0xFF2E354A)),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { showAllToolsGrid = false; isGridView = true },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.FolderOpen,
                                            contentDescription = "My Files",
                                            tint = if (!showAllToolsGrid) Color(0xFF38BDF8) else Color.Gray,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { showAllToolsGrid = true },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Apps,
                                            contentDescription = "All Tools Grid",
                                            tint = if (showAllToolsGrid) Color(0xFFEF4444) else Color.Gray,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }
                            }

                            // Switch to Mobile Mode button
                            OutlinedButton(
                                onClick = onSwitchToMobileMode,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF10B981)),
                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.8f)),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Default.Smartphone, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("मोबाइल मोड", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Row 1: Software Suite Filter Bar (Adobe, iLovePDF, Xodo, Foxit, PDFgear, Creator Pro, AI)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PdfAppSuite.values().forEach { suite ->
                            val isSelected = selectedSuite == suite
                            Surface(
                                onClick = {
                                    selectedSuite = suite
                                    showAllToolsGrid = true
                                },
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSelected) suite.badgeColor else Color(0xFF1B202E),
                                border = BorderStroke(1.dp, if (isSelected) suite.badgeColor else Color(0xFF2A3145)),
                                modifier = Modifier.height(26.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        suite.icon,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else suite.badgeColor,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = suite.displayNameHindi,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Row 2: Category Ribbon Menu Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DesktopRibbonChip(
                            title = "सभी टूल्स (${allMasterTools.size})",
                            isSelected = selectedRibbonTab == "ALL",
                            badgeColor = Color(0xFFEF4444),
                            onClick = { selectedRibbonTab = "ALL" }
                        )
                        DesktopRibbonChip(
                            title = "ऑर्गेनाइज़ व स्प्लिट",
                            isSelected = selectedRibbonTab == "ORGANIZE",
                            badgeColor = Color(0xFFF97316),
                            onClick = { selectedRibbonTab = "ORGANIZE" }
                        )
                        DesktopRibbonChip(
                            title = "ऑप्टिमाइज़ व कम्प्रेस",
                            isSelected = selectedRibbonTab == "OPTIMIZE",
                            badgeColor = Color(0xFF10B981),
                            onClick = { selectedRibbonTab = "OPTIMIZE" }
                        )
                        DesktopRibbonChip(
                            title = "नया PDF व कैनवास",
                            isSelected = selectedRibbonTab == "CREATE",
                            badgeColor = Color(0xFF8B5CF6),
                            onClick = { selectedRibbonTab = "CREATE" }
                        )
                        DesktopRibbonChip(
                            title = "PDF में कनवर्ट",
                            isSelected = selectedRibbonTab == "TO_PDF",
                            badgeColor = Color(0xFF3B82F6),
                            onClick = { selectedRibbonTab = "TO_PDF" }
                        )
                        DesktopRibbonChip(
                            title = "PDF से कनवर्ट",
                            isSelected = selectedRibbonTab == "FROM_PDF",
                            badgeColor = Color(0xFFE11D48),
                            onClick = { selectedRibbonTab = "FROM_PDF" }
                        )
                        DesktopRibbonChip(
                            title = "एडिट, साइन व नोट्स",
                            isSelected = selectedRibbonTab == "EDIT",
                            badgeColor = Color(0xFFEC4899),
                            onClick = { selectedRibbonTab = "EDIT" }
                        )
                        DesktopRibbonChip(
                            title = "सुरक्षा व तुलना",
                            isSelected = selectedRibbonTab == "SECURITY",
                            badgeColor = Color(0xFF6366F1),
                            onClick = { selectedRibbonTab = "SECURITY" }
                        )
                        DesktopRibbonChip(
                            title = "AI को-पायलट",
                            isSelected = selectedRibbonTab == "AI",
                            badgeColor = Color(0xFF8B5CF6),
                            onClick = { selectedRibbonTab = "AI" }
                        )
                        DesktopRibbonChip(
                            title = "फोटो एडिट (iLoveIMG)",
                            isSelected = selectedRibbonTab == "PHOTO_EDIT",
                            badgeColor = Color(0xFF0284C7),
                            onClick = {
                                selectedRibbonTab = "PHOTO_EDIT"
                                onOpenPhotoStudio()
                            }
                        )
                        DesktopRibbonChip(
                            title = "बैच मोड",
                            isSelected = selectedRibbonTab == "BATCH",
                            badgeColor = TealAccent,
                            onClick = {
                                selectedRibbonTab = "BATCH"
                                isBatchMode = true
                            }
                        )
                    }

                    // Dynamic Sub-Ribbon Tool Action Strip based on Active Tab
                    Column(modifier = Modifier.padding(top = 6.dp)) {
                        Divider(color = Color(0xFF222736), modifier = Modifier.padding(bottom = 6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (selectedRibbonTab == "BATCH") {
                                RibbonActionBtn("सभी चुनें (${displayedList.size})", Icons.Default.SelectAll, Color(0xFF38BDF8)) {
                                    selectedDocIds.clear()
                                    selectedDocIds.addAll(displayedList.map { it.id })
                                }
                                RibbonActionBtn("चुनी हुई मर्ज करें (${selectedDocIds.size})", Icons.Default.MergeType, Color(0xFF10B981)) {
                                    if (selectedDocIds.size >= 2) onMergeFiles() else Toast.makeText(context, "कम से कम 2 PDF चुनें", Toast.LENGTH_SHORT).show()
                                }
                                RibbonActionBtn("बैच एक्सपोर्ट", Icons.Default.Share, Color(0xFFF59E0B)) {
                                    Toast.makeText(context, "${selectedDocIds.size} फाइलें बैच प्रोसेस के लिए तैयार", Toast.LENGTH_SHORT).show()
                                }
                                RibbonActionBtn("बैच मोड बंद करें", Icons.Default.Close, Color.Gray) {
                                    isBatchMode = false
                                    selectedDocIds.clear()
                                }
                            } else {
                                filteredToolsByTab.forEach { tool ->
                                    RibbonActionBtn(
                                        title = tool.titleHindi,
                                        icon = tool.icon,
                                        color = tool.accentColor
                                    ) {
                                        handleToolClick(tool)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. Main Desktop Multi-Pane Body
            if (isWideScreen) {
                // Tablet / Desktop 3-Pane Layout (Navigation Rail + Center Area + Right Inspector)
                Row(modifier = Modifier.fillMaxSize()) {
                    // Left Navigation Rail (Explorer Style)
                    Surface(
                        modifier = Modifier
                            .width(160.dp)
                            .fillMaxHeight(),
                        color = Color(0xFF11141E),
                        border = BorderStroke(1.dp, Color(0xFF1E2230))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(6.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(
                                "एक्सप्लोरर",
                                color = Color(0xFF64748B),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )

                            DesktopNavRailItem(
                                icon = Icons.Default.Apps,
                                label = "सभी टूल्स",
                                isSelected = showAllToolsGrid,
                                accentColor = Color(0xFFEF4444),
                                onClick = { showAllToolsGrid = true }
                            )
                            DesktopNavRailItem(
                                icon = Icons.Default.Folder,
                                label = "सभी फाइलें (${documents.size})",
                                isSelected = !showAllToolsGrid && selectedNavFilter == "ALL",
                                onClick = { showAllToolsGrid = false; selectedNavFilter = "ALL" }
                            )
                            DesktopNavRailItem(
                                icon = Icons.Default.PictureAsPdf,
                                label = "PDF फाइल्स",
                                isSelected = !showAllToolsGrid && selectedNavFilter == "PDF",
                                onClick = { showAllToolsGrid = false; selectedNavFilter = "PDF" }
                            )
                            DesktopNavRailItem(
                                icon = Icons.Default.Star,
                                label = "तारांकित",
                                isSelected = !showAllToolsGrid && selectedNavFilter == "STARRED",
                                onClick = { showAllToolsGrid = false; selectedNavFilter = "STARRED" }
                            )
                            DesktopNavRailItem(
                                icon = Icons.Default.Description,
                                label = "Office फाइलें",
                                isSelected = !showAllToolsGrid && selectedNavFilter == "OFFICE",
                                onClick = { showAllToolsGrid = false; selectedNavFilter = "OFFICE" }
                            )

                            Divider(color = Color(0xFF1E2230), modifier = Modifier.padding(vertical = 4.dp))

                            Text(
                                "क्विक टूल्स",
                                color = Color(0xFF64748B),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )

                            DesktopNavRailItem(
                                icon = Icons.Default.MergeType,
                                label = "मर्ज PDF",
                                accentColor = Color(0xFFEF4444),
                                onClick = onMergeFiles
                            )
                            DesktopNavRailItem(
                                icon = Icons.Default.Compress,
                                label = "कम्प्रेस PDF",
                                accentColor = Color(0xFF10B981),
                                onClick = {
                                    selectedDocument?.let { onViewDocument(it) } ?: onOpenFiles()
                                }
                            )
                            DesktopNavRailItem(
                                icon = Icons.Default.DocumentScanner,
                                label = "OCR स्कैनर",
                                accentColor = Color(0xFF0EA5E9),
                                onClick = onOcrScan
                            )
                            DesktopNavRailItem(
                                icon = Icons.Default.AddBox,
                                label = "नया ब्लैंक PDF",
                                accentColor = Color(0xFF38BDF8),
                                onClick = onOpenBlankPdfCreator
                            )
                            DesktopNavRailItem(
                                icon = Icons.Default.AutoAwesome,
                                label = "Gemini AI",
                                accentColor = Color(0xFF8B5CF6),
                                onClick = onNavigateToAi
                            )
                        }
                    }

                    // Center Document Area or Full iLovePDF Tools Grid Showcase
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(10.dp)
                    ) {
                        SearchBarField(
                            searchInput = searchInput,
                            onSearchChange = { searchInput = it }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // View mode header (Files vs All iLovePDF Tools)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (showAllToolsGrid) "🛠️ सभी iLovePDF टूल्स ग्रिड (${filteredToolsByTab.size} टूल्स)"
                                else "📂 दस्तावेज़ सूची (${displayedList.size} फाइलें)",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChipSmall(
                                    label = "🛠️ टूल्स ग्रिड",
                                    isSelected = showAllToolsGrid,
                                    accentColor = Color(0xFFEF4444),
                                    onClick = { showAllToolsGrid = true }
                                )
                                FilterChipSmall(
                                    label = "📂 फाइलें",
                                    isSelected = !showAllToolsGrid,
                                    accentColor = Color(0xFF38BDF8),
                                    onClick = { showAllToolsGrid = false }
                                )
                            }
                        }

                        if (showAllToolsGrid) {
                            // Full iLovePDF Iconic Colorful Grid
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 150.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(filteredToolsByTab) { tool ->
                                    ILovePdfToolCard(
                                        tool = tool,
                                        onClick = { handleToolClick(tool) }
                                    )
                                }
                            }
                        } else {
                            // Batch selection notification bar
                            if (isBatchMode) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 8.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF1E293B),
                                    border = BorderStroke(1.dp, Color(0xFF38BDF8))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            "बैच मोड: ${selectedDocIds.size} फाइलें चुनी गईं",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Button(
                                                onClick = onMergeFiles,
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                                modifier = Modifier.height(26.dp)
                                            ) {
                                                Text("मर्ज करें", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                            OutlinedButton(
                                                onClick = {
                                                    isBatchMode = false
                                                    selectedDocIds.clear()
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray),
                                                modifier = Modifier.height(26.dp)
                                            ) {
                                                Text("रद्द", fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            // Grid vs Table View
                            if (isGridView) {
                                DocumentGridContent(
                                    displayedList = displayedList,
                                    selectedDocument = selectedDocument,
                                    isBatchMode = isBatchMode,
                                    selectedDocIds = selectedDocIds,
                                    onSelect = { doc ->
                                        selectedDocument = doc
                                        if (isBatchMode) {
                                            if (selectedDocIds.contains(doc.id)) selectedDocIds.remove(doc.id) else selectedDocIds.add(doc.id)
                                        }
                                    },
                                    onOpen = { onViewDocument(it) },
                                    onToggleStar = onToggleStarDoc
                                )
                            } else {
                                DocumentTableView(
                                    displayedList = displayedList,
                                    selectedDocument = selectedDocument,
                                    isBatchMode = isBatchMode,
                                    selectedDocIds = selectedDocIds,
                                    onSelect = { doc ->
                                        selectedDocument = doc
                                        if (isBatchMode) {
                                            if (selectedDocIds.contains(doc.id)) selectedDocIds.remove(doc.id) else selectedDocIds.add(doc.id)
                                        }
                                    },
                                    onOpen = { onViewDocument(it) },
                                    onToggleStar = onToggleStarDoc
                                )
                            }
                        }
                    }

                    // Right Inspector & Complete iLovePDF Tools Action Panel
                    Surface(
                        modifier = Modifier
                            .width(270.dp)
                            .fillMaxHeight(),
                        color = Color(0xFF11141E),
                        border = BorderStroke(1.dp, Color(0xFF1E2230))
                    ) {
                        InspectorPaneContent(
                            doc = selectedDocument,
                            onView = { doc -> onViewDocument(doc) },
                            onWatermark = { doc -> onWatermark(doc) },
                            onPdfToImage = { doc -> onPdfToImage(doc) },
                            onOrganize = { doc -> onOrganizePages(doc) },
                            onProtect = { doc -> onProtect(doc) },
                            onTranslate = { doc -> onTranslate(doc) },
                            onQuiz = { doc -> onQuiz(doc) },
                            onPodcast = { doc -> onPodcast(doc) },
                            onAudioNote = { doc -> onAudioNote(doc) },
                            onShare = { doc -> onShareDoc(doc) },
                            onDelete = { doc -> onDeleteDoc(doc) },
                            onAi = onNavigateToAi,
                            onMerge = onMergeFiles,
                            onRepair = onRepairPdf,
                            onCompare = onComparePdf,
                            onOcr = onOcrScan
                        )
                    }
                }
            } else {
                // Mobile Screen Standard Mode: Responsive Layout with full iLovePDF suite
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    // Filter Chips Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChipSmall(
                            label = "सभी टूल्स ग्रिड",
                            isSelected = showAllToolsGrid,
                            accentColor = Color(0xFFEF4444),
                            onClick = { showAllToolsGrid = true }
                        )
                        FilterChipSmall(
                            label = "सभी (${documents.size})",
                            isSelected = !showAllToolsGrid && selectedNavFilter == "ALL",
                            onClick = { showAllToolsGrid = false; selectedNavFilter = "ALL" }
                        )
                        FilterChipSmall(
                            label = "PDF",
                            isSelected = !showAllToolsGrid && selectedNavFilter == "PDF",
                            onClick = { showAllToolsGrid = false; selectedNavFilter = "PDF" }
                        )
                        FilterChipSmall(
                            label = "तारांकित",
                            isSelected = !showAllToolsGrid && selectedNavFilter == "STARRED",
                            onClick = { showAllToolsGrid = false; selectedNavFilter = "STARRED" }
                        )
                        FilterChipSmall(
                            label = "Office",
                            isSelected = !showAllToolsGrid && selectedNavFilter == "OFFICE",
                            onClick = { showAllToolsGrid = false; selectedNavFilter = "OFFICE" }
                        )
                        FilterChipSmall(
                            label = if (isBatchMode) "बैच सक्रिय" else "बैच",
                            isSelected = isBatchMode,
                            accentColor = TealAccent,
                            onClick = {
                                isBatchMode = !isBatchMode
                                if (!isBatchMode) selectedDocIds.clear()
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    SearchBarField(
                        searchInput = searchInput,
                        onSearchChange = { searchInput = it }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Content Area (Tools Grid or Files)
                    Box(modifier = Modifier.weight(1f)) {
                        if (showAllToolsGrid) {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 135.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(filteredToolsByTab) { tool ->
                                    ILovePdfToolCard(
                                        tool = tool,
                                        onClick = { handleToolClick(tool) }
                                    )
                                }
                            }
                        } else {
                            if (isGridView) {
                                DocumentGridContent(
                                    displayedList = displayedList,
                                    selectedDocument = selectedDocument,
                                    isBatchMode = isBatchMode,
                                    selectedDocIds = selectedDocIds,
                                    onSelect = { doc ->
                                        selectedDocument = doc
                                        if (isBatchMode) {
                                            if (selectedDocIds.contains(doc.id)) selectedDocIds.remove(doc.id) else selectedDocIds.add(doc.id)
                                        } else {
                                            showMobileInspectorSheet = true
                                        }
                                    },
                                    onOpen = { doc -> onViewDocument(doc) },
                                    onToggleStar = onToggleStarDoc
                                )
                            } else {
                                DocumentTableView(
                                    displayedList = displayedList,
                                    selectedDocument = selectedDocument,
                                    isBatchMode = isBatchMode,
                                    selectedDocIds = selectedDocIds,
                                    onSelect = { doc ->
                                        selectedDocument = doc
                                        if (isBatchMode) {
                                            if (selectedDocIds.contains(doc.id)) selectedDocIds.remove(doc.id) else selectedDocIds.add(doc.id)
                                        } else {
                                            showMobileInspectorSheet = true
                                        }
                                    },
                                    onOpen = { doc -> onViewDocument(doc) },
                                    onToggleStar = onToggleStarDoc
                                )
                            }
                        }
                    }

                    // Bottom Docked Quick Action Bar when a doc is selected
                    selectedDocument?.let { doc ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1A1D27),
                            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        doc.title,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "${doc.pageCount} पन्ने • ${doc.fileSizeFormatted}",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 10.sp
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    FilledTonalButton(
                                        onClick = { onViewDocument(doc) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.filledTonalButtonColors(
                                            containerColor = Color(0xFF0284C7),
                                            contentColor = Color.White
                                        )
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("खोलें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    IconButton(
                                        onClick = { showMobileInspectorSheet = true },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(Icons.Default.Tune, contentDescription = "टूल्स", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Mobile Inspector Bottom Sheet (Complete Computer Tools List)
        if (showMobileInspectorSheet && selectedDocument != null) {
            val doc = selectedDocument!!
            ModalBottomSheet(
                onDismissRequest = { showMobileInspectorSheet = false },
                containerColor = Color(0xFF13151F)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        doc.title,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${doc.pageCount} पृष्ठ • साइज़: ${doc.fileSizeFormatted} • ${doc.formattedDate}",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                    Divider(color = Color(0xFF262638), modifier = Modifier.padding(vertical = 4.dp))

                    Text("⚡ iLovePDF प्रो टूल्स (All Tools):", color = Color(0xFFEF4444), fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    // Primary View
                    Button(
                        onClick = {
                            showMobileInspectorSheet = false
                            onViewDocument(doc)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PDF व्यूअर में खोलें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // 2-column grid of all pro tools
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                showMobileInspectorSheet = false
                                onWatermark(doc)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEC4899)),
                            border = BorderStroke(1.dp, Color(0xFFEC4899)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.BrandingWatermark, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("वॉटरमार्क", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                showMobileInspectorSheet = false
                                onPdfToImage(doc)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF59E0B)),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("इमेज कनवर्ट", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                showMobileInspectorSheet = false
                                onOrganizePages(doc)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF10B981)),
                            border = BorderStroke(1.dp, Color(0xFF10B981)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.AutoStories, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("पेज स्प्लिट / रीऑर्डर", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                showMobileInspectorSheet = false
                                onProtect(doc)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF38BDF8)),
                            border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("पासवर्ड लॉक", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                showMobileInspectorSheet = false
                                onTranslate(doc)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF8B5CF6)),
                            border = BorderStroke(1.dp, Color(0xFF8B5CF6)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("AI अनुवाद", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                showMobileInspectorSheet = false
                                onPodcast(doc)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF43F5E)),
                            border = BorderStroke(1.dp, Color(0xFFF43F5E)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Headphones, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("पॉडकास्ट", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                showMobileInspectorSheet = false
                                onQuiz(doc)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF10B981)),
                            border = BorderStroke(1.dp, Color(0xFF10B981)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("AI क्विज़", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                showMobileInspectorSheet = false
                                onAudioNote(doc)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF9333EA)),
                            border = BorderStroke(1.dp, Color(0xFF9333EA)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("वॉइस नोट", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
private fun ILovePdfToolCard(
    tool: MasterPdfTool,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF161924),
        border = BorderStroke(1.dp, tool.accentColor.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .height(118.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = tool.accentColor.copy(alpha = 0.15f),
                    modifier = Modifier.size(32.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            tool.icon,
                            contentDescription = tool.titleHindi,
                            tint = tool.accentColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                if (tool.badge != null) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = tool.accentColor.copy(alpha = 0.2f)
                    ) {
                        Text(
                            tool.badge,
                            color = tool.accentColor,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Column {
                Text(
                    tool.titleHindi,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    tool.titleEn,
                    color = tool.suite.badgeColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    tool.description,
                    color = Color(0xFF94A3B8),
                    fontSize = 9.sp,
                    lineHeight = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun RibbonActionBtn(
    title: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = Color(0xFF1E2332),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f)),
        modifier = Modifier.height(28.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(title, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SearchBarField(
    searchInput: String,
    onSearchChange: (String) -> Unit
) {
    OutlinedTextField(
        value = searchInput,
        onValueChange = onSearchChange,
        placeholder = { Text("कंप्यूटर सर्च (दस्तावेज़, OCR टेक्स्ट या टूल्स खोजें)...", fontSize = 11.sp, color = Color.Gray) },
        singleLine = true,
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp)) },
        trailingIcon = {
            if (searchInput.isNotEmpty()) {
                IconButton(onClick = { onSearchChange("") }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(14.dp))
                }
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFF38BDF8),
            unfocusedBorderColor = Color(0xFF262C3D),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        ),
        shape = RoundedCornerShape(10.dp)
    )
}

@Composable
private fun DocumentGridContent(
    displayedList: List<ScannedDocument>,
    selectedDocument: ScannedDocument?,
    isBatchMode: Boolean,
    selectedDocIds: List<Long>,
    onSelect: (ScannedDocument) -> Unit,
    onOpen: (ScannedDocument) -> Unit,
    onToggleStar: (ScannedDocument) -> Unit
) {
    if (displayedList.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(40.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text("कोई दस्तावेज़ नहीं मिला", color = Color(0xFF94A3B8), fontSize = 12.sp)
            }
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 140.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(displayedList) { doc ->
                val isSelected = selectedDocument?.id == doc.id
                val isChecked = selectedDocIds.contains(doc.id)

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(doc) },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected || isChecked) Color(0xFF1E293B) else Color(0xFF151822),
                    border = BorderStroke(
                        if (isSelected || isChecked) 1.5.dp else 1.dp,
                        if (isSelected || isChecked) Color(0xFF38BDF8) else Color(0xFF222736)
                    )
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isBatchMode) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { onSelect(doc) },
                                    modifier = Modifier.size(20.dp),
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF38BDF8))
                                )
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (doc.title.endsWith(".docx", true)) Color(0xFF1D4ED8)
                                    else if (doc.title.endsWith(".xlsx", true)) Color(0xFF15803D)
                                    else PdfRed
                                ) {
                                    Text(
                                        if (doc.title.endsWith(".docx", true)) "DOCX"
                                        else if (doc.title.endsWith(".xlsx", true)) "XLSX"
                                        else "PDF",
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            IconButton(
                                onClick = { onToggleStar(doc) },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    imageVector = if (doc.isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Star",
                                    tint = if (doc.isStarred) Color(0xFFFFD700) else Color.Gray,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            doc.title,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            "${doc.pageCount} पन्ने • ${doc.fileSizeFormatted}",
                            color = Color(0xFF64748B),
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}

// Windows Explorer Style Detailed Table View for Standard Mode
@Composable
private fun DocumentTableView(
    displayedList: List<ScannedDocument>,
    selectedDocument: ScannedDocument?,
    isBatchMode: Boolean,
    selectedDocIds: List<Long>,
    onSelect: (ScannedDocument) -> Unit,
    onOpen: (ScannedDocument) -> Unit,
    onToggleStar: (ScannedDocument) -> Unit
) {
    if (displayedList.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("कोई दस्तावेज़ नहीं मिला", color = Color(0xFF94A3B8), fontSize = 12.sp)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Table Header Row
            item {
                Surface(
                    color = Color(0xFF181C28),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("नाम (Name)", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                        Text("पृष्ठ (Pages)", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(60.dp))
                        Text("साइज़ (Size)", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(60.dp))
                        Text("तारीख (Date)", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(70.dp))
                    }
                }
            }

            items(displayedList) { doc ->
                val isSelected = selectedDocument?.id == doc.id
                val isChecked = selectedDocIds.contains(doc.id)

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(doc) },
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSelected || isChecked) Color(0xFF1E293B) else Color(0xFF131620),
                    border = BorderStroke(
                        1.dp,
                        if (isSelected || isChecked) Color(0xFF38BDF8) else Color(0xFF1E2230)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isBatchMode) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { onSelect(doc) },
                                modifier = Modifier.size(20.dp),
                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF38BDF8))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }

                        Icon(
                            if (doc.title.endsWith(".docx", true)) Icons.Default.Description
                            else if (doc.title.endsWith(".xlsx", true)) Icons.Default.TableChart
                            else Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = if (doc.title.endsWith(".docx", true)) Color(0xFF38BDF8)
                            else if (doc.title.endsWith(".xlsx", true)) Color(0xFF10B981)
                            else PdfRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        Text(
                            doc.title,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1.5f)
                        )

                        Text(
                            "${doc.pageCount} P",
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            modifier = Modifier.width(60.dp)
                        )

                        Text(
                            doc.fileSizeFormatted,
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            modifier = Modifier.width(60.dp)
                        )

                        Text(
                            doc.formattedDate,
                            color = Color(0xFF64748B),
                            fontSize = 9.sp,
                            maxLines = 1,
                            modifier = Modifier.width(70.dp)
                        )
                    }
                }
            }
        }
    }
}

// Right Desktop Inspector Pane (Live Pro Tools for Selected Document)
@Composable
private fun InspectorPaneContent(
    doc: ScannedDocument?,
    onView: (ScannedDocument) -> Unit,
    onWatermark: (ScannedDocument) -> Unit,
    onPdfToImage: (ScannedDocument) -> Unit,
    onOrganize: (ScannedDocument) -> Unit,
    onProtect: (ScannedDocument) -> Unit,
    onTranslate: (ScannedDocument) -> Unit,
    onQuiz: (ScannedDocument) -> Unit,
    onPodcast: (ScannedDocument) -> Unit,
    onAudioNote: (ScannedDocument) -> Unit,
    onShare: (ScannedDocument) -> Unit,
    onDelete: (ScannedDocument) -> Unit,
    onAi: () -> Unit,
    onMerge: () -> Unit,
    onRepair: () -> Unit,
    onCompare: () -> Unit,
    onOcr: () -> Unit
) {
    if (doc != null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "दस्तावेज़ इंस्पेक्टर (Inspector)",
                color = Color(0xFFEF4444),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            // Document Info Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF171A26),
                border = BorderStroke(1.dp, Color(0xFF262C3D))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        doc.title,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("पृष्ठ: ${doc.pageCount} • साइज़: ${doc.fileSizeFormatted}", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text("तारीख: ${doc.formattedDate}", color = Color(0xFF64748B), fontSize = 9.sp)
                }
            }

            // Primary View Button
            Button(
                onClick = { onView(doc) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("PDF व्यूअर में खोलें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Divider(color = Color(0xFF1E2230), modifier = Modifier.padding(vertical = 2.dp))

            Text("iLovePDF टूल्स ऑपरेशन्स:", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)

            // Quick Desktop Action Rows
            InspectorActionRow(Icons.Default.MergeType, "PDF मर्ज करें", Color(0xFFEF4444)) { onMerge() }
            InspectorActionRow(Icons.Default.AutoStories, "पेज स्प्लिट व रीऑर्डर", Color(0xFFF97316)) { onOrganize(doc) }
            InspectorActionRow(Icons.Default.BrandingWatermark, "वॉटरमार्क जोड़ें", Color(0xFFEC4899)) { onWatermark(doc) }
            InspectorActionRow(Icons.Default.Image, "इमेज में कनवर्ट करें", Color(0xFFF59E0B)) { onPdfToImage(doc) }
            InspectorActionRow(Icons.Default.Lock, "पासवर्ड लॉक व सुरक्षा", Color(0xFF38BDF8)) { onProtect(doc) }
            InspectorActionRow(Icons.Default.DocumentScanner, "OCR टेक्स्ट एक्सट्रैक्ट", Color(0xFF0EA5E9)) { onOcr() }
            InspectorActionRow(Icons.Default.Translate, "AI बहुभाषी अनुवाद", Color(0xFF8B5CF6)) { onTranslate(doc) }
            InspectorActionRow(Icons.Default.School, "AI क्विज़ मेकर", Color(0xFF10B981)) { onQuiz(doc) }
            InspectorActionRow(Icons.Default.Headphones, "AI ऑडियो पॉडकास्ट", Color(0xFFF43F5E)) { onPodcast(doc) }
            InspectorActionRow(Icons.Default.Mic, "वॉइस ऑडियो नोट", Color(0xFF9333EA)) { onAudioNote(doc) }
            InspectorActionRow(Icons.Default.Build, "डैमेज PDF रिपेयर", Color(0xFF06B6D4)) { onRepair() }
            InspectorActionRow(Icons.Default.Compare, "2 PDF की तुलना (Compare)", Color(0xFF6366F1)) { onCompare() }
            InspectorActionRow(Icons.Default.Share, "शेयर व एक्सपोर्ट", Color.LightGray) { onShare(doc) }
            InspectorActionRow(Icons.Default.Delete, "हटाएं (Trash)", PdfRed) { onDelete(doc) }
        }
    } else {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("कंप्यूटर टूल्स देखने के लिए कोई PDF चुनें", color = Color(0xFF64748B), fontSize = 11.sp)
        }
    }
}

@Composable
private fun InspectorActionRow(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = Color(0xFF161924),
        border = BorderStroke(1.dp, Color(0xFF222736)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun DesktopRibbonChip(
    title: String,
    isSelected: Boolean,
    badgeColor: Color? = null,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) Color(0xFF1E293B) else Color(0xFF13151D),
        border = BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) (badgeColor ?: Color(0xFF38BDF8)) else Color(0xFF262B3D)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                title,
                color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
private fun DesktopNavRailItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean = false,
    accentColor: Color = Color(0xFF38BDF8),
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) Color(0xFF1E293B) else Color.Transparent,
        border = if (isSelected) BorderStroke(1.dp, accentColor) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (isSelected) accentColor else Color(0xFF94A3B8),
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                label,
                color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun FilterChipSmall(
    label: String,
    isSelected: Boolean,
    accentColor: Color = Color(0xFF38BDF8),
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) accentColor.copy(alpha = 0.2f) else Color(0xFF161922),
        border = BorderStroke(1.dp, if (isSelected) accentColor else Color(0xFF262C3D))
    ) {
        Text(
            label,
            color = if (isSelected) Color.White else Color(0xFF94A3B8),
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
