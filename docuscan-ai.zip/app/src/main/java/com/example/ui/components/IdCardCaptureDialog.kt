package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Pageview
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.util.LanguageManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdCardCaptureDialog(
    initialFrontBitmap: Bitmap?,
    initialBackBitmap: Bitmap?,
    onSaveIdCardPdf: (front: Bitmap, back: Bitmap, title: String) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val languageManager = remember { LanguageManager(context) }

    var frontBitmap by remember { mutableStateOf(initialFrontBitmap) }
    var backBitmap by remember { mutableStateOf(initialBackBitmap) }
    var idTitle by remember { mutableStateOf("ID_Card_${System.currentTimeMillis() % 10000}") }
    var selectedViewMode by remember { mutableIntStateOf(0) } // 0: Capture & Edit, 1: A4 Preview

    var isCapturingFront by remember { mutableStateOf(true) }

    // Direct Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bmp: Bitmap? ->
        if (bmp != null) {
            if (isCapturingFront) {
                frontBitmap = bmp
            } else {
                backBitmap = bmp
            }
        }
    }

    // Direct Gallery launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                @Suppress("DEPRECATION")
                val bmp = MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                if (bmp != null) {
                    if (isCapturingFront) {
                        frontBitmap = bmp
                    } else {
                        backBitmap = bmp
                    }
                }
            } catch (_: Exception) {}
        }
    }

    fun rotateBitmap(src: Bitmap): Bitmap {
        val matrix = Matrix().apply { postRotate(90f) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF101016)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Top App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF161622))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismissRequest) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFF241416), CircleShape)
                            .border(1.dp, Color(0xFFFA0F00), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = null,
                            tint = Color(0xFFFA0F00),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Text(
                        text = languageManager.t("id_card"),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    // Quick Switch / Swap front and back if both exist
                    if (frontBitmap != null && backBitmap != null) {
                        IconButton(
                            onClick = {
                                val temp = frontBitmap
                                frontBitmap = backBitmap
                                backBitmap = temp
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Flip,
                                contentDescription = "Swap",
                                tint = Color(0xFF8E8E9E)
                            )
                        }
                    }
                }

                // Sub-tabs: Edit / A4 Preview
                TabRow(
                    selectedTabIndex = selectedViewMode,
                    containerColor = Color(0xFF161622),
                    contentColor = Color(0xFFFA0F00),
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedViewMode]),
                            color = Color(0xFFFA0F00),
                            height = 2.5.dp
                        )
                    },
                    divider = {
                        HorizontalDivider(color = Color(0xFF242434), thickness = 1.dp)
                    }
                ) {
                    Tab(
                        selected = selectedViewMode == 0,
                        onClick = { selectedViewMode = 0 },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.ViewAgenda,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        text = {
                            Text(
                                text = languageManager.t("front_side") + " & " + languageManager.t("back_side"),
                                fontSize = 12.sp,
                                fontWeight = if (selectedViewMode == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedViewMode == 0) Color(0xFFFA0F00) else Color(0xFF9E9EAE)
                            )
                        }
                    )

                    Tab(
                        selected = selectedViewMode == 1,
                        onClick = { selectedViewMode = 1 },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Pageview,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        text = {
                            Text(
                                text = "A4 " + languageManager.t("preview"),
                                fontSize = 12.sp,
                                fontWeight = if (selectedViewMode == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedViewMode == 1) Color(0xFFFA0F00) else Color(0xFF9E9EAE)
                            )
                        }
                    )
                }

                // Main Content Body
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (selectedViewMode == 0) {
                        // Capture & Edit Slots
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Slot 1: Front Side
                            IdCardSlotItem(
                                title = languageManager.t("front_side"),
                                bitmap = frontBitmap,
                                watermarkIcon = Icons.Default.Badge,
                                onCameraClick = {
                                    isCapturingFront = true
                                    cameraLauncher.launch(null)
                                },
                                onGalleryClick = {
                                    isCapturingFront = true
                                    galleryLauncher.launch("image/*")
                                },
                                onRotateClick = {
                                    frontBitmap?.let { bmp ->
                                        frontBitmap = rotateBitmap(bmp)
                                    }
                                },
                                onDeleteClick = {
                                    frontBitmap = null
                                },
                                cameraLabel = languageManager.t("camera"),
                                galleryLabel = languageManager.t("gallery"),
                                rotateLabel = languageManager.t("rotate"),
                                clearLabel = languageManager.t("clear")
                            )

                            // Slot 2: Back Side
                            IdCardSlotItem(
                                title = languageManager.t("back_side"),
                                bitmap = backBitmap,
                                watermarkIcon = Icons.Default.QrCode,
                                onCameraClick = {
                                    isCapturingFront = false
                                    cameraLauncher.launch(null)
                                },
                                onGalleryClick = {
                                    isCapturingFront = false
                                    galleryLauncher.launch("image/*")
                                },
                                onRotateClick = {
                                    backBitmap?.let { bmp ->
                                        backBitmap = rotateBitmap(bmp)
                                    }
                                },
                                onDeleteClick = {
                                    backBitmap = null
                                },
                                cameraLabel = languageManager.t("camera"),
                                galleryLabel = languageManager.t("gallery"),
                                rotateLabel = languageManager.t("rotate"),
                                clearLabel = languageManager.t("clear")
                            )
                        }
                    } else {
                        // Live A4 Page Layout Simulator
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            // A4 Sheet Container (Aspect Ratio 1 : 1.414)
                            Card(
                                modifier = Modifier
                                    .fillMaxHeight(0.92f)
                                    .aspectRatio(1f / 1.414f)
                                    .shadow(16.dp, RoundedCornerShape(4.dp)),
                                shape = RoundedCornerShape(4.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // A4 Sheet Header
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Badge,
                                                contentDescription = null,
                                                tint = Color(0xFFFA0F00),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = idTitle.ifBlank { "ID Card" },
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF1E1E2E)
                                            )
                                        }
                                        Text(
                                            text = "A4 Page (1/1)",
                                            fontSize = 9.sp,
                                            color = Color(0xFF888888)
                                        )
                                    }

                                    HorizontalDivider(color = Color(0xFFE0E0E0), thickness = 1.dp)

                                    // Front side placement
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(0.92f)
                                            .weight(1f)
                                            .border(1.dp, Color(0xFFD0D0D8), RoundedCornerShape(6.dp))
                                            .background(Color(0xFFF8F8FA), RoundedCornerShape(6.dp))
                                            .padding(4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (frontBitmap != null) {
                                            Image(
                                                bitmap = frontBitmap!!.asImageBitmap(),
                                                contentDescription = "Front",
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .clip(RoundedCornerShape(4.dp)),
                                                contentScale = ContentScale.Fit
                                            )
                                        } else {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(
                                                    imageVector = Icons.Default.Badge,
                                                    contentDescription = null,
                                                    tint = Color(0xFFBBBBCC),
                                                    modifier = Modifier.size(32.dp)
                                                )
                                                Text(
                                                    text = languageManager.t("front_side"),
                                                    fontSize = 10.sp,
                                                    color = Color(0xFF9999AA)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Back side placement
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(0.92f)
                                            .weight(1f)
                                            .border(1.dp, Color(0xFFD0D0D8), RoundedCornerShape(6.dp))
                                            .background(Color(0xFFF8F8FA), RoundedCornerShape(6.dp))
                                            .padding(4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (backBitmap != null) {
                                            Image(
                                                bitmap = backBitmap!!.asImageBitmap(),
                                                contentDescription = "Back",
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .clip(RoundedCornerShape(4.dp)),
                                                contentScale = ContentScale.Fit
                                            )
                                        } else {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(
                                                    imageVector = Icons.Default.QrCode,
                                                    contentDescription = null,
                                                    tint = Color(0xFFBBBBCC),
                                                    modifier = Modifier.size(32.dp)
                                                )
                                                Text(
                                                    text = languageManager.t("back_side"),
                                                    fontSize = 10.sp,
                                                    color = Color(0xFF9999AA)
                                                )
                                            }
                                        }
                                    }

                                    // A4 Sheet Footer
                                    Text(
                                        text = "A4 ID Scanner • Adobe Acrobat Suite",
                                        fontSize = 8.sp,
                                        color = Color(0xFFAAAAAA),
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Action & Save Bar
                Surface(
                    color = Color(0xFF161622),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        OutlinedTextField(
                            value = idTitle,
                            onValueChange = { idTitle = it },
                            placeholder = {
                                Text(
                                    languageManager.t("id_title_hint"),
                                    fontSize = 13.sp,
                                    color = Color(0xFF7E7E90)
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.CreditCard,
                                    contentDescription = null,
                                    tint = Color(0xFFFA0F00),
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFFA0F00),
                                unfocusedBorderColor = Color(0xFF2C2C3E),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color(0xFF1E1E2C),
                                unfocusedContainerColor = Color(0xFF1E1E2C)
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        val canSave = frontBitmap != null || backBitmap != null

                        Button(
                            onClick = {
                                val f = frontBitmap ?: Bitmap.createBitmap(500, 320, Bitmap.Config.ARGB_8888)
                                val b = backBitmap ?: Bitmap.createBitmap(500, 320, Bitmap.Config.ARGB_8888)
                                onSaveIdCardPdf(f, b, idTitle.ifBlank { "ID_Card" })
                            },
                            enabled = canSave,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFA0F00),
                                disabledContainerColor = Color(0xFF332024)
                            ),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = if (canSave) Color.White else Color(0xFF888888),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = languageManager.t("save_a4_pdf"),
                                color = if (canSave) Color.White else Color(0xFF888888),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IdCardSlotItem(
    title: String,
    bitmap: Bitmap?,
    watermarkIcon: androidx.compose.ui.graphics.vector.ImageVector,
    onCameraClick: () -> Unit,
    onGalleryClick: () -> Unit,
    onRotateClick: () -> Unit,
    onDeleteClick: () -> Unit,
    cameraLabel: String,
    galleryLabel: String,
    rotateLabel: String,
    clearLabel: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.2.dp,
                color = if (bitmap != null) Color(0xFFFA0F00) else Color(0xFF262638),
                shape = RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF181824))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(
                                if (bitmap != null) Color(0xFF2E1518) else Color(0xFF242432),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (bitmap != null) Icons.Default.CheckCircle else watermarkIcon,
                            contentDescription = null,
                            tint = if (bitmap != null) Color(0xFFFA0F00) else Color(0xFF8E8E9E),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Action Controls if image exists
                if (bitmap != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalIconButton(
                            onClick = onRotateClick,
                            modifier = Modifier.size(34.dp),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = Color(0xFF252536),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.RotateRight,
                                contentDescription = rotateLabel,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        FilledTonalIconButton(
                            onClick = onDeleteClick,
                            modifier = Modifier.size(34.dp),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = Color(0xFF321A1E),
                                contentColor = Color(0xFFFF5252)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = clearLabel,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Card Viewfinder / Canvas Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF101018))
                    .border(1.dp, Color(0xFF2A2A3C), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    // Empty Card Placeholder with Visual Logos & Guide
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = watermarkIcon,
                            contentDescription = null,
                            tint = Color(0xFF3A3A52),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            color = Color(0xFF6E6E82)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Camera & Gallery Buttons (Compact Logo-Driven)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onCameraClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (bitmap == null) Color(0xFFFA0F00) else Color(0xFF252536)
                    ),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = cameraLabel,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = cameraLabel,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    )
                }

                Button(
                    onClick = onGalleryClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF252536)
                    ),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = galleryLabel,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = galleryLabel,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    )
                }
            }
        }
    }
}
