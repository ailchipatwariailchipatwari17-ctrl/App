package com.example.ui.components

import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.hypot
import kotlin.math.min

/**
 * 8-Point Intelligent Crop Overlay matching Screenshot 1:
 * - 4 Corner Handles (Concentric Blue Ring + White Halo + Cyan Center)
 * - 4 Edge Midpoint Handles (White Capsule Pills with Blue/Cyan Stroke)
 * - Seamless aspect ratio coordinate projection for pixel-perfect edge alignment
 * - Draggable on all 8 touch points with intelligent multi-point edge shifting
 */
@Composable
fun EdgeCropOverlay(
    normalizedPoints: List<PointF>, // 4 points with normalized coordinates in [0f..1f]
    imageWidth: Float,
    imageHeight: Float,
    onPointMoved: (index: Int, newNormX: Float, newNormY: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    if (normalizedPoints.size < 4) return

    // Active drag index: 0..3 = corners (TL, TR, BR, BL), 4..7 = edges (Top, Right, Bottom, Left)
    var activeHandleIndex by remember { mutableIntStateOf(-1) }

    val cyanBlue = Color(0xFF00A2E8)
    val deepBlue = Color(0xFF0C7BB3)

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(normalizedPoints, imageWidth, imageHeight) {
                    detectDragGestures(
                        onDragStart = { startPos ->
                            val canvasW = size.width.toFloat()
                            val canvasH = size.height.toFloat()

                            if (imageWidth <= 0f || imageHeight <= 0f || canvasW <= 0f || canvasH <= 0f) {
                                activeHandleIndex = -1
                                return@detectDragGestures
                            }

                            val scale = min(canvasW / imageWidth, canvasH / imageHeight)
                            val drawnW = imageWidth * scale
                            val drawnH = imageHeight * scale
                            val offsetX = (canvasW - drawnW) / 2f
                            val offsetY = (canvasH - drawnH) / 2f

                            val p0 = normalizedPoints[0]
                            val p1 = normalizedPoints[1]
                            val p2 = normalizedPoints[2]
                            val p3 = normalizedPoints[3]

                            fun toScreen(p: PointF): Offset =
                                Offset(offsetX + p.x * drawnW, offsetY + p.y * drawnH)

                            val s0 = toScreen(p0)
                            val s1 = toScreen(p1)
                            val s2 = toScreen(p2)
                            val s3 = toScreen(p3)

                            val edgeTop = Offset((s0.x + s1.x) / 2f, (s0.y + s1.y) / 2f)
                            val edgeRight = Offset((s1.x + s2.x) / 2f, (s1.y + s2.y) / 2f)
                            val edgeBottom = Offset((s2.x + s3.x) / 2f, (s2.y + s3.y) / 2f)
                            val edgeLeft = Offset((s3.x + s0.x) / 2f, (s3.y + s0.y) / 2f)

                            val handles = listOf(s0, s1, s2, s3, edgeTop, edgeRight, edgeBottom, edgeLeft)

                            var closestIdx = -1
                            var minDistance = Float.MAX_VALUE
                            handles.forEachIndexed { idx, pt ->
                                val dist = hypot(pt.x - startPos.x, pt.y - startPos.y)
                                if (dist < minDistance) {
                                    minDistance = dist
                                    closestIdx = idx
                                }
                            }

                            // 120px touch tolerance target
                            if (minDistance < 140f) {
                                activeHandleIndex = closestIdx
                            } else {
                                activeHandleIndex = -1
                            }
                        },
                        onDragEnd = { activeHandleIndex = -1 },
                        onDragCancel = { activeHandleIndex = -1 },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val canvasW = size.width.toFloat()
                            val canvasH = size.height.toFloat()
                            if (imageWidth <= 0f || imageHeight <= 0f || canvasW <= 0f || canvasH <= 0f) return@detectDragGestures

                            val scale = min(canvasW / imageWidth, canvasH / imageHeight)
                            val drawnW = imageWidth * scale
                            val drawnH = imageHeight * scale

                            if (drawnW <= 0f || drawnH <= 0f) return@detectDragGestures

                            val deltaNormX = dragAmount.x / drawnW
                            val deltaNormY = dragAmount.y / drawnH

                            if (activeHandleIndex in 0..3) {
                                val current = normalizedPoints[activeHandleIndex]
                                val newX = (current.x + deltaNormX).coerceIn(0f, 1f)
                                val newY = (current.y + deltaNormY).coerceIn(0f, 1f)
                                onPointMoved(activeHandleIndex, newX, newY)
                            } else if (activeHandleIndex in 4..7) {
                                when (activeHandleIndex) {
                                    4 -> { // Top Edge (moves TL and TR vertically)
                                        val tl = normalizedPoints[0]
                                        val tr = normalizedPoints[1]
                                        onPointMoved(0, tl.x, (tl.y + deltaNormY).coerceIn(0f, 0.9f))
                                        onPointMoved(1, tr.x, (tr.y + deltaNormY).coerceIn(0f, 0.9f))
                                    }
                                    5 -> { // Right Edge (moves TR and BR horizontally)
                                        val tr = normalizedPoints[1]
                                        val br = normalizedPoints[2]
                                        onPointMoved(1, (tr.x + deltaNormX).coerceIn(0.1f, 1f), tr.y)
                                        onPointMoved(2, (br.x + deltaNormX).coerceIn(0.1f, 1f), br.y)
                                    }
                                    6 -> { // Bottom Edge (moves BR and BL vertically)
                                        val br = normalizedPoints[2]
                                        val bl = normalizedPoints[3]
                                        onPointMoved(2, br.x, (br.y + deltaNormY).coerceIn(0.1f, 1f))
                                        onPointMoved(3, bl.x, (bl.y + deltaNormY).coerceIn(0.1f, 1f))
                                    }
                                    7 -> { // Left Edge (moves BL and TL horizontally)
                                        val bl = normalizedPoints[3]
                                        val tl = normalizedPoints[0]
                                        onPointMoved(3, (bl.x + deltaNormX).coerceIn(0f, 0.9f), bl.y)
                                        onPointMoved(0, (tl.x + deltaNormX).coerceIn(0f, 0.9f), tl.y)
                                    }
                                }
                            }
                        }
                    )
                }
        ) {
            val canvasW = size.width
            val canvasH = size.height
            if (imageWidth <= 0f || imageHeight <= 0f || canvasW <= 0f || canvasH <= 0f) return@Canvas

            val scale = min(canvasW / imageWidth, canvasH / imageHeight)
            val drawnW = imageWidth * scale
            val drawnH = imageHeight * scale
            val offsetX = (canvasW - drawnW) / 2f
            val offsetY = (canvasH - drawnH) / 2f

            fun toScreen(p: PointF): Offset =
                Offset(offsetX + p.x * drawnW, offsetY + p.y * drawnH)

            val p0 = toScreen(normalizedPoints[0]) // TL
            val p1 = toScreen(normalizedPoints[1]) // TR
            val p2 = toScreen(normalizedPoints[2]) // BR
            val p3 = toScreen(normalizedPoints[3]) // BL

            // 1. Boundary Path
            val boundaryPath = Path().apply {
                moveTo(p0.x, p0.y)
                lineTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(p3.x, p3.y)
                close()
            }

            // Draw Subtle Grid inside crop area
            val gridPath = Path().apply {
                // Horizontal thirds
                val h1A = Offset(p0.x + (p3.x - p0.x) / 3f, p0.y + (p3.y - p0.y) / 3f)
                val h1B = Offset(p1.x + (p2.x - p1.x) / 3f, p1.y + (p2.y - p1.y) / 3f)
                moveTo(h1A.x, h1A.y); lineTo(h1B.x, h1B.y)

                val h2A = Offset(p0.x + (p3.x - p0.x) * 2f / 3f, p0.y + (p3.y - p0.y) * 2f / 3f)
                val h2B = Offset(p1.x + (p2.x - p1.x) * 2f / 3f, p1.y + (p2.y - p1.y) * 2f / 3f)
                moveTo(h2A.x, h2A.y); lineTo(h2B.x, h2B.y)

                // Vertical thirds
                val v1A = Offset(p0.x + (p1.x - p0.x) / 3f, p0.y + (p1.y - p0.y) / 3f)
                val v1B = Offset(p3.x + (p2.x - p3.x) / 3f, p3.y + (p2.y - p3.y) / 3f)
                moveTo(v1A.x, v1A.y); lineTo(v1B.x, v1B.y)

                val v2A = Offset(p0.x + (p1.x - p0.x) * 2f / 3f, p0.y + (p1.y - p0.y) * 2f / 3f)
                val v2B = Offset(p3.x + (p2.x - p3.x) * 2f / 3f, p3.y + (p2.y - p3.y) * 2f / 3f)
                moveTo(v2A.x, v2A.y); lineTo(v2B.x, v2B.y)
            }

            drawPath(
                path = gridPath,
                color = Color.White.copy(alpha = 0.25f),
                style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
            )

            // Draw Outer Bounding cyan line
            drawPath(
                path = boundaryPath,
                color = cyanBlue,
                style = Stroke(width = 4.5f, cap = StrokeCap.Round)
            )

            // 2. Midpoints for 4 edges
            val midTop = Offset((p0.x + p1.x) / 2f, (p0.y + p1.y) / 2f)
            val midRight = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f)
            val midBottom = Offset((p2.x + p3.x) / 2f, (p2.y + p3.y) / 2f)
            val midLeft = Offset((p3.x + p0.x) / 2f, (p3.y + p0.y) / 2f)

            // Pill helper - horizontal
            fun drawHorizontalPill(center: Offset) {
                val pillWidth = 46f
                val pillHeight = 16f
                val topLeft = Offset(center.x - pillWidth / 2f, center.y - pillHeight / 2f)
                drawRoundRect(
                    color = Color.White,
                    topLeft = topLeft,
                    size = Size(pillWidth, pillHeight),
                    cornerRadius = CornerRadius(8f, 8f)
                )
                drawRoundRect(
                    color = cyanBlue,
                    topLeft = topLeft,
                    size = Size(pillWidth, pillHeight),
                    cornerRadius = CornerRadius(8f, 8f),
                    style = Stroke(width = 3.5f)
                )
            }

            // Pill helper - vertical
            fun drawVerticalPill(center: Offset) {
                val pillWidth = 16f
                val pillHeight = 46f
                val topLeft = Offset(center.x - pillWidth / 2f, center.y - pillHeight / 2f)
                drawRoundRect(
                    color = Color.White,
                    topLeft = topLeft,
                    size = Size(pillWidth, pillHeight),
                    cornerRadius = CornerRadius(8f, 8f)
                )
                drawRoundRect(
                    color = cyanBlue,
                    topLeft = topLeft,
                    size = Size(pillWidth, pillHeight),
                    cornerRadius = CornerRadius(8f, 8f),
                    style = Stroke(width = 3.5f)
                )
            }

            drawHorizontalPill(midTop)
            drawHorizontalPill(midBottom)
            drawVerticalPill(midLeft)
            drawVerticalPill(midRight)

            // 3. Draw 4 Corner Handles (Screenshot 1: Blue outer ring + White halo + Cyan center)
            listOf(p0, p1, p2, p3).forEach { pt ->
                // Outer ring
                drawCircle(
                    color = deepBlue,
                    radius = 24f,
                    center = pt,
                    style = Stroke(width = 4.5f)
                )
                // Middle white halo
                drawCircle(
                    color = Color.White,
                    radius = 18f,
                    center = pt
                )
                // Inner bright cyan solid center
                drawCircle(
                    color = cyanBlue,
                    radius = 13f,
                    center = pt
                )
            }
        }
    }
}
