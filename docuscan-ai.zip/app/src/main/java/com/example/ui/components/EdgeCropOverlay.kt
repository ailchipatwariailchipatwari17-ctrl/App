package com.example.ui.components

import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import com.example.ui.theme.TealAccent
import com.example.ui.theme.VaultAmber
import kotlin.math.hypot

@Composable
fun EdgeCropOverlay(
    cornerPoints: List<PointF>,
    onCornerMoved: (index: Int, newPoint: PointF) -> Unit,
    modifier: Modifier = Modifier
) {
    if (cornerPoints.size < 4) return

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(cornerPoints) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val touchX = change.position.x
                        val touchY = change.position.y

                        // Find closest corner point
                        var closestIdx = 0
                        var minDistance = Float.MAX_VALUE
                        cornerPoints.forEachIndexed { idx, pt ->
                            val dist = hypot(pt.x - touchX, pt.y - touchY)
                            if (dist < minDistance) {
                                minDistance = dist
                                closestIdx = idx
                            }
                        }

                        // Allow drag if within reasonable threshold
                        if (minDistance < 120f) {
                            val activePt = cornerPoints[closestIdx]
                            onCornerMoved(closestIdx, PointF(activePt.x + dragAmount.x, activePt.y + dragAmount.y))
                        }
                    }
                }
        ) {
            val p0 = Offset(cornerPoints[0].x, cornerPoints[0].y)
            val p1 = Offset(cornerPoints[1].x, cornerPoints[1].y)
            val p2 = Offset(cornerPoints[2].x, cornerPoints[2].y)
            val p3 = Offset(cornerPoints[3].x, cornerPoints[3].y)

            // Draw bounding quadrilateral polygon
            val path = Path().apply {
                moveTo(p0.x, p0.y)
                lineTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(p3.x, p3.y)
                close()
            }

            // Draw translucent highlight overlay inside boundary
            drawPath(
                path = path,
                color = TealAccent.copy(alpha = 0.22f)
            )

            // Draw edge guide border line
            drawPath(
                path = path,
                color = TealAccent,
                style = Stroke(width = 5f, cap = StrokeCap.Round)
            )

            // Draw interactive corner handles
            listOf(p0, p1, p2, p3).forEachIndexed { idx, pt ->
                drawCircle(
                    color = Color.White,
                    radius = 22f,
                    center = pt
                )
                drawCircle(
                    color = VaultAmber,
                    radius = 16f,
                    center = pt
                )
                drawCircle(
                    color = Color.Black.copy(alpha = 0.3f),
                    radius = 22f,
                    center = pt,
                    style = Stroke(width = 3f)
                )
            }
        }
    }
}
