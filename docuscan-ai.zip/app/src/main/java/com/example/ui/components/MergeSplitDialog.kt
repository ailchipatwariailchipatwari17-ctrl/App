package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.CallMerge
import androidx.compose.material.icons.automirrored.filled.CallSplit
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ScannedDocument
import com.example.util.LanguageManager

@Composable
fun MergeSplitDialog(
    availableDocuments: List<ScannedDocument>,
    onMergeSelected: (String, List<Long>) -> Unit,
    onSplitSelected: (Long, String, Int, Int) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val languageManager = remember { LanguageManager(context) }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Merge, 1: Split

    // Merge State
    var mergeTitle by remember { mutableStateOf("Merged_${System.currentTimeMillis() % 10000}") }
    val selectedDocIds = remember { mutableStateListOf<Long>() }

    // Split State
    var selectedDocForSplit by remember { mutableStateOf(availableDocuments.firstOrNull()) }
    var splitTitle by remember { mutableStateOf("Split_Pages") }
    var startPageText by remember { mutableStateOf("1") }
    var endPageText by remember { mutableStateOf("2") }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF101016)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Top App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF161622))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismissRequest) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFF241416), CircleShape)
                            .border(1.dp, Color(0xFFFA0F00), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (selectedTab == 0) Icons.AutoMirrored.Filled.CallMerge else Icons.AutoMirrored.Filled.CallSplit,
                            contentDescription = null,
                            tint = Color(0xFFFA0F00),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Text(
                        text = if (selectedTab == 0) languageManager.t("merge_pdf") else languageManager.t("split_pdf"),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Sub-tabs: Merge / Split
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFF161622),
                    contentColor = Color(0xFFFA0F00),
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = Color(0xFFFA0F00),
                            height = 2.5.dp
                        )
                    },
                    divider = {
                        HorizontalDivider(color = Color(0xFF242434), thickness = 1.dp)
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.CallMerge,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        text = {
                            Text(
                                text = languageManager.t("merge_pdf"),
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 0) Color(0xFFFA0F00) else Color(0xFF9E9EAE)
                            )
                        }
                    )

                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.CallSplit,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        text = {
                            Text(
                                text = languageManager.t("split_pdf"),
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 1) Color(0xFFFA0F00) else Color(0xFF9E9EAE)
                            )
                        }
                    )
                }

                // Content Area
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    if (selectedTab == 0) {
                        // Merge Mode
                        Column(modifier = Modifier.fillMaxSize()) {
                            OutlinedTextField(
                                value = mergeTitle,
                                onValueChange = { mergeTitle = it },
                                placeholder = { Text(languageManager.t("id_title_hint"), color = Color(0xFF7E7E90)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFFFA0F00),
                                    unfocusedBorderColor = Color(0xFF2C2C3E),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = Color(0xFF1E1E2C),
                                    unfocusedContainerColor = Color(0xFF1E1E2C)
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(availableDocuments) { doc ->
                                    val isSelected = selectedDocIds.contains(doc.id)
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (isSelected) {
                                                    selectedDocIds.remove(doc.id)
                                                } else {
                                                    selectedDocIds.add(doc.id)
                                                }
                                            }
                                            .border(
                                                1.dp,
                                                if (isSelected) Color(0xFFFA0F00) else Color(0xFF262638),
                                                RoundedCornerShape(12.dp)
                                            ),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) Color(0xFF20161C) else Color(0xFF181824)
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Description,
                                                contentDescription = null,
                                                tint = if (isSelected) Color(0xFFFA0F00) else Color(0xFF8E8E9E),
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = doc.title,
                                                    color = Color.White,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                                Text(
                                                    text = "${doc.pageCount} p • ${doc.fileSizeFormatted}",
                                                    color = Color(0xFF8E8E9E),
                                                    fontSize = 11.sp
                                                )
                                            }
                                            Checkbox(
                                                checked = isSelected,
                                                onCheckedChange = { checked ->
                                                    if (checked) selectedDocIds.add(doc.id) else selectedDocIds.remove(doc.id)
                                                },
                                                colors = CheckboxDefaults.colors(
                                                    checkedColor = Color(0xFFFA0F00),
                                                    uncheckedColor = Color(0xFF6E6E7E)
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Split Mode
                        Column(modifier = Modifier.fillMaxSize()) {
                            OutlinedTextField(
                                value = splitTitle,
                                onValueChange = { splitTitle = it },
                                placeholder = { Text(languageManager.t("id_title_hint"), color = Color(0xFF7E7E90)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFFFA0F00),
                                    unfocusedBorderColor = Color(0xFF2C2C3E),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = Color(0xFF1E1E2C),
                                    unfocusedContainerColor = Color(0xFF1E1E2C)
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = startPageText,
                                    onValueChange = { startPageText = it },
                                    label = { Text("Start", color = Color(0xFF9E9EAE), fontSize = 12.sp) },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFFFA0F00),
                                        unfocusedBorderColor = Color(0xFF2C2C3E),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedContainerColor = Color(0xFF1E1E2C),
                                        unfocusedContainerColor = Color(0xFF1E1E2C)
                                    )
                                )

                                OutlinedTextField(
                                    value = endPageText,
                                    onValueChange = { endPageText = it },
                                    label = { Text("End", color = Color(0xFF9E9EAE), fontSize = 12.sp) },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFFFA0F00),
                                        unfocusedBorderColor = Color(0xFF2C2C3E),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedContainerColor = Color(0xFF1E1E2C),
                                        unfocusedContainerColor = Color(0xFF1E1E2C)
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(availableDocuments) { doc ->
                                    val isSelected = selectedDocForSplit?.id == doc.id
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedDocForSplit = doc }
                                            .border(
                                                1.dp,
                                                if (isSelected) Color(0xFFFA0F00) else Color(0xFF262638),
                                                RoundedCornerShape(12.dp)
                                            ),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) Color(0xFF20161C) else Color(0xFF181824)
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Description,
                                                contentDescription = null,
                                                tint = if (isSelected) Color(0xFFFA0F00) else Color(0xFF8E8E9E),
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = doc.title,
                                                    color = Color.White,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                                Text(
                                                    text = "${doc.pageCount} p • ${doc.fileSizeFormatted}",
                                                    color = Color(0xFF8E8E9E),
                                                    fontSize = 11.sp
                                                )
                                            }
                                            if (isSelected) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = Color(0xFFFA0F00),
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Action Bar
                Surface(
                    color = Color(0xFF161622),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(16.dp)) {
                        if (selectedTab == 0) {
                            val canMerge = selectedDocIds.size >= 2
                            Button(
                                onClick = {
                                    onMergeSelected(mergeTitle, selectedDocIds.toList())
                                    onDismissRequest()
                                },
                                enabled = canMerge,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFA0F00),
                                    disabledContainerColor = Color(0xFF332024)
                                ),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.CallMerge,
                                    contentDescription = null,
                                    tint = if (canMerge) Color.White else Color(0xFF888888),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = languageManager.t("merge_pdf"),
                                    color = if (canMerge) Color.White else Color(0xFF888888),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            val doc = selectedDocForSplit
                            val startP = startPageText.toIntOrNull() ?: 1
                            val endP = endPageText.toIntOrNull() ?: 1
                            val canSplit = doc != null && startP in 1..endP

                            Button(
                                onClick = {
                                    if (doc != null) {
                                        onSplitSelected(doc.id, splitTitle, startP, endP)
                                        onDismissRequest()
                                    }
                                },
                                enabled = canSplit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFA0F00),
                                    disabledContainerColor = Color(0xFF332024)
                                ),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.CallSplit,
                                    contentDescription = null,
                                    tint = if (canSplit) Color.White else Color(0xFF888888),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = languageManager.t("split_pdf"),
                                    color = if (canSplit) Color.White else Color(0xFF888888),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
