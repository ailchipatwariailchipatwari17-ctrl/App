package com.example.ui.components

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.util.AppThemeManager
import com.example.util.LanguageManager

class TermsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_terms_conditions_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_TERMS_ACCEPTED = "is_terms_accepted_v1"
    }

    var isTermsAccepted: Boolean
        get() = prefs.getBoolean(KEY_TERMS_ACCEPTED, false)
        set(value) = prefs.edit().putBoolean(KEY_TERMS_ACCEPTED, value).apply()
}

@Composable
fun TermsAndConditionsDialog(
    onAccept: () -> Unit = {},
    onAccepted: () -> Unit = onAccept,
    onDismissRequest: () -> Unit = {},
    isForcedNewUserMode: Boolean = false
) {
    val context = LocalContext.current
    val languageManager = remember { LanguageManager(context) }
    val termsManager = remember { TermsManager(context) }
    val currentPalette by AppThemeManager.currentPaletteFlow.collectAsStateWithLifecycle()
    var isChecked by remember { mutableStateOf(true) }

    Dialog(
        onDismissRequest = {
            if (!isForcedNewUserMode) {
                onDismissRequest()
            }
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF101016)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                // Top App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF161622))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(currentPalette.primaryAccent.copy(alpha = 0.15f), CircleShape)
                            .border(1.5.dp, currentPalette.primaryAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gavel,
                            contentDescription = null,
                            tint = currentPalette.primaryAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = languageManager.t("terms_conditions"),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "नियम व गोपनीयता शर्तें (Privacy & Terms)",
                            fontSize = 11.sp,
                            color = Color(0xFF9E9EA8)
                        )
                    }
                }

                // Terms Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFF262638), RoundedCornerShape(16.dp)),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF181824))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // 1. Data Privacy
                            Text(
                                text = "1. यूज़र डेटा गोपनीयता (100% User Data Privacy)",
                                color = Color(0xFF4ADE80),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "आपके द्वारा स्कैन या अपलोड किए गए सभी दस्तावेज़ (PDFs, फ़ोटो, नोट्स) आपकी व्यक्तिगत संपत्ति हैं। हम यूज़र की स्पष्ट सहमति (Consent) के बिना किसी भी तीसरे पक्ष (Third Party) के साथ आपका डेटा साझा नहीं करते हैं। सारा डेटा लोकल सैंडबॉक्स में सुरक्षित रहता है।",
                                color = Color(0xFFC0C0D0),
                                fontSize = 12.5.sp,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // 2. Misinformation & Deepfake Prohibition
                            Text(
                                text = "2. भ्रामक जानकारी व डीपफेक निषेध (IT Rules Compliance)",
                                color = Color(0xFF60A5FA),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "सरकारी IT नियमों के तहत AI द्वारा भ्रामक/गलत जानकारी, डीपफेक (Synthetic Content), अश्लील व नग्न सामग्री, जाली प्रमाण पत्र या नफ़रत फैलाने वाले कंटेंट का निर्माण पूर्णतः प्रतिबंधित है। हमारा AI असिस्टेंट ऐसा कोई कंटेंट नहीं बनाता।",
                                color = Color(0xFFC0C0D0),
                                fontSize = 12.5.sp,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // 3. Copyright & IP Protection
                            Text(
                                text = "3. कॉपीराइट व बौद्धिक संपदा (Copyright Protection)",
                                color = Color(0xFFFBBF24),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "हम कॉपीराइट और बौद्धिक संपदा का पूरा सम्मान करते हैं। AI किसी की कॉपीराइट सामग्री, पेड बुक्स या कॉपीराइटेड कोड को अनधिकृत रूप से कॉपी/पाइरेट नहीं करता है।",
                                color = Color(0xFFC0C0D0),
                                fontSize = 12.5.sp,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // 4. AI Disclaimer
                            Text(
                                text = "4. AI अस्वीकरण (Mandatory AI Disclaimer)",
                                color = Color(0xFFF472B6),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "\"यह AI द्वारा जनरेट किया गया उत्तर है, महत्वपूर्ण जानकारी को दोबारा जाँच लें। AI से गलतियाँ हो सकती है।\"",
                                color = Color(0xFFFBCFE8),
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                lineHeight = 18.sp
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isChecked = !isChecked }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { isChecked = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = currentPalette.primaryAccent,
                                uncheckedColor = Color(0xFF6E6E80)
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = languageManager.t("agree_terms"),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Elevated Bottom Action Bar (Slightly higher with generous bottom margin so it is always easy to press)
                Surface(
                    color = Color(0xFF161622),
                    modifier = Modifier.fillMaxWidth(),
                    shadowElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF262638))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 32.dp)
                    ) {
                        Button(
                            onClick = {
                                termsManager.isTermsAccepted = true
                                onAccept()
                                onAccepted()
                            },
                            enabled = isChecked,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = currentPalette.primaryAccent,
                                disabledContainerColor = Color(0xFF332024)
                            ),
                            shape = RoundedCornerShape(27.dp),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp, pressedElevation = 1.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (isChecked) Color.White else Color(0xFF888888),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "नियम स्वीकारें और आगे बढ़ें (Accept & Continue)",
                                color = if (isChecked) Color.White else Color(0xFF888888),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
