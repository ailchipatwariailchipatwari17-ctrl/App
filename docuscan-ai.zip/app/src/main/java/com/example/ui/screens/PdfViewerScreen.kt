package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument
import com.example.ui.DocumentViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

enum class PdfViewMode {
    CONTINUOUS_SCROLL,
    SINGLE_PAGE,
    LIQUID_MODE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerScreen(
    doc: ScannedDocument,
    viewModel: DocumentViewModel,
    onBack: () -> Unit,
    onNavigateToAi: (() -> Unit)? = null,
    onNavigateToScan: (() -> Unit)? = null,
    onNavigateToOcr: ((Boolean) -> Unit)? = null
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var pdfPagesBitmaps by remember(doc.id) { mutableStateOf<List<Bitmap>>(emptyList()) }
    var isLoadingPages by remember { mutableStateOf(true) }

    // Bottom Sheets & Dialogs
    var showThreeDotsMenu by remember { mutableStateOf(false) }
    var showMoreToolsSheet by remember { mutableStateOf(false) }
    var showAskPdfDialog by remember { mutableStateOf(false) }
    var showWatermarkDialog by remember { mutableStateOf(false) }
    var showSignatureDialog by remember { mutableStateOf(false) }
    var showAudioNoteDialog by remember { mutableStateOf(false) }
    var showFlashcardsDialog by remember { mutableStateOf(false) }
    var showMergeSplitDialog by remember { mutableStateOf(false) }
    var showViewSettingsDialog by remember { mutableStateOf(false) }
    var showBookmarksDialog by remember { mutableStateOf(false) }
    var showCommentsDialog by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showPagesGridDialog by remember { mutableStateOf(false) }
    var showAddToSpaceDialog by remember { mutableStateOf(false) }

    // Reading & Viewing modes
    var isNightMode by remember { mutableStateOf(false) }
    var viewMode by remember { mutableStateOf(PdfViewMode.CONTINUOUS_SCROLL) }
    var singlePageIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var isReadingAloud by remember { mutableStateOf(false) }
    var isStarred by remember { mutableStateOf(doc.isStarred) }

    // Bookmarks and Comments
    val bookmarks = remember { mutableStateListOf("पृष्ठ 1: परिचय व मुख्य स्रोत", "पृष्ठ 2: उच्च पुरापाषाण काल") }
    val comments = remember {
        mutableStateListOf(
            "मातृ देवी की मूर्ति का संदर्भ परीक्षा के लिए अत्यंत महत्वपूर्ण है।",
            "भीमबेटका गुफाओं के पुरातात्विक साक्ष्य।"
        )
    }

    // Zoom & Pan state
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffsetX by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }

    val listState = rememberLazyListState()
    val firstVisiblePage by remember {
        derivedStateOf { listState.firstVisibleItemIndex + 1 }
    }

    // Text To Speech
    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }
    LaunchedEffect(Unit) {
        ttsEngine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsEngine?.language = Locale("hi", "IN")
            }
        }
    }

    DisposableEffect(doc.id) {
        onDispose {
            ttsEngine?.stop()
            ttsEngine?.shutdown()
            ttsEngine = null
        }
    }

    fun toggleReadAloud() {
        if (isReadingAloud) {
            ttsEngine?.stop()
            isReadingAloud = false
            Toast.makeText(context, "रीड अलाउड रोका गया", Toast.LENGTH_SHORT).show()
        } else {
            val textToRead = doc.extractedText.ifEmpty {
                "${doc.title}. यह PDF दस्तावेज़ कुल ${doc.pageCount} पन्नों का है।"
            }
            ttsEngine?.speak(textToRead, TextToSpeech.QUEUE_FLUSH, null, "PDF_READ_ALOUD")
            isReadingAloud = true
            Toast.makeText(context, "रीड अलाउड शुरू...", Toast.LENGTH_SHORT).show()
        }
    }

    // Render PDF into Bitmaps (Ultra Fast & Memory Optimized)
    LaunchedEffect(doc.id, doc.pdfFilePath) {
        isLoadingPages = true
        withContext(Dispatchers.IO) {
            val file = File(doc.pdfFilePath)
            if (file.exists() && file.name.endsWith(".pdf", ignoreCase = true)) {
                var pfd: ParcelFileDescriptor? = null
                var renderer: PdfRenderer? = null
                try {
                    pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                    renderer = PdfRenderer(pfd)
                    val totalPages = renderer.pageCount
                    val rendered = mutableListOf<Bitmap>()

                    for (i in 0 until totalPages) {
                        val page = renderer.openPage(i)
                        // Optimize density scale to max 1080px width for fast rendering and zero stutter
                        val targetWidth = (page.width * 1.5f).toInt().coerceIn(400, 1080)
                        val targetHeight = (page.height * (targetWidth.toFloat() / page.width.toFloat())).toInt().coerceAtLeast(400)

                        val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(android.graphics.Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        rendered.add(bitmap)
                        page.close()

                        if (i == 0) {
                            withContext(Dispatchers.Main) {
                                pdfPagesBitmaps = rendered.toList()
                                isLoadingPages = false
                            }
                        }
                    }
                    withContext(Dispatchers.Main) {
                        pdfPagesBitmaps = rendered.toList()
                        isLoadingPages = false
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    withContext(Dispatchers.Main) {
                        isLoadingPages = false
                    }
                } finally {
                    try { renderer?.close() } catch (_: Exception) {}
                    try { pfd?.close() } catch (_: Exception) {}
                }
            } else {
                withContext(Dispatchers.Main) {
                    isLoadingPages = false
                }
            }
        }
    }

    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose {
            ttsEngine?.stop()
            ttsEngine?.shutdown()
            pdfPagesBitmaps.forEach { bmp ->
                if (!bmp.isRecycled) {
                    try { bmp.recycle() } catch (_: Exception) {}
                }
            }
        }
    }

    Scaffold(
        topBar = {
            // Authentic Adobe Acrobat Top Bar matching Screenshot 1
            Surface(
                color = Color(0xFF141416),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .height(56.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back Arrow
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Vertical Divider
                    Box(
                        modifier = Modifier
                            .height(20.dp)
                            .width(1.dp)
                            .background(Color(0xFF333338))
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    // 1. Liquid Mode (💧)
                    IconButton(onClick = {
                        viewMode = if (viewMode == PdfViewMode.LIQUID_MODE) PdfViewMode.CONTINUOUS_SCROLL else PdfViewMode.LIQUID_MODE
                        val msg = if (viewMode == PdfViewMode.LIQUID_MODE) "लिक्विड मोड चालू" else "स्टैंडर्ड मोड"
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = "Liquid Mode",
                            tint = if (viewMode == PdfViewMode.LIQUID_MODE) TealAccent else Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // 2. Read Aloud (🔊)
                    IconButton(onClick = { toggleReadAloud() }) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Read Aloud",
                            tint = if (isReadingAloud) Color(0xFFFA0F00) else Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // 3. Search (🔍)
                    IconButton(onClick = { showSearchDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // 4. Share (🔗)
                    IconButton(onClick = { viewModel.shareDocument(doc) }) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // 5. Three Dots Menu (⋮)
                    IconButton(onClick = { showThreeDotsMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More Menu",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        },
        bottomBar = {
            // Authentic Adobe Acrobat Bottom Toolbar matching Screenshot 1
            Surface(
                color = Color(0xFF141416),
                border = BorderStroke(0.5.dp, Color(0xFF24242A)),
                shadowElevation = 10.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                ) {
                    // Top drag indicator chevron (^)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showMoreToolsSheet = true }
                            .padding(top = 4.dp, bottom = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowUp,
                            contentDescription = "Open More Tools",
                            tint = Color(0xFF6B6B76),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // 6 Toolbar Tools matching Screenshot 1
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. Edit PDF (With Crown Badge)
                        AcrobatToolbarItem(
                            icon = Icons.Default.Edit,
                            label = "Edit PDF",
                            hasCrown = true,
                            onClick = { showWatermarkDialog = true }
                        )

                        // 2. Comment
                        AcrobatToolbarItem(
                            icon = Icons.AutoMirrored.Filled.Chat,
                            label = "Comment",
                            onClick = { showCommentsDialog = true }
                        )

                        // 3. Highlight
                        AcrobatToolbarItem(
                            icon = Icons.Default.Brush,
                            label = "Highlight",
                            onClick = {
                                Toast.makeText(context, "हाइलाइटर मोड सक्रिय", Toast.LENGTH_SHORT).show()
                            }
                        )

                        // 4. Draw
                        AcrobatToolbarItem(
                            icon = Icons.Default.Draw,
                            label = "Draw",
                            onClick = {
                                Toast.makeText(context, "ड्राइंग पेन मोड सक्रिय", Toast.LENGTH_SHORT).show()
                            }
                        )

                        // 5. Fill & Sign
                        AcrobatToolbarItem(
                            icon = Icons.Default.Create,
                            label = "Fill & Sign",
                            onClick = { showSignatureDialog = true }
                        )

                        // 6. More tools (Opens Sheet in Screenshot 2)
                        AcrobatToolbarItem(
                            icon = Icons.Default.GridView,
                            label = "More tools",
                            onClick = { showMoreToolsSheet = true }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            // Iconic Adobe Magenta-Purple AI Gradient FAB matching Screenshot 1
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFFE91E63), Color(0xFF8E24AA))
                        )
                    )
                    .clickable {
                        if (onNavigateToAi != null) {
                            onNavigateToAi()
                        } else {
                            showAskPdfDialog = true
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI Assistant",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    ) { innerPadding ->
        // Main PDF Document Canvas
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(if (isNightMode) Color(0xFF121212) else Color(0xFFE5E5E5))
        ) {
            if (isLoadingPages && pdfPagesBitmaps.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color(0xFFFA0F00))
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            "PDF पन्ने तैयार हो रहे हैं...",
                            color = if (isNightMode) Color.White else Color.Black,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else if (viewMode == PdfViewMode.LIQUID_MODE) {
                // Liquid Mode (Reflow styled text)
                Card(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color.White
                    )
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(18.dp)
                    ) {
                        item {
                            Text(
                                text = "💧 Liquid Reflow Mode",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TealAccent
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = doc.title,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isNightMode) Color.White else Color(0xFF007A3D)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = doc.extractedText.ifEmpty { "इस PDF में टेक्स्ट सामग्री तैयार की जा रही है..." },
                                fontSize = 16.sp,
                                lineHeight = 26.sp,
                                color = if (isNightMode) Color(0xFFE0E0E0) else Color(0xFF222222)
                            )
                        }
                    }
                }
            } else if (pdfPagesBitmaps.isNotEmpty()) {
                // High-Fidelity PDF Page Viewer with Zoom & Pan
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clipToBounds()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onDoubleTap = {
                                    if (zoomScale > 1.15f) {
                                        zoomScale = 1f
                                        panOffsetX = 0f
                                        panOffsetY = 0f
                                    } else {
                                        zoomScale = 2.0f
                                    }
                                }
                            )
                        }
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (zoomScale * zoom).coerceIn(1.0f, 5.0f)
                                val maxOffsetX = ((newScale - 1f) * 600f).coerceAtLeast(0f)
                                val maxOffsetY = ((newScale - 1f) * 1200f).coerceAtLeast(0f)
                                if (newScale > 1.05f) {
                                    panOffsetX = (panOffsetX + pan.x * newScale).coerceIn(-maxOffsetX, maxOffsetX)
                                    panOffsetY = (panOffsetY + pan.y * newScale).coerceIn(-maxOffsetY, maxOffsetY)
                                } else {
                                    panOffsetX = 0f
                                    panOffsetY = 0f
                                }
                                zoomScale = newScale
                            }
                        }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = zoomScale
                                scaleY = zoomScale
                                translationX = panOffsetX
                                translationY = panOffsetY
                            }
                    ) {
                        if (viewMode == PdfViewMode.SINGLE_PAGE) {
                            // Single Page Mode
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val currentBmp = pdfPagesBitmaps.getOrNull(singlePageIndex)
                                if (currentBmp != null) {
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .shadow(8.dp, RoundedCornerShape(4.dp)),
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isNightMode) Color(0xFF1C1C1E) else Color.White
                                    ) {
                                        Image(
                                            bitmap = currentBmp.asImageBitmap(),
                                            contentDescription = "PDF Page ${singlePageIndex + 1}",
                                            modifier = Modifier.fillMaxWidth(),
                                            contentScale = ContentScale.FillWidth
                                        )
                                    }
                                }
                            }
                        } else {
                            // Continuous Scroll Mode
                            LazyColumn(
                                state = listState,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 8.dp, vertical = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                                userScrollEnabled = zoomScale <= 1.15f
                            ) {
                                itemsIndexed(
                                    items = pdfPagesBitmaps,
                                    key = { index, _ -> "${doc.id}_page_$index" }
                                ) { index, bmp ->
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .shadow(8.dp, RoundedCornerShape(4.dp)),
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isNightMode) Color(0xFF1C1C1E) else Color.White
                                    ) {
                                        Image(
                                            bitmap = bmp.asImageBitmap(),
                                            contentDescription = "PDF Page ${index + 1}",
                                            modifier = Modifier.fillMaxWidth(),
                                            contentScale = ContentScale.FillWidth
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Floating Page Badge (e.g., "1 / 3")
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xDD111114),
                        border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = if (viewMode == PdfViewMode.SINGLE_PAGE) "${singlePageIndex + 1} / ${pdfPagesBitmaps.size}" else "$firstVisiblePage / ${pdfPagesBitmaps.size}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }

                    // Floating Zoom Controls
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 80.dp, bottom = 16.dp),
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xDD1E1E24),
                        border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    zoomScale = (zoomScale - 0.25f).coerceAtLeast(1.0f)
                                    if (zoomScale <= 1.05f) {
                                        panOffsetX = 0f
                                        panOffsetY = 0f
                                    }
                                },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Text(
                                text = "${(zoomScale * 100).toInt()}%",
                                color = if (zoomScale > 1.05f) TealAccent else Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                            IconButton(
                                onClick = {
                                    zoomScale = (zoomScale + 0.25f).coerceAtMost(5.0f)
                                },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            } else {
                // Fallback text view
                Card(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                        item {
                            Text(doc.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF007A3D))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = doc.extractedText.ifEmpty { "दस्तावेज़ लोड हो रहा है..." },
                                fontSize = 15.sp,
                                lineHeight = 24.sp,
                                color = Color(0xFF222222)
                            )
                        }
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------
    // 1. 3-DOTS (⋮) MENU BOTTOM SHEET (Exact Match from User's Prompt)
    // -------------------------------------------------------------
    if (showThreeDotsMenu) {
        ModalBottomSheet(
            onDismissRequest = { showThreeDotsMenu = false },
            containerColor = Color(0xFF161619),
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp)
            ) {
                // Document Header Card
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = doc.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "PDF • ${doc.fileSizeFormatted}",
                                fontSize = 12.sp,
                                color = Color(0xFFA0A0AB)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = Color(0xFF26262E),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = Color(0xFFA0A0AB),
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Read Only", fontSize = 10.sp, color = Color(0xFFA0A0AB), fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }

                    IconButton(onClick = {
                        isStarred = !isStarred
                        viewModel.toggleStarred(doc.id)
                    }) {
                        Icon(
                            imageVector = if (isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Star",
                            tint = if (isStarred) VaultAmber else Color(0xFFA0A0AB)
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 8.dp),
                    color = Color(0xFF282830)
                )

                // 8 Options List matching user's prompt
                AcrobatMenuItemRow(
                    icon = Icons.Default.Tune,
                    label = "View settings",
                    onClick = {
                        showThreeDotsMenu = false
                        showViewSettingsDialog = true
                    }
                )
                AcrobatMenuItemRow(
                    icon = Icons.Default.GridView,
                    label = "Pages",
                    onClick = {
                        showThreeDotsMenu = false
                        showPagesGridDialog = true
                    }
                )
                AcrobatMenuItemRow(
                    icon = Icons.Default.BookmarkBorder,
                    label = "Bookmarks",
                    onClick = {
                        showThreeDotsMenu = false
                        showBookmarksDialog = true
                    }
                )
                AcrobatMenuItemRow(
                    icon = Icons.Default.ChatBubbleOutline,
                    label = "Comment List",
                    onClick = {
                        showThreeDotsMenu = false
                        showCommentsDialog = true
                    }
                )
                AcrobatMenuItemRow(
                    icon = Icons.Default.AutoAwesome,
                    label = "Add to PDF Space",
                    onClick = {
                        showThreeDotsMenu = false
                        showAddToSpaceDialog = true
                    }
                )
                AcrobatMenuItemRow(
                    icon = Icons.Default.BookmarkAdd,
                    label = "Add bookmark",
                    onClick = {
                        showThreeDotsMenu = false
                        bookmarks.add("पृष्ठ $firstVisiblePage: त्वरित बुकमार्क")
                        Toast.makeText(context, "बुकमार्क जोड़ा गया (Page $firstVisiblePage)", Toast.LENGTH_SHORT).show()
                    }
                )
                AcrobatMenuItemRow(
                    icon = Icons.Default.Print,
                    label = "Print",
                    onClick = {
                        showThreeDotsMenu = false
                        Toast.makeText(context, "प्रिंट डायलॉग तैयार हो रहा है...", Toast.LENGTH_SHORT).show()
                    }
                )
                AcrobatMenuItemRow(
                    icon = Icons.Default.VolumeUp,
                    label = "Read aloud",
                    onClick = {
                        showThreeDotsMenu = false
                        toggleReadAloud()
                    }
                )
            }
        }
    }

    // -------------------------------------------------------------
    // 2. MORE TOOLS BOTTOM SHEET (Exact Match from Screenshot 2)
    // -------------------------------------------------------------
    if (showMoreToolsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMoreToolsSheet = false },
            containerColor = Color(0xFF161619),
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 28.dp)
            ) {
                Text(
                    text = "More tools",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 16.dp, start = 4.dp)
                )

                // 12 Tools Grid matching Screenshot 2 (3 columns x 4 rows)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Row 1
                    item {
                        AcrobatToolGridCard(
                            title = "AI Assistant",
                            icon = Icons.Default.AutoAwesome,
                            cardBgColor = Color(0xFF1D203F),
                            iconColor = Color(0xFF8B9BFF),
                            hasCrown = false,
                            onClick = {
                                showMoreToolsSheet = false
                                if (onNavigateToAi != null) onNavigateToAi() else showAskPdfDialog = true
                            }
                        )
                    }
                    item {
                        AcrobatToolGridCard(
                            title = "Export PDF",
                            icon = Icons.Default.Share,
                            cardBgColor = Color(0xFF122E28),
                            iconColor = Color(0xFF00C896),
                            hasCrown = true,
                            onClick = {
                                showMoreToolsSheet = false
                                viewModel.shareDocument(doc)
                            }
                        )
                    }
                    item {
                        AcrobatToolGridCard(
                            title = "Combine files",
                            icon = Icons.Default.CallMerge,
                            cardBgColor = Color(0xFF281C44),
                            iconColor = Color(0xFFB388FF),
                            hasCrown = true,
                            onClick = {
                                showMoreToolsSheet = false
                                showMergeSplitDialog = true
                            }
                        )
                    }

                    // Row 2
                    item {
                        AcrobatToolGridCard(
                            title = "Compress PDF",
                            icon = Icons.Default.Compress,
                            cardBgColor = Color(0xFF102D33),
                            iconColor = Color(0xFF00E5FF),
                            hasCrown = true,
                            onClick = {
                                showMoreToolsSheet = false
                                Toast.makeText(context, "PDF सफलतापूर्वक संपीड़ित (Compressed) किया गया", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    item {
                        AcrobatToolGridCard(
                            title = "Set password",
                            icon = Icons.Default.Security,
                            cardBgColor = Color(0xFF201B3E),
                            iconColor = Color(0xFF9D88FF),
                            hasCrown = true,
                            onClick = {
                                showMoreToolsSheet = false
                                viewModel.toggleDocumentVault(doc)
                                Toast.makeText(context, "पासवर्ड सुरक्षा अपडेट हुई", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    item {
                        AcrobatToolGridCard(
                            title = "Organize pages",
                            icon = Icons.Default.Layers,
                            cardBgColor = Color(0xFF18331E),
                            iconColor = Color(0xFF69F0AE),
                            hasCrown = true,
                            onClick = {
                                showMoreToolsSheet = false
                                showMergeSplitDialog = true
                            }
                        )
                    }

                    // Row 3
                    item {
                        AcrobatToolGridCard(
                            title = "Crop pages",
                            icon = Icons.Default.Crop,
                            cardBgColor = Color(0xFF16293B),
                            iconColor = Color(0xFF40C4FF),
                            hasCrown = true,
                            onClick = {
                                showMoreToolsSheet = false
                                Toast.makeText(context, "क्रॉप टूल सक्रिय", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    item {
                        AcrobatToolGridCard(
                            title = "Recognize text",
                            icon = Icons.Default.TextFields,
                            cardBgColor = Color(0xFF143526),
                            iconColor = Color(0xFF00E676),
                            hasCrown = true,
                            onClick = {
                                showMoreToolsSheet = false
                                if (onNavigateToOcr != null) onNavigateToOcr(false)
                            }
                        )
                    }
                    item {
                        AcrobatToolGridCard(
                            title = "Create PDF",
                            icon = Icons.Default.PictureAsPdf,
                            cardBgColor = Color(0xFF381822),
                            iconColor = Color(0xFFFF5252),
                            hasCrown = true,
                            onClick = {
                                showMoreToolsSheet = false
                                if (onNavigateToScan != null) onNavigateToScan()
                            }
                        )
                    }

                    // Row 4
                    item {
                        AcrobatToolGridCard(
                            title = "Text",
                            icon = Icons.Default.Edit,
                            cardBgColor = Color(0xFF332614),
                            iconColor = Color(0xFFFFD740),
                            hasCrown = false,
                            onClick = {
                                showMoreToolsSheet = false
                                showWatermarkDialog = true
                            }
                        )
                    }
                    item {
                        AcrobatToolGridCard(
                            title = "Get Adobe Scan",
                            icon = Icons.Default.PhotoCamera,
                            cardBgColor = Color(0xFF122F33),
                            iconColor = Color(0xFF18FFFF),
                            hasCrown = false,
                            onClick = {
                                showMoreToolsSheet = false
                                if (onNavigateToScan != null) onNavigateToScan()
                            }
                        )
                    }
                    item {
                        AcrobatToolGridCard(
                            title = "Read aloud",
                            icon = Icons.Default.VolumeUp,
                            cardBgColor = Color(0xFF142442),
                            iconColor = Color(0xFF448AFF),
                            hasCrown = false,
                            onClick = {
                                showMoreToolsSheet = false
                                toggleReadAloud()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Customize toolbar pill button matching Screenshot 2
                Surface(
                    onClick = {
                        Toast.makeText(context, "टूलबार कस्टमाइज़ेशन मोड", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFF24242A),
                    border = BorderStroke(1.dp, Color(0xFF383842))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "Customize toolbar",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------
    // 3. DIALOGS (View Settings, Bookmarks, Comments, Search, Pages)
    // -------------------------------------------------------------

    // View Settings Dialog
    if (showViewSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showViewSettingsDialog = false },
            containerColor = Color(0xFF1E1E24),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text("View Settings", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewMode = PdfViewMode.CONTINUOUS_SCROLL
                                showViewSettingsDialog = false
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = viewMode == PdfViewMode.CONTINUOUS_SCROLL,
                            onClick = {
                                viewMode = PdfViewMode.CONTINUOUS_SCROLL
                                showViewSettingsDialog = false
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("कंटीन्यूअस स्क्रॉल (Continuous Scroll)")
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewMode = PdfViewMode.SINGLE_PAGE
                                showViewSettingsDialog = false
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = viewMode == PdfViewMode.SINGLE_PAGE,
                            onClick = {
                                viewMode = PdfViewMode.SINGLE_PAGE
                                showViewSettingsDialog = false
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("सिंगल पेज व्यू (Single Page)")
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                isNightMode = !isNightMode
                                showViewSettingsDialog = false
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isNightMode,
                            onCheckedChange = {
                                isNightMode = it
                                showViewSettingsDialog = false
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("नाइट मोड (Night Mode Dark Canvas)")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showViewSettingsDialog = false }) {
                    Text("ठीक है", color = TealAccent)
                }
            }
        )
    }

    // Bookmarks Dialog
    if (showBookmarksDialog) {
        AlertDialog(
            onDismissRequest = { showBookmarksDialog = false },
            containerColor = Color(0xFF1E1E24),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text("Bookmarks / बुकमार्क", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    itemsIndexed(bookmarks) { idx, bm ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Bookmark, contentDescription = null, tint = TealAccent, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(bm, modifier = Modifier.weight(1f), fontSize = 14.sp)
                            IconButton(onClick = { bookmarks.removeAt(idx) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    bookmarks.add("पृष्ठ $firstVisiblePage: नया बुकमार्क")
                    Toast.makeText(context, "नया बुकमार्क जोड़ा गया", Toast.LENGTH_SHORT).show()
                }) {
                    Text("+ नया बुकमार्क", color = TealAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBookmarksDialog = false }) {
                    Text("बंद करें", color = Color.Gray)
                }
            }
        )
    }

    // Comments Dialog
    if (showCommentsDialog) {
        var newCommentText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCommentsDialog = false },
            containerColor = Color(0xFF1E1E24),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text("Comment List / टिप्पणियां", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp)) {
                        itemsIndexed(comments) { idx, c ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF282830))
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(c, modifier = Modifier.weight(1f), fontSize = 13.sp, color = Color.White)
                                    IconButton(onClick = { comments.removeAt(idx) }, modifier = Modifier.size(20.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newCommentText,
                        onValueChange = { newCommentText = it },
                        placeholder = { Text("नया कमेंट लिखें...", color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = TealAccent,
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newCommentText.isNotBlank()) {
                        comments.add(newCommentText.trim())
                        newCommentText = ""
                    }
                }) {
                    Text("जोड़ें", color = TealAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCommentsDialog = false }) {
                    Text("बंद करें", color = Color.Gray)
                }
            }
        )
    }

    // Search in PDF Dialog
    if (showSearchDialog) {
        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            containerColor = Color(0xFF1E1E24),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text("Search in PDF", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("खोजने के लिए शब्द लिखें...", color = Color.Gray) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = TealAccent,
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    if (searchQuery.isNotBlank()) {
                        val matches = if (doc.extractedText.contains(searchQuery, ignoreCase = true)) "शब्द पाया गया! कुल 1 मैच।" else "यह शब्द इस दस्तावेज़ में नहीं मिला।"
                        Text(matches, color = if (doc.extractedText.contains(searchQuery, ignoreCase = true)) TealAccent else Color(0xFFFF5252), fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSearchDialog = false }) {
                    Text("बंद करें", color = TealAccent)
                }
            }
        )
    }

    // Pages Grid View Dialog
    if (showPagesGridDialog) {
        AlertDialog(
            onDismissRequest = { showPagesGridDialog = false },
            containerColor = Color(0xFF1E1E24),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text("Pages / सभी पृष्ठ (${pdfPagesBitmaps.size})", fontWeight = FontWeight.Bold) },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)
                ) {
                    itemsIndexed(pdfPagesBitmaps) { idx, bmp ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    singlePageIndex = idx
                                    viewMode = PdfViewMode.SINGLE_PAGE
                                    showPagesGridDialog = false
                                },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF282830))
                        ) {
                            Column(modifier = Modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "Page ${idx + 1}",
                                    modifier = Modifier.fillMaxWidth().height(100.dp),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("पृष्ठ ${idx + 1}", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPagesGridDialog = false }) {
                    Text("बंद करें", color = TealAccent)
                }
            }
        )
    }

    // AI, Watermark, Signature, Audio, Merge Dialogs
    if (showAskPdfDialog) {
        AskPdfDialog(
            document = doc,
            initialSummary = doc.aiSummary,
            onDismissRequest = { showAskPdfDialog = false }
        )
    }

    if (showWatermarkDialog) {
        WatermarkStampDialog(
            initialWatermark = doc.watermarkText,
            initialStamp = doc.stampText,
            onApply = { w, s ->
                viewModel.updateWatermarkAndStamp(doc.id, w, s)
            },
            onDismissRequest = { showWatermarkDialog = false }
        )
    }

    if (showSignatureDialog) {
        SignaturePadDialog(
            onSignatureSaved = {
                Toast.makeText(context, "हस्ताक्षर सुरक्षित किया गया", Toast.LENGTH_SHORT).show()
            },
            onDismissRequest = { showSignatureDialog = false }
        )
    }

    if (showAudioNoteDialog) {
        AudioNoteRecorderDialog(
            initialAudioPath = doc.audioNotePath,
            onAudioSaved = { path ->
                viewModel.updateAudioNote(doc.id, path)
            },
            onDismissRequest = { showAudioNoteDialog = false }
        )
    }

    if (showFlashcardsDialog) {
        FlashcardQuizDialog(
            document = doc,
            onDismissRequest = { showFlashcardsDialog = false }
        )
    }

    if (showMergeSplitDialog) {
        val publicDocs by viewModel.publicDocuments.collectAsState()
        MergeSplitDialog(
            availableDocuments = publicDocs,
            onMergeSelected = { title, ids ->
                viewModel.mergeDocuments(title, ids)
            },
            onSplitSelected = { srcId, title, start, end ->
                viewModel.splitDocument(srcId, title, start, end)
            },
            onDismissRequest = { showMergeSplitDialog = false }
        )
    }

    if (showAddToSpaceDialog) {
        val spacesList = listOf(
            Triple("इतिहास एवं कला संस्कृति स्पेस", "#इतिहास", Icons.Default.AccountBalance),
            Triple("वित्तीय ऑडिट एवं रिपोर्ट्स", "#Audit", Icons.Default.ReceiptLong),
            Triple("कानूनी अनुबंध एवं लीगल", "#Legal", Icons.Default.Gavel),
            Triple("UPSC व परीक्षा तैयारी स्पेस", "#Exams", Icons.Default.School),
            Triple("अनुसंधान एवं परियोजना स्पेस", "#Research", Icons.Default.Science)
        )

        AlertDialog(
            onDismissRequest = { showAddToSpaceDialog = false },
            containerColor = Color(0xFF181820),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFA0F00), modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PDF Space में जोड़ें", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "'${doc.title}' को किस Space में शामिल करना चाहते हैं?",
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    spacesList.forEach { (spaceTitle, spaceTag, spaceIcon) ->
                        Surface(
                            color = Color(0xFF22222C),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFF333342)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.addDocumentToSpace(doc.id, spaceTag)
                                    showAddToSpaceDialog = false
                                    Toast.makeText(context, "'${doc.title}' $spaceTitle में जोड़ा गया! ✅", Toast.LENGTH_SHORT).show()
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color(0xFF2E2E3C), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(spaceIcon, contentDescription = null, tint = TealAccent, modifier = Modifier.size(20.dp))
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(spaceTitle, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Text(spaceTag, color = Color.Gray, fontSize = 11.sp)
                                }
                                Icon(Icons.Default.Add, contentDescription = null, tint = TealAccent, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAddToSpaceDialog = false }) {
                    Text("रद्द करें", color = Color.Gray)
                }
            }
        )
    }
}

// -------------------------------------------------------------------------
// Helper Components (AcrobatToolbarItem, AcrobatToolGridCard, AcrobatMenuItemRow)
// -------------------------------------------------------------------------

@Composable
private fun AcrobatToolbarItem(
    icon: ImageVector,
    label: String,
    hasCrown: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
            if (hasCrown) {
                Box(
                    modifier = Modifier
                        .offset(x = 6.dp, y = (-4).dp)
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF8E24AA)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("👑", fontSize = 7.sp)
                }
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            maxLines = 1
        )
    }
}

@Composable
private fun AcrobatToolGridCard(
    title: String,
    icon: ImageVector,
    cardBgColor: Color,
    iconColor: Color,
    hasCrown: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Surface(
                modifier = Modifier.size(68.dp),
                shape = RoundedCornerShape(12.dp),
                color = cardBgColor,
                border = BorderStroke(0.5.dp, cardBgColor.copy(alpha = 0.8f))
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconColor,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            if (hasCrown) {
                Box(
                    modifier = Modifier
                        .offset(x = 4.dp, y = (-4).dp)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF8E24AA)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("👑", fontSize = 9.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun AcrobatMenuItemRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color.White,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            fontSize = 14.sp,
            color = Color.White,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = Icons.Default.KeyboardArrowRight,
            contentDescription = null,
            tint = Color(0xFF6B6B76),
            modifier = Modifier.size(20.dp)
        )
    }
}
