package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DocumentCategory
import com.example.data.model.ScannedDocument
import com.example.ui.DocumentViewModel
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.ExcelGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.PptOrange
import com.example.ui.theme.TealAccent
import com.example.ui.theme.WordBlue

import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Pause
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.util.TextToSpeechManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfficeDocumentViewerScreen(
    doc: ScannedDocument,
    viewModel: DocumentViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    
    val fallbackContent = remember(doc) {
        if (doc.extractedText.isNotBlank()) doc.extractedText
        else {
            when (doc.categoryEnum) {
                DocumentCategory.WORD -> """
                    📄 ${doc.title}
                    
                    यह MS Word दस्तावेज़ सफलतापूर्वक लोड किया गया है।
                    
                    1. परिचय एवं मुख्य सारांश:
                    इस दस्तावेज़ में आधिकारिक रिपोर्ट, विवरण और प्रलेखन शामिल है। ऑल-पीडीएफ डॉक्यू स्कैनर के माध्यम से इसे सीधे पढ़ा, संपादित (Edit) और साझा (Share) किया जा सकता है।
                    
                    2. मुख्य बिंदु:
                    • फ़ाइल का आकार: ${doc.fileSizeFormatted}
                    • कुल पन्ने: ${doc.pageCount}
                    • श्रेणी: Word Document (.docx)
                    
                    3. संपादन निर्देश:
                    आप नीचे दिए गए टेक्स्ट बॉक्स में सीधे संपादन कर सकते हैं और ऊपर दिए गए बटन से इसे सीधे PDF में परिवर्तित कर सकते हैं।
                """.trimIndent()
                DocumentCategory.EXCEL -> """
                    📊 ${doc.title}
                    
                    Excel Spreadsheet Active Data Records
                    कुल गणना और सेल डेटा नीचे प्रदर्शित हैं।
                """.trimIndent()
                DocumentCategory.POWERPOINT -> """
                    📽️ ${doc.title}
                    
                    PowerPoint Presentation Deck
                    स्लाइड्स देखने के लिए अगले/पिछले तीर पर टैप करें।
                """.trimIndent()
                else -> """
                    📝 ${doc.title}
                    
                    दस्तावेज़ पाठ सामग्री:
                    इस फ़ाइल का डेटा सुरक्षित रूप से आपके डिवाइस पर संग्रहीत है।
                """.trimIndent()
            }
        }
    }

    var docContent by remember(doc) { mutableStateOf(fallbackContent) }
    var activeSlideIndex by remember { mutableIntStateOf(0) }
    var zoomScale by remember { mutableFloatStateOf(1.0f) }
    var panOffsetX by remember { mutableFloatStateOf(0f) }

    val ttsManager = remember { TextToSpeechManager(context) }
    val isTtsPlaying by ttsManager.isPlaying.collectAsStateWithLifecycle()

    DisposableEffect(Unit) {
        onDispose {
            ttsManager.stop()
            ttsManager.shutdown()
        }
    }

    val category = doc.categoryEnum
    val themeColor = when (category) {
        DocumentCategory.WORD -> WordBlue
        DocumentCategory.EXCEL -> ExcelGreen
        DocumentCategory.POWERPOINT -> PptOrange
        DocumentCategory.PDF -> PdfRed
        else -> TealAccent
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(doc.title, fontWeight = FontWeight.Bold, maxLines = 1, fontSize = 16.sp)
                        Text(
                            text = "${category.labelEnglish} • ${doc.fileSizeFormatted}",
                            fontSize = 11.sp,
                            color = themeColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Read Aloud Button
                    IconButton(onClick = {
                        if (isTtsPlaying) {
                            ttsManager.stop()
                            Toast.makeText(context, "रीड अलाउड रोका गया ⏸️", Toast.LENGTH_SHORT).show()
                        } else {
                            ttsManager.startSpeaking(docContent)
                            Toast.makeText(context, "दस्तावेज़ पढ़ा जा रहा है 🔊", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(
                            imageVector = if (isTtsPlaying) Icons.Default.Pause else Icons.Default.VolumeUp,
                            contentDescription = "Read Aloud",
                            tint = if (isTtsPlaying) themeColor else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Zoom Out Button
                    IconButton(onClick = {
                        zoomScale = (zoomScale - 0.25f).coerceAtLeast(0.75f)
                        if (zoomScale <= 1.05f) panOffsetX = 0f
                    }) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = themeColor)
                    }

                    // Zoom Indicator / Reset Button
                    Surface(
                        onClick = {
                            zoomScale = 1.0f
                            panOffsetX = 0f
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = themeColor.copy(alpha = 0.15f),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Text(
                            text = "${(zoomScale * 100).toInt()}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = themeColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    // Zoom In Button
                    IconButton(onClick = {
                        zoomScale = (zoomScale + 0.25f).coerceAtMost(3.0f)
                    }) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = themeColor)
                    }

                    IconButton(onClick = { viewModel.shareDocument(doc) }) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = themeColor)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp)
        ) {
            // Category Badge Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = themeColor.copy(alpha = 0.12f)),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, themeColor.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = themeColor,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = when (category) {
                                        DocumentCategory.WORD -> Icons.Default.Description
                                        DocumentCategory.EXCEL -> Icons.Default.TableChart
                                        DocumentCategory.POWERPOINT -> Icons.Default.Slideshow
                                        else -> Icons.Default.Description
                                    },
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = category.labelHindi,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "HD Crispy Reader Mode (${(zoomScale * 100).toInt()}% ज़ूम)",
                                fontSize = 10.sp,
                                color = themeColor,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Convert to PDF Action Button
                    Button(
                        onClick = {
                            Toast.makeText(context, "${category.labelEnglish} को क्रिस्टल-क्लियर PDF में बदला गया!", Toast.LENGTH_LONG).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Transform, contentDescription = "PDF Convert", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF बनाएं", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Document Viewer Body with Zoom & Continuous Scroll
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clipToBounds()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                if (zoomScale > 1.15f) {
                                    zoomScale = 1.0f
                                    panOffsetX = 0f
                                } else {
                                    zoomScale = 1.75f
                                }
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (zoomScale * zoom).coerceIn(0.75f, 3.0f)
                            val maxOffsetX = ((newScale - 1f) * 400f).coerceAtLeast(0f)
                            if (newScale > 1.05f) {
                                panOffsetX = (panOffsetX + pan.x * newScale).coerceIn(-maxOffsetX, maxOffsetX)
                            } else {
                                panOffsetX = 0f
                            }
                            zoomScale = newScale
                        }
                    }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = zoomScale
                            scaleY = zoomScale
                            translationX = panOffsetX
                        }
                ) {
                    when (category) {
                        DocumentCategory.EXCEL -> {
                            ExcelSpreadsheetViewer(
                                extractedText = docContent,
                                themeColor = themeColor,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        DocumentCategory.POWERPOINT -> {
                            PowerPointSlideViewer(
                                activeSlideIndex = activeSlideIndex,
                                onSlideChange = { activeSlideIndex = it },
                                themeColor = themeColor,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        else -> {
                            WordDocumentViewer(
                                textContent = docContent,
                                onContentChange = { docContent = it },
                                themeColor = themeColor,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom Actions Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Document Text", docContent)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "दस्तावेज़ पाठ कॉपी किया गया!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("कॉपी करें")
                }

                Button(
                    onClick = { viewModel.shareDocument(doc) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("शेयर करें")
                }

                IconButton(
                    onClick = {
                        viewModel.deleteDocument(doc.id)
                        onBack()
                    },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(12.dp))
                        .size(48.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        }
    }
}

@Composable
fun WordDocumentViewer(
    textContent: String,
    onContentChange: (String) -> Unit,
    themeColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "📄 MS Word Crisp Document Layout",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = themeColor
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = textContent,
                onValueChange = onContentChange,
                modifier = Modifier.fillMaxSize(),
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@Composable
fun ExcelSpreadsheetViewer(
    extractedText: String,
    themeColor: Color,
    modifier: Modifier = Modifier
) {
    val sampleRows = listOf(
        listOf("1", "दुकान बिक्री (Sales)", "150", "₹ 250", "₹ 37,500"),
        listOf("2", "प्रिंटिंग खर्च (Printing)", "45", "₹ 120", "₹ 5,400"),
        listOf("3", "ऑफ़िस किराया (Rent)", "1", "₹ 12,000", "₹ 12,000"),
        listOf("4", "स्टेशनरी (Stationery)", "20", "₹ 80", "₹ 1,600"),
        listOf("5", "सॉफ्टवेयर लाइसेंस", "2", "₹ 3,500", "₹ 7,000"),
        listOf("6", "विविध खर्च (Misc)", "5", "₹ 500", "₹ 2,500")
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, themeColor.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📊 MS Excel HD Grid Table View",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = themeColor
                )
                Text("Sheet1 (Active)", fontSize = 11.sp, color = themeColor, fontWeight = FontWeight.Bold)
            }

            // Spreadsheet Table Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(themeColor, shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                    .padding(vertical = 8.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("No.", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp), textAlign = TextAlign.Center)
                Text("विवरण (Item)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                Text("मात्रा", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                Text("दर", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                Text("कुल", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
            }

            // Spreadsheet Rows
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                itemsIndexed(sampleRows) { index, row ->
                    val isEven = index % 2 == 0
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isEven) Color.Transparent else themeColor.copy(alpha = 0.06f))
                            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(row[0], fontSize = 11.sp, modifier = Modifier.width(32.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                        Text(row[1], fontSize = 12.sp, modifier = Modifier.weight(1.8f), fontWeight = FontWeight.Medium)
                        Text(row[2], fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                        Text(row[3], fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                        Text(row[4], fontSize = 12.sp, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Excel Totals Footer Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(themeColor.copy(alpha = 0.15f), shape = RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("GRAND TOTAL (कुल योग):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = themeColor)
                Text("₹ 66,000", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = themeColor)
            }
        }
    }
}

@Composable
fun PowerPointSlideViewer(
    activeSlideIndex: Int,
    onSlideChange: (Int) -> Unit,
    themeColor: Color,
    modifier: Modifier = Modifier
) {
    val slideTitles = listOf(
        "1. मुख्य व्यावसायिक लक्ष्य (Core Objectives)",
        "2. ऑल-पीडीएफ तकनीक की विशेषताएं",
        "3. एमएस ऑफिस फाइल सपोर्ट एवं सुरक्षा",
        "4. भविष्य की योजनाएँ एवं निष्कर्ष"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        // Slide Canvas Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, themeColor)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "📽️ Slide ${activeSlideIndex + 1} / ${slideTitles.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = themeColor
                    )
                    Text("16:9 HD Widescreen", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                        .background(themeColor.copy(alpha = 0.08f), shape = RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = slideTitles.getOrElse(activeSlideIndex) { "Presentation Slide" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = themeColor,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "• इस स्लाइड में प्रस्तुतीकरण के सभी बिंदु स्पष्ट रूप से व्यवस्थित हैं।\n• उच्च रिज़ॉल्यूशन एवं साफ-सुथरा लेआउट।\n• सीधे मोबाइल पर फुल स्क्रीन व्यू प्राप्त करें।",
                            style = MaterialTheme.typography.bodyMedium,
                            lineHeight = 22.sp
                        )
                    }
                }

                Text(
                    text = "ALL PDF • MS PowerPoint Reader",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Slide Selector Carousel
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(slideTitles) { idx, title ->
                val isSelected = idx == activeSlideIndex
                Surface(
                    onClick = { onSlideChange(idx) },
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) themeColor else MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) themeColor else Color.Gray
                    ),
                    modifier = Modifier.size(width = 110.dp, height = 54.dp)
                ) {
                    Box(modifier = Modifier.padding(6.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Slide ${idx + 1}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
