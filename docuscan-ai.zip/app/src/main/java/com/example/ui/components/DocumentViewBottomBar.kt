package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument

/**
 * High-precision Document View Bottom Navigation Bar matching Screenshots 2, 3, 4:
 * Includes all essential document actions in a horizontal scrollable tool strip:
 * - Back
 * - Edit (Single page crop/filter)
 * - Edit All (Batch page filter)
 * - Open PDF (Full reader mode)
 * - Share (Opens Share & Export Sheet)
 * - Save (Save to Gallery / Downloads)
 * - Retake (Replace page via camera)
 * - Print (Direct print output)
 * - Image to Text (OCR)
 * - Copy Text (Clipboard)
 * - Rename (Title edit)
 * - Rotate (90 deg rotation)
 * - Note (Attach document notes)
 * - Favourite (Star toggle)
 * - More (Full extra options bottom sheet)
 */
@Composable
fun DocumentViewBottomBar(
    doc: ScannedDocument,
    isStarred: Boolean,
    onBack: () -> Unit,
    onEditSingle: () -> Unit,
    onEditAll: () -> Unit,
    onOpenPdf: () -> Unit,
    onShare: () -> Unit,
    onSaveToGallery: () -> Unit,
    onRetake: () -> Unit,
    onPrint: () -> Unit,
    onImageToText: () -> Unit,
    onCopyText: () -> Unit,
    onRename: () -> Unit,
    onRotate: () -> Unit,
    onAddNote: () -> Unit,
    onToggleFavourite: () -> Unit,
    onMoreTools: () -> Unit
) {
    Surface(
        color = Color(0xFF101014),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E26)),
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Back
                DocToolItem(
                    icon = Icons.AutoMirrored.Filled.ArrowBack,
                    label = "Back",
                    onClick = onBack
                )

                // 2. Edit
                DocToolItem(
                    icon = Icons.Default.Edit,
                    label = "Edit",
                    iconTint = Color(0xFF00A2E8),
                    onClick = onEditSingle
                )

                // 3. Edit All
                DocToolItem(
                    icon = Icons.Default.Crop,
                    label = "Edit All",
                    iconTint = Color(0xFF00A2E8),
                    onClick = onEditAll
                )

                // 4. Open PDF
                DocToolItem(
                    icon = Icons.Default.PictureAsPdf,
                    label = "Open PDF",
                    iconTint = Color(0xFFFA0F00),
                    onClick = onOpenPdf
                )

                // 5. Share
                DocToolItem(
                    icon = Icons.Default.Share,
                    label = "Share",
                    iconTint = Color(0xFF00C896),
                    onClick = onShare
                )

                // 6. Save
                DocToolItem(
                    icon = Icons.Default.SaveAlt,
                    label = "Save",
                    iconTint = Color(0xFF00E5FF),
                    onClick = onSaveToGallery
                )

                // 7. Retake
                DocToolItem(
                    icon = Icons.Default.CameraAlt,
                    label = "Retake",
                    onClick = onRetake
                )

                // 8. Print
                DocToolItem(
                    icon = Icons.Default.Print,
                    label = "Print",
                    onClick = onPrint
                )

                // 9. Image to Text (OCR)
                DocToolItem(
                    icon = Icons.Default.TextFields,
                    label = "OCR Text",
                    iconTint = Color(0xFFB388FF),
                    onClick = onImageToText
                )

                // 10. Copy Text
                DocToolItem(
                    icon = Icons.Default.ContentCopy,
                    label = "Copy Text",
                    onClick = onCopyText
                )

                // 11. Rename
                DocToolItem(
                    icon = Icons.Default.Edit,
                    label = "Rename",
                    onClick = onRename
                )

                // 12. Rotate
                DocToolItem(
                    icon = Icons.AutoMirrored.Filled.RotateRight,
                    label = "Rotate",
                    onClick = onRotate
                )

                // 13. Note
                DocToolItem(
                    icon = Icons.Default.NoteAdd,
                    label = "Note",
                    onClick = onAddNote
                )

                // 14. Favourite
                DocToolItem(
                    icon = if (isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                    label = "Favourite",
                    iconTint = if (isStarred) Color(0xFFFFC107) else Color.White,
                    onClick = onToggleFavourite
                )

                // 15. More
                DocToolItem(
                    icon = Icons.Default.MoreHoriz,
                    label = "More",
                    onClick = onMoreTools
                )
            }
        }
    }
}

@Composable
fun DocToolItem(
    icon: ImageVector,
    label: String,
    iconTint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(Color(0xFF181820), CircleShape)
                .border(1.dp, Color(0xFF2E2E3C), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(20.dp),
                tint = iconTint
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color(0xFFD4D4E0),
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Extended Document Menu Bottom Sheet matching Screenshot 2 & 3:
 * Provides top action buttons + detailed list of advanced tools
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentMoreToolsSheet(
    doc: ScannedDocument,
    isStarred: Boolean,
    onDismiss: () -> Unit,
    onShare: () -> Unit,
    onCompress: () -> Unit,
    onLockToggle: () -> Unit,
    onDelete: () -> Unit,
    onSaveToGallery: () -> Unit,
    onEditSingle: () -> Unit,
    onEditAll: () -> Unit,
    onSplit: () -> Unit,
    onOcr: () -> Unit,
    onWatermark: () -> Unit,
    onSignature: () -> Unit,
    onAddNote: () -> Unit,
    onRename: () -> Unit,
    onToggleStar: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF141418),
        contentColor = Color.White,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp)
        ) {
            // Top Quick Action Icons Row (Screenshot 2 & 3: PDF, Share, Email, Compress, Lock, Delete)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1C1C24), RoundedCornerShape(12.dp))
                    .padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                QuickIconAction(icon = Icons.Default.Share, label = "Share", onClick = { onDismiss(); onShare() })
                QuickIconAction(icon = Icons.Default.Email, label = "Email", onClick = { onDismiss(); onShare() })
                QuickIconAction(icon = Icons.Default.AutoAwesome, label = "Compress", onClick = { onDismiss(); onCompress() })
                QuickIconAction(
                    icon = if (doc.isPrivateVault) Icons.Default.Lock else Icons.Default.LockOpen,
                    label = if (doc.isPrivateVault) "Locked" else "Lock",
                    iconColor = if (doc.isPrivateVault) Color(0xFF00A2E8) else Color.White,
                    onClick = { onDismiss(); onLockToggle() }
                )
                QuickIconAction(icon = Icons.Default.Delete, label = "Delete", iconColor = Color(0xFFFF5252), onClick = { onDismiss(); onDelete() })
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = Color(0xFF262630))
            Spacer(modifier = Modifier.height(10.dp))

            // Detailed Tools List
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                DocOptionListRow(
                    icon = Icons.Default.SaveAlt,
                    title = "Save to Gallery",
                    subtitle = "Export document pages directly to phone photo album",
                    onClick = { onDismiss(); onSaveToGallery() }
                )
                DocOptionListRow(
                    icon = Icons.Default.Edit,
                    title = "Edit Current Page",
                    subtitle = "Crop boundaries and apply live filters",
                    onClick = { onDismiss(); onEditSingle() }
                )
                DocOptionListRow(
                    icon = Icons.Default.Crop,
                    title = "Batch Edit All Pages",
                    subtitle = "Apply filter & enhancements across entire document",
                    onClick = { onDismiss(); onEditAll() }
                )
                DocOptionListRow(
                    icon = Icons.Default.TextFields,
                    title = "Recognize Text (OCR)",
                    subtitle = "Extract Hindi & English editable text with AI",
                    onClick = { onDismiss(); onOcr() }
                )
                DocOptionListRow(
                    icon = Icons.Default.GridView,
                    title = "Split / Organize Pages",
                    subtitle = "Rearrange, extract, or split document pages",
                    onClick = { onDismiss(); onSplit() }
                )
                DocOptionListRow(
                    icon = Icons.Default.AutoAwesome,
                    title = "Watermark & Stamp",
                    subtitle = "Add certified stamp, signature, or custom watermark",
                    onClick = { onDismiss(); onWatermark() }
                )
                DocOptionListRow(
                    icon = Icons.Default.NoteAdd,
                    title = "Document Notes",
                    subtitle = "Attach personal remarks or audio summary",
                    onClick = { onDismiss(); onAddNote() }
                )
                DocOptionListRow(
                    icon = if (isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                    title = if (isStarred) "Remove from Favourites" else "Add to Favourites",
                    subtitle = "Mark document for instant quick-access",
                    onClick = { onDismiss(); onToggleStar() }
                )
            }
        }
    }
}

@Composable
fun QuickIconAction(
    icon: ImageVector,
    label: String,
    iconColor: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = iconColor,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, fontSize = 10.sp, color = Color(0xFFA0A0AB))
    }
}

@Composable
fun DocOptionListRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(Color(0xFF1E1E28), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = Color(0xFF00A2E8), modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Text(text = subtitle, fontSize = 11.sp, color = Color(0xFF888894), maxLines = 1)
        }
    }
}
