package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Star
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.LinearEasing
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.LanguageSelectionDialog
import com.example.util.LanguageManager
import com.example.util.AiMediaGenerator
import com.example.util.AiVideoMeta
import com.example.util.AiPhotoEditingEngine
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.AiChatSession
import com.example.data.model.AiMessage
import com.example.data.model.AiModelType
import com.example.data.model.ScannedDocument
import com.example.data.repository.AiChatRepository
import com.example.data.util.GeminiOcrHelper
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import com.example.ui.theme.WordBlue
import com.example.ui.components.AiPhotoEditorDialog
import com.example.ui.components.AiCodeExecutorDialog
import com.example.ui.components.AiVideoStudioDialog
import com.example.util.AiSafetyManager
import com.example.util.ViolationResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AiToolMode(
    val title: String,
    val shortLabel: String,
    val iconEmoji: String,
    val placeholder: String,
    val badgeColor: Color,
    val borderColor: Color,
    val promptContext: String
) {
    PHOTO_STUDIO(
        title = "AI फ़ोटो एडिटर / Image Studio",
        shortLabel = "AI फ़ोटो एडिटर",
        iconEmoji = "🎨",
        placeholder = "फ़ोटो जोड़ें और बताएं क्या बदलाव करना है...",
        badgeColor = Color(0xFF2B1229),
        borderColor = Color(0xFFE879F9),
        promptContext = "[Mode: AI Photo Studio & Image Editor] कृपया संलग्न फ़ोटो या प्रश्न के अनुसार फ़ोटो एडिटिंग, इफेक्ट्स, रंग व सुधार के निर्देश और सुझाव दें: "
    ),
    CODE_ENGINE(
        title = "AI कोडिंग इंजन / Code Runner",
        shortLabel = "AI कोडिंग इंजन",
        iconEmoji = "💻",
        placeholder = "कोडिंग से संबंधित निर्देश लिखें (Python, HTML/JS, Kotlin)...",
        badgeColor = Color(0xFF0C241B),
        borderColor = Color(0xFF34D399),
        promptContext = "[Mode: AI Code Generation & Runner] निम्नलिखित कार्य के लिए स्पष्ट, संपूर्ण और चलाने योग्य (runnable) कोड ब्लॉक प्रदान करें: "
    ),
    VIDEO_STUDIO(
        title = "AI वीडियो स्टूडियो / Story Reel",
        shortLabel = "AI वीडियो स्टूडियो",
        iconEmoji = "🎬",
        placeholder = "वीडियो/रील का विषय या स्टोरीलाइन का विचार लिखें...",
        badgeColor = Color(0xFF1E1B4B),
        borderColor = Color(0xFF818CF8),
        promptContext = "[Mode: AI Video Studio & Reel Generator] निम्नलिखित विषय पर सीन-बाय-सीन वीडियो स्टोरीबोर्ड, विजुअल विवरण, समय और वॉइसओवर स्क्रिप्ट बनाएं: "
    ),
    DOC_ANALYSIS(
        title = "दस्तावेज़ विश्लेषण / Doc Insight",
        shortLabel = "दस्तावेज़ विश्लेषण",
        iconEmoji = "📑",
        placeholder = "दस्तावेज़ का विस्तृत सारांश या तथ्य पूछें...",
        badgeColor = Color(0xFF13233A),
        borderColor = Color(0xFF38BDF8),
        promptContext = "[Mode: Deep Document Analysis] दस्तावेज़ का पूर्ण सारांश, मुख्य बिंदु व साक्ष्य स्पष्ट रूप से प्रस्तुत करें: "
    ),
    TRANSLATION(
        title = "स्मार्ट अनुवाद / Smart Translate",
        shortLabel = "स्मार्ट अनुवाद",
        iconEmoji = "🌐",
        placeholder = "जिस भाषा में अनुवाद करना है वह निर्देश लिखें...",
        badgeColor = Color(0xFF2C1C0D),
        borderColor = Color(0xFFFBBF24),
        promptContext = "[Mode: Multilingual Translation] दिए गए पाठ का उपयुक्त भाषा में सटीक और स्पष्ट अनुवाद करें: "
    ),
    EXAM_QUIZ(
        title = "परीक्षा क्विज़ / MCQ Maker",
        shortLabel = "परीक्षा क्विज़",
        iconEmoji = "🎯",
        placeholder = "क्विज़ के विषय, प्रश्नों की संख्या या कठिनाई लिखें...",
        badgeColor = Color(0xFF231135),
        borderColor = Color(0xFFC084FC),
        promptContext = "[Mode: Exam Quiz & MCQ Generator] आगामी परीक्षा के लिए बहुविकल्पीय प्रश्न (MCQs with Explanations) तैयार करें: "
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
    initialDocument: ScannedDocument? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val repository = remember { AiChatRepository(context) }

    val sessions by repository.sessions.collectAsState()
    val messages by repository.currentMessages.collectAsState()

    var activeSession by remember { mutableStateOf<AiChatSession?>(null) }
    var selectedModelType by remember { mutableStateOf(AiModelType.GEMINI) }
    var userPromptText by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }

    // Gemini-style active tool mode (Photo, Code, Video, Summary, etc.)
    var activeToolMode by remember { mutableStateOf<AiToolMode?>(null) }

    // Drawer / History Panel State
    var isHistoryDrawerOpen by remember { mutableStateOf(false) }
    var isMultiDeleteMode by remember { mutableStateOf(false) }
    val selectedSessionIds = remember { mutableStateListOf<String>() }

    // Attachment State
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var attachedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var attachedBitmapPath by remember { mutableStateOf<String?>(null) }

    // Live Voice Call State
    var isLiveVoiceCallActive by remember { mutableStateOf(false) }

    // Safety Alert & Ban State
    var warningAlertMessage by remember { mutableStateOf<String?>(null) }
    var isUserBanned by remember { mutableStateOf(AiSafetyManager.isUserBanned(context)) }
    var remainingBanTimeMillis by remember { mutableLongStateOf(AiSafetyManager.getRemainingBanTimeMillis(context)) }

    // Multimodal AI Power Tools Dialog State
    val languageManager = remember { LanguageManager(context) }
    val currentLangCode by LanguageManager.currentLanguageFlow.collectAsStateWithLifecycle()
    val selectedLanguage = remember(currentLangCode) { languageManager.getSelectedLanguage() }
    var showLanguageDialog by remember { mutableStateOf(false) }

    var showPhotoEditorDialog by remember { mutableStateOf(false) }
    var photoToEditBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showCodeExecutorDialog by remember { mutableStateOf(false) }
    var codeToRunText by remember { mutableStateOf("") }
    var codeToRunLang by remember { mutableStateOf("Python") }
    var showVideoStudioDialog by remember { mutableStateOf(false) }
    var showOriginalMediaDialog by remember { mutableStateOf(false) }
    var originalMediaToViewPath by remember { mutableStateOf<String?>(null) }
    var originalMediaToViewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var originalMediaIsVideo by remember { mutableStateOf(false) }
    var originalMediaTitle by remember { mutableStateOf("मूल AI फोटो / वीडियो") }

    // TTS Engine for AI voice replies
    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        var ttsInstance: TextToSpeech? = null
        ttsInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsInstance?.language = java.util.Locale("hi", "IN")
            }
        }
        ttsEngine = ttsInstance
        onDispose {
            ttsInstance.stop()
            ttsInstance.shutdown()
        }
    }

    // Ban countdown timer
    LaunchedEffect(isUserBanned) {
        while (isUserBanned) {
            val rem = AiSafetyManager.getRemainingBanTimeMillis(context)
            remainingBanTimeMillis = rem
            if (rem <= 0) {
                isUserBanned = false
                break
            }
            delay(1000)
        }
    }

    // Initialize active session
    LaunchedEffect(sessions) {
        if (activeSession == null) {
            if (sessions.isNotEmpty()) {
                val first = sessions.first()
                activeSession = first
                selectedModelType = first.modelType
                repository.loadMessages(first.id)
            } else {
                val newSess = repository.createNewSession(
                    title = if (!initialDocument?.title.isNullOrBlank()) initialDocument.title else "ALL PDF AI Assistant",
                    modelType = selectedModelType
                )
                activeSession = newSess
                repository.loadMessages(newSess.id)
            }
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Image Picker & Camera Launchers
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) {
            attachedBitmap = bmp
            attachedBitmapPath = saveBitmapLocally(context, bmp)
            showAttachmentSheet = false
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bmp != null) {
                    attachedBitmap = bmp
                    attachedBitmapPath = saveBitmapLocally(context, bmp)
                }
            } catch (e: Exception) {
                Toast.makeText(context, "फ़ाइल लोड करने में त्रुटि", Toast.LENGTH_SHORT).show()
            }
            showAttachmentSheet = false
        }
    }

    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                userPromptText = spokenText
            }
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "PDF के बारे में कुछ भी बोलें...")
            }
            try {
                speechRecognizerLauncher.launch(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "वॉइस इनपुट प्रारंभ नहीं हो सका", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "माइक्रोफोन अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            cameraLauncher.launch()
        } else {
            Toast.makeText(context, "कैमरा अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    // Send Query Handler
    val onSendMessage: (String, Bitmap?) -> Unit = { promptText, imageBmp ->
        val cleanPrompt = promptText.trim()
        val sendBitmap = imageBmp ?: attachedBitmap
        val sendBitmapPath = attachedBitmapPath
        val currentTool = activeToolMode

        if (cleanPrompt.isNotBlank() || sendBitmap != null || currentTool != null) {
            if (AiSafetyManager.isUserBanned(context)) {
                isUserBanned = true
            } else if (AiSafetyManager.containsAbusiveLanguage(cleanPrompt)) {
                // Safety Violation Handler
                when (val result = AiSafetyManager.recordViolation(context)) {
                    is ViolationResult.Warning -> {
                        warningAlertMessage = result.message
                    }
                    is ViolationResult.Banned -> {
                        isUserBanned = true
                        remainingBanTimeMillis = 24 * 60 * 60 * 1000L
                    }
                }
            } else {
                // Check IT Rules / Deepfake / Synthetic harm / Copyright compliance
                val safetyRefusal = AiSafetyManager.checkPromptSafety(cleanPrompt)

                // Clear text inputs
                userPromptText = ""
                attachedBitmap = null
                attachedBitmapPath = null

                coroutineScope.launch {
                    val currentSess = activeSession ?: repository.createNewSession(
                        title = if (!initialDocument?.title.isNullOrBlank()) initialDocument.title else if (cleanPrompt.isNotBlank()) cleanPrompt.take(24) else (currentTool?.shortLabel ?: "ALL PDF AI Assistant"),
                        modelType = selectedModelType
                    ).also {
                        activeSession = it
                    }

                    val userDisplayText = when {
                        cleanPrompt.isNotBlank() && currentTool != null -> "${currentTool.iconEmoji} ${cleanPrompt}"
                        cleanPrompt.isNotBlank() -> cleanPrompt
                        currentTool != null -> "${currentTool.iconEmoji} [${currentTool.title}]"
                        else -> "📷 [संलग्न फोटो/दस्तावेज़ का विश्लेषण]"
                    }

                    val userMsg = AiMessage(
                        sessionId = currentSess.id,
                        sender = "User",
                        text = userDisplayText,
                        isUser = true,
                        attachedImagePath = sendBitmapPath,
                        modelUsed = selectedModelType
                    )

                    repository.addMessage(userMsg)

                    if (safetyRefusal != null) {
                        val aiMsg = AiMessage(
                            sessionId = currentSess.id,
                            sender = selectedModelType.displayName,
                            text = safetyRefusal,
                            isUser = false,
                            modelUsed = selectedModelType
                        )
                        repository.addMessage(aiMsg)
                    } else {
                        isThinking = true

                        // Check if there is an image either attached now or from the recent conversation
                        val effectiveBitmap = sendBitmap ?: if (
                            (AiPhotoEditingEngine.isMediaEditRequest(cleanPrompt) || AiMediaGenerator.isPhotoToVideoRequest(cleanPrompt)) &&
                            messages.any { it.attachedImagePath != null }
                        ) {
                            val lastImgPath = messages.lastOrNull { it.attachedImagePath != null }?.attachedImagePath
                            if (lastImgPath != null) BitmapFactory.decodeFile(lastImgPath) else null
                        } else null

                        // 1. Photo-to-Video conversion request
                        if (effectiveBitmap != null && (AiMediaGenerator.isPhotoToVideoRequest(cleanPrompt) || (AiMediaGenerator.isVideoGenerationRequest(cleanPrompt) && sendBitmap != null))) {
                            val meta = AiMediaGenerator.convertPhotoToVideoMeta(sendBitmapPath, cleanPrompt)
                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = "[AI_VIDEO:${meta.title}|${meta.durationSeconds}|${meta.visualTheme}|${meta.musicMood}]",
                                isUser = false,
                                attachedImagePath = sendBitmapPath ?: messages.lastOrNull { it.attachedImagePath != null }?.attachedImagePath,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        }
                        // 2. Photo Editing & Background Change request
                        else if (effectiveBitmap != null && (AiPhotoEditingEngine.isMediaEditRequest(cleanPrompt) || cleanPrompt.isBlank() || currentTool == AiToolMode.PHOTO_STUDIO)) {
                            val (modifiedPath, actionSummary) = AiPhotoEditingEngine.processMediaModification(context, effectiveBitmap, cleanPrompt)
                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = "🖼️ [AI Modified Photo]\n$actionSummary\n\nयदि आप इसमें कोई और बदलाव (जैसे और रोशनी, बैकग्राउंड कलर या वीडियो में बदलना) चाहते हैं, तो बस मुझे बताएं!",
                                isUser = false,
                                attachedImagePath = modifiedPath,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        }
                        // 3. Video Editing request on previous video
                        else if (AiMediaGenerator.isVideoEditRequest(cleanPrompt) && messages.any { it.text.startsWith("[AI_VIDEO:") }) {
                            val lastVideoMsg = messages.lastOrNull { it.text.startsWith("[AI_VIDEO:") }
                            val currentMeta = if (lastVideoMsg != null) {
                                val content = lastVideoMsg.text.removePrefix("[AI_VIDEO:").removeSuffix("]")
                                val parts = content.split("|")
                                val title = parts.getOrNull(0) ?: "🎬 AI Video"
                                val dur = parts.getOrNull(1)?.toIntOrNull() ?: 15
                                val theme = parts.getOrNull(2) ?: "dynamic"
                                val music = parts.getOrNull(3) ?: "Ambient Beats"
                                AiVideoMeta(title = title, durationSeconds = dur, visualTheme = theme, musicMood = music, scenes = emptyList())
                            } else {
                                AiMediaGenerator.generateVideoMeta(cleanPrompt, initialDocument?.title ?: "")
                            }
                            val updatedMeta = AiMediaGenerator.editExistingVideoMeta(currentMeta, cleanPrompt)
                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = "[AI_VIDEO:${updatedMeta.title}|${updatedMeta.durationSeconds}|${updatedMeta.visualTheme}|${updatedMeta.musicMood}]",
                                isUser = false,
                                attachedImagePath = lastVideoMsg?.attachedImagePath,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        }
                        // 4. Standalone Image Generation request
                        else if (AiMediaGenerator.isImageGenerationRequest(cleanPrompt)) {
                            val genPath = AiMediaGenerator.generateImageForPrompt(context, cleanPrompt)
                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = "🖼️ [AI Generated Photo]\nआपकी मांग के अनुसार यह आकर्षक फोटो तैयार की गई है। क्या आप इसमें कोई बदलाव करना चाहते हैं?",
                                isUser = false,
                                attachedImagePath = genPath,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        }
                        // 5. Standalone Video Generation request
                        else if (AiMediaGenerator.isVideoGenerationRequest(cleanPrompt)) {
                            val videoThumbPath = AiMediaGenerator.generateImageForPrompt(context, cleanPrompt)
                            val meta = AiMediaGenerator.generateVideoMeta(cleanPrompt, initialDocument?.title ?: "")
                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = "[AI_VIDEO:${meta.title}|${meta.durationSeconds}|${meta.visualTheme}|${meta.musicMood}]",
                                isUser = false,
                                attachedImagePath = videoThumbPath,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        }
                        // 6. Conversational Intelligence & Deep Knowledge
                        else {
                            val promptForAi = when {
                                currentTool != null && cleanPrompt.isNotBlank() -> "${currentTool.promptContext}\n$cleanPrompt"
                                currentTool != null -> "${currentTool.promptContext}\nसंलग्न छवि या प्रश्न का विश्लेषण करके उत्तर दें।"
                                cleanPrompt.isNotBlank() -> cleanPrompt
                                else -> "नमस्ते! आप कैसे हैं? आज मैं आपकी क्या सहायता कर सकता हूँ?"
                            }

                            val aiReply = GeminiOcrHelper.askMultiModelAi(
                                prompt = promptForAi,
                                modelType = selectedModelType.name,
                                contextDocTitle = initialDocument?.title ?: "",
                                bitmap = sendBitmap
                            )

                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = aiReply,
                                isUser = false,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        }
                    }
                }
            }
        }
    }

    // Back navigation handler for hardware back button / gestures
    BackHandler {
        if (isHistoryDrawerOpen) {
            isHistoryDrawerOpen = false
            isMultiDeleteMode = false
            selectedSessionIds.clear()
        } else if (showAttachmentSheet) {
            showAttachmentSheet = false
        } else if (showPhotoEditorDialog) {
            showPhotoEditorDialog = false
        } else if (showCodeExecutorDialog) {
            showCodeExecutorDialog = false
        } else if (showVideoStudioDialog) {
            showVideoStudioDialog = false
        } else if (showLanguageDialog) {
            showLanguageDialog = false
        } else if (warningAlertMessage != null) {
            warningAlertMessage = null
        } else if (isLiveVoiceCallActive) {
            isLiveVoiceCallActive = false
        } else {
            onBack()
        }
    }

    // If User is Banned, show 24-Hour Ban Lock Screen
    if (isUserBanned) {
        BanLockoutScreen(
            remainingTimeText = AiSafetyManager.formatRemainingBanTime(remainingBanTimeMillis),
            onBack = onBack,
            onDevReset = {
                AiSafetyManager.resetBan(context)
                isUserBanned = false
            }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    ModelSelectorDropdown(
                        currentModel = selectedModelType,
                        onSelectModel = { newModel ->
                            selectedModelType = newModel
                        }
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("ai_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "वापस जाएं (Back)",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // Chat History Drawer Button (☰ 3-Line Menu)
                    IconButton(
                        onClick = { isHistoryDrawerOpen = true },
                        modifier = Modifier.testTag("ai_history_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "चैट इतिहास ☰",
                            tint = Color(0xFFE2E2E8),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // New Chat Button (Pencil / Edit icon as in Gemini)
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                val newSess = repository.createNewSession(modelType = selectedModelType)
                                activeSession = newSess
                                repository.loadMessages(newSess.id)
                                Toast.makeText(context, "नया चैट शुरू हुआ ✨", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("ai_new_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "नया चैट",
                            tint = Color(0xFFE2E2E8),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF000000)
                )
            )
        },
        containerColor = Color(0xFF000000)
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF000000))
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Initial document badge banner if opened from a specific PDF
                if (initialDocument != null) {
                    Surface(
                        color = Color(0xFF1A1A24),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = TealAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "सक्रिय दस्तावेज़: ${initialDocument.title}",
                                color = Color(0xFFC0C0D0),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Chat Messages List & Welcome Hero Carousel (HomeScreen Style)
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    contentPadding = PaddingValues(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Welcome & Hero Gemini Display when chat is fresh
                    if (messages.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 36.dp, bottom = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Multi-color Gemini 4-Point Radiant Sparkle Star
                                GeminiSparkleStar(
                                    modifier = Modifier.size(52.dp)
                                )

                                Spacer(modifier = Modifier.height(24.dp))

                                // Universal Greeting: नमस्ते!
                                Text(
                                    text = "नमस्ते!",
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Subtitle: क्या आपका कोई सवाल है?
                                Text(
                                    text = "क्या आपका कोई सवाल है?",
                                    color = Color(0xFFE2E2E8),
                                    fontSize = 23.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(28.dp))

                                // Conversational Suggestion Chips Row
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    val quickPrompts = listOf(
                                        "🌍 दुनिया की कोई भी जानकारी पूछें",
                                        "🖼️ फोटो भेजकर बैकग्राउंड बदलें",
                                        "🎬 फोटो को 4K वीडियो रील में बदलें",
                                        "💡 कोई भी सवाल, सलाह या बातचीत",
                                        "💻 किसी भी भाषा में कोड बनवाएं",
                                        "📄 दस्तावेज़ का विश्लेषण व सारांश"
                                    )
                                    items(quickPrompts) { promptText ->
                                        Surface(
                                            color = Color(0xFF1E1F24),
                                            shape = RoundedCornerShape(20.dp),
                                            border = BorderStroke(1.dp, Color(0xFF2E2F38)),
                                            modifier = Modifier.clickable {
                                                userPromptText = promptText.substringAfter(" ")
                                            }
                                        ) {
                                            Text(
                                                text = promptText,
                                                color = Color(0xFFE2E2E8),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    items(messages) { msg ->
                        ChatMessageBubble(
                            message = msg,
                            onSpeakText = { text ->
                                ttsEngine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AI_MSG")
                            },
                            onRetry = {
                                val lastUserMsg = messages.lastOrNull { it.isUser }
                                if (lastUserMsg != null) {
                                    val bmp = lastUserMsg.attachedImagePath?.let { BitmapFactory.decodeFile(it) }
                                    onSendMessage(lastUserMsg.text, bmp)
                                }
                            },
                            onStartNewChat = {
                                coroutineScope.launch {
                                    val newSess = repository.createNewSession(modelType = selectedModelType)
                                    activeSession = newSess
                                    repository.loadMessages(newSess.id)
                                    attachedBitmap = null
                                    attachedBitmapPath = null
                                    userPromptText = ""
                                    activeToolMode = null
                                    Toast.makeText(context, "✨ नया चैट शुरू हुआ", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onViewOriginalMedia = { path, bmp, isVideo, title ->
                                originalMediaToViewPath = path
                                originalMediaToViewBitmap = bmp
                                originalMediaIsVideo = isVideo
                                originalMediaTitle = title
                                showOriginalMediaDialog = true
                            },
                            onOpenPhotoEditor = { bmp ->
                                photoToEditBitmap = bmp ?: attachedBitmap
                                showPhotoEditorDialog = true
                            },
                            onOpenCodeExecutor = { code, lang ->
                                codeToRunText = code
                                codeToRunLang = lang
                                showCodeExecutorDialog = true
                            },
                            onOpenVideoStudio = {
                                showVideoStudioDialog = true
                            }
                        )
                    }

                    if (isThinking) {
                        item {
                            ThinkingIndicator(modelType = selectedModelType)
                        }
                    }
                }

                // Active Tool Badge & Attached Image Bar (Directly Above Input Box)
                AnimatedVisibility(
                    visible = activeToolMode != null || attachedBitmap != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Surface(
                        color = activeToolMode?.badgeColor ?: Color(0xFF1E1E28),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.2.dp, activeToolMode?.borderColor ?: Color(0xFF333348)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (activeToolMode != null) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(activeToolMode!!.borderColor.copy(alpha = 0.25f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = activeToolMode!!.iconEmoji, fontSize = 16.sp)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = activeToolMode!!.title,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (attachedBitmap != null) "फ़ोटो संलग्न है • निर्देश लिखकर भेजें" else "नीचे निर्देश या प्रश्न लिखें",
                                        color = Color(0xFFB8B8C8),
                                        fontSize = 11.sp
                                    )
                                }
                            } else {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("फोटो संलग्न की गई", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("प्रश्न के साथ AI विश्लेषण होगा", color = Color.Gray, fontSize = 11.sp)
                                }
                            }

                            if (attachedBitmap != null) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, activeToolMode?.borderColor ?: Color.White, RoundedCornerShape(8.dp))
                                ) {
                                    Image(
                                        bitmap = attachedBitmap!!.asImageBitmap(),
                                        contentDescription = "Attached Preview",
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            } else if (activeToolMode == AiToolMode.PHOTO_STUDIO) {
                                TextButton(
                                    onClick = { showAttachmentSheet = true },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("+ फ़ोटो जोड़ें", color = Color(0xFFFF80AB), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // (✕) Clear Active Tool Badge
                            IconButton(
                                onClick = {
                                    activeToolMode = null
                                    attachedBitmap = null
                                    attachedBitmapPath = null
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "टूल हटाएं",
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // Bottom Floating Pill Input Bar (Exact Gemini Layout)
                Surface(
                    color = Color(0xFF0F0F12),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Surface(
                            color = Color(0xFF1E1F24),
                            shape = RoundedCornerShape(32.dp),
                            border = BorderStroke(1.dp, Color(0xFF2E2F38)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // (+) Attachment Button
                                IconButton(
                                    onClick = { showAttachmentSheet = true },
                                    modifier = Modifier
                                        .size(38.dp)
                                        .background(Color(0xFF2B2C34), CircleShape)
                                        .testTag("ai_attachment_plus_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "अटैचमेंट जोड़ें (+)",
                                        tint = Color(0xFFC4C7C5),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                // Text Input Field
                                OutlinedTextField(
                                    value = userPromptText,
                                    onValueChange = { userPromptText = it },
                                    placeholder = {
                                        Text(
                                            text = "Gemini से कहें",
                                            color = Color(0xFF8E8E98),
                                            fontSize = 15.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("ai_prompt_input_field"),
                                    maxLines = 4,
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                    keyboardActions = KeyboardActions(onSend = {
                                        if (userPromptText.isNotBlank() || attachedBitmap != null || activeToolMode != null) {
                                            onSendMessage(userPromptText, attachedBitmap)
                                        }
                                    }),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedContainerColor = Color.Transparent,
                                        unfocusedContainerColor = Color.Transparent,
                                        focusedBorderColor = Color.Transparent,
                                        unfocusedBorderColor = Color.Transparent
                                    )
                                )

                                // Mic Icon Button
                                IconButton(
                                    onClick = {
                                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Gemini से कुछ भी बोलें...")
                                            }
                                            try {
                                                speechRecognizerLauncher.launch(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "वॉइस इनपुट उपलब्ध नहीं है", Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Mic,
                                        contentDescription = "वॉइस इनपुट 🎙️",
                                        tint = Color(0xFFC4C7C5),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                val canSend = userPromptText.isNotBlank() || attachedBitmap != null || activeToolMode != null

                                // Action Button: Live Waveform when empty, or Send Arrow when text is present!
                                IconButton(
                                    onClick = {
                                        if (canSend) {
                                            onSendMessage(userPromptText, attachedBitmap)
                                        } else {
                                            isLiveVoiceCallActive = true
                                        }
                                    },
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFF2B64E2), CircleShape)
                                        .testTag("ai_send_prompt_button")
                                ) {
                                    if (canSend) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Send,
                                            contentDescription = "Send",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    } else {
                                        LiveAudioWaveform(
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Bottom Privacy Notice
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp, bottom = 2.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "AI से गलतियाँ हो सकती है • 🔒 डेटा 100% सुरक्षित है",
                                color = Color(0xFF64748B),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Slide-over Chat History Panel (☰ 3-Line Menu Drawer)
            AnimatedVisibility(
                visible = isHistoryDrawerOpen,
                enter = slideInHorizontally { -it } + fadeIn(),
                exit = slideOutHorizontally { -it } + fadeOut()
            ) {
                AiHistoryDrawerPanel(
                    sessions = sessions,
                    activeSessionId = activeSession?.id,
                    isMultiDeleteMode = isMultiDeleteMode,
                    selectedSessionIds = selectedSessionIds,
                    onToggleMultiDeleteMode = {
                        isMultiDeleteMode = !isMultiDeleteMode
                        selectedSessionIds.clear()
                    },
                    onSelectAll = {
                        selectedSessionIds.clear()
                        selectedSessionIds.addAll(sessions.map { it.id })
                    },
                    onToggleSelectSession = { id ->
                        if (selectedSessionIds.contains(id)) {
                            selectedSessionIds.remove(id)
                        } else {
                            selectedSessionIds.add(id)
                        }
                    },
                    onDeleteSelected = {
                        coroutineScope.launch {
                            repository.deleteSessions(selectedSessionIds.toSet())
                            selectedSessionIds.clear()
                            isMultiDeleteMode = false
                            if (sessions.isNotEmpty()) {
                                val first = sessions.first()
                                activeSession = first
                                repository.loadMessages(first.id)
                            } else {
                                val newSess = repository.createNewSession()
                                activeSession = newSess
                            }
                        }
                    },
                    onSelectSession = { session ->
                        activeSession = session
                        selectedModelType = session.modelType
                        coroutineScope.launch {
                            repository.loadMessages(session.id)
                        }
                        isHistoryDrawerOpen = false
                    },
                    onNewChatClick = {
                        coroutineScope.launch {
                            val newSess = repository.createNewSession(modelType = selectedModelType)
                            activeSession = newSess
                            isHistoryDrawerOpen = false
                        }
                    },
                    onCloseDrawer = {
                        isHistoryDrawerOpen = false
                        isMultiDeleteMode = false
                        selectedSessionIds.clear()
                    }
                )
            }
        }
    }

    // Attachment Bottom Sheet: Camera & Gallery options
    if (showAttachmentSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachmentSheet = false },
            containerColor = Color(0xFF1E1E26)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "फ़ोटो या दस्तावेज़ जोड़ें (+)",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Option 1: Camera
                Card(
                    onClick = {
                        val permission = Manifest.permission.CAMERA
                        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                            cameraLauncher.launch()
                        } else {
                            cameraPermissionLauncher.launch(permission)
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF282834)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = TealAccent, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("📷 कैमरे से फोटो लें (Camera)", color = Color.White, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                            Text("पेज या नोट की तुरंत फोटो खींचकर सवाल पूछें", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Option 2: Gallery / Files
                Card(
                    onClick = {
                        filePickerLauncher.launch("image/*")
                    },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF282834)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = WordBlue, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("📁 गैलरी / फ़ाइल से चुनें (Gallery / Files)", color = Color.White, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                            Text("फ़ोन से कोई भी फोटो या स्क्रीनशॉट अपलोड करें", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Live Voice Call Screen Overlay
    if (isLiveVoiceCallActive) {
        LiveVoiceCallOverlay(
            modelType = selectedModelType,
            ttsEngine = ttsEngine,
            onSendMessage = onSendMessage,
            onCloseCall = { isLiveVoiceCallActive = false }
        )
    }

    // Safety Warning Dialog
    if (warningAlertMessage != null) {
        AlertDialog(
            onDismissRequest = { warningAlertMessage = null },
            icon = {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFFB74D), modifier = Modifier.size(36.dp))
            },
            title = {
                Text("सुरक्षा चेतावनी (Safety Alert)", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(warningAlertMessage ?: "", color = Color(0xFFE0E0E0), fontSize = 14.sp)
            },
            confirmButton = {
                Button(
                    onClick = { warningAlertMessage = null },
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                ) {
                    Text("मैं समझ गया (OK)", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF252530)
        )
    }

    // AI Photo Editor Dialog
    if (showPhotoEditorDialog) {
        val bmpToEdit = photoToEditBitmap ?: createSampleDocumentBitmap()
        AiPhotoEditorDialog(
            initialBitmap = bmpToEdit,
            onSaveEditedPhoto = { editedBmp, path ->
                attachedBitmap = editedBmp
                attachedBitmapPath = path
                showPhotoEditorDialog = false
            },
            onDismissRequest = { showPhotoEditorDialog = false }
        )
    }

    // AI Code Runner & IDE Dialog
    if (showCodeExecutorDialog) {
        AiCodeExecutorDialog(
            initialCode = codeToRunText,
            initialLanguage = codeToRunLang,
            onDismissRequest = { showCodeExecutorDialog = false }
        )
    }

    // AI Video Studio & Reels Dialog
    if (showVideoStudioDialog) {
        val bitmapsList = listOfNotNull(attachedBitmap ?: photoToEditBitmap)
        AiVideoStudioDialog(
            initialBitmaps = bitmapsList,
            docTitle = initialDocument?.title ?: "ALL PDF AI Story",
            onDismissRequest = { showVideoStudioDialog = false }
        )
    }

    // Original Media (Photo / Video) Full-Screen Viewer Dialog
    if (showOriginalMediaDialog) {
        OriginalMediaViewerDialog(
            mediaPath = originalMediaToViewPath,
            bitmap = originalMediaToViewBitmap,
            isVideo = originalMediaIsVideo,
            title = originalMediaTitle,
            onDismissRequest = {
                showOriginalMediaDialog = false
                originalMediaToViewPath = null
                originalMediaToViewBitmap = null
            }
        )
    }

    // Language Selector Dialog
    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguageCode = selectedLanguage.code,
            onLanguageSelected = { lang ->
                languageManager.applyLanguageLocale(context, lang.code)
            },
            onConfirm = {
                showLanguageDialog = false
                Toast.makeText(
                    context,
                    "${selectedLanguage.flagEmoji} ${selectedLanguage.nativeName} सेट किया गया",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }
}

@Composable
fun ModelSelectorDropdown(
    currentModel: AiModelType,
    onSelectModel: (AiModelType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { expanded = true }
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = currentModel.displayName,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = "Select Model",
                tint = Color(0xFFC4C7C5),
                modifier = Modifier.size(20.dp)
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color(0xFF1E1F24))
        ) {
            AiModelType.values().forEach { model ->
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(model.displayName, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(model.subtitle, color = Color(0xFF9E9EA8), fontSize = 11.sp)
                        }
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = when (model) {
                                AiModelType.GEMINI, AiModelType.GEMINI_PRO, AiModelType.GEMINI_ADVANCED -> Icons.Default.AutoAwesome
                                AiModelType.CHATGPT -> Icons.Default.Psychology
                                else -> Icons.Default.SmartToy
                            },
                            contentDescription = null,
                            tint = when (model) {
                                AiModelType.GEMINI, AiModelType.GEMINI_PRO, AiModelType.GEMINI_ADVANCED -> TealAccent
                                AiModelType.CHATGPT -> Color(0xFF10A37F)
                                else -> EmeraldGreen
                            }
                        )
                    },
                    onClick = {
                        onSelectModel(model)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun ChatMessageBubble(
    message: AiMessage,
    onSpeakText: (String) -> Unit,
    onRetry: (() -> Unit)? = null,
    onStartNewChat: (() -> Unit)? = null,
    onViewOriginalMedia: ((String?, Bitmap?, Boolean, String) -> Unit)? = null,
    onOpenPhotoEditor: ((Bitmap?) -> Unit)? = null,
    onOpenCodeExecutor: ((String, String) -> Unit)? = null,
    onOpenVideoStudio: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var isLiked by remember { mutableStateOf(false) }
    var isDisliked by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showResponseInfoDialog by remember { mutableStateOf(false) }

    if (showResponseInfoDialog) {
        ResponseInfoDialog(
            modelName = message.modelUsed?.displayName ?: "Gemini 2.5 Flash",
            messageText = message.text,
            hasMedia = message.attachedImagePath != null || message.text.startsWith("[AI_VIDEO:"),
            onDismissRequest = { showResponseInfoDialog = false }
        )
    }

    if (message.isUser) {
        // User Message: Dark rounded pill on the right
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Surface(
                color = Color(0xFF26282E),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.widthIn(max = 300.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    if (message.attachedImagePath != null) {
                        val file = File(message.attachedImagePath)
                        if (file.exists()) {
                            val bmp = BitmapFactory.decodeFile(file.absolutePath)
                            if (bmp != null) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "User Attachment",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 200.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable {
                                            onViewOriginalMedia?.invoke(file.absolutePath, bmp, false, "उपयोगकर्ता संलग्नक")
                                        }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }

                    Text(
                        text = message.text,
                        color = Color.White,
                        fontSize = 15.sp,
                        lineHeight = 21.sp
                    )
                }
            }
        }
    } else {
        // AI Response: Direct plain text on dark canvas (matching Gemini screenshot)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            if (message.text.startsWith("[AI_VIDEO:")) {
                val raw = message.text.removePrefix("[AI_VIDEO:").removeSuffix("]")
                val parts = raw.split("|")
                val vTitle = parts.getOrNull(0) ?: "🎬 AI Video"
                val vDuration = parts.getOrNull(1)?.toIntOrNull() ?: 15
                val vTheme = parts.getOrNull(2) ?: "AI Video"
                val vMusic = parts.getOrNull(3) ?: "Cinematic Beats"

                AiInlineVideoPlayerCard(
                    title = vTitle,
                    durationSeconds = vDuration,
                    theme = vTheme,
                    musicMood = vMusic,
                    imagePath = message.attachedImagePath,
                    onCardClick = {
                        onViewOriginalMedia?.invoke(message.attachedImagePath, null, true, vTitle)
                    },
                    onOpenStudio = { onOpenVideoStudio?.invoke() }
                )
            } else {
                if (message.attachedImagePath != null) {
                    val file = File(message.attachedImagePath)
                    if (file.exists()) {
                        val bmp = BitmapFactory.decodeFile(file.absolutePath)
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "AI Image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 260.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(1.dp, Color(0xFF2E313A), RoundedCornerShape(14.dp))
                                    .clickable {
                                        // Open original photo directly without opening the editor
                                        onViewOriginalMedia?.invoke(file.absolutePath, bmp, false, "मूल AI फोटो")
                                    }
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }
                }

                Text(
                    text = message.text,
                    color = Color(0xFFE3E3E3),
                    fontSize = 15.5.sp,
                    lineHeight = 24.sp,
                    modifier = Modifier.padding(horizontal = 2.dp)
                )
            }

            // Action Icons Row: Like, Dislike, Regenerate, Copy, 3-dots Menu, Speaker
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 👍 Thumbs Up (लाइक)
                IconButton(
                    onClick = {
                        isLiked = !isLiked
                        if (isLiked) isDisliked = false
                        Toast.makeText(context, if (isLiked) "प्रतिक्रिया दर्ज हुई 👍" else "प्रतिक्रिया हटाई गई", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                        contentDescription = "लाइक",
                        tint = if (isLiked) Color(0xFF60A5FA) else Color(0xFF9E9EA8),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(2.dp))

                // 👎 Thumbs Down (डिसलाइक)
                IconButton(
                    onClick = {
                        isDisliked = !isDisliked
                        if (isDisliked) isLiked = false
                        Toast.makeText(context, if (isDisliked) "सुधार प्रतिक्रिया दर्ज हुई 👎" else "प्रतिक्रिया हटाई गई", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = if (isDisliked) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                        contentDescription = "नापसंद",
                        tint = if (isDisliked) Color(0xFFF87171) else Color(0xFF9E9EA8),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(2.dp))

                // 🔄 Regenerate / Retry
                IconButton(
                    onClick = {
                        onRetry?.invoke()
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "पुनः उत्पन्न करें",
                        tint = Color(0xFF9E9EA8),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(2.dp))

                // 📋 Copy
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("AI Response", message.text)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "उत्तर कॉपी हो गया 📋", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = "कॉपी करें",
                        tint = Color(0xFF9E9EA8),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(2.dp))

                // ⋯ Three Dots Menu (तीन डॉट विकल्प)
                Box {
                    IconButton(
                        onClick = { showMoreMenu = true },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreHoriz,
                            contentDescription = "तीन डॉट विकल्प",
                            tint = Color(0xFF9E9EA8),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMoreMenu,
                        onDismissRequest = { showMoreMenu = false },
                        modifier = Modifier
                            .background(Color(0xFF1E1F28))
                            .border(1.dp, Color(0xFF2E313A), RoundedCornerShape(8.dp))
                    ) {
                        // 1. नई चैट शुरू करें
                        DropdownMenuItem(
                            text = { Text("1. नई चैट शुरू करें", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium) },
                            leadingIcon = {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                showMoreMenu = false
                                onStartNewChat?.invoke()
                            }
                        )

                        // 2. इमेज कॉपी करें
                        DropdownMenuItem(
                            text = { Text("2. इमेज कॉपी करें", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium) },
                            leadingIcon = {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                showMoreMenu = false
                                if (message.attachedImagePath != null) {
                                    val file = File(message.attachedImagePath)
                                    if (file.exists()) {
                                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newUri(context.contentResolver, "AI Image", uri)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "🖼️ इमेज क्लिपबोर्ड में कॉपी की गई", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("AI Message", message.text)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "📋 टेक्स्ट क्लिपबोर्ड में कॉपी किया गया", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )

                        // 3. इमेज सेव करें
                        DropdownMenuItem(
                            text = { Text("3. इमेज सेव करें", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium) },
                            leadingIcon = {
                                Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                showMoreMenu = false
                                if (message.attachedImagePath != null) {
                                    val srcFile = File(message.attachedImagePath)
                                    if (srcFile.exists()) {
                                        val destDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES)
                                        val destFile = File(destDir, "AI_Photo_${System.currentTimeMillis()}.jpg")
                                        srcFile.copyTo(destFile, overwrite = true)
                                        android.media.MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf("image/jpeg"), null)
                                        Toast.makeText(context, "💾 इमेज सफलतापूर्वक गैलरी में सेव हो गई!", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    Toast.makeText(context, "💾 संदेश सुरक्षित कर लिया गया", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )

                        // 4. Docs में एक्सपोर्ट करें
                        DropdownMenuItem(
                            text = { Text("4. Docs में एक्सपोर्ट करें", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium) },
                            leadingIcon = {
                                Icon(Icons.Default.Description, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                showMoreMenu = false
                                val docsIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Gemini AI Document")
                                    putExtra(Intent.EXTRA_TEXT, message.text)
                                    setPackage("com.google.android.apps.docs.editors.docs")
                                }
                                try {
                                    context.startActivity(docsIntent)
                                } catch (e: Exception) {
                                    val genericIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "Gemini AI Document")
                                        putExtra(Intent.EXTRA_TEXT, message.text)
                                    }
                                    context.startActivity(Intent.createChooser(genericIntent, "Docs में एक्सपोर्ट करें"))
                                }
                                Toast.makeText(context, "📄 Docs में एक्सपोर्ट किया गया", Toast.LENGTH_SHORT).show()
                            }
                        )

                        // 5. M Gmail में ड्राफ्ट बनाएँ
                        DropdownMenuItem(
                            text = { Text("5. M Gmail में ड्राफ्ट बनाएँ", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium) },
                            leadingIcon = {
                                Icon(Icons.Default.Email, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                showMoreMenu = false
                                val emailIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = if (message.attachedImagePath != null) "image/jpeg" else "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Gemini AI Assistant Response")
                                    putExtra(Intent.EXTRA_TEXT, message.text)
                                    if (message.attachedImagePath != null) {
                                        val file = File(message.attachedImagePath)
                                        if (file.exists()) {
                                            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                    }
                                    setPackage("com.google.android.gm")
                                }
                                try {
                                    context.startActivity(emailIntent)
                                } catch (e: Exception) {
                                    val fallback = Intent(Intent.ACTION_SENDTO).apply {
                                        data = Uri.parse("mailto:")
                                        putExtra(Intent.EXTRA_SUBJECT, "Gemini AI Draft")
                                        putExtra(Intent.EXTRA_TEXT, message.text)
                                    }
                                    try { context.startActivity(fallback) } catch (ex: Exception) {
                                        val share = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_TEXT, message.text)
                                        }
                                        context.startActivity(Intent.createChooser(share, "Gmail ड्राफ्ट"))
                                    }
                                }
                                Toast.makeText(context, "✉️ Gmail में ड्राफ्ट खोला गया", Toast.LENGTH_SHORT).show()
                            }
                        )

                        // 6. जवाब की जानकारी देखें
                        DropdownMenuItem(
                            text = { Text("6. जवाब की जानकारी देखें", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium) },
                            leadingIcon = {
                                Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFA855F7), modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                showMoreMenu = false
                                showResponseInfoDialog = true
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // 🔊 Read Aloud / TTS Speaker
                IconButton(
                    onClick = { onSpeakText(message.text) },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "पढ़कर सुनाएं",
                        tint = Color(0xFFC4C7C5),
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AiInlineVideoPlayerCard(
    title: String,
    durationSeconds: Int,
    theme: String,
    musicMood: String,
    imagePath: String?,
    onCardClick: (() -> Unit)? = null,
    onOpenStudio: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(true) }
    var progress by remember { mutableFloatStateOf(0f) }
    var isMuted by remember { mutableStateOf(false) }

    val videoBitmap = remember(imagePath) {
        imagePath?.let {
            val f = File(it)
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        }
    }

    // Video Playback Progress Loop
    LaunchedEffect(isPlaying, durationSeconds) {
        if (isPlaying) {
            val stepTimeMs = 50L
            val totalSteps = (durationSeconds * 1000L) / stepTimeMs
            val delta = 1f / totalSteps.coerceAtLeast(1)
            while (true) {
                kotlinx.coroutines.delay(stepTimeMs)
                progress = (progress + delta)
                if (progress >= 1f) {
                    progress = 0f
                }
            }
        }
    }

    // Ken Burns Smooth Motion Simulation
    val infiniteTransition = rememberInfiniteTransition(label = "video_motion")
    val scaleMotion by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    val panMotionX by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "panX"
    )

    val currentSeconds = (progress * durationSeconds).toInt()
    val timeFormatted = String.format("%02d:%02d", currentSeconds / 60, currentSeconds % 60)
    val totalFormatted = String.format("%02d:%02d", durationSeconds / 60, durationSeconds % 60)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F121C)),
        border = BorderStroke(1.dp, Color(0xFF2E344A)),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Main Video Viewport
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .background(Color.Black)
                    .clickable { isPlaying = !isPlaying }
            ) {
                // Video Graphic / Decoded Bitmap Frame with motion
                if (videoBitmap != null) {
                    Image(
                        bitmap = videoBitmap.asImageBitmap(),
                        contentDescription = title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                if (isPlaying) {
                                    scaleX = scaleMotion
                                    scaleY = scaleMotion
                                    translationX = panMotionX
                                }
                            }
                    )
                } else {
                    // Fallback cinematic visual
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                androidx.compose.ui.graphics.Brush.verticalGradient(
                                    listOf(Color(0xFF1E1B4B), Color(0xFF0F172A), Color(0xFF020617))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = when {
                                theme.contains("बंदर") || theme.contains("monkey") -> "🐒"
                                theme.contains("शेर") || theme.contains("lion") -> "🦁"
                                theme.contains("कुत्ता") || theme.contains("dog") -> "🐕"
                                theme.contains("बिल्ली") || theme.contains("cat") -> "🐱"
                                theme.contains("कार") || theme.contains("car") -> "🏎️"
                                theme.contains("पहाड़") || theme.contains("mountain") -> "🏔️"
                                else -> "🎬"
                            },
                            fontSize = 64.sp
                        )
                    }
                }

                // Top Vignette Overlay
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .align(Alignment.TopCenter)
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)
                            )
                        )
                )

                // Top Badges Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .background(if (isPlaying) Color(0xFFEF4444) else Color.Gray, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "4K AI VIDEO • 60 FPS",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Surface(
                        color = Color.Black.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = totalFormatted,
                            color = TealAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Center Play/Pause Glass Icon (shows briefly on pause or click)
                if (!isPlaying) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.65f),
                        border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.8f)),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                // Bottom Video Controls & Seekbar Overlay
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Video Progress Seekbar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(Color.White.copy(alpha = 0.25f), RoundedCornerShape(2.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progress.coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .background(TealAccent, RoundedCornerShape(2.dp))
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Controls Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { isPlaying = !isPlaying },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(
                                text = "$timeFormatted / $totalFormatted",
                                color = Color.White,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            // Sound Equalizer Waveform
                            if (isPlaying && !isMuted) {
                                LiveAudioWaveform(color = TealAccent)
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Mute/Unmute
                            IconButton(
                                onClick = { isMuted = !isMuted },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = "Mute",
                                    tint = if (isMuted) Color.Gray else Color.White,
                                    modifier = Modifier.size(17.dp)
                                )
                            }

                            // Fullscreen
                            IconButton(
                                onClick = { onCardClick?.invoke() },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fullscreen,
                                    contentDescription = "Fullscreen",
                                    tint = Color.White,
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Info & Quick Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        text = "🎵 $musicMood",
                        color = Color.Gray,
                        fontSize = 11.5.sp,
                        maxLines = 1
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Quick Save
                    Surface(
                        onClick = {
                            if (videoBitmap != null) {
                                try {
                                    val picturesDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES)
                                    val saveFile = File(picturesDir, "AI_Video_Reel_${System.currentTimeMillis()}.jpg")
                                    java.io.FileOutputStream(saveFile).use { out ->
                                        videoBitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                                    }
                                    android.media.MediaScannerConnection.scanFile(context, arrayOf(saveFile.absolutePath), arrayOf("image/jpeg"), null)
                                    Toast.makeText(context, "💾 वीडियो गैलरी में सेव हो गया!", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "सेव विफल: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(context, "💾 वीडियो सहेजा गया!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E2235),
                        border = BorderStroke(1.dp, Color(0xFF333A56))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = TealAccent, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("सेव", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                        }
                    }

                    // Quick Share
                    Surface(
                        onClick = {
                            if (imagePath != null) {
                                val file = File(imagePath)
                                if (file.exists()) {
                                    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "image/*"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        putExtra(Intent.EXTRA_TEXT, "$title\nDocuScan AI Video")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "AI वीडियो शेयर करें"))
                                }
                            } else {
                                Toast.makeText(context, "वीडियो शेयर किया गया", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E2235),
                        border = BorderStroke(1.dp, Color(0xFF333A56))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("शेयर", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

private fun extractCodeBlock(text: String): String {
    val regex = "```(?:[a-zA-Z]*\\n)?([\\s\\S]*?)```".toRegex()
    val match = regex.find(text)
    return match?.groupValues?.get(1)?.trim() ?: text
}

private fun createSampleDocumentBitmap(): Bitmap {
    val bitmap = Bitmap.createBitmap(800, 1000, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    return bitmap
}

@Composable
fun ThinkingIndicator(modelType: AiModelType) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(start = 8.dp)
    ) {
        CircularProgressIndicator(
            color = TealAccent,
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp
        )
        Text(
            text = "${modelType.displayName} सोच रहा है...",
            color = Color.Gray,
            fontSize = 12.sp
        )
    }
}

@Composable
fun AiHistoryDrawerPanel(
    sessions: List<AiChatSession>,
    activeSessionId: String?,
    isMultiDeleteMode: Boolean,
    selectedSessionIds: List<String>,
    onToggleMultiDeleteMode: () -> Unit,
    onSelectAll: () -> Unit,
    onToggleSelectSession: (String) -> Unit,
    onDeleteSelected: () -> Unit,
    onSelectSession: (AiChatSession) -> Unit,
    onNewChatClick: () -> Unit,
    onCloseDrawer: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable { onCloseDrawer() }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxHeight()
                .width(320.dp)
                .clickable(enabled = false) {}, // consume clicks
            color = Color(0xFF16161D)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "चैट इतिहास (History)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    IconButton(onClick = onCloseDrawer) {
                        Icon(Icons.Default.Close, contentDescription = "बंद करें", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // + New Chat Button
                Button(
                    onClick = onNewChatClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_new_chat_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("+ New Chat (नया चैट)", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Multi-Delete Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isMultiDeleteMode) "${selectedSessionIds.size} चुने गए" else "हालिया चैट्स (${sessions.size})",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row {
                        if (isMultiDeleteMode) {
                            IconButton(onClick = onSelectAll, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.SelectAll, contentDescription = "Select All", tint = TealAccent, modifier = Modifier.size(20.dp))
                            }
                            if (selectedSessionIds.isNotEmpty()) {
                                IconButton(onClick = onDeleteSelected, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Selected", tint = PdfRed, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                        IconButton(onClick = onToggleMultiDeleteMode, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = if (isMultiDeleteMode) Icons.Default.Check else Icons.Default.DeleteSweep,
                                contentDescription = "मल्टी-डिलीट मेन्यू",
                                tint = if (isMultiDeleteMode) TealAccent else Color.LightGray,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFF282835), modifier = Modifier.padding(vertical = 8.dp))

                // Sessions List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(sessions) { session ->
                        val isSelected = selectedSessionIds.contains(session.id)
                        val isActive = session.id == activeSessionId

                        Card(
                            onClick = {
                                if (isMultiDeleteMode) {
                                    onToggleSelectSession(session.id)
                                } else {
                                    onSelectSession(session)
                                }
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    isSelected -> TealAccent.copy(alpha = 0.25f)
                                    isActive -> Color(0xFF252535)
                                    else -> Color(0xFF1E1E26)
                                }
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isMultiDeleteMode) {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                                        contentDescription = null,
                                        tint = if (isSelected) TealAccent else Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = session.title,
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = session.previewText.ifBlank { "कोई संदेश नहीं" },
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = dateFormat.format(Date(session.updatedAt)),
                                        color = Color(0xFF707085),
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiveVoiceCallOverlay(
    modelType: AiModelType,
    ttsEngine: TextToSpeech?,
    onSendMessage: (String, Bitmap?) -> Unit,
    onCloseCall: () -> Unit
) {
    val context = LocalContext.current
    var isMuted by remember { mutableStateOf(false) }
    var callStatus by remember { mutableStateOf("Connected with ${modelType.displayName}...") }
    var speechInputText by remember { mutableStateOf("") }
    var isAiSpeaking by remember { mutableStateOf(false) }

    // Pulsing animation for audio waves
    val transition = rememberInfiniteTransition(label = "pulse")
    val waveScale by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave"
    )

    // Speech Recognizer setup
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    val recordAudioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startListening(context, onResult = { text ->
                speechInputText = text
                callStatus = "AI सुन रहा है: \"$text\""
                onSendMessage(text, null)
            })
        }
    }

    DisposableEffect(Unit) {
        val permission = Manifest.permission.RECORD_AUDIO
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            speechRecognizer = startListening(context, onResult = { text ->
                speechInputText = text
                callStatus = "AI विचार कर रहा है..."
                onSendMessage(text, null)
            })
        } else {
            recordAudioLauncher.launch(permission)
        }

        onDispose {
            speechRecognizer?.destroy()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F1016)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "🔴 Live AI Voice Call",
                    color = TealAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = modelType.displayName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = callStatus,
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }

            // Pulsing Audio Avatar in the Center
            Box(
                modifier = Modifier
                    .size(200.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Wave
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .scale(waveScale)
                        .background(TealAccent.copy(alpha = 0.15f), CircleShape)
                )

                // Middle Wave
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .scale(waveScale * 0.95f)
                        .background(TealAccent.copy(alpha = 0.3f), CircleShape)
                )

                // Inner glowing Circle
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(TealAccent, Color(0xFF00796B))
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Live Call",
                        tint = Color.Black,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            // Spoken transcript preview
            if (speechInputText.isNotBlank()) {
                Surface(
                    color = Color(0xFF1E1E2A),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "\"$speechInputText\"",
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Call Controls: Mute, End Call
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mute
                IconButton(
                    onClick = { isMuted = !isMuted },
                    modifier = Modifier
                        .size(56.dp)
                        .background(if (isMuted) PdfRed.copy(alpha = 0.3f) else Color(0xFF262634), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = if (isMuted) PdfRed else Color.White
                    )
                }

                // End Call Button
                IconButton(
                    onClick = {
                        speechRecognizer?.stopListening()
                        onCloseCall()
                    },
                    modifier = Modifier
                        .size(64.dp)
                        .background(PdfRed, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Speak reply test
                IconButton(
                    onClick = {
                        ttsEngine?.speak("नमस्ते! मैं आपकी बात सुन रहा हूँ। आप कोई भी सवाल पूछ सकते हैं।", TextToSpeech.QUEUE_FLUSH, null, "LIVE_CALL")
                    },
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color(0xFF262634), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Speaker",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

private fun startListening(context: Context, onResult: (String) -> Unit): SpeechRecognizer? {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return null
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
    }
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {}
        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!matches.isNullOrEmpty()) {
                onResult(matches[0])
            }
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    recognizer.startListening(intent)
    return recognizer
}

@Composable
fun BanLockoutScreen(
    remainingTimeText: String,
    onBack: () -> Unit,
    onDevReset: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF140D0D)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(PdfRed.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Banned",
                    tint = PdfRed,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "🚫 AI सुविधा अस्थायी रूप से बंद है",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "अभद्र या गाली-गलौज वाली भाषा का बार-बार उपयोग करने के कारण आपकी AI सेवा 24 घंटे के लिए ब्लॉक कर दी गई है।",
                color = Color(0xFFD0B0B0),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            Surface(
                color = Color(0xFF241515),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "शेष समय (Remaining Time):",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = remainingTimeText,
                        color = Color(0xFFFF8A80),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF33333E)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("वापस जाएँ (Go Back)", color = Color.White)
            }

            Spacer(modifier = Modifier.height(8.dp))

            TextButton(
                onClick = onDevReset,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("रीसेट करें (Reset Restriction)", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

private fun saveBitmapLocally(context: Context, bitmap: Bitmap): String {
    val dir = File(context.cacheDir, "ai_attachments")
    if (!dir.exists()) dir.mkdirs()
    val file = File(dir, "attach_${System.currentTimeMillis()}.jpg")
    val fos = FileOutputStream(file)
    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos)
    fos.flush()
    fos.close()
    return file.absolutePath
}

@Composable
fun StudioCarouselCard(
    title: String,
    description: String,
    buttonText: String,
    bgGradient: List<Color>,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(260.dp)
            .height(138.dp)
            .clickable { onAction() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(bgGradient))
                .padding(14.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = description,
                            color = Color(0xFFD0D0E0),
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onAction,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0265DC)),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text(buttonText, color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun StudioOutlineToolItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    hasCrown: Boolean,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    var isClickedActive by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val active = isSelected || isClickedActive
    val borderColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color.White,
        label = "studio_outline_border"
    )
    val bgColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFF280808) else Color(0xFF0F0F14),
        label = "studio_outline_bg"
    )
    val iconColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color.White,
        label = "studio_outline_icon"
    )
    val labelColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color(0xFFE0E0EA),
        label = "studio_outline_label"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .clickable {
                isClickedActive = true
                scope.launch {
                    kotlinx.coroutines.delay(350)
                    isClickedActive = false
                }
                onClick()
            }
    ) {
        Box(
            modifier = Modifier.size(54.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(bgColor, CircleShape)
                    .border(1.5.dp, borderColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            if (hasCrown) {
                Surface(
                    color = Color(0xFFFFB300),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(16.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Pro",
                            tint = Color.Black,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            color = labelColor,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 13.sp,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun GeminiSparkleStar(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        val path = Path().apply {
            moveTo(cx, 0f)
            cubicTo(cx * 1.06f, cy * 0.72f, cx * 1.28f, cy * 0.94f, w, cy)
            cubicTo(cx * 1.28f, cy * 1.06f, cx * 1.06f, cy * 1.28f, cx, h)
            cubicTo(cx * 0.94f, cy * 1.28f, cx * 0.72f, cy * 1.06f, 0f, cy)
            cubicTo(cx * 0.72f, cy * 0.94f, cx * 0.94f, cy * 0.72f, cx, 0f)
            close()
        }

        val brush = androidx.compose.ui.graphics.Brush.linearGradient(
            colors = listOf(
                Color(0xFF4285F4), // Blue
                Color(0xFF9C51B6), // Purple
                Color(0xFFEA4335), // Coral Red
                Color(0xFFFBBC04)  // Amber Yellow
            ),
            start = Offset(0f, 0f),
            end = Offset(w, h)
        )

        drawPath(path = path, brush = brush)
    }
}

@Composable
fun LiveAudioWaveform(
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val h1 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(450, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h1"
    )
    val h2 by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 0.4f,
        animationSpec = infiniteRepeatable(tween(550, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h2"
    )
    val h3 by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(480, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h3"
    )

    Row(
        modifier = modifier.height(18.dp),
        horizontalArrangement = Arrangement.spacedBy(2.5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.width(2.5.dp).fillMaxHeight(h1).background(color, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(2.5.dp).fillMaxHeight(h3).background(color, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(2.5.dp).fillMaxHeight(h2).background(color, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(2.5.dp).fillMaxHeight(h1).background(color, RoundedCornerShape(2.dp)))
    }
}

@Composable
fun OriginalMediaViewerDialog(
    mediaPath: String?,
    bitmap: Bitmap?,
    isVideo: Boolean,
    title: String,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val resolvedBitmap = remember(mediaPath, bitmap) {
        bitmap ?: mediaPath?.let { BitmapFactory.decodeFile(it) }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0D0E15)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onDismissRequest) {
                            Icon(Icons.Default.Close, contentDescription = "बंद करें", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = title,
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }

                    Row {
                        // Share
                        IconButton(onClick = {
                            if (mediaPath != null) {
                                val file = File(mediaPath)
                                if (file.exists()) {
                                    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = if (isVideo) "video/*" else "image/*"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "मूल मीडिया शेयर करें"))
                                }
                            } else {
                                Toast.makeText(context, "मीडिया शेयर किया गया", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "शेयर करें", tint = Color.White)
                        }

                        // Save
                        IconButton(onClick = {
                            if (resolvedBitmap != null) {
                                try {
                                    val picturesDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES)
                                    val saveFile = File(picturesDir, "AI_Original_${System.currentTimeMillis()}.jpg")
                                    FileOutputStream(saveFile).use { out ->
                                        resolvedBitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                                    }
                                    android.media.MediaScannerConnection.scanFile(context, arrayOf(saveFile.absolutePath), arrayOf("image/jpeg"), null)
                                    Toast.makeText(context, "💾 गैलरी में सेव हो गया!", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "सेव विफल: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(context, "💾 मीडिया सहेजा गया", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Default.Download, contentDescription = "सेव करें", tint = TealAccent)
                        }
                    }
                }

                // Media Display Canvas
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (isVideo) {
                        var isPlayingFull by remember { mutableStateOf(true) }
                        var fullProgress by remember { mutableFloatStateOf(0f) }
                        val fullDuration = 15

                        LaunchedEffect(isPlayingFull) {
                            if (isPlayingFull) {
                                val step = 50L
                                val totalSteps = (fullDuration * 1000L) / step
                                val delta = 1f / totalSteps.coerceAtLeast(1)
                                while (true) {
                                    kotlinx.coroutines.delay(step)
                                    fullProgress += delta
                                    if (fullProgress >= 1f) fullProgress = 0f
                                }
                            }
                        }

                        val infiniteTransition = rememberInfiniteTransition(label = "fullscreen_video")
                        val scale by infiniteTransition.animateFloat(
                            initialValue = 1f,
                            targetValue = 1.06f,
                            animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Reverse),
                            label = "scale"
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable { isPlayingFull = !isPlayingFull },
                            contentAlignment = Alignment.Center
                        ) {
                            if (resolvedBitmap != null) {
                                Image(
                                    bitmap = resolvedBitmap.asImageBitmap(),
                                    contentDescription = title,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer {
                                            if (isPlayingFull) {
                                                scaleX = scale
                                                scaleY = scale
                                            }
                                        }
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                                listOf(Color(0xFF1E1B4B), Color(0xFF0F172A), Color(0xFF020617))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("🎬", fontSize = 80.sp)
                                }
                            }

                            // Center Play / Pause Indicator
                            if (!isPlayingFull) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color.Black.copy(alpha = 0.65f),
                                    border = BorderStroke(2.dp, Color.White),
                                    modifier = Modifier.size(68.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.PlayArrow,
                                            contentDescription = "Play",
                                            tint = Color.White,
                                            modifier = Modifier.size(40.dp)
                                        )
                                    }
                                }
                            }

                            // Bottom Fullscreen Video Controls
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.BottomCenter)
                                    .background(
                                        androidx.compose.ui.graphics.Brush.verticalGradient(
                                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))
                                        )
                                    )
                                    .padding(horizontal = 20.dp, vertical = 16.dp)
                            ) {
                                // Progress Bar
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(5.dp)
                                        .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(2.5.dp))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(fullProgress.coerceIn(0f, 1f))
                                            .fillMaxHeight()
                                            .background(TealAccent, RoundedCornerShape(2.5.dp))
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = { isPlayingFull = !isPlayingFull },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (isPlayingFull) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = if (isPlayingFull) "Pause" else "Play",
                                                tint = Color.White,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        val cur = (fullProgress * fullDuration).toInt()
                                        Text(
                                            text = String.format("%02d:%02d / %02d:%02d", cur / 60, cur % 60, fullDuration / 60, fullDuration % 60),
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium
                                        )

                                        Spacer(modifier = Modifier.width(12.dp))

                                        if (isPlayingFull) {
                                            LiveAudioWaveform(color = TealAccent)
                                        }
                                    }

                                    Surface(
                                        color = Color.White.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "4K 60FPS AI",
                                            color = TealAccent,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    } else if (resolvedBitmap != null) {
                        Image(
                            bitmap = resolvedBitmap.asImageBitmap(),
                            contentDescription = "Original Photo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text(
                            text = "फोटो लोड नहीं हो सकी",
                            color = Color.LightGray,
                            fontSize = 14.sp
                        )
                    }
                }

                // Bottom bar info
                Surface(
                    color = Color(0xFF161822),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isVideo) "AI वीडियो प्रीव्यू" else "मूल AI फोटो (Original Unedited Photo)",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (resolvedBitmap != null) "${resolvedBitmap.width} × ${resolvedBitmap.height} px" else "हाई डेफिनिशन",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = onDismissRequest,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E313A))
                        ) {
                            Text("बंद करें (Close)", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ResponseInfoDialog(
    modelName: String,
    messageText: String,
    hasMedia: Boolean,
    onDismissRequest: () -> Unit
) {
    val charCount = remember(messageText) { messageText.length }
    val wordCount = remember(messageText) { messageText.split("\\s+".toRegex()).filter { it.isNotBlank() }.size }
    val estimatedTokens = remember(charCount) { (charCount / 4).coerceAtLeast(1) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = Color(0xFF1E202A),
        icon = {
            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFA855F7), modifier = Modifier.size(32.dp))
        },
        title = {
            Text("जवाब की जानकारी (Response Details)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                InfoRowItem(label = "AI मॉडल", value = modelName, color = Color(0xFF38BDF8))
                InfoRowItem(label = "इंजन", value = "Google Gemini Neural Engine", color = Color(0xFF4ADE80))
                InfoRowItem(label = "शब्द गणना", value = "$wordCount शब्द ($charCount अक्षर)", color = Color.White)
                InfoRowItem(label = "अनुमानित टोकन", value = "~$estimatedTokens tokens", color = Color(0xFFFBBF24))
                InfoRowItem(label = "मीडिया प्रकार", value = if (hasMedia) "छवि / दृश्य शामिल है" else "केवल टेक्स्ट", color = Color(0xFFE879F9))
                InfoRowItem(label = "सुरक्षा स्तर", value = "100% सुरक्षित (Verified Safe)", color = Color(0xFF34D399))
            }
        },
        confirmButton = {
            Button(
                onClick = onDismissRequest,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7))
            ) {
                Text("ठीक है (OK)", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun InfoRowItem(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color.Gray, fontSize = 13.sp)
        Text(text = value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

