package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.LanguageSelectionDialog
import com.example.util.LanguageManager
import com.example.util.AiMediaGenerator
import com.example.util.AiVideoMeta
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.AiChatSession
import com.example.data.model.AiMessage
import com.example.data.model.AiModelType
import com.example.data.model.ScannedDocument
import com.example.data.repository.AiChatRepository
import com.example.data.util.GeminiOcrHelper
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import com.example.ui.theme.WordBlue
import com.example.ui.components.AiPhotoEditorDialog
import com.example.ui.components.AiCodeExecutorDialog
import com.example.ui.components.AiVideoStudioDialog
import com.example.util.AiSafetyManager
import com.example.util.ViolationResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AiToolMode(
    val title: String,
    val shortLabel: String,
    val iconEmoji: String,
    val placeholder: String,
    val badgeColor: Color,
    val borderColor: Color,
    val promptContext: String
) {
    PHOTO_STUDIO(
        title = "AI फ़ोटो एडिटर / Image Studio",
        shortLabel = "AI फ़ोटो एडिटर",
        iconEmoji = "🎨",
        placeholder = "फ़ोटो जोड़ें और बताएं क्या बदलाव करना है...",
        badgeColor = Color(0xFF2B1229),
        borderColor = Color(0xFFE879F9),
        promptContext = "[Mode: AI Photo Studio & Image Editor] कृपया संलग्न फ़ोटो या प्रश्न के अनुसार फ़ोटो एडिटिंग, इफेक्ट्स, रंग व सुधार के निर्देश और सुझाव दें: "
    ),
    CODE_ENGINE(
        title = "AI कोडिंग इंजन / Code Runner",
        shortLabel = "AI कोडिंग इंजन",
        iconEmoji = "💻",
        placeholder = "कोडिंग से संबंधित निर्देश लिखें (Python, HTML/JS, Kotlin)...",
        badgeColor = Color(0xFF0C241B),
        borderColor = Color(0xFF34D399),
        promptContext = "[Mode: AI Code Generation & Runner] निम्नलिखित कार्य के लिए स्पष्ट, संपूर्ण और चलाने योग्य (runnable) कोड ब्लॉक प्रदान करें: "
    ),
    VIDEO_STUDIO(
        title = "AI वीडियो स्टूडियो / Story Reel",
        shortLabel = "AI वीडियो स्टूडियो",
        iconEmoji = "🎬",
        placeholder = "वीडियो/रील का विषय या स्टोरीलाइन का विचार लिखें...",
        badgeColor = Color(0xFF1E1B4B),
        borderColor = Color(0xFF818CF8),
        promptContext = "[Mode: AI Video Studio & Reel Generator] निम्नलिखित विषय पर सीन-बाय-सीन वीडियो स्टोरीबोर्ड, विजुअल विवरण, समय और वॉइसओवर स्क्रिप्ट बनाएं: "
    ),
    DOC_ANALYSIS(
        title = "दस्तावेज़ विश्लेषण / Doc Insight",
        shortLabel = "दस्तावेज़ विश्लेषण",
        iconEmoji = "📑",
        placeholder = "दस्तावेज़ का विस्तृत सारांश या तथ्य पूछें...",
        badgeColor = Color(0xFF13233A),
        borderColor = Color(0xFF38BDF8),
        promptContext = "[Mode: Deep Document Analysis] दस्तावेज़ का पूर्ण सारांश, मुख्य बिंदु व साक्ष्य स्पष्ट रूप से प्रस्तुत करें: "
    ),
    TRANSLATION(
        title = "स्मार्ट अनुवाद / Smart Translate",
        shortLabel = "स्मार्ट अनुवाद",
        iconEmoji = "🌐",
        placeholder = "जिस भाषा में अनुवाद करना है वह निर्देश लिखें...",
        badgeColor = Color(0xFF2C1C0D),
        borderColor = Color(0xFFFBBF24),
        promptContext = "[Mode: Multilingual Translation] दिए गए पाठ का उपयुक्त भाषा में सटीक और स्पष्ट अनुवाद करें: "
    ),
    EXAM_QUIZ(
        title = "परीक्षा क्विज़ / MCQ Maker",
        shortLabel = "परीक्षा क्विज़",
        iconEmoji = "🎯",
        placeholder = "क्विज़ के विषय, प्रश्नों की संख्या या कठिनाई लिखें...",
        badgeColor = Color(0xFF231135),
        borderColor = Color(0xFFC084FC),
        promptContext = "[Mode: Exam Quiz & MCQ Generator] आगामी परीक्षा के लिए बहुविकल्पीय प्रश्न (MCQs with Explanations) तैयार करें: "
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
    initialDocument: ScannedDocument? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val repository = remember { AiChatRepository(context) }

    val sessions by repository.sessions.collectAsState()
    val messages by repository.currentMessages.collectAsState()

    var activeSession by remember { mutableStateOf<AiChatSession?>(null) }
    var selectedModelType by remember { mutableStateOf(AiModelType.GEMINI) }
    var userPromptText by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }

    // Gemini-style active tool mode (Photo, Code, Video, Summary, etc.)
    var activeToolMode by remember { mutableStateOf<AiToolMode?>(null) }

    // Drawer / History Panel State
    var isHistoryDrawerOpen by remember { mutableStateOf(false) }
    var isMultiDeleteMode by remember { mutableStateOf(false) }
    val selectedSessionIds = remember { mutableStateListOf<String>() }

    // Attachment State
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var attachedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var attachedBitmapPath by remember { mutableStateOf<String?>(null) }

    // Live Voice Call State
    var isLiveVoiceCallActive by remember { mutableStateOf(false) }

    // Safety Alert & Ban State
    var warningAlertMessage by remember { mutableStateOf<String?>(null) }
    var isUserBanned by remember { mutableStateOf(AiSafetyManager.isUserBanned(context)) }
    var remainingBanTimeMillis by remember { mutableLongStateOf(AiSafetyManager.getRemainingBanTimeMillis(context)) }

    // Multimodal AI Power Tools Dialog State
    val languageManager = remember { LanguageManager(context) }
    val currentLangCode by LanguageManager.currentLanguageFlow.collectAsStateWithLifecycle()
    val selectedLanguage = remember(currentLangCode) { languageManager.getSelectedLanguage() }
    var showLanguageDialog by remember { mutableStateOf(false) }

    var showPhotoEditorDialog by remember { mutableStateOf(false) }
    var photoToEditBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showCodeExecutorDialog by remember { mutableStateOf(false) }
    var codeToRunText by remember { mutableStateOf("") }
    var codeToRunLang by remember { mutableStateOf("Python") }
    var showVideoStudioDialog by remember { mutableStateOf(false) }

    // TTS Engine for AI voice replies
    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        var ttsInstance: TextToSpeech? = null
        ttsInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsInstance?.language = java.util.Locale("hi", "IN")
            }
        }
        ttsEngine = ttsInstance
        onDispose {
            ttsInstance.stop()
            ttsInstance.shutdown()
        }
    }

    // Ban countdown timer
    LaunchedEffect(isUserBanned) {
        while (isUserBanned) {
            val rem = AiSafetyManager.getRemainingBanTimeMillis(context)
            remainingBanTimeMillis = rem
            if (rem <= 0) {
                isUserBanned = false
                break
            }
            delay(1000)
        }
    }

    // Initialize active session
    LaunchedEffect(sessions) {
        if (activeSession == null) {
            if (sessions.isNotEmpty()) {
                val first = sessions.first()
                activeSession = first
                selectedModelType = first.modelType
                repository.loadMessages(first.id)
            } else {
                val newSess = repository.createNewSession(
                    title = if (!initialDocument?.title.isNullOrBlank()) initialDocument.title else "ALL PDF AI Assistant",
                    modelType = selectedModelType
                )
                activeSession = newSess
                repository.loadMessages(newSess.id)
            }
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Image Picker & Camera Launchers
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) {
            attachedBitmap = bmp
            attachedBitmapPath = saveBitmapLocally(context, bmp)
            showAttachmentSheet = false
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bmp != null) {
                    attachedBitmap = bmp
                    attachedBitmapPath = saveBitmapLocally(context, bmp)
                }
            } catch (e: Exception) {
                Toast.makeText(context, "फ़ाइल लोड करने में त्रुटि", Toast.LENGTH_SHORT).show()
            }
            showAttachmentSheet = false
        }
    }

    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                userPromptText = spokenText
            }
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "PDF के बारे में कुछ भी बोलें...")
            }
            try {
                speechRecognizerLauncher.launch(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "वॉइस इनपुट प्रारंभ नहीं हो सका", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "माइक्रोफोन अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            cameraLauncher.launch()
        } else {
            Toast.makeText(context, "कैमरा अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    // Send Query Handler
    val onSendMessage: (String, Bitmap?) -> Unit = { promptText, imageBmp ->
        val cleanPrompt = promptText.trim()
        val sendBitmap = imageBmp ?: attachedBitmap
        val sendBitmapPath = attachedBitmapPath
        val currentTool = activeToolMode

        if (cleanPrompt.isNotBlank() || sendBitmap != null || currentTool != null) {
            if (AiSafetyManager.isUserBanned(context)) {
                isUserBanned = true
            } else if (AiSafetyManager.containsAbusiveLanguage(cleanPrompt)) {
                // Safety Violation Handler
                when (val result = AiSafetyManager.recordViolation(context)) {
                    is ViolationResult.Warning -> {
                        warningAlertMessage = result.message
                    }
                    is ViolationResult.Banned -> {
                        isUserBanned = true
                        remainingBanTimeMillis = 24 * 60 * 60 * 1000L
                    }
                }
            } else {
                // Check IT Rules / Deepfake / Synthetic harm / Copyright compliance
                val safetyRefusal = AiSafetyManager.checkPromptSafety(cleanPrompt)

                // Clear text inputs
                userPromptText = ""
                attachedBitmap = null
                attachedBitmapPath = null

                coroutineScope.launch {
                    val currentSess = activeSession ?: repository.createNewSession(
                        title = if (!initialDocument?.title.isNullOrBlank()) initialDocument.title else if (cleanPrompt.isNotBlank()) cleanPrompt.take(24) else (currentTool?.shortLabel ?: "ALL PDF AI Assistant"),
                        modelType = selectedModelType
                    ).also {
                        activeSession = it
                    }

                    val userDisplayText = when {
                        cleanPrompt.isNotBlank() && currentTool != null -> "${currentTool.iconEmoji} ${cleanPrompt}"
                        cleanPrompt.isNotBlank() -> cleanPrompt
                        currentTool != null -> "${currentTool.iconEmoji} [${currentTool.title}]"
                        else -> "📷 [संलग्न फोटो/दस्तावेज़ का विश्लेषण]"
                    }

                    val userMsg = AiMessage(
                        sessionId = currentSess.id,
                        sender = "User",
                        text = userDisplayText,
                        isUser = true,
                        attachedImagePath = sendBitmapPath,
                        modelUsed = selectedModelType
                    )

                    repository.addMessage(userMsg)

                    if (safetyRefusal != null) {
                        val aiMsg = AiMessage(
                            sessionId = currentSess.id,
                            sender = selectedModelType.displayName,
                            text = safetyRefusal,
                            isUser = false,
                            modelUsed = selectedModelType
                        )
                        repository.addMessage(aiMsg)
                    } else {
                        isThinking = true

                        if (AiMediaGenerator.isImageGenerationRequest(cleanPrompt)) {
                            val genPath = AiMediaGenerator.generateImageForPrompt(context, cleanPrompt)
                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = "🖼️ [AI Generated Photo]",
                                isUser = false,
                                attachedImagePath = genPath,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        } else if (AiMediaGenerator.isVideoGenerationRequest(cleanPrompt)) {
                            val meta = AiMediaGenerator.generateVideoMeta(cleanPrompt, initialDocument?.title ?: "")
                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = "[AI_VIDEO:${meta.title}|${meta.scenes.joinToString(";")}|${meta.visualTheme}]",
                                isUser = false,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        } else {
                            val promptForAi = when {
                                currentTool != null && cleanPrompt.isNotBlank() -> "${currentTool.promptContext}\n$cleanPrompt"
                                currentTool != null -> "${currentTool.promptContext}\nसंलग्न छवि या दस्तावेज़ का विश्लेषण करके उचित परिणाम प्रदान करें।"
                                cleanPrompt.isNotBlank() -> cleanPrompt
                                else -> "इस फोटो/दस्तावेज़ में क्या है? संक्षेप में समझाइए।"
                            }

                            val aiReply = GeminiOcrHelper.askMultiModelAi(
                                prompt = promptForAi,
                                modelType = selectedModelType.name,
                                contextDocTitle = initialDocument?.title ?: "",
                                bitmap = sendBitmap
                            )

                            val aiMsg = AiMessage(
                                sessionId = currentSess.id,
                                sender = selectedModelType.displayName,
                                text = aiReply,
                                isUser = false,
                                modelUsed = selectedModelType
                            )
                            repository.addMessage(aiMsg)
                            isThinking = false
                        }
                    }
                }
            }
        }
    }

    // If User is Banned, show 24-Hour Ban Lock Screen
    if (isUserBanned) {
        BanLockoutScreen(
            remainingTimeText = AiSafetyManager.formatRemainingBanTime(remainingBanTimeMillis),
            onBack = onBack,
            onDevReset = {
                AiSafetyManager.resetBan(context)
                isUserBanned = false
            }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    ModelSelectorDropdown(
                        currentModel = selectedModelType,
                        onSelectModel = { newModel ->
                            selectedModelType = newModel
                        }
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { isHistoryDrawerOpen = true },
                        modifier = Modifier.testTag("ai_history_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "चैट इतिहास ☰",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // New Chat Button (Pencil / Edit icon as in Gemini)
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                val newSess = repository.createNewSession(modelType = selectedModelType)
                                activeSession = newSess
                                repository.loadMessages(newSess.id)
                                Toast.makeText(context, "नया चैट शुरू हुआ ✨", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "नया चैट",
                            tint = Color(0xFFE2E2E8),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Back / Close Button
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close AI Assistant",
                            tint = Color(0xFF9E9EA8),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F0F12)
                )
            )
        },
        containerColor = Color(0xFF0F0F12)
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Mandatory Compliance & Disclaimer Banner
                Surface(
                    color = Color(0xFF161922),
                    border = BorderStroke(0.8.dp, Color(0xFF283548)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFF60A5FA),
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "यह AI द्वारा जनरेट किया गया उत्तर है, महत्वपूर्ण जानकारी को दोबारा जाँच लें।",
                            color = Color(0xFF93C5FD),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 15.sp
                        )
                    }
                }

                // Initial document badge banner if opened from a specific PDF
                if (initialDocument != null) {
                    Surface(
                        color = Color(0xFF1A1A24),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = TealAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "सक्रिय दस्तावेज़: ${initialDocument.title}",
                                color = Color(0xFFC0C0D0),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Chat Messages List & Welcome Hero Carousel (HomeScreen Style)
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    contentPadding = PaddingValues(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Welcome & Hero Gemini Display when chat is fresh
                    if (messages.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 36.dp, bottom = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Multi-color Gemini 4-Point Radiant Sparkle Star
                                GeminiSparkleStar(
                                    modifier = Modifier.size(52.dp)
                                )

                                Spacer(modifier = Modifier.height(24.dp))

                                // Universal Greeting: नमस्ते!
                                Text(
                                    text = "नमस्ते!",
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Subtitle: क्या आपका कोई सवाल है?
                                Text(
                                    text = "क्या आपका कोई सवाल है?",
                                    color = Color(0xFFE2E2E8),
                                    fontSize = 23.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(28.dp))

                                // Gemini Quick Suggestion Chips Row
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    val quickPrompts = listOf(
                                        Triple("📄 दस्तावेज़ का सारांश", AiToolMode.DOC_ANALYSIS, "दस्तावेज़ का पूर्ण सारांश (Executive Summary) और मुख्य निष्कर्ष बताएं।"),
                                        Triple("🎨 AI फोटो एडिट", AiToolMode.PHOTO_STUDIO, "फोटो को एन्हांस करें और मुख्य तत्वों का विश्लेषण प्रस्तुत करें।"),
                                        Triple("💻 कोड बनाएं", AiToolMode.CODE_ENGINE, "पायथन में एक स्वच्छ और कुशल कोड लिखकर समझाइए।"),
                                        Triple("🌐 हिंदी अनुवाद", AiToolMode.TRANSLATION, "इस पाठ का सरल और स्पष्ट हिंदी में सटीक अनुवाद करें।"),
                                        Triple("🎯 5 परीक्षा प्रश्न", AiToolMode.EXAM_QUIZ, "इस दस्तावेज़ से आगामी परीक्षा के लिए 5 महत्वपूर्ण बहुविकल्पीय प्रश्न (MCQs with Answers) तैयार करें।")
                                    )
                                    items(quickPrompts) { (label, toolMode, prompt) ->
                                        Surface(
                                            color = Color(0xFF1E1F24),
                                            shape = RoundedCornerShape(20.dp),
                                            border = BorderStroke(1.dp, Color(0xFF2E2F38)),
                                            modifier = Modifier.clickable {
                                                activeToolMode = toolMode
                                                userPromptText = prompt
                                            }
                                        ) {
                                            Text(
                                                text = label,
                                                color = Color(0xFFE2E2E8),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                // Quick Tools Carousel Cards
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    item {
                                        StudioCarouselCard(
                                            title = "AI Generative Studio",
                                            description = "दस्तावेज़ों का पूर्ण विश्लेषण, सारांश और डायरेक्ट प्रश्न-उत्तर।",
                                            buttonText = "चैट शुरू करें",
                                            bgGradient = listOf(Color(0xFF1E2B58), Color(0xFF121830)),
                                            icon = Icons.Default.AutoAwesome,
                                            onAction = {
                                                userPromptText = "दस्तावेज़ का पूर्ण सारांश (Executive Summary) और मुख्य निष्कर्ष बताएं।"
                                            }
                                        )
                                    }
                                    item {
                                        StudioCarouselCard(
                                            title = "AI Photo Studio",
                                            description = "4K विज़ुअल्स, फोटो जनरेशन और डायरेक्ट इमेज एन्हांसमेंट।",
                                            buttonText = "फोटो बनाएं",
                                            bgGradient = listOf(Color(0xFF4A154B), Color(0xFF281032)),
                                            icon = Icons.Default.AddPhotoAlternate,
                                            onAction = {
                                                activeToolMode = AiToolMode.PHOTO_STUDIO
                                                showPhotoEditorDialog = true
                                            }
                                        )
                                    }
                                    item {
                                        StudioCarouselCard(
                                            title = "AI Ultra Code IDE",
                                            description = "Python, Kotlin, JavaScript और HTML5 गेम्स तुरंत चलाएं।",
                                            buttonText = "कोड रनर",
                                            bgGradient = listOf(Color(0xFF0C2B1D), Color(0xFF05170F)),
                                            icon = Icons.Default.Code,
                                            onAction = {
                                                activeToolMode = AiToolMode.CODE_ENGINE
                                                showCodeExecutorDialog = true
                                            }
                                        )
                                    }
                                    item {
                                        StudioCarouselCard(
                                            title = "AI Video & Reel Creator",
                                            description = "9:16 वर्टिकल एनिमेटेड रील्स और वीडियो सीन जनरेट करें।",
                                            buttonText = "वीडियो बनाएं",
                                            bgGradient = listOf(Color(0xFF2B1C48), Color(0xFF140D24)),
                                            icon = Icons.Default.Movie,
                                            onAction = {
                                                activeToolMode = AiToolMode.VIDEO_STUDIO
                                                showVideoStudioDialog = true
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    items(messages) { msg ->
                        ChatMessageBubble(
                            message = msg,
                            onSpeakText = { text ->
                                ttsEngine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AI_MSG")
                            },
                            onOpenPhotoEditor = { bmp ->
                                photoToEditBitmap = bmp ?: attachedBitmap
                                showPhotoEditorDialog = true
                            },
                            onOpenCodeExecutor = { code, lang ->
                                codeToRunText = code
                                codeToRunLang = lang
                                showCodeExecutorDialog = true
                            },
                            onOpenVideoStudio = {
                                showVideoStudioDialog = true
                            }
                        )
                    }

                    if (isThinking) {
                        item {
                            ThinkingIndicator(modelType = selectedModelType)
                        }
                    }
                }

                // Active Tool Badge & Attached Image Bar (Directly Above Input Box)
                AnimatedVisibility(
                    visible = activeToolMode != null || attachedBitmap != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Surface(
                        color = activeToolMode?.badgeColor ?: Color(0xFF1E1E28),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.2.dp, activeToolMode?.borderColor ?: Color(0xFF333348)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (activeToolMode != null) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(activeToolMode!!.borderColor.copy(alpha = 0.25f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = activeToolMode!!.iconEmoji, fontSize = 16.sp)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = activeToolMode!!.title,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (attachedBitmap != null) "फ़ोटो संलग्न है • निर्देश लिखकर भेजें" else "नीचे निर्देश या प्रश्न लिखें",
                                        color = Color(0xFFB8B8C8),
                                        fontSize = 11.sp
                                    )
                                }
                            } else {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("फोटो संलग्न की गई", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("प्रश्न के साथ AI विश्लेषण होगा", color = Color.Gray, fontSize = 11.sp)
                                }
                            }

                            if (attachedBitmap != null) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, activeToolMode?.borderColor ?: Color.White, RoundedCornerShape(8.dp))
                                ) {
                                    Image(
                                        bitmap = attachedBitmap!!.asImageBitmap(),
                                        contentDescription = "Attached Preview",
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            } else if (activeToolMode == AiToolMode.PHOTO_STUDIO) {
                                TextButton(
                                    onClick = { showAttachmentSheet = true },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("+ फ़ोटो जोड़ें", color = Color(0xFFFF80AB), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // (✕) Clear Active Tool Badge
                            IconButton(
                                onClick = {
                                    activeToolMode = null
                                    attachedBitmap = null
                                    attachedBitmapPath = null
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "टूल हटाएं",
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // Quick AI Action Suggestion Pills
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Tool 1: Photo Studio
                    item {
                        val isSel = activeToolMode == AiToolMode.PHOTO_STUDIO
                        Surface(
                            color = if (isSel) Color(0xFF3B1838) else Color(0xFF241424),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) Color(0xFFFF80AB) else Color(0xFF6B21A8)),
                            modifier = Modifier.clickable {
                                activeToolMode = if (isSel) null else AiToolMode.PHOTO_STUDIO
                                if (!isSel && attachedBitmap == null) {
                                    showAttachmentSheet = true
                                }
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🎨", fontSize = 12.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("AI फ़ोटो एडिटर", color = Color(0xFFFF80AB), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Tool 2: Code Runner
                    item {
                        val isSel = activeToolMode == AiToolMode.CODE_ENGINE
                        Surface(
                            color = if (isSel) Color(0xFF143828) else Color(0xFF0F261C),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) EmeraldGreen else Color(0xFF047857)),
                            modifier = Modifier.clickable {
                                activeToolMode = if (isSel) null else AiToolMode.CODE_ENGINE
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("💻", fontSize = 12.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("AI कोडिंग इंजन", color = EmeraldGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Tool 3: Video Studio
                    item {
                        val isSel = activeToolMode == AiToolMode.VIDEO_STUDIO
                        Surface(
                            color = if (isSel) Color(0xFF2E2A68) else Color(0xFF1E1B4B),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) Color(0xFF818CF8) else Color(0xFF4338CA)),
                            modifier = Modifier.clickable {
                                activeToolMode = if (isSel) null else AiToolMode.VIDEO_STUDIO
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🎬", fontSize = 12.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("AI वीडियो स्टूडियो", color = TealAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    val quickActions = listOf(
                        Triple("📑 पूर्ण सारांश", AiToolMode.DOC_ANALYSIS, "दस्तावेज़ का पूर्ण सारांश (Executive Summary) और मुख्य निष्कर्ष बताएं।"),
                        Triple("🌐 AI अनुवाद", AiToolMode.TRANSLATION, "इस पाठ का सरल और स्पष्ट भाषा में सटीक अनुवाद करें।"),
                        Triple("🎯 5 परीक्षा प्रश्न", AiToolMode.EXAM_QUIZ, "इस पाठ से आगामी परीक्षा के लिए 5 महत्वपूर्ण बहुविकल्पीय प्रश्न (MCQs with Answers) तैयार करें।"),
                        Triple("💡 मुख्य बिंदु व साक्ष्य", AiToolMode.DOC_ANALYSIS, "दस्तावेज़ में उल्लिखित सभी मुख्य स्थलों, साक्ष्यों और तथ्यों की सूची सारणी (Table) में दें।"),
                        Triple("👶 सरल भाषा में समझाइए", AiToolMode.DOC_ANALYSIS, "इस दस्तावेज़ की मुख्य बातों को बहुत ही आसान और सरल भाषा में उदाहरण देकर समझाइए।"),
                        Triple("📊 डेटा व तालिका", AiToolMode.DOC_ANALYSIS, "दस्तावेज़ में दी गई सभी तिथियों, स्थानों और आंकड़ों को क्रमबद्ध तालिका में प्रस्तुत करें।")
                    )
                    items(quickActions) { (label, toolMode, defaultPrompt) ->
                        val isSel = activeToolMode == toolMode
                        Surface(
                            color = if (isSel) Color(0xFF262634) else Color(0xFF1E1E26),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, if (isSel) TealAccent else Color(0xFF333342)),
                            modifier = Modifier.clickable {
                                activeToolMode = toolMode
                                userPromptText = defaultPrompt
                            }
                        ) {
                            Text(
                                text = label,
                                color = if (isSel) TealAccent else Color(0xFFE2E2E8),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                // Bottom Floating Pill Input Bar (Exact Gemini Layout)
                Surface(
                    color = Color(0xFF0F0F12),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Surface(
                            color = Color(0xFF1E1F24),
                            shape = RoundedCornerShape(32.dp),
                            border = BorderStroke(1.dp, Color(0xFF2E2F38)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // (+) Attachment Button
                                IconButton(
                                    onClick = { showAttachmentSheet = true },
                                    modifier = Modifier
                                        .size(38.dp)
                                        .background(Color(0xFF2B2C34), CircleShape)
                                        .testTag("ai_attachment_plus_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "अटैचमेंट जोड़ें (+)",
                                        tint = Color(0xFFC4C7C5),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                // Text Input Field
                                OutlinedTextField(
                                    value = userPromptText,
                                    onValueChange = { userPromptText = it },
                                    placeholder = {
                                        Text(
                                            text = "Gemini से कहें",
                                            color = Color(0xFF8E8E98),
                                            fontSize = 15.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("ai_prompt_input_field"),
                                    maxLines = 4,
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                    keyboardActions = KeyboardActions(onSend = {
                                        if (userPromptText.isNotBlank() || attachedBitmap != null || activeToolMode != null) {
                                            onSendMessage(userPromptText, attachedBitmap)
                                        }
                                    }),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedContainerColor = Color.Transparent,
                                        unfocusedContainerColor = Color.Transparent,
                                        focusedBorderColor = Color.Transparent,
                                        unfocusedBorderColor = Color.Transparent
                                    )
                                )

                                // Mic Icon Button
                                IconButton(
                                    onClick = {
                                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Gemini से कुछ भी बोलें...")
                                            }
                                            try {
                                                speechRecognizerLauncher.launch(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "वॉइस इनपुट उपलब्ध नहीं है", Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Mic,
                                        contentDescription = "वॉइस इनपुट 🎙️",
                                        tint = Color(0xFFC4C7C5),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                val canSend = userPromptText.isNotBlank() || attachedBitmap != null || activeToolMode != null

                                // Action Button: Live Waveform when empty, or Send Arrow when text is present!
                                IconButton(
                                    onClick = {
                                        if (canSend) {
                                            onSendMessage(userPromptText, attachedBitmap)
                                        } else {
                                            isLiveVoiceCallActive = true
                                        }
                                    },
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFF2B64E2), CircleShape)
                                        .testTag("ai_send_prompt_button")
                                ) {
                                    if (canSend) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Send,
                                            contentDescription = "Send",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    } else {
                                        LiveAudioWaveform(
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Bottom Privacy Notice
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp, bottom = 2.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "AI से गलतियाँ हो सकती है • 🔒 डेटा 100% सुरक्षित है",
                                color = Color(0xFF64748B),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Slide-over Chat History Panel (☰ 3-Line Menu Drawer)
            AnimatedVisibility(
                visible = isHistoryDrawerOpen,
                enter = slideInHorizontally { -it } + fadeIn(),
                exit = slideOutHorizontally { -it } + fadeOut()
            ) {
                AiHistoryDrawerPanel(
                    sessions = sessions,
                    activeSessionId = activeSession?.id,
                    isMultiDeleteMode = isMultiDeleteMode,
                    selectedSessionIds = selectedSessionIds,
                    onToggleMultiDeleteMode = {
                        isMultiDeleteMode = !isMultiDeleteMode
                        selectedSessionIds.clear()
                    },
                    onSelectAll = {
                        selectedSessionIds.clear()
                        selectedSessionIds.addAll(sessions.map { it.id })
                    },
                    onToggleSelectSession = { id ->
                        if (selectedSessionIds.contains(id)) {
                            selectedSessionIds.remove(id)
                        } else {
                            selectedSessionIds.add(id)
                        }
                    },
                    onDeleteSelected = {
                        coroutineScope.launch {
                            repository.deleteSessions(selectedSessionIds.toSet())
                            selectedSessionIds.clear()
                            isMultiDeleteMode = false
                            if (sessions.isNotEmpty()) {
                                val first = sessions.first()
                                activeSession = first
                                repository.loadMessages(first.id)
                            } else {
                                val newSess = repository.createNewSession()
                                activeSession = newSess
                            }
                        }
                    },
                    onSelectSession = { session ->
                        activeSession = session
                        selectedModelType = session.modelType
                        coroutineScope.launch {
                            repository.loadMessages(session.id)
                        }
                        isHistoryDrawerOpen = false
                    },
                    onNewChatClick = {
                        coroutineScope.launch {
                            val newSess = repository.createNewSession(modelType = selectedModelType)
                            activeSession = newSess
                            isHistoryDrawerOpen = false
                        }
                    },
                    onCloseDrawer = {
                        isHistoryDrawerOpen = false
                        isMultiDeleteMode = false
                        selectedSessionIds.clear()
                    }
                )
            }
        }
    }

    // Attachment Bottom Sheet: Camera & Gallery options
    if (showAttachmentSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachmentSheet = false },
            containerColor = Color(0xFF1E1E26)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "फ़ोटो या दस्तावेज़ जोड़ें (+)",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Option 1: Camera
                Card(
                    onClick = {
                        val permission = Manifest.permission.CAMERA
                        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                            cameraLauncher.launch()
                        } else {
                            cameraPermissionLauncher.launch(permission)
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF282834)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = TealAccent, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("📷 कैमरे से फोटो लें (Camera)", color = Color.White, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                            Text("पेज या नोट की तुरंत फोटो खींचकर सवाल पूछें", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Option 2: Gallery / Files
                Card(
                    onClick = {
                        filePickerLauncher.launch("image/*")
                    },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF282834)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = WordBlue, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("📁 गैलरी / फ़ाइल से चुनें (Gallery / Files)", color = Color.White, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                            Text("फ़ोन से कोई भी फोटो या स्क्रीनशॉट अपलोड करें", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Live Voice Call Screen Overlay
    if (isLiveVoiceCallActive) {
        LiveVoiceCallOverlay(
            modelType = selectedModelType,
            ttsEngine = ttsEngine,
            onSendMessage = onSendMessage,
            onCloseCall = { isLiveVoiceCallActive = false }
        )
    }

    // Safety Warning Dialog
    if (warningAlertMessage != null) {
        AlertDialog(
            onDismissRequest = { warningAlertMessage = null },
            icon = {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFFB74D), modifier = Modifier.size(36.dp))
            },
            title = {
                Text("सुरक्षा चेतावनी (Safety Alert)", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(warningAlertMessage ?: "", color = Color(0xFFE0E0E0), fontSize = 14.sp)
            },
            confirmButton = {
                Button(
                    onClick = { warningAlertMessage = null },
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                ) {
                    Text("मैं समझ गया (OK)", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF252530)
        )
    }

    // AI Photo Editor Dialog
    if (showPhotoEditorDialog) {
        val bmpToEdit = photoToEditBitmap ?: createSampleDocumentBitmap()
        AiPhotoEditorDialog(
            initialBitmap = bmpToEdit,
            onSaveEditedPhoto = { editedBmp, path ->
                attachedBitmap = editedBmp
                attachedBitmapPath = path
                showPhotoEditorDialog = false
            },
            onDismissRequest = { showPhotoEditorDialog = false }
        )
    }

    // AI Code Runner & IDE Dialog
    if (showCodeExecutorDialog) {
        AiCodeExecutorDialog(
            initialCode = codeToRunText,
            initialLanguage = codeToRunLang,
            onDismissRequest = { showCodeExecutorDialog = false }
        )
    }

    // AI Video Studio & Reels Dialog
    if (showVideoStudioDialog) {
        val bitmapsList = listOfNotNull(attachedBitmap ?: photoToEditBitmap)
        AiVideoStudioDialog(
            initialBitmaps = bitmapsList,
            docTitle = initialDocument?.title ?: "ALL PDF AI Story",
            onDismissRequest = { showVideoStudioDialog = false }
        )
    }

    // Language Selector Dialog
    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguageCode = selectedLanguage.code,
            onLanguageSelected = { lang ->
                languageManager.applyLanguageLocale(context, lang.code)
            },
            onConfirm = {
                showLanguageDialog = false
                Toast.makeText(
                    context,
                    "${selectedLanguage.flagEmoji} ${selectedLanguage.nativeName} सेट किया गया",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }
}

@Composable
fun ModelSelectorDropdown(
    currentModel: AiModelType,
    onSelectModel: (AiModelType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { expanded = true }
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = currentModel.displayName,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = "Select Model",
                tint = Color(0xFFC4C7C5),
                modifier = Modifier.size(20.dp)
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color(0xFF1E1F24))
        ) {
            AiModelType.values().forEach { model ->
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(model.displayName, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(model.subtitle, color = Color(0xFF9E9EA8), fontSize = 11.sp)
                        }
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = when (model) {
                                AiModelType.GEMINI, AiModelType.GEMINI_PRO, AiModelType.GEMINI_ADVANCED -> Icons.Default.AutoAwesome
                                AiModelType.CHATGPT -> Icons.Default.Psychology
                                else -> Icons.Default.SmartToy
                            },
                            contentDescription = null,
                            tint = when (model) {
                                AiModelType.GEMINI, AiModelType.GEMINI_PRO, AiModelType.GEMINI_ADVANCED -> TealAccent
                                AiModelType.CHATGPT -> Color(0xFF10A37F)
                                else -> EmeraldGreen
                            }
                        )
                    },
                    onClick = {
                        onSelectModel(model)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun ChatMessageBubble(
    message: AiMessage,
    onSpeakText: (String) -> Unit,
    onOpenPhotoEditor: ((Bitmap?) -> Unit)? = null,
    onOpenCodeExecutor: ((String, String) -> Unit)? = null,
    onOpenVideoStudio: (() -> Unit)? = null
) {
    val context = LocalContext.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!message.isUser) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(
                        when (message.modelUsed) {
                            AiModelType.CHATGPT -> Color(0xFF10A37F).copy(alpha = 0.2f)
                            AiModelType.APP_ASSISTANT -> EmeraldGreen.copy(alpha = 0.2f)
                            else -> TealAccent.copy(alpha = 0.2f)
                        },
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (message.modelUsed) {
                        AiModelType.CHATGPT -> Icons.Default.Psychology
                        AiModelType.APP_ASSISTANT -> Icons.Default.SmartToy
                        else -> Icons.Default.AutoAwesome
                    },
                    contentDescription = null,
                    tint = when (message.modelUsed) {
                        AiModelType.CHATGPT -> Color(0xFF10A37F)
                        AiModelType.APP_ASSISTANT -> EmeraldGreen
                        else -> TealAccent
                    },
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Surface(
            color = if (message.isUser) Color(0xFF005C4B) else Color(0xFF1E1E26),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isUser) 16.dp else 4.dp,
                bottomEnd = if (message.isUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (message.text.startsWith("[AI_VIDEO:")) {
                    val raw = message.text.removePrefix("[AI_VIDEO:").removeSuffix("]")
                    val parts = raw.split("|")
                    val vTitle = parts.getOrNull(0) ?: "🎬 AI Video"
                    val vScenes = parts.getOrNull(1)?.split(";") ?: listOf("सीन 1", "सीन 2", "सीन 3")
                    val vTheme = parts.getOrNull(2) ?: "AI Studio"

                    AiInlineVideoPlayerCard(
                        title = vTitle,
                        scenes = vScenes,
                        theme = vTheme,
                        onSpeakText = onSpeakText,
                        onOpenStudio = { onOpenVideoStudio?.invoke() }
                    )
                } else {
                    if (message.attachedImagePath != null) {
                        val file = File(message.attachedImagePath)
                        if (file.exists()) {
                            val bmp = BitmapFactory.decodeFile(file.absolutePath)
                            if (bmp != null) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "AI Image",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 240.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.dp, Color(0xFF3B4252), RoundedCornerShape(12.dp))
                                        .clickable {
                                            onOpenPhotoEditor?.invoke(bmp)
                                        }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }

                    Text(
                        text = message.text,
                        color = Color.White,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }

                // Multimodal Interactive Action Triggers in Bubble
                if (!message.isUser) {
                    val lower = message.text.lowercase()
                    if (message.text.contains("```") || lower.contains("python") || lower.contains("def ") || lower.contains("function") || lower.contains("class ")) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0C291E))
                                .clickable {
                                    val code = extractCodeBlock(message.text)
                                    val lang = if (lower.contains("html") || lower.contains("<!doctype")) "HTML/Web"
                                    else if (lower.contains("kotlin") || lower.contains("val ") || lower.contains("fun ")) "Kotlin"
                                    else if (lower.contains("javascript") || lower.contains("console.log")) "JavaScript"
                                    else "Python"
                                    onOpenCodeExecutor?.invoke(code, lang)
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("▶️ AI सैंडबॉक्स में चलाएं (Run Code)", color = EmeraldGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (lower.contains("photo") || lower.contains("filter") || lower.contains("फ़ोटो") || message.attachedImagePath != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF28182B))
                                .clickable {
                                    val bmp = message.attachedImagePath?.let { BitmapFactory.decodeFile(it) }
                                    onOpenPhotoEditor?.invoke(bmp)
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFF80AB), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("🎨 AI Photo Editor खोलें", color = Color(0xFFFF80AB), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (lower.contains("video") || lower.contains("reel") || lower.contains("shorts") || lower.contains("वीडियो")) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E1A4A))
                                .clickable {
                                    onOpenVideoStudio?.invoke()
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = TealAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("🎬 AI Video Studio खोलें", color = TealAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = Color(0xFF2C2C38), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // AI Disclaimer Tag
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "AI से गलतियाँ हो सकती है",
                                color = Color(0xFF94A3B8),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Copy Button
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("AI Response", message.text)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "उत्तर कॉपी हो गया 📋", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy text",
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(15.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            // Read aloud Button
                            IconButton(
                                onClick = { onSpeakText(message.text) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Read Aloud",
                                    tint = TealAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiInlineVideoPlayerCard(
    title: String,
    scenes: List<String>,
    theme: String,
    onSpeakText: (String) -> Unit,
    onOpenStudio: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var currentSceneIndex by remember { mutableStateOf(0) }

    LaunchedEffect(isPlaying, scenes) {
        if (isPlaying && scenes.isNotEmpty()) {
            while (true) {
                kotlinx.coroutines.delay(4000)
                currentSceneIndex = (currentSceneIndex + 1) % scenes.size
            }
        }
    }

    val currentSceneText = scenes.getOrElse(currentSceneIndex) { "🎬 AI दृश्य" }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = BorderStroke(1.dp, Color(0xFF334155)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Movie,
                        contentDescription = null,
                        tint = TealAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }

                Surface(
                    color = TealAccent.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "9:16 AI Reel",
                        color = TealAccent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Animated Video Canvas Frame
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        when (currentSceneIndex % 3) {
                            0 -> Color(0xFF1E293B)
                            1 -> Color(0xFF1E1B4B)
                            else -> Color(0xFF0F291E)
                        }
                    )
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = when {
                            theme.contains("बंदर") || theme.contains("monkey") -> "🐒"
                            theme.contains("शेर") || theme.contains("lion") -> "🦁"
                            theme.contains("कुत्ता") || theme.contains("dog") -> "🐕"
                            theme.contains("बिल्ली") || theme.contains("cat") -> "🐱"
                            theme.contains("कार") || theme.contains("car") -> "🏎️"
                            theme.contains("पहाड़") || theme.contains("mountain") -> "🏔️"
                            else -> "🎬"
                        },
                        fontSize = 44.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = currentSceneText,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 16.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines = 3
                    )
                }

                // Scene Indicator Badge
                Surface(
                    color = Color.Black.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                ) {
                    Text(
                        text = "सीन ${currentSceneIndex + 1}/${scenes.size}",
                        color = Color.White,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Player Controls Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { isPlaying = !isPlaying },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Close else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = TealAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = { onSpeakText(currentSceneText) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Voiceover",
                            tint = Color.LightGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                TextButton(
                    onClick = onOpenStudio,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("HD स्टूडियो में खोलें ↗", color = TealAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun extractCodeBlock(text: String): String {
    val regex = "```(?:[a-zA-Z]*\\n)?([\\s\\S]*?)```".toRegex()
    val match = regex.find(text)
    return match?.groupValues?.get(1)?.trim() ?: text
}

private fun createSampleDocumentBitmap(): Bitmap {
    val bitmap = Bitmap.createBitmap(800, 1000, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    return bitmap
}

@Composable
fun ThinkingIndicator(modelType: AiModelType) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(start = 8.dp)
    ) {
        CircularProgressIndicator(
            color = TealAccent,
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp
        )
        Text(
            text = "${modelType.displayName} सोच रहा है...",
            color = Color.Gray,
            fontSize = 12.sp
        )
    }
}

@Composable
fun AiHistoryDrawerPanel(
    sessions: List<AiChatSession>,
    activeSessionId: String?,
    isMultiDeleteMode: Boolean,
    selectedSessionIds: List<String>,
    onToggleMultiDeleteMode: () -> Unit,
    onSelectAll: () -> Unit,
    onToggleSelectSession: (String) -> Unit,
    onDeleteSelected: () -> Unit,
    onSelectSession: (AiChatSession) -> Unit,
    onNewChatClick: () -> Unit,
    onCloseDrawer: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable { onCloseDrawer() }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxHeight()
                .width(320.dp)
                .clickable(enabled = false) {}, // consume clicks
            color = Color(0xFF16161D)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "चैट इतिहास (History)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    IconButton(onClick = onCloseDrawer) {
                        Icon(Icons.Default.Close, contentDescription = "बंद करें", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // + New Chat Button
                Button(
                    onClick = onNewChatClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_new_chat_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("+ New Chat (नया चैट)", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Multi-Delete Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isMultiDeleteMode) "${selectedSessionIds.size} चुने गए" else "हालिया चैट्स (${sessions.size})",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row {
                        if (isMultiDeleteMode) {
                            IconButton(onClick = onSelectAll, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.SelectAll, contentDescription = "Select All", tint = TealAccent, modifier = Modifier.size(20.dp))
                            }
                            if (selectedSessionIds.isNotEmpty()) {
                                IconButton(onClick = onDeleteSelected, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Selected", tint = PdfRed, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                        IconButton(onClick = onToggleMultiDeleteMode, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = if (isMultiDeleteMode) Icons.Default.Check else Icons.Default.DeleteSweep,
                                contentDescription = "मल्टी-डिलीट मेन्यू",
                                tint = if (isMultiDeleteMode) TealAccent else Color.LightGray,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFF282835), modifier = Modifier.padding(vertical = 8.dp))

                // Sessions List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(sessions) { session ->
                        val isSelected = selectedSessionIds.contains(session.id)
                        val isActive = session.id == activeSessionId

                        Card(
                            onClick = {
                                if (isMultiDeleteMode) {
                                    onToggleSelectSession(session.id)
                                } else {
                                    onSelectSession(session)
                                }
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    isSelected -> TealAccent.copy(alpha = 0.25f)
                                    isActive -> Color(0xFF252535)
                                    else -> Color(0xFF1E1E26)
                                }
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isMultiDeleteMode) {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                                        contentDescription = null,
                                        tint = if (isSelected) TealAccent else Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = session.title,
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = session.previewText.ifBlank { "कोई संदेश नहीं" },
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = dateFormat.format(Date(session.updatedAt)),
                                        color = Color(0xFF707085),
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiveVoiceCallOverlay(
    modelType: AiModelType,
    ttsEngine: TextToSpeech?,
    onSendMessage: (String, Bitmap?) -> Unit,
    onCloseCall: () -> Unit
) {
    val context = LocalContext.current
    var isMuted by remember { mutableStateOf(false) }
    var callStatus by remember { mutableStateOf("Connected with ${modelType.displayName}...") }
    var speechInputText by remember { mutableStateOf("") }
    var isAiSpeaking by remember { mutableStateOf(false) }

    // Pulsing animation for audio waves
    val transition = rememberInfiniteTransition(label = "pulse")
    val waveScale by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave"
    )

    // Speech Recognizer setup
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    val recordAudioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startListening(context, onResult = { text ->
                speechInputText = text
                callStatus = "AI सुन रहा है: \"$text\""
                onSendMessage(text, null)
            })
        }
    }

    DisposableEffect(Unit) {
        val permission = Manifest.permission.RECORD_AUDIO
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            speechRecognizer = startListening(context, onResult = { text ->
                speechInputText = text
                callStatus = "AI विचार कर रहा है..."
                onSendMessage(text, null)
            })
        } else {
            recordAudioLauncher.launch(permission)
        }

        onDispose {
            speechRecognizer?.destroy()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F1016)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "🔴 Live AI Voice Call",
                    color = TealAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = modelType.displayName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = callStatus,
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }

            // Pulsing Audio Avatar in the Center
            Box(
                modifier = Modifier
                    .size(200.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Wave
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .scale(waveScale)
                        .background(TealAccent.copy(alpha = 0.15f), CircleShape)
                )

                // Middle Wave
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .scale(waveScale * 0.95f)
                        .background(TealAccent.copy(alpha = 0.3f), CircleShape)
                )

                // Inner glowing Circle
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(TealAccent, Color(0xFF00796B))
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Live Call",
                        tint = Color.Black,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            // Spoken transcript preview
            if (speechInputText.isNotBlank()) {
                Surface(
                    color = Color(0xFF1E1E2A),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "\"$speechInputText\"",
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Call Controls: Mute, End Call
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mute
                IconButton(
                    onClick = { isMuted = !isMuted },
                    modifier = Modifier
                        .size(56.dp)
                        .background(if (isMuted) PdfRed.copy(alpha = 0.3f) else Color(0xFF262634), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = if (isMuted) PdfRed else Color.White
                    )
                }

                // End Call Button
                IconButton(
                    onClick = {
                        speechRecognizer?.stopListening()
                        onCloseCall()
                    },
                    modifier = Modifier
                        .size(64.dp)
                        .background(PdfRed, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Speak reply test
                IconButton(
                    onClick = {
                        ttsEngine?.speak("नमस्ते! मैं आपकी बात सुन रहा हूँ। आप कोई भी सवाल पूछ सकते हैं।", TextToSpeech.QUEUE_FLUSH, null, "LIVE_CALL")
                    },
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color(0xFF262634), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Speaker",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

private fun startListening(context: Context, onResult: (String) -> Unit): SpeechRecognizer? {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return null
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
    }
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {}
        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!matches.isNullOrEmpty()) {
                onResult(matches[0])
            }
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    recognizer.startListening(intent)
    return recognizer
}

@Composable
fun BanLockoutScreen(
    remainingTimeText: String,
    onBack: () -> Unit,
    onDevReset: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF140D0D)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(PdfRed.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Banned",
                    tint = PdfRed,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "🚫 AI सुविधा अस्थायी रूप से बंद है",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "अभद्र या गाली-गलौज वाली भाषा का बार-बार उपयोग करने के कारण आपकी AI सेवा 24 घंटे के लिए ब्लॉक कर दी गई है।",
                color = Color(0xFFD0B0B0),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            Surface(
                color = Color(0xFF241515),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "शेष समय (Remaining Time):",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = remainingTimeText,
                        color = Color(0xFFFF8A80),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF33333E)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("वापस जाएँ (Go Back)", color = Color.White)
            }

            Spacer(modifier = Modifier.height(8.dp))

            TextButton(
                onClick = onDevReset,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("रीसेट करें (Reset Restriction)", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

private fun saveBitmapLocally(context: Context, bitmap: Bitmap): String {
    val dir = File(context.cacheDir, "ai_attachments")
    if (!dir.exists()) dir.mkdirs()
    val file = File(dir, "attach_${System.currentTimeMillis()}.jpg")
    val fos = FileOutputStream(file)
    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos)
    fos.flush()
    fos.close()
    return file.absolutePath
}

@Composable
fun StudioCarouselCard(
    title: String,
    description: String,
    buttonText: String,
    bgGradient: List<Color>,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(260.dp)
            .height(138.dp)
            .clickable { onAction() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(bgGradient))
                .padding(14.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = description,
                            color = Color(0xFFD0D0E0),
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onAction,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0265DC)),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text(buttonText, color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun StudioOutlineToolItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    hasCrown: Boolean,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    var isClickedActive by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val active = isSelected || isClickedActive
    val borderColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color.White,
        label = "studio_outline_border"
    )
    val bgColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFF280808) else Color(0xFF0F0F14),
        label = "studio_outline_bg"
    )
    val iconColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color.White,
        label = "studio_outline_icon"
    )
    val labelColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color(0xFFE0E0EA),
        label = "studio_outline_label"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .clickable {
                isClickedActive = true
                scope.launch {
                    kotlinx.coroutines.delay(350)
                    isClickedActive = false
                }
                onClick()
            }
    ) {
        Box(
            modifier = Modifier.size(54.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(bgColor, CircleShape)
                    .border(1.5.dp, borderColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            if (hasCrown) {
                Surface(
                    color = Color(0xFFFFB300),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(16.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Pro",
                            tint = Color.Black,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            color = labelColor,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 13.sp,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun GeminiSparkleStar(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        val path = Path().apply {
            moveTo(cx, 0f)
            cubicTo(cx * 1.06f, cy * 0.72f, cx * 1.28f, cy * 0.94f, w, cy)
            cubicTo(cx * 1.28f, cy * 1.06f, cx * 1.06f, cy * 1.28f, cx, h)
            cubicTo(cx * 0.94f, cy * 1.28f, cx * 0.72f, cy * 1.06f, 0f, cy)
            cubicTo(cx * 0.72f, cy * 0.94f, cx * 0.94f, cy * 0.72f, cx, 0f)
            close()
        }

        val brush = androidx.compose.ui.graphics.Brush.linearGradient(
            colors = listOf(
                Color(0xFF4285F4), // Blue
                Color(0xFF9C51B6), // Purple
                Color(0xFFEA4335), // Coral Red
                Color(0xFFFBBC04)  // Amber Yellow
            ),
            start = Offset(0f, 0f),
            end = Offset(w, h)
        )

        drawPath(path = path, brush = brush)
    }
}

@Composable
fun LiveAudioWaveform(
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val h1 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(450, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h1"
    )
    val h2 by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 0.4f,
        animationSpec = infiniteRepeatable(tween(550, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h2"
    )
    val h3 by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(480, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h3"
    )

    Row(
        modifier = modifier.height(18.dp),
        horizontalArrangement = Arrangement.spacedBy(2.5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.width(2.5.dp).fillMaxHeight(h1).background(color, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(2.5.dp).fillMaxHeight(h3).background(color, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(2.5.dp).fillMaxHeight(h2).background(color, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(2.5.dp).fillMaxHeight(h1).background(color, RoundedCornerShape(2.dp)))
    }
}
