package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.ScannedDocument
import com.example.data.util.GeminiOcrHelper
import com.example.ui.DocumentViewModel
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.PptOrange
import com.example.ui.theme.TealAccent
import com.example.ui.theme.VaultAmber
import com.example.ui.theme.WordBlue
import kotlinx.coroutines.launch
import java.util.Locale

data class SpaceDefinition(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val description: String,
    val tagKeywords: List<String>,
    val icon: ImageVector,
    val gradient: List<Color>,
    val defaultSummary: String
)

data class SpaceChatMessage(
    val sender: String,
    val message: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfSpacesScreen(
    viewModel: DocumentViewModel,
    onViewDocument: (ScannedDocument) -> Unit,
    onNavigateToScan: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val allDocs by viewModel.publicDocuments.collectAsState()

    // Default predefined spaces
    val predefinedSpaces = remember {
        listOf(
            SpaceDefinition(
                id = "history",
                titleHindi = "इतिहास एवं कला संस्कृति स्पेस",
                titleEnglish = "History & Culture Space",
                description = "प्राचीन भारत, पाषाण काल, पुरातात्विक साक्ष्य एवं नोट्स",
                tagKeywords = listOf("इतिहास", "पाषाण_काल", "Culture", "Notes", "History"),
                icon = Icons.Default.AccountBalance,
                gradient = listOf(Color(0xFF6B1D2F), Color(0xFF330C15)),
                defaultSummary = "यह स्पेस भारतीय इतिहास और पुरातात्विक साक्ष्यों (भीमबेटका, हथनोरा, लोहदनाला, पतणे) के बहु-दस्तावेज़ विश्लेषण पर केंद्रित है।"
            ),
            SpaceDefinition(
                id = "finance",
                titleHindi = "वित्तीय ऑडिट एवं रिपोर्ट्स",
                titleEnglish = "Finance & Audit Space",
                description = "वार्षिक बैलेंस शीट, राजस्व, खर्च और वित्तीय विश्लेषण",
                tagKeywords = listOf("Audit", "Finance", "Report", "बैलेंस", "Financial"),
                icon = Icons.Default.ReceiptLong,
                gradient = listOf(Color(0xFF133B36), Color(0xFF081C19)),
                defaultSummary = "इस स्पेस में संगठन के वार्षिक वित्तीय आंकड़े, ऑडिट रिपोर्ट और लाभ-हानि का संयुक्त तुलनात्मक डेटाबेस उपलब्ध है।"
            ),
            SpaceDefinition(
                id = "legal",
                titleHindi = "कानूनी अनुबंध एवं लीगल स्पेस",
                titleEnglish = "Legal & Contracts Space",
                description = "किराया समझौता, डीड, एग्रीमेंट्स और कानूनी शर्तें",
                tagKeywords = listOf("Legal", "Lease", "Agreement", "किराया", "अनुबंध"),
                icon = Icons.Default.Gavel,
                gradient = listOf(Color(0xFF281C44), Color(0xFF140D24)),
                defaultSummary = "इस स्पेस में सभी कानूनी अनुबंध, लीज शर्तें, लॉक-इन अवधि और एग्रीमेंट दस्तावेजों का कानूनी विश्लेषण किया जाता है।"
            ),
            SpaceDefinition(
                id = "exam",
                titleHindi = "UPSC व परीक्षा तैयारी स्पेस",
                titleEnglish = "UPSC & Exam Prep Space",
                description = "सभी विषयों के नोट्स, टेस्ट सीरीज़ और क्विज़ सामग्री",
                tagKeywords = listOf("Exams", "UPSC", "Notes", "Test", "Quiz"),
                icon = Icons.Default.School,
                gradient = listOf(Color(0xFF1E2B58), Color(0xFF0D1429)),
                defaultSummary = "प्रतियोगी परीक्षाओं की तैयारी के लिए बहु-दस्तावेज़ अध्ययन सामग्री, मॉक टेस्ट और त्वरित रिवीजन नोट्स।"
            ),
            SpaceDefinition(
                id = "research",
                titleHindi = "अनुसंधान एवं परियोजना स्पेस",
                titleEnglish = "Research & Projects Space",
                description = "शोध पत्र, तकनीकी रिपोर्ट्स और प्रोजेक्ट्स",
                tagKeywords = listOf("Research", "Project", "PPT", "Word"),
                icon = Icons.Default.Science,
                gradient = listOf(Color(0xFF4A154B), Color(0xFF240A25)),
                defaultSummary = "सभी तकनीकी और शैक्षणिक शोध पत्रों का समग्र ज्ञानकोष और तुलनात्मक विश्लेषण।"
            )
        )
    }

    var customSpaces = remember { mutableStateListOf<SpaceDefinition>() }
    val allSpaces = predefinedSpaces + customSpaces

    var selectedSpaceId by remember { mutableStateOf(predefinedSpaces.first().id) }
    val currentSpace = allSpaces.find { it.id == selectedSpaceId } ?: predefinedSpaces.first()

    // Filter documents matching current space's keywords
    val spaceDocs = allDocs.filter { doc ->
        val docTags = doc.tagList.joinToString(" ")
        val title = doc.title
        currentSpace.tagKeywords.any { kw ->
            docTags.contains(kw, ignoreCase = true) || title.contains(kw, ignoreCase = true)
        }
    }

    // AI Chat state for current space
    val chatMessages = remember(selectedSpaceId) {
        mutableStateListOf(
            SpaceChatMessage(
                sender = "Space AI",
                message = "👋 स्वागत है **${currentSpace.titleHindi}** में!\n" +
                        "मैंने इस स्पेस के सभी **${spaceDocs.size} दस्तावेज़ों (${spaceDocs.sumOf { it.pageCount }} पृष्ठ)** का क्रॉस-डॉक्यूमेंट इंडेक्स तैयार कर लिया है।\n" +
                        "आप मुझसे किसी भी विषय पर तुलना, समग्र सारांश या परीक्षा क्विज़ पूछ सकते हैं।",
                isUser = false
            )
        )
    }

    var userQueryText by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }

    // Dialog states
    var showAddDocBottomSheet by remember { mutableStateOf(false) }
    var showCreateSpaceDialog by remember { mutableStateOf(false) }
    var newSpaceName by remember { mutableStateOf("") }
    var newSpaceDesc by remember { mutableStateOf("") }
    var newSpaceKeywords by remember { mutableStateOf("") }

    // TTS & Speech Recognition
    var tts: TextToSpeech? by remember { mutableStateOf(null) }
    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
        onDispose {
            tts?.stop()
            tts?.shutdown()
        }
    }

    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                userQueryText = spokenText
            }
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "पूरे स्पेस से संबंधित सवाल पूछें...")
            }
            try {
                speechRecognizerLauncher.launch(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "वॉइस इनपुट प्रारंभ नहीं हो सका", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "माइक अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    val sendSpaceQuery: (String) -> Unit = { query ->
        if (query.isNotBlank() && !isThinking) {
            chatMessages.add(SpaceChatMessage("You", query, true))
            userQueryText = ""
            isThinking = true

            coroutineScope.launch {
                val docContext = if (spaceDocs.isNotEmpty()) {
                    spaceDocs.joinToString("\n---\n") { d ->
                        "दस्तावेज़: ${d.title} (Pages: ${d.pageCount})\nसामग्री: ${d.extractedText.take(1500)}"
                    }
                } else {
                    "दस्तावेज़: ${currentSpace.titleHindi} - ${currentSpace.description}"
                }

                val aiReply = GeminiOcrHelper.askMultiModelAi(
                    prompt = "Space: ${currentSpace.titleEnglish}\nQuery: $query\nCross-Doc Documents:\n$docContext",
                    modelType = "GEMINI",
                    contextDocTitle = "PDF Space: ${currentSpace.titleEnglish}"
                )

                chatMessages.add(SpaceChatMessage("Space AI", aiReply, false))
                isThinking = false
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0C0F))
            .padding(bottom = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // 1. Top Header & Title
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "PDF Spaces",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = Color(0xFFFA0F00).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFFA0F00).copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "PRO AI",
                                color = Color(0xFFFF5252),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "मल्टी-डॉक्यूमेंट AI नॉलेज हब और क्रॉस-डॉक एनालिसिस",
                        color = Color(0xFFA0A0AB),
                        fontSize = 12.sp
                    )
                }

                Button(
                    onClick = { showCreateSpaceDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E1E26)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFF333342)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New Space", tint = TealAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ नया स्पेस", color = Color.White, fontSize = 12.sp)
                }
            }
        }

        // 2. Spaces Carousel / Selector
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(allSpaces) { space ->
                    val isSelected = space.id == selectedSpaceId
                    Surface(
                        onClick = { selectedSpaceId = space.id },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) Color(0xFF1F1F2B) else Color(0xFF14141A),
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) Color(0xFFFA0F00) else Color(0xFF262632)
                        ),
                        modifier = Modifier.width(170.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        brush = Brush.linearGradient(space.gradient),
                                        shape = RoundedCornerShape(10.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = space.icon,
                                    contentDescription = space.titleEnglish,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = space.titleHindi,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = space.titleEnglish,
                                color = Color(0xFF888894),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // 3. Active Space Banner & Stats Card
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(brush = Brush.linearGradient(currentSpace.gradient))
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .background(Color.White.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(currentSpace.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = currentSpace.titleHindi,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${spaceDocs.size} दस्तावेज़ • ${spaceDocs.sumOf { it.pageCount }} पन्ने • AI सिंक सक्रिय",
                                        color = Color.White.copy(alpha = 0.8f),
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = currentSpace.description,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Space Quick Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    sendSpaceQuery("इस स्पेस के सभी दस्तावेजों का विस्तृत तुलनात्मक और संयुक्त सारांश (Executive Summary) प्रस्तुत करें।")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("समग्र सारांश", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    sendSpaceQuery("इस स्पेस के सभी दस्तावेज़ों से संबंधित 10 सबसे महत्वपूर्ण परीक्षा प्रश्न (MCQs) और उत्तर बनाएं।")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Quiz, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("स्पेस क्विज़", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    val summaryText = chatMessages.lastOrNull { !it.isUser }?.message ?: currentSpace.defaultSummary
                                    viewModel.createSpaceExportPdf(currentSpace.titleEnglish, summaryText) { savedDoc ->
                                        Toast.makeText(context, "Space PDF रिपोर्ट तैयार: ${savedDoc.title}", Toast.LENGTH_LONG).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("PDF रिपोर्ट", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 4. Documents Section in this Space
        item {
            Spacer(modifier = Modifier.height(18.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "इस स्पेस के दस्तावेज़ (${spaceDocs.size})",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                TextButton(
                    onClick = { showAddDocBottomSheet = true },
                    contentPadding = PaddingValues(horizontal = 6.dp)
                ) {
                    Icon(Icons.Default.AddCircleOutline, contentDescription = null, tint = TealAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ दस्तावेज़ जोड़ें", color = TealAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (spaceDocs.isEmpty()) {
            item {
                Surface(
                    color = Color(0xFF14141A),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFF242430)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = Color(0xFF6B6B78), modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("इस स्पेस में अभी कोई दस्तावेज़ नहीं है", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("नीचे दिए गए बटन से अपने किसी भी PDF को इस स्पेस में जोड़ें", color = Color.Gray, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { showAddDocBottomSheet = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFA0F00)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+ PDF शामिल करें", fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            items(spaceDocs) { doc ->
                Surface(
                    color = Color(0xFF16161D),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFF262632)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFFA0F00).copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFFA0F00), modifier = Modifier.size(22.dp))
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = doc.title,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${doc.pageCount} पृष्ठ • ${doc.fileSizeFormatted} • ${doc.formattedDate}",
                                color = Color(0xFFA0A0AB),
                                fontSize = 11.sp
                            )
                        }

                        // Open Document Button
                        IconButton(
                            onClick = { onViewDocument(doc) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = "View", tint = TealAccent, modifier = Modifier.size(18.dp))
                        }

                        // Remove from space tag
                        IconButton(
                            onClick = {
                                viewModel.removeDocumentFromSpace(doc.id, currentSpace.tagKeywords.first())
                                Toast.makeText(context, "स्पेस से हटाया गया", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Remove", tint = Color(0xFF888894), modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        // 5. Cross-Document Space AI Chat Engine
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, tint = TealAccent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "क्रॉस-डॉक्यूमेंट Space AI इंजन",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Prompt Chips Row
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val spacePrompts = listOf(
                    "📊 तुलनात्मक विश्लेषण" to "इस स्पेस के सभी दस्तावेजों का तुलनात्मक चार्ट और मुख्य समानताएं/अंतर बताएं।",
                    "🎯 10 परीक्षा प्रश्न" to "इस स्पेस के सभी पाठों से मिलाकर 10 सबसे महत्वपूर्ण परीक्षा प्रश्न (MCQs) व उत्तर स्पष्टीकरण सहित दें।",
                    "💡 मुख्य तथ्य व आंकड़े" to "स्पेस के सभी दस्तावेजों में उपस्थित मुख्य तिथियों, नामों, स्थानों और आंकड़ों की सूची दें।",
                    "🔍 विरोधाभास जाँच" to "क्या इन दस्तावेजों में किसी तथ्य या आंकड़े को लेकर कोई मतभेद अथवा विभिन्न मत दिए गए हैं?",
                    "🌐 English Synthesis" to "Provide an integrated high-level executive briefing in English synthesizing all documents.",
                    "👶 सरल भाषा में समझाइए" to "इस पूरे स्पेस के ज्ञान को बहुत ही सरल, रोचक और आसान भाषा में समझाएं।"
                )
                items(spacePrompts) { (label, prompt) ->
                    Surface(
                        color = Color(0xFF1E1E28),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color(0xFF333344)),
                        modifier = Modifier.clickable {
                            sendSpaceQuery(prompt)
                        }
                    ) {
                        Text(
                            text = label,
                            color = Color(0xFFE2E2E8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // 6. Chat Messages in Space
        items(chatMessages) { msg ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                contentAlignment = if (msg.isUser) Alignment.CenterEnd else Alignment.CenterStart
            ) {
                Surface(
                    color = if (msg.isUser) Color(0xFF1E3A8A) else Color(0xFF16161E),
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (msg.isUser) 16.dp else 4.dp,
                        bottomEnd = if (msg.isUser) 4.dp else 16.dp
                    ),
                    border = BorderStroke(1.dp, if (msg.isUser) Color(0xFF2563EB) else Color(0xFF282836)),
                    modifier = Modifier.fillMaxWidth(0.92f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (msg.isUser) "आप (You)" else "✨ ${currentSpace.titleEnglish} AI",
                                color = if (msg.isUser) Color(0xFF93C5FD) else TealAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = msg.message,
                            color = Color.White,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )

                        if (!msg.isUser) {
                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = Color(0xFF282836), thickness = 0.5.dp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Copy
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Space AI", msg.message))
                                        Toast.makeText(context, "उत्तर कॉपी हो गया 📋", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color.LightGray, modifier = Modifier.size(15.dp))
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                // Share
                                IconButton(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_TEXT, msg.message)
                                        }
                                        context.startActivity(Intent.createChooser(intent, "स्पेस उत्तर शेयर करें"))
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.LightGray, modifier = Modifier.size(15.dp))
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                // TTS Read
                                IconButton(
                                    onClick = {
                                        tts?.speak(msg.message.replace("#", "").replace("*", ""), TextToSpeech.QUEUE_FLUSH, null, "SpaceTTS")
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "TTS", tint = TealAccent, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (isThinking) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = TealAccent)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "सभी दस्तावेज़ों का गहन क्रॉस-एनालिसिस हो रहा है...",
                        color = TealAccent,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // 7. Bottom Input Bar
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                color = Color(0xFF14141B),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFF2B2B38)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = userQueryText,
                        onValueChange = { userQueryText = it },
                        placeholder = { Text("इस स्पेस से कुछ भी पूछें...", color = Color(0xFF7A7A8A), fontSize = 13.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("space_ai_query_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true
                    )

                    // Voice Input Button
                    IconButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "पूरे स्पेस से संबंधित सवाल पूछें...")
                                }
                                try {
                                    speechRecognizerLauncher.launch(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "वॉइस इनपुट प्रारंभ नहीं हो सका", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice Query", tint = TealAccent)
                    }

                    // Send Button
                    IconButton(
                        onClick = { sendSpaceQuery(userQueryText) },
                        enabled = userQueryText.isNotBlank() && !isThinking,
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                color = if (userQueryText.isNotBlank() && !isThinking) Color(0xFFFA0F00) else Color(0xFF2E2E38),
                                shape = CircleShape
                            )
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------
    // Add Document to Space Bottom Sheet
    // -------------------------------------------------------------
    if (showAddDocBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddDocBottomSheet = false },
            containerColor = Color(0xFF16161B),
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp)
            ) {
                Text(
                    text = "${currentSpace.titleHindi} में दस्तावेज़ जोड़ें",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "नीचे दिए गए दस्तावेज़ों में से चुनें:",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                LazyColumn(modifier = Modifier.fillMaxWidth().height(320.dp)) {
                    items(allDocs) { doc ->
                        val isAlreadyInSpace = spaceDocs.any { it.id == doc.id }
                        Surface(
                            color = if (isAlreadyInSpace) Color(0xFF1E2822) else Color(0xFF1E1E26),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (isAlreadyInSpace) EmeraldGreen else Color(0xFF333340)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    if (!isAlreadyInSpace) {
                                        viewModel.addDocumentToSpace(doc.id, currentSpace.tagKeywords.first())
                                        Toast.makeText(context, "'${doc.title}' स्पेस में जोड़ा गया ✅", Toast.LENGTH_SHORT).show()
                                        showAddDocBottomSheet = false
                                    } else {
                                        Toast.makeText(context, "यह दस्तावेज़ पहले से इस स्पेस में है", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = if (isAlreadyInSpace) EmeraldGreen else PdfRed)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(doc.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                                    Text("${doc.pageCount} पृष्ठ • ${doc.fileSizeFormatted}", color = Color.Gray, fontSize = 11.sp)
                                }
                                if (isAlreadyInSpace) {
                                    Text("शामिल है", color = EmeraldGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Text("+ जोड़ें", color = TealAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------
    // Create New Custom Space Dialog
    // -------------------------------------------------------------
    if (showCreateSpaceDialog) {
        AlertDialog(
            onDismissRequest = { showCreateSpaceDialog = false },
            title = { Text("नया PDF Space बनाएं") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newSpaceName,
                        onValueChange = { newSpaceName = it },
                        label = { Text("स्पेस का नाम (e.g., कॉलेज प्रोजेक्ट्स)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newSpaceDesc,
                        onValueChange = { newSpaceDesc = it },
                        label = { Text("विवरण (Description)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newSpaceKeywords,
                        onValueChange = { newSpaceKeywords = it },
                        label = { Text("टैग कीवर्ड्स (e.g. #Project,#Notes)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newSpaceName.isNotBlank()) {
                            val newSpace = SpaceDefinition(
                                id = "custom_${System.currentTimeMillis()}",
                                titleHindi = newSpaceName,
                                titleEnglish = newSpaceName,
                                description = newSpaceDesc.ifBlank { "कस्टम यूजर स्पेस" },
                                tagKeywords = if (newSpaceKeywords.isNotBlank()) newSpaceKeywords.split(",") else listOf(newSpaceName),
                                icon = Icons.Default.Folder,
                                gradient = listOf(Color(0xFF2C3E50), Color(0xFF1A252F)),
                                defaultSummary = "नया स्पेस सफलतापूर्वक निर्मित किया गया।"
                            )
                            customSpaces.add(newSpace)
                            selectedSpaceId = newSpace.id
                            showCreateSpaceDialog = false
                            newSpaceName = ""
                            newSpaceDesc = ""
                            newSpaceKeywords = ""
                            Toast.makeText(context, "नया Space बनाया गया! 🎉", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFA0F00))
                ) {
                    Text("स्पेस बनाएं")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateSpaceDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}
