package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.util.PdfGenerator
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class TemplateType(val title: String, val subtitle: String, val icon: ImageVector) {
    INVOICE("Tax Invoice / बिल", "Professional GST/Business Invoice", Icons.Default.ReceiptLong),
    ASSIGNMENT_COVER("Assignment Cover Page", "College / School front sheet", Icons.Default.Assignment),
    CERTIFICATE("Certificate / प्रमाण पत्र", "Achievement & completion award", Icons.Default.CardMembership),
    FORMAL_LETTER("Formal Notice / Letter", "Official memo or letterhead", Icons.Default.Description)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DocumentTemplateDialog(
    onPdfGenerated: (File, String) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    var selectedTemplate by remember { mutableStateOf(TemplateType.INVOICE) }

    // Invoice Form Fields
    val todayDate = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()) }
    var invNumber by remember { mutableStateOf("INV-${(1000..9999).random()}") }
    var businessName by remember { mutableStateOf("Apex Tech Solutions Pvt Ltd") }
    var customerName by remember { mutableStateOf("Rahul Sharma") }
    var item1Name by remember { mutableStateOf("Web Development & Design Services") }
    var item1Price by remember { mutableStateOf("15000") }
    var item2Name by remember { mutableStateOf("Cloud Hosting & Maintenance (1 Yr)") }
    var item2Price by remember { mutableStateOf("3500") }
    var taxPercent by remember { mutableStateOf("18") }
    var invNotes by remember { mutableStateOf("Thank you for your business! Payment due within 15 days via UPI/Bank Transfer.") }

    // Assignment Form Fields
    var institutionName by remember { mutableStateOf("National Institute of Technology") }
    var assignmentTitle by remember { mutableStateOf("Artificial Intelligence & Machine Learning Project") }
    var subjectName by remember { mutableStateOf("Computer Science Engineering (CS-402)") }
    var studentName by remember { mutableStateOf("Priya Verma") }
    var rollNo by remember { mutableStateOf("2024CS1098") }
    var semester by remember { mutableStateOf("6th Semester (B.Tech)") }
    var facultyName by remember { mutableStateOf("Dr. Rajesh Kumar (HOD)") }

    // Certificate Form Fields
    var certRecipient by remember { mutableStateOf("Aman Gupta") }
    var certTitle by remember { mutableStateOf("Certificate of Excellence") }
    var certReason by remember { mutableStateOf("For outstanding performance and successful completion of Android App Development Masterclass 2026.") }
    var certOrg by remember { mutableStateOf("DocuScan AI Academy & Digital India") }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0A0A0A)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismissRequest) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "PDF Template Creator (टेम्पलेट से PDF)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Instant professional invoices, coversheets & certificates",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // Template Selector Chips
                    Text(
                        text = "SELECT TEMPLATE (टेम्पलेट चुनें)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFA0F00),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TemplateType.values().forEach { tmpl ->
                            val isSelected = selectedTemplate == tmpl
                            Surface(
                                onClick = { selectedTemplate = tmpl },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(0xFFFA0F00) else Color(0xFF181818),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) Color(0xFFFA0F00) else Color(0xFF2A2A2A)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = tmpl.icon,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else Color.LightGray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = tmpl.title,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) Color.White else Color.LightGray
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Form based on selection
                    when (selectedTemplate) {
                        TemplateType.INVOICE -> {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242424))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("INVOICE DETAILS", color = Color(0xFFFA0F00), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    Row(modifier = Modifier.fillMaxWidth()) {
                                        TemplateTextField(
                                            value = invNumber,
                                            onValueChange = { invNumber = it },
                                            label = "Invoice #",
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        TemplateTextField(
                                            value = taxPercent,
                                            onValueChange = { taxPercent = it },
                                            label = "GST/Tax %",
                                            modifier = Modifier.weight(0.7f)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = businessName,
                                        onValueChange = { businessName = it },
                                        label = "From (Your Company / Shop Name)",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = customerName,
                                        onValueChange = { customerName = it },
                                        label = "Billed To (Client / Customer)",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text("ITEM 1", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Row(modifier = Modifier.fillMaxWidth()) {
                                        TemplateTextField(
                                            value = item1Name,
                                            onValueChange = { item1Name = it },
                                            label = "Description",
                                            modifier = Modifier.weight(2f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        TemplateTextField(
                                            value = item1Price,
                                            onValueChange = { item1Price = it },
                                            label = "Price (₹)",
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("ITEM 2", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Row(modifier = Modifier.fillMaxWidth()) {
                                        TemplateTextField(
                                            value = item2Name,
                                            onValueChange = { item2Name = it },
                                            label = "Description",
                                            modifier = Modifier.weight(2f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        TemplateTextField(
                                            value = item2Price,
                                            onValueChange = { item2Price = it },
                                            label = "Price (₹)",
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = invNotes,
                                        onValueChange = { invNotes = it },
                                        label = "Notes / Payment Info",
                                        modifier = Modifier.fillMaxWidth(),
                                        minLines = 2
                                    )
                                }
                            }
                        }

                        TemplateType.ASSIGNMENT_COVER -> {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242424))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("ASSIGNMENT & COLLEGE DETAILS", color = Color(0xFF2196F3), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    TemplateTextField(
                                        value = institutionName,
                                        onValueChange = { institutionName = it },
                                        label = "School / College / University Name",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = assignmentTitle,
                                        onValueChange = { assignmentTitle = it },
                                        label = "Project / Topic Title",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = subjectName,
                                        onValueChange = { subjectName = it },
                                        label = "Subject Name & Code",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(modifier = Modifier.fillMaxWidth()) {
                                        TemplateTextField(
                                            value = studentName,
                                            onValueChange = { studentName = it },
                                            label = "Student Name",
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        TemplateTextField(
                                            value = rollNo,
                                            onValueChange = { rollNo = it },
                                            label = "Roll No / ID",
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(modifier = Modifier.fillMaxWidth()) {
                                        TemplateTextField(
                                            value = semester,
                                            onValueChange = { semester = it },
                                            label = "Class / Semester",
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        TemplateTextField(
                                            value = facultyName,
                                            onValueChange = { facultyName = it },
                                            label = "Submitted To (Teacher)",
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }

                        TemplateType.CERTIFICATE -> {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242424))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("CERTIFICATE OF COMPLETION", color = Color(0xFFFFB300), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    TemplateTextField(
                                        value = certOrg,
                                        onValueChange = { certOrg = it },
                                        label = "Issuing Organization / Company",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = certTitle,
                                        onValueChange = { certTitle = it },
                                        label = "Certificate Title",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = certRecipient,
                                        onValueChange = { certRecipient = it },
                                        label = "Recipient Full Name (प्रमाणित नाम)",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = certReason,
                                        onValueChange = { certReason = it },
                                        label = "Achievement / Completion Description",
                                        modifier = Modifier.fillMaxWidth(),
                                        minLines = 3
                                    )
                                }
                            }
                        }

                        TemplateType.FORMAL_LETTER -> {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242424))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("FORMAL LETTER & MEMO", color = Color(0xFF00BFA5), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    TemplateTextField(
                                        value = businessName,
                                        onValueChange = { businessName = it },
                                        label = "Organization / Sender Header",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = "Subject: Official Resignation & Handover Notice",
                                        onValueChange = { },
                                        label = "Subject Line",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TemplateTextField(
                                        value = "Dear Management,\n\nPlease accept this letter as formal notification that I am submitting my formal handover. I appreciate the opportunities provided during my tenure.\n\nSincerely,\nRahul Sharma",
                                        onValueChange = { },
                                        label = "Body Content",
                                        modifier = Modifier.fillMaxWidth(),
                                        minLines = 4
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Action Button
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF121212),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242424))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                val generatedFile: File = when (selectedTemplate) {
                                    TemplateType.INVOICE -> {
                                        val p1 = item1Price.toDoubleOrNull() ?: 0.0
                                        val p2 = item2Price.toDoubleOrNull() ?: 0.0
                                        val tax = taxPercent.toDoubleOrNull() ?: 18.0
                                        PdfGenerator.createInvoicePdf(
                                            context = context,
                                            invoiceNumber = invNumber,
                                            businessName = businessName,
                                            customerName = customerName,
                                            date = todayDate,
                                            items = listOf(item1Name to p1, item2Name to p2),
                                            taxRatePercent = tax,
                                            notes = invNotes
                                        )
                                    }
                                    TemplateType.ASSIGNMENT_COVER -> {
                                        PdfGenerator.createAssignmentCoverPdf(
                                            context = context,
                                            institutionName = institutionName,
                                            projectTitle = assignmentTitle,
                                            subjectName = subjectName,
                                            submittedBy = studentName,
                                            rollNumber = rollNo,
                                            semester = semester,
                                            submittedTo = facultyName,
                                            date = todayDate
                                        )
                                    }
                                    TemplateType.CERTIFICATE -> {
                                        PdfGenerator.createCertificatePdf(
                                            context = context,
                                            recipientName = certRecipient,
                                            certificateTitle = certTitle,
                                            reason = certReason,
                                            issuingOrganization = certOrg,
                                            date = todayDate
                                        )
                                    }
                                    TemplateType.FORMAL_LETTER -> {
                                        PdfGenerator.createInvoicePdf(
                                            context = context,
                                            invoiceNumber = "LTR-01",
                                            businessName = businessName,
                                            customerName = "HR Department",
                                            date = todayDate,
                                            items = listOf("Notice Period Consultation" to 0.0),
                                            taxRatePercent = 0.0,
                                            notes = "Official Notice Memo"
                                        )
                                    }
                                }
                                val title = when (selectedTemplate) {
                                    TemplateType.INVOICE -> "Invoice_$invNumber"
                                    TemplateType.ASSIGNMENT_COVER -> "Cover_$assignmentTitle"
                                    TemplateType.CERTIFICATE -> "Certificate_$certRecipient"
                                    TemplateType.FORMAL_LETTER -> "Formal_Notice"
                                }
                                onPdfGenerated(generatedFile, title)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFA0F00)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("PDF बनाएं और सेव करें (Generate PDF)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TemplateTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.sp) },
        minLines = minLines,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFFA0F00),
            unfocusedBorderColor = Color(0xFF333333),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedLabelColor = Color(0xFFFA0F00),
            unfocusedLabelColor = Color.Gray,
            cursorColor = Color(0xFFFA0F00)
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    )
}
