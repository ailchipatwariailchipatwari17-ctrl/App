package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.CompressionLevel
import com.example.data.model.DocumentCategory
import com.example.data.model.MasterPdfTool
import com.example.data.model.MasterPdfToolsCatalog
import com.example.data.model.ILoveToolItem
import com.example.data.model.ILoveToolsCatalog
import com.example.data.model.ToolMainType
import com.example.data.model.PdfAppSuite
import com.example.data.model.ScannedDocument
import com.example.data.util.PdfGenerator
import com.example.ui.DocumentViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.AppDisplayMode
import com.example.util.AppLanguage
import com.example.util.AppModeManager
import com.example.util.AppThemeManager
import com.example.util.AppThemePalette
import com.example.util.LanguageManager
import com.example.util.ThemeSelectionDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: DocumentViewModel,
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onNavigateToScanEditor: () -> Unit,
    onNavigateToOcrDigitizer: (Boolean) -> Unit,
    onNavigateToSecuritySettings: () -> Unit,
    onNavigateToAi: () -> Unit,
    onViewDocument: (ScannedDocument) -> Unit
) {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        AppModeManager.init(context)
    }
    val currentAppMode by AppModeManager.displayModeFlow.collectAsStateWithLifecycle()
    val isDesktopActive = AppModeManager.isDesktopModeActive()
    var showModeSelectionSheet by remember { mutableStateOf(false) }
    var showBlankPdfCreatorDialog by remember { mutableStateOf(false) }

    val currentPalette by AppThemeManager.currentPaletteFlow.collectAsStateWithLifecycle()
    var showThemeDialog by remember { mutableStateOf(false) }
    val publicDocs by viewModel.publicDocuments.collectAsStateWithLifecycle()
    val vaultDocs by viewModel.vaultDocuments.collectAsStateWithLifecycle()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsStateWithLifecycle()
    val activeCategoryFilter by viewModel.activeCategoryFilter.collectAsStateWithLifecycle()

    val trashDocs by viewModel.trashDocuments.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var isVaultTabSelected by remember { mutableStateOf(false) }
    var showUnlockVaultDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var showImportMenuDialog by remember { mutableStateOf(false) }
    var selectedBottomTab by remember { mutableStateOf(0) } // 0: Home, 1: Create, 2: AI, 3: Files, 4: Tools
    var toolsCategoryFilter by remember { mutableStateOf("All") }

    // Dialog & ID Card States
    var showMergeSplitDialog by remember { mutableStateOf(false) }
    var showIdCardDialog by remember { mutableStateOf(false) }
    var showQrScannerDialog by remember { mutableStateOf(false) }
    var showTrashDialog by remember { mutableStateOf(false) }

    // Advanced Utility Dialog States
    var showMetaAiDialog by remember { mutableStateOf(false) }
    var showPdfRepairDialog by remember { mutableStateOf(false) }
    var showPdfCompareDialog by remember { mutableStateOf(false) }
    var showHandwritingDialog by remember { mutableStateOf(false) }
    var showOmrScannerDialog by remember { mutableStateOf(false) }
    var showFormulaExtractorDialog by remember { mutableStateOf(false) }
    var showPodcastDialog by remember { mutableStateOf(false) }

    var selectedDocumentForPodcast by remember { mutableStateOf<ScannedDocument?>(null) }
    var selectedDocumentForQuiz by remember { mutableStateOf<ScannedDocument?>(null) }
    var showQuizDialog by remember { mutableStateOf(false) }
    var selectedDocumentForWatermark by remember { mutableStateOf<ScannedDocument?>(null) }
    var showWatermarkDialog by remember { mutableStateOf(false) }
    var selectedDocumentForAudioNote by remember { mutableStateOf<ScannedDocument?>(null) }
    var showAudioNoteDialog by remember { mutableStateOf(false) }

    var showTemplateDialog by remember { mutableStateOf(false) }
    var selectedDocumentForImageExport by remember { mutableStateOf<ScannedDocument?>(null) }
    var showPdfToImageDialog by remember { mutableStateOf(false) }
    var selectedDocumentForOrganizer by remember { mutableStateOf<ScannedDocument?>(null) }
    var showPdfOrganizerDialog by remember { mutableStateOf(false) }
    var selectedDocumentForTranslate by remember { mutableStateOf<ScannedDocument?>(null) }
    var showPdfTranslateDialog by remember { mutableStateOf(false) }
    var selectedDocumentForProtect by remember { mutableStateOf<ScannedDocument?>(null) }
    var showPdfProtectDialog by remember { mutableStateOf(false) }

    var docToShare by remember { mutableStateOf<ScannedDocument?>(null) }
    var showShareExportDialog by remember { mutableStateOf(false) }
    var docForOptionsSheet by remember { mutableStateOf<ScannedDocument?>(null) }
    var docToRename by remember { mutableStateOf<ScannedDocument?>(null) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var renameInputText by remember { mutableStateOf("") }

    var idCardFrontBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var idCardBackBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var pendingToolAction by remember { mutableStateOf<ToolActionType?>(null) }
    var showSelectDocumentForToolDialog by remember { mutableStateOf(false) }

    fun executeToolWithDocument(toolType: ToolActionType, doc: ScannedDocument) {
        when (toolType) {
            ToolActionType.WATERMARK -> {
                selectedDocumentForWatermark = doc
                showWatermarkDialog = true
            }
            ToolActionType.EDIT_PDF -> {
                onViewDocument(doc)
                Toast.makeText(context, "दस्तावेज़ में टेक्स्ट, ड्रॉइंग और हस्ताक्षर जोड़ने के लिए एडिटिंग टूल बार का उपयोग करें", Toast.LENGTH_SHORT).show()
            }
            ToolActionType.CONVERT_TO_IMAGES -> {
                selectedDocumentForImageExport = doc
                showPdfToImageDialog = true
            }
            ToolActionType.ORGANIZE_PAGES -> {
                selectedDocumentForOrganizer = doc
                showPdfOrganizerDialog = true
            }
            ToolActionType.TRANSLATE -> {
                selectedDocumentForTranslate = doc
                showPdfTranslateDialog = true
            }
            ToolActionType.PODCAST -> {
                selectedDocumentForPodcast = doc
                showPodcastDialog = true
            }
            ToolActionType.QUIZ -> {
                selectedDocumentForQuiz = doc
                showQuizDialog = true
            }
            ToolActionType.AUDIO_NOTE -> {
                selectedDocumentForAudioNote = doc
                showAudioNoteDialog = true
            }
            ToolActionType.PROTECT -> {
                selectedDocumentForProtect = doc
                showPdfProtectDialog = true
            }
            ToolActionType.COMPRESS -> {
                onViewDocument(doc)
                Toast.makeText(context, "PDF व्यूअर में 'Export' से कंप्रेशन चुनें", Toast.LENGTH_SHORT).show()
            }
            ToolActionType.READ_ALOUD -> {
                onViewDocument(doc)
            }
            ToolActionType.EXPORT_SHARE -> {
                docToShare = doc
                showShareExportDialog = true
            }
        }
    }

    fun triggerToolWithDocumentPicker(toolType: ToolActionType) {
        val allDocs = publicDocs + vaultDocs
        if (allDocs.size == 1) {
            executeToolWithDocument(toolType, allDocs.first())
        } else {
            pendingToolAction = toolType
            showSelectDocumentForToolDialog = true
        }
    }

    val languageManager = remember { LanguageManager(context) }
    val currentLangCode by LanguageManager.currentLanguageFlow.collectAsStateWithLifecycle()
    val selectedLanguage = remember(currentLangCode) { languageManager.getSelectedLanguage() }
    var showLanguageDialog by remember { mutableStateOf(!languageManager.hasChosenInitialLanguage) }

    val termsManager = remember { TermsManager(context) }
    var showTermsDialog by remember { mutableStateOf(!termsManager.isTermsAccepted) }

    var showILoveImageStudioDialog by remember { mutableStateOf(false) }
    var activeImageStudioToolId by remember { mutableStateOf("photo_editor") }
    var activeImageStudioBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showThreeLineDrawerMenu by remember { mutableStateOf(false) }
    var initialPortalTabType by remember { mutableStateOf(ToolMainType.PDF) }

    // Dedicated Image Studio Gallery Launcher
    val photoStudioGalleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val stream = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(stream)
                if (bmp != null) {
                    activeImageStudioBitmap = bmp
                    showILoveImageStudioDialog = true
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Camera Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            viewModel.addWorkingPage(bitmap)
            onNavigateToScanEditor()
        }
    }

    // Camera Permission Launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "कैमरा स्कैन के लिए कैमरा अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCameraWithPermission() {
        onNavigateToScanEditor()
    }

    // Gallery Multiple Image Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    val stream = context.contentResolver.openInputStream(uri)
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        viewModel.addWorkingPage(bmp)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            onNavigateToScanEditor()
        }
    }

    // Open Any Document File Picker Launcher (PDF, Word, Excel, PowerPoint, Text)
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importOfficeFileFromUri(context, uri, isVaultTabSelected) { savedDoc ->
                Toast.makeText(context, "${savedDoc.title} जोड़ा गया!", Toast.LENGTH_SHORT).show()
                val pending = pendingToolAction
                if (pending != null) {
                    pendingToolAction = null
                    executeToolWithDocument(pending, savedDoc)
                } else {
                    onViewDocument(savedDoc)
                }
            }
        }
    }

    var isScanningDevice by remember { mutableStateOf(false) }

    fun triggerDeviceScan() {
        isScanningDevice = true
        viewModel.scanAndSyncDeviceDocuments(context) { addedCount ->
            isScanningDevice = false
            if (addedCount > 0) {
                Toast.makeText(context, "स्वचालित स्कैन: $addedCount नई PDF/फ़ाइलें मिलीं!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val anyGranted = permissions.values.any { it }
        if (anyGranted) {
            triggerDeviceScan()
        } else {
            Toast.makeText(context, "दस्तावेज़ स्कैन के लिए स्टोरेज/मीडिया अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    fun requestStorageAndScan() {
        if (android.os.Build.VERSION.SDK_INT >= 34) { // Android 14+ (UPSIDE_DOWN_CAKE)
            storagePermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_AUDIO,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                )
            )
        } else if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) { // Android 13
            storagePermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_AUDIO
                )
            )
        } else {
            storagePermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            )
        }
    }

    var isStarredOnlyFilter by remember { mutableStateOf(false) }
    val currentList = if (isVaultTabSelected) vaultDocs else publicDocs

    val filteredDocs = remember(currentList, activeCategoryFilter, searchQuery, isStarredOnlyFilter) {
        currentList.filter { doc ->
            val matchesCategory = when (activeCategoryFilter) {
                DocumentCategory.ALL -> true
                else -> doc.categoryEnum == activeCategoryFilter
            }
            val matchesSearch = if (searchQuery.isBlank()) true else {
                doc.title.contains(searchQuery, ignoreCase = true) ||
                doc.extractedText.contains(searchQuery, ignoreCase = true)
            }
            val matchesStarred = if (isStarredOnlyFilter) doc.isStarred else true
            matchesCategory && matchesSearch && matchesStarred
        }
    }

    if (isDesktopActive) {
        DesktopStandardWorkspaceView(
            documents = publicDocs + vaultDocs,
            onViewDocument = onViewDocument,
            onOpenBlankPdfCreator = { showBlankPdfCreatorDialog = true },
            onScanDocument = { launchCameraWithPermission() },
            onOpenFiles = { openDocumentLauncher.launch("*/*") },
            onMergeFiles = { showMergeSplitDialog = true },
            onNavigateToAi = onNavigateToAi,
            onOpenTools = {
                AppModeManager.setDisplayMode(AppDisplayMode.NORMAL_MOBILE)
                selectedBottomTab = 4
            },
            onSwitchToMobileMode = {
                AppModeManager.setDisplayMode(AppDisplayMode.NORMAL_MOBILE)
                Toast.makeText(context, "📱 नॉर्मल मोबाइल मोड सक्रिय", Toast.LENGTH_SHORT).show()
            },
            onWatermark = { doc ->
                selectedDocumentForWatermark = doc
                showWatermarkDialog = true
            },
            onPdfToImage = { doc ->
                selectedDocumentForImageExport = doc
                showPdfToImageDialog = true
            },
            onOrganizePages = { doc ->
                selectedDocumentForOrganizer = doc
                showPdfOrganizerDialog = true
            },
            onTranslate = { doc ->
                selectedDocumentForTranslate = doc
                showPdfTranslateDialog = true
            },
            onPodcast = { doc ->
                selectedDocumentForPodcast = doc
                showPodcastDialog = true
            },
            onQuiz = { doc ->
                selectedDocumentForQuiz = doc
                showQuizDialog = true
            },
            onAudioNote = { doc ->
                selectedDocumentForAudioNote = doc
                showAudioNoteDialog = true
            },
            onProtect = { doc ->
                selectedDocumentForProtect = doc
                showPdfProtectDialog = true
            },
            onShareDoc = { doc ->
                docToShare = doc
                showShareExportDialog = true
            },
            onDeleteDoc = { doc ->
                viewModel.deleteDocument(doc.id)
                Toast.makeText(context, "🗑️ ट्रैश में भेजा गया", Toast.LENGTH_SHORT).show()
            },
            onToggleStarDoc = { doc ->
                viewModel.toggleStarred(doc.id)
            },
            onOcrScan = {
                onNavigateToOcrDigitizer(false)
            },
            onRepairPdf = {
                showPdfRepairDialog = true
            },
            onComparePdf = {
                showPdfCompareDialog = true
            },
            onIdCardScan = {
                showIdCardDialog = true
            },
            onOpenPhotoStudio = {
                activeImageStudioToolId = "photo_editor"
                photoStudioGalleryLauncher.launch("image/*")
            }
        )
    } else {
        Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = { showModeSelectionSheet = true },
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "मोड बदलें (☰)",
                            tint = if (isDesktopActive) Color(0xFF38BDF8) else currentPalette.primaryAccent,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                },
                title = {
                    if (isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("खोजें (Search PDF, Word, Excel...)", fontSize = 13.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(24.dp)
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_app_brand_logo),
                                    contentDescription = "PDF PRO Logo",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "PDF PRO",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "PDF, MS Word, Excel, PPT व OCR दस्तावेज़",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TealAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                actions = {
                    Surface(
                        color = if (isDesktopActive) Color(0xFF0F3E5C) else Color(0xFF1E1E28),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isDesktopActive) Color(0xFF38BDF8) else Color(0xFF10B981)
                        ),
                        modifier = Modifier
                            .clickable { showModeSelectionSheet = true }
                            .padding(end = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (isDesktopActive) Icons.Default.LaptopMac else Icons.Default.Smartphone,
                                contentDescription = null,
                                tint = if (isDesktopActive) Color(0xFF38BDF8) else Color(0xFF10B981),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isDesktopActive) "स्टैंडर्ड" else "नॉर्मल",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    IconButton(onClick = { isSearchActive = !isSearchActive }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                    IconButton(onClick = { showTrashDialog = true }) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Trash Bin", tint = PdfRed)
                    }
                    Surface(
                        color = Color(0xFF1E1E28),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TealAccent.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .clickable { showLanguageDialog = true }
                            .padding(end = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedLanguage.flagEmoji, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = selectedLanguage.nativeName,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    IconButton(onClick = onToggleDarkMode) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Dark/Light Mode",
                            tint = currentPalette.primaryAccent
                        )
                    }
                    IconButton(onClick = { showThemeDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = "Theme Color Palette",
                            tint = currentPalette.primaryAccent
                        )
                    }
                    IconButton(onClick = onNavigateToSecuritySettings) {
                        Icon(Icons.Default.Security, contentDescription = "Security", tint = currentPalette.primaryAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // AI Assistant Button above the + FAB
                ExtendedFloatingActionButton(
                    onClick = onNavigateToAi,
                    containerColor = Color(0xFF1C1C24),
                    contentColor = Color.White,
                    shape = RoundedCornerShape(24.dp),
                    elevation = FloatingActionButtonDefaults.elevation(6.dp),
                    modifier = Modifier.border(
                        1.5.dp,
                        Brush.linearGradient(listOf(currentPalette.primaryAccent, currentPalette.secondaryAccent)),
                        RoundedCornerShape(24.dp)
                    ),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Assistant",
                            tint = currentPalette.primaryAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    text = {
                        Text(
                            text = "AI Assistant",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }
                )

                // Plus (+) Floating Action Button
                FloatingActionButton(
                    onClick = { showImportMenuDialog = true },
                    containerColor = currentPalette.primaryAccent,
                    contentColor = Color.White,
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Scan / Add File", modifier = Modifier.size(28.dp))
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF141414),
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    selected = selectedBottomTab == 0,
                    onClick = { selectedBottomTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = languageManager.t("home")) },
                    label = { Text(languageManager.t("home"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = currentPalette.primaryAccent,
                        selectedTextColor = currentPalette.primaryAccent,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = currentPalette.primaryAccent.copy(alpha = 0.2f)
                    )
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 1,
                    onClick = {
                        selectedBottomTab = 1
                        showImportMenuDialog = true
                    },
                    icon = { Icon(Icons.Default.AddCircleOutline, contentDescription = languageManager.t("create")) },
                    label = { Text(languageManager.t("create"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = currentPalette.primaryAccent,
                        selectedTextColor = currentPalette.primaryAccent,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = currentPalette.primaryAccent.copy(alpha = 0.2f)
                    )
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 2,
                    onClick = {
                        selectedBottomTab = 2
                    },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = languageManager.t("pdf_spaces")) },
                    label = { Text(languageManager.t("pdf_spaces"), fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = currentPalette.primaryAccent,
                        selectedTextColor = currentPalette.primaryAccent,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = currentPalette.primaryAccent.copy(alpha = 0.2f)
                    )
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 3,
                    onClick = { selectedBottomTab = 3 },
                    icon = { Icon(Icons.Default.Folder, contentDescription = languageManager.t("files")) },
                    label = { Text(languageManager.t("files"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = currentPalette.primaryAccent,
                        selectedTextColor = currentPalette.primaryAccent,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = currentPalette.primaryAccent.copy(alpha = 0.2f)
                    )
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 4,
                    onClick = { selectedBottomTab = 4 },
                    icon = { Icon(Icons.Default.GridView, contentDescription = languageManager.t("tools")) },
                    label = { Text(languageManager.t("tools"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = currentPalette.primaryAccent,
                        selectedTextColor = currentPalette.primaryAccent,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = currentPalette.primaryAccent.copy(alpha = 0.2f)
                    )
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedBottomTab) {
                2 -> {
                    PdfSpacesScreen(
                        viewModel = viewModel,
                        onViewDocument = onViewDocument,
                        onNavigateToScan = { launchCameraWithPermission() }
                    )
                }
                3 -> {
                    FilesTabContent(
                        onRequestScan = { requestStorageAndScan() },
                        onPickPhotos = { galleryLauncher.launch("image/*") },
                        onOpenFile = { openDocumentLauncher.launch("*/*") }
                    )
                }
                1, 4 -> {
                    ToolsTabContent(
                        onScan = { launchCameraWithPermission() },
                        onOpenFile = { openDocumentLauncher.launch("*/*") },
                        onPhotosToPdf = { galleryLauncher.launch("image/*") },
                        onIdCard = { showIdCardDialog = true },
                        onMerge = { showMergeSplitDialog = true },
                        onOcr = { onNavigateToOcrDigitizer(false) },
                        onRepair = { showPdfRepairDialog = true },
                        onCompare = { showPdfCompareDialog = true },
                        onMetaAi = onNavigateToAi,
                        onEditPdf = {
                            triggerToolWithDocumentPicker(ToolActionType.EDIT_PDF)
                        },
                        onCompress = {
                            triggerToolWithDocumentPicker(ToolActionType.COMPRESS)
                        },
                        onTemplateCreator = { showTemplateDialog = true },
                        onConvertToImages = {
                            triggerToolWithDocumentPicker(ToolActionType.CONVERT_TO_IMAGES)
                        },
                        onOrganizePages = {
                            triggerToolWithDocumentPicker(ToolActionType.ORGANIZE_PAGES)
                        },
                        onTranslate = {
                            triggerToolWithDocumentPicker(ToolActionType.TRANSLATE)
                        },
                        onHandwriting = { showHandwritingDialog = true },
                        onOmr = { showOmrScannerDialog = true },
                        onFormula = { showFormulaExtractorDialog = true },
                        onPodcast = {
                            triggerToolWithDocumentPicker(ToolActionType.PODCAST)
                        },
                        onQuiz = {
                            triggerToolWithDocumentPicker(ToolActionType.QUIZ)
                        },
                        onWatermark = {
                            triggerToolWithDocumentPicker(ToolActionType.WATERMARK)
                        },
                        onAudioNote = {
                            triggerToolWithDocumentPicker(ToolActionType.AUDIO_NOTE)
                        },
                        onProtect = {
                            triggerToolWithDocumentPicker(ToolActionType.PROTECT)
                        },
                        onQrScanner = {
                            showQrScannerDialog = true
                        },
                        onTrash = {
                            showTrashDialog = true
                        },
                        onLanguageSettings = {
                            showLanguageDialog = true
                        },
                        onBlankPdf = {
                            showBlankPdfCreatorDialog = true
                        },
                        onSwitchMode = {
                            showModeSelectionSheet = true
                        },
                        onOpenPhotoStudio = { toolId ->
                            activeImageStudioToolId = toolId
                            photoStudioGalleryLauncher.launch("image/*")
                        },
                        onOpenThreeLineMenu = {
                            showThreeLineDrawerMenu = true
                        },
                        initialTabType = initialPortalTabType
                    )
                }
                else -> {
                    // Acrobat-Style Home Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF0F0F12))
                    ) {
                            // "Welcome back" Greeting
                            Text(
                                text = "Welcome back",
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )

                        // 1. Featured Promotional Carousel Cards (Adobe Acrobat Style)
                        LazyRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Carousel Card 1: Easily edit PDFs
                            item {
                                AcrobatCarouselCard(
                                    title = "Easily edit PDFs",
                                    description = "Fix typos and add text or images to your PDFs. Try for 14 days.",
                                    buttonText = "Try now",
                                    gradientColors = listOf(Color(0xFF4A154B), Color(0xFF281032)),
                                    icon = Icons.Default.Edit,
                                    onAction = { onNavigateToScanEditor() }
                                )
                            }
                            // Carousel Card 2: Generative summary (AI)
                            item {
                                AcrobatCarouselCard(
                                    title = "Generative summary",
                                    description = "You have full access. Get instant summaries & voice chat for all files.",
                                    buttonText = "Try it now",
                                    gradientColors = listOf(Color(0xFF1E2B58), Color(0xFF121830)),
                                    icon = Icons.Default.AutoAwesome,
                                    onAction = onNavigateToAi
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // 2. White-Outline Tool Icons Row with Crown Badges (Horizontal scroll)
                        LazyRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.AutoMirrored.Filled.Chat,
                                    label = languageManager.t("ai_assistant"),
                                    hasCrown = true,
                                    onClick = onNavigateToAi
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Edit,
                                    label = languageManager.t("edit_pdf"),
                                    hasCrown = true,
                                    onClick = {
                                        triggerToolWithDocumentPicker(ToolActionType.EDIT_PDF)
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.VolumeUp,
                                    label = languageManager.t("read_aloud"),
                                    hasCrown = false,
                                    onClick = {
                                        triggerToolWithDocumentPicker(ToolActionType.READ_ALOUD)
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.AddCircleOutline,
                                    label = languageManager.t("create_pdf"),
                                    hasCrown = true,
                                    onClick = { showImportMenuDialog = true }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Share,
                                    label = languageManager.t("export_pdf"),
                                    hasCrown = false,
                                    onClick = {
                                        triggerToolWithDocumentPicker(ToolActionType.EXPORT_SHARE)
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Mic,
                                    label = languageManager.t("podcast"),
                                    hasCrown = false,
                                    onClick = {
                                        triggerToolWithDocumentPicker(ToolActionType.PODCAST)
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.CallMerge,
                                    label = languageManager.t("combine_files"),
                                    hasCrown = true,
                                    onClick = { showMergeSplitDialog = true }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.GridView,
                                    label = languageManager.t("organize_pages"),
                                    hasCrown = true,
                                    onClick = {
                                        triggerToolWithDocumentPicker(ToolActionType.ORGANIZE_PAGES)
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Compress,
                                    label = languageManager.t("compress_pdf"),
                                    hasCrown = true,
                                    onClick = {
                                        triggerToolWithDocumentPicker(ToolActionType.COMPRESS)
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Lock,
                                    label = languageManager.t("set_password"),
                                    hasCrown = false,
                                    onClick = {
                                        triggerToolWithDocumentPicker(ToolActionType.PROTECT)
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Badge,
                                    label = languageManager.t("id_card"),
                                    hasCrown = false,
                                    onClick = { showIdCardDialog = true }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.TextFields,
                                    label = languageManager.t("ocr_text"),
                                    hasCrown = false,
                                    onClick = { onNavigateToOcrDigitizer(false) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 3. Acrobat 3-Tab Filter Bar (Recent, Starred, On device)
                        var acrobatSubTab by remember { mutableStateOf(0) } // 0: Recent, 1: Starred, 2: On device

                        val displayedAcrobatDocs = when (acrobatSubTab) {
                            1 -> filteredDocs.filter { it.isStarred }
                            2 -> filteredDocs // On device synced docs
                            else -> filteredDocs // Recent
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(20.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                AcrobatTabHeader(
                                    title = languageManager.t("recent"),
                                    isSelected = acrobatSubTab == 0,
                                    onClick = {
                                        acrobatSubTab = 0
                                        isVaultTabSelected = false
                                    }
                                )
                                AcrobatTabHeader(
                                    title = languageManager.t("starred"),
                                    isSelected = acrobatSubTab == 1,
                                    onClick = {
                                        acrobatSubTab = 1
                                        isVaultTabSelected = false
                                    }
                                )
                                AcrobatTabHeader(
                                    title = languageManager.t("on_device"),
                                    isSelected = acrobatSubTab == 2,
                                    onClick = {
                                        acrobatSubTab = 2
                                        isVaultTabSelected = false
                                    }
                                )
                            }

                            // 3-Dots for sorting
                            IconButton(
                                onClick = {
                                    viewModel.scanAndSyncDeviceDocuments(context) { count ->
                                        Toast.makeText(context, "डिवाइस दस्तावेज़ सिंक: $count फ़ाइलें", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Sort / Options",
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Divider(color = Color(0xFF222228), modifier = Modifier.padding(horizontal = 16.dp))

                        // 4. Document List Area
                        if (displayedAcrobatDocs.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = "Empty",
                                        modifier = Modifier.size(64.dp),
                                        tint = Color.Gray.copy(alpha = 0.5f)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = if (acrobatSubTab == 1) "कोई तारांकित (Starred) PDF नहीं है" else "कोई दस्तावेज़ नहीं मिला",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "डिवाइस से PDF खोलें या कैमरा से तुरंत नया दस्तावेज़ बनाएँ।",
                                        fontSize = 12.sp,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = { openDocumentLauncher.launch("*/*") },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0265DC))
                                        ) {
                                            Icon(Icons.Default.FolderOpen, contentDescription = null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("फ़ाइल चुनें", color = Color.White)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.createQuickSampleDocument { doc ->
                                                    onViewDocument(doc)
                                                }
                                            },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF00E5FF)),
                                            border = BorderStroke(1.dp, Color(0xFF00E5FF))
                                        ) {
                                            Icon(Icons.Default.AutoStories, contentDescription = null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("टेस्ट नोट्स PDF")
                                        }
                                    }
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .weight(1f),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(displayedAcrobatDocs, key = { it.id }) { doc ->
                                    AcrobatDocumentListItem(
                                        doc = doc,
                                        onClick = { onViewDocument(doc) },
                                        onOptionsClick = { docForOptionsSheet = doc }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

    // Blank PDF Creator Dialog (Foxit & Xodo & PDF Creator style)
    if (showBlankPdfCreatorDialog) {
        BlankPdfCreatorDialog(
            onDismissRequest = { showBlankPdfCreatorDialog = false },
            onPdfCreated = { title, subtitle, body, paperStyle, pageSize, isLandscape, stamp ->
                showBlankPdfCreatorDialog = false
                val generatedFile = PdfGenerator.createCustomBlankPdf(
                    context = context,
                    title = title,
                    subtitle = subtitle,
                    bodyText = body,
                    paperStyle = paperStyle,
                    pageSize = pageSize,
                    isLandscape = isLandscape,
                    stampBadge = stamp
                )
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(generatedFile), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "✅ ज़ीरो से नया PDF तैयार! (100% No Watermark)", Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    // App Mode Selection Sheet (Normal Mobile vs Standard Desktop Pro)
    if (showModeSelectionSheet) {
        AppModeSelectionBottomSheet(
            currentMode = currentAppMode,
            onSelectMode = { mode ->
                AppModeManager.setDisplayMode(mode)
                val msg = when (mode) {
                    AppDisplayMode.NORMAL_MOBILE -> "📱 नॉर्मल मोबाइल मोड सक्रिय"
                    AppDisplayMode.STANDARD_DESKTOP -> "💻 स्टैंडर्ड डेस्कटॉप मोड सक्रिय"
                    AppDisplayMode.AUTO_DETECT -> "🔄 ऑटो-डिटेक्ट स्क्रीन मोड सक्रिय"
                }
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            },
            onDismissRequest = { showModeSelectionSheet = false },
            onOpenBlankPdfCreator = { showBlankPdfCreatorDialog = true },
            onOpenAllTools = { selectedBottomTab = 4 }
        )
    }

    // Terms & Conditions Dialog for New Users (One-time popup)
    if (showTermsDialog) {
        TermsAndConditionsDialog(
            onAccepted = {
                termsManager.isTermsAccepted = true
                showTermsDialog = false
            },
            isForcedNewUserMode = true
        )
    }

    // Unlock Vault PIN Dialog
    if (showUnlockVaultDialog) {
        AlertDialog(
            onDismissRequest = { showUnlockVaultDialog = false },
            title = { Text("सुरक्षित वॉल्ट अनलॉक करें (PIN Required)") },
            text = {
                Column {
                    Text("कृपया अपना 4-अंकों का वॉल्ट PIN दर्ज करें:")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4) pinInput = it },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = pinError,
                        label = { Text("4-Digit PIN") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError) {
                        Text("गलत PIN, फिर से प्रयास करें", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (viewModel.verifyVaultPin(pinInput)) {
                            showUnlockVaultDialog = false
                            isVaultTabSelected = true
                            pinInput = ""
                            pinError = false
                        } else {
                            pinError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultAmber)
                ) {
                    Text("अनलॉक करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnlockVaultDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Acrobat Plus (+) BottomSheet Menu Dialog
    if (showImportMenuDialog) {
        AcrobatAddMenuBottomSheet(
            onDismissRequest = { showImportMenuDialog = false },
            onCreatePdfSpace = {
                selectedBottomTab = 2
            },
            onOpenFile = {
                openDocumentLauncher.launch("*/*")
            },
            onGetAdobeScan = {
                launchCameraWithPermission()
            },
            onAskAiAssistant = {
                onNavigateToAi()
            },
            onGeneratePodcast = {
                triggerToolWithDocumentPicker(ToolActionType.PODCAST)
            },
            onEditPdf = {
                triggerToolWithDocumentPicker(ToolActionType.EDIT_PDF)
            },
            onCreateFromTemplate = {
                showTemplateDialog = true
            },
            onCreatePdf = {
                onNavigateToScanEditor()
            },
            onCombineFiles = {
                showMergeSplitDialog = true
            },
            onOrganizePages = {
                triggerToolWithDocumentPicker(ToolActionType.ORGANIZE_PAGES)
            },
            onCompressPdf = {
                triggerToolWithDocumentPicker(ToolActionType.COMPRESS)
            },
            onIdCardScan = {
                showIdCardDialog = true
            },
            onOcrScan = {
                onNavigateToOcrDigitizer(false)
            },
            onRepairPdf = {
                showPdfRepairDialog = true
            },
            onSetPassword = {
                triggerToolWithDocumentPicker(ToolActionType.PROTECT)
            },
            onConvertToImages = {
                triggerToolWithDocumentPicker(ToolActionType.CONVERT_TO_IMAGES)
            },
            onTranslateDocument = {
                triggerToolWithDocumentPicker(ToolActionType.TRANSLATE)
            },
            onTemplateCreator = {
                showTemplateDialog = true
            },
            onCreateBlankPdf = {
                showBlankPdfCreatorDialog = true
            },
            onSwitchDisplayMode = {
                showModeSelectionSheet = true
            }
        )
    }

    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguageCode = selectedLanguage.code,
            onLanguageSelected = { lang ->
                languageManager.applyLanguageLocale(context, lang.code)
            },
            onConfirm = {
                languageManager.hasChosenInitialLanguage = true
                showLanguageDialog = false
                if (!termsManager.isTermsAccepted) {
                    showTermsDialog = true
                }
                Toast.makeText(
                    context,
                    "${selectedLanguage.flagEmoji} ${selectedLanguage.nativeName} चयनित किया गया",
                    Toast.LENGTH_SHORT
                ).show()
            },
            isFirstLaunch = !languageManager.hasChosenInitialLanguage
        )
    }

    if (!showLanguageDialog && showTermsDialog) {
        TermsAndConditionsDialog(
            onAccept = {
                termsManager.isTermsAccepted = true
                showTermsDialog = false
            },
            onDismissRequest = {
                showTermsDialog = false
            }
        )
    }

    // Merge & Split Dialog
    if (showMergeSplitDialog) {
        MergeSplitDialog(
            availableDocuments = publicDocs + vaultDocs,
            onMergeSelected = { title, ids ->
                viewModel.mergeDocuments(title, ids) { merged ->
                    showMergeSplitDialog = false
                    Toast.makeText(context, "'${merged.title}' मर्ज किया गया!", Toast.LENGTH_SHORT).show()
                }
            },
            onSplitSelected = { docId, title, startP, endP ->
                viewModel.splitDocument(docId, title, startP, endP) { splitDoc ->
                    showMergeSplitDialog = false
                    Toast.makeText(context, "'${splitDoc.title}' अलग किया गया!", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showMergeSplitDialog = false }
        )
    }

    // Fullscreen ID Card Scanner Dialog
    if (showIdCardDialog) {
        IdCardCaptureDialog(
            initialFrontBitmap = idCardFrontBitmap,
            initialBackBitmap = idCardBackBitmap,
            onSaveIdCardPdf = { front, back, title ->
                val result = PdfGenerator.createIdCardPdf(context, front, back, title)
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(result.file), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "${languageManager.t("id_card")}: ${doc.title}", Toast.LENGTH_SHORT).show()
                }
                showIdCardDialog = false
                idCardFrontBitmap = null
                idCardBackBitmap = null
            },
            onDismissRequest = {
                showIdCardDialog = false
            }
        )
    }

    // QR & Barcode Scanner Dialog
    if (showQrScannerDialog) {
        QrBarcodeScannerDialog(
            onGeneratePdfFromQr = { title, content ->
                val generatedPdf = PdfGenerator.createQrBarcodePdf(context, title, content)
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(generatedPdf), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "✅ QR / Barcode PDF Card बनाया गया!", Toast.LENGTH_SHORT).show()
                }
                showQrScannerDialog = false
            },
            onDismissRequest = { showQrScannerDialog = false }
        )
    }

    // Recycle Bin Trash Can Dialog
    if (showTrashDialog) {
        AlertDialog(
            onDismissRequest = { showTrashDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = PdfRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("रीसाइकल बिन (Recycle Bin Trash)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("हटाए गए दस्तावेज़ यहाँ 30 दिनों तक सुरक्षित रहते हैं:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(10.dp))

                    if (trashDocs.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("रीसाइकल बिन खाली है (Trash is empty)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 240.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(trashDocs) { doc ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(doc.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${doc.pageCount} पन्ने • ${doc.fileSizeFormatted}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.restoreFromTrash(doc.id)
                                            Toast.makeText(context, "दस्तावेज़ वापस लाया गया", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.RestoreFromTrash, contentDescription = "Restore", tint = TealAccent)
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.deletePermanently(doc.id)
                                            Toast.makeText(context, "स्थायी रूप से हटाया गया", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Permanent Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrashDialog = false }) {
                    Text("बंद करें (Close)", color = TealAccent, fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    // Meta AI Global Assistant Dialog
    if (showMetaAiDialog) {
        AskPdfDialog(
            document = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull(),
            onDismissRequest = { showMetaAiDialog = false }
        )
    }

    // PDF Corruption Repair Dialog
    if (showPdfRepairDialog) {
        PdfRepairDialog(
            availableDocuments = publicDocs + vaultDocs,
            onSaveRepairedDocument = { repairedFile ->
                showPdfRepairDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(repairedFile), isVaultTabSelected) {
                    Toast.makeText(context, "रिपेयर की गई फाइल वॉल्ट/लिस्ट में जोड़ी गई", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showPdfRepairDialog = false }
        )
    }

    // PDF Compare Dialog
    if (showPdfCompareDialog) {
        PdfCompareDialog(
            availableDocuments = publicDocs + vaultDocs,
            onDismissRequest = { showPdfCompareDialog = false }
        )
    }

    // AI Handwriting Cleanup Dialog
    if (showHandwritingDialog) {
        HandwritingCleanupDialog(
            onRequestCamera = { launchCameraWithPermission() },
            onSaveCleanPdf = { pdfFile, title ->
                showHandwritingDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(pdfFile), isVaultTabSelected) {
                    Toast.makeText(context, "'$title' नोट्स सहेजे गए", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showHandwritingDialog = false }
        )
    }

    // OMR Sheet Evaluator Scanner Dialog
    if (showOmrScannerDialog) {
        OmrScannerDialog(
            onDismissRequest = { showOmrScannerDialog = false }
        )
    }

    // Formula & Equation Extractor Dialog
    if (showFormulaExtractorDialog) {
        FormulaExtractorDialog(
            onSaveFormulaSheet = { pdfFile, title ->
                showFormulaExtractorDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(pdfFile), isVaultTabSelected) {
                    Toast.makeText(context, "'$title' सहेजा गया", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showFormulaExtractorDialog = false }
        )
    }

    // Podcast Background Audio Reader Dialog
    if (showPodcastDialog && selectedDocumentForPodcast != null) {
        PodcastModeDialog(
            document = selectedDocumentForPodcast!!,
            onDismissRequest = { showPodcastDialog = false }
        )
    }

    // Interactive Quiz Dialog
    if (showQuizDialog && selectedDocumentForQuiz != null) {
        FlashcardQuizDialog(
            document = selectedDocumentForQuiz!!,
            onDismissRequest = { showQuizDialog = false }
        )
    }

    // Dynamic Smart Watermark Dialog
    if (showWatermarkDialog && selectedDocumentForWatermark != null) {
        val targetDoc = selectedDocumentForWatermark!!
        WatermarkStampDialog(
            initialWatermark = targetDoc.watermarkText.ifBlank { "FOR OFFICIAL USE ONLY" },
            initialStamp = targetDoc.stampText.ifBlank { "CONFIDENTIAL" },
            onApply = { wmText, stamp ->
                showWatermarkDialog = false
                viewModel.updateWatermarkAndStamp(targetDoc.id, wmText, stamp)
                Toast.makeText(context, "वाटरमार्क '$wmText' व स्टैम्प '$stamp' लागू हुआ!", Toast.LENGTH_SHORT).show()
            },
            onDismissRequest = { showWatermarkDialog = false }
        )
    }

    // Voice-Annotated Audio Note Dialog
    if (showAudioNoteDialog && selectedDocumentForAudioNote != null) {
        val targetDoc = selectedDocumentForAudioNote!!
        AudioNoteRecorderDialog(
            initialAudioPath = targetDoc.audioNotePath,
            onAudioSaved = { savedPath ->
                showAudioNoteDialog = false
                viewModel.updateAudioNote(targetDoc.id, savedPath)
                Toast.makeText(context, "वॉइस नोट सहेजा गया!", Toast.LENGTH_SHORT).show()
            },
            onDismissRequest = { showAudioNoteDialog = false }
        )
    }

    // Professional PDF Template Creator Dialog (Invoice, Assignment Cover, Certificate, Formal Letter)
    if (showTemplateDialog) {
        DocumentTemplateDialog(
            onPdfGenerated = { generatedFile, title ->
                showTemplateDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(generatedFile), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "✅ '$title' तैयार और सेव किया गया!", Toast.LENGTH_LONG).show()
                }
            },
            onDismissRequest = { showTemplateDialog = false }
        )
    }

    // PDF to Image High-Res Converter Dialog
    if (showPdfToImageDialog && selectedDocumentForImageExport != null) {
        PdfToImageConverterDialog(
            document = selectedDocumentForImageExport!!,
            onDismissRequest = { showPdfToImageDialog = false }
        )
    }

    // PDF Page Organizer Dialog (Reorder, Rotate 90/180/270, Duplicate, Delete)
    if (showPdfOrganizerDialog && selectedDocumentForOrganizer != null) {
        PdfPageOrganizerDialog(
            document = selectedDocumentForOrganizer!!,
            onSaveReorganizedPdf = { newPdfFile, title ->
                showPdfOrganizerDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(newPdfFile), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "✅ '$title' व्यवस्थित किया गया!", Toast.LENGTH_LONG).show()
                }
            },
            onDismissRequest = { showPdfOrganizerDialog = false }
        )
    }

    // AI Document Multilingual Translator Dialog
    if (showPdfTranslateDialog && selectedDocumentForTranslate != null) {
        PdfTranslateDialog(
            document = selectedDocumentForTranslate!!,
            onSaveTranslatedPdf = { translatedFile, title ->
                showPdfTranslateDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(translatedFile), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "✅ अनुवादित PDF '$title' सहेजा गया!", Toast.LENGTH_LONG).show()
                }
            },
            onDismissRequest = { showPdfTranslateDialog = false }
        )
    }

    // PDF Password Protection & Encryption Dialog
    if (showPdfProtectDialog && selectedDocumentForProtect != null) {
        val targetDoc = selectedDocumentForProtect!!
        PdfProtectDialog(
            document = targetDoc,
            onProtectPdf = { password ->
                showPdfProtectDialog = false
                if (!targetDoc.isPrivateVault) {
                    viewModel.toggleDocumentVault(targetDoc)
                }
                Toast.makeText(context, "🔒 '${targetDoc.title}' पासवर्ड से सुरक्षित वॉल्ट में सहेजा गया!", Toast.LENGTH_LONG).show()
            },
            onDismissRequest = { showPdfProtectDialog = false }
        )
    }

    // Smart Document Selector Dialog for Tools
    if (showSelectDocumentForToolDialog && pendingToolAction != null) {
        val currentAction = pendingToolAction!!
        SelectDocumentForToolDialog(
            toolName = currentAction.titleHindi,
            toolSubtitle = "उपयोग के लिए कोई दस्तावेज़ चुनें या नया बनाएं",
            availableDocuments = (publicDocs + vaultDocs),
            onDocumentSelected = { doc ->
                showSelectDocumentForToolDialog = false
                pendingToolAction = null
                executeToolWithDocument(currentAction, doc)
            },
            onCameraScanRequested = {
                showSelectDocumentForToolDialog = false
                pendingToolAction = null
                launchCameraWithPermission()
            },
            onGalleryPickRequested = {
                showSelectDocumentForToolDialog = false
                pendingToolAction = null
                galleryLauncher.launch("image/*")
            },
            onDeviceFilePickRequested = {
                showSelectDocumentForToolDialog = false
                openDocumentLauncher.launch("*/*")
            },
            onCreateDemoSampleRequested = {
                showSelectDocumentForToolDialog = false
                viewModel.createQuickSampleDocument { doc ->
                    pendingToolAction = null
                    executeToolWithDocument(currentAction, doc)
                    Toast.makeText(context, "✅ डेमो PDF तैयार किया गया!", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = {
                showSelectDocumentForToolDialog = false
                pendingToolAction = null
            }
        )
    }

    // Photo Editing Studio Dialog (iLoveIMG Suite)
    if (showILoveImageStudioDialog && activeImageStudioBitmap != null) {
        ILoveImageStudioDialog(
            initialBitmap = activeImageStudioBitmap!!,
            initialToolId = activeImageStudioToolId,
            onSaveImage = { savedBmp, title ->
                val file = File(context.cacheDir, "${title}_${System.currentTimeMillis()}.jpg")
                FileOutputStream(file).use { out ->
                    savedBmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
                }
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(file), isVaultTabSelected) { doc ->
                    Toast.makeText(context, "🖼️ '$title' सहेजा गया!", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showILoveImageStudioDialog = false }
        )
    }

    // Navigation 3-Line Menu Drawer (ILove Navigation Portal)
    if (showThreeLineDrawerMenu) {
        ILoveDrawerBottomSheet(
            onDismissRequest = { showThreeLineDrawerMenu = false },
            onSelectMainMode = { type ->
                initialPortalTabType = type
                selectedBottomTab = 4
            },
            onSwitchAppDisplayMode = {
                showModeSelectionSheet = true
            },
            onOpenLanguageDialog = {
                showLanguageDialog = true
            },
            onOpenScanner = {
                launchCameraWithPermission()
            },
            onOpenAiSpaces = {
                selectedBottomTab = 2
            },
            onOpenBlankPdf = {
                showBlankPdfCreatorDialog = true
            },
            onOpenFiles = {
                openDocumentLauncher.launch("*/*")
            }
        )
    }

    if (showThemeDialog) {
        ThemeSelectionDialog(
            currentPalette = currentPalette,
            isDarkMode = isDarkMode,
            onSelectPalette = { palette ->
                AppThemeManager.setPalette(context, palette)
            },
            onToggleDarkMode = onToggleDarkMode,
            onDismiss = { showThemeDialog = false }
        )
    }

    // Share & Export Sheet (Screenshot 1)
    if (showShareExportDialog && docToShare != null) {
        ShareExportDialog(
            doc = docToShare!!,
            onDismiss = {
                showShareExportDialog = false
                docToShare = null
            },
            onCompressRequested = {
                val targetDoc = docToShare
                showShareExportDialog = false
                if (targetDoc != null) {
                    onViewDocument(targetDoc)
                }
            },
            onRenameTitle = { newTitle ->
                docToShare?.let {
                    viewModel.renameDocument(it.id, newTitle)
                    Toast.makeText(context, "नाम बदला गया: $newTitle", Toast.LENGTH_SHORT).show()
                }
            },
            onShareConfirmed = { format, isPwd, pwd, isOcr, isLong, isZip, pageSize ->
                val targetDoc = docToShare
                showShareExportDialog = false
                docToShare = null
                if (targetDoc != null) {
                    viewModel.shareDocument(targetDoc)
                    Toast.makeText(context, "साझा किया जा रहा है...", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Authentic 3-Dots / More Document Options Bottom Sheet (Screenshots 6 & 7)
    if (docForOptionsSheet != null) {
        val targetDoc = docForOptionsSheet!!
        DocumentOptionsBottomSheet(
            doc = targetDoc,
            onDismiss = { docForOptionsSheet = null },
            onOpenPdfJpg = {
                docForOptionsSheet = null
                onViewDocument(targetDoc)
            },
            onShare = {
                docForOptionsSheet = null
                docToShare = targetDoc
                showShareExportDialog = true
            },
            onSendEmail = {
                docForOptionsSheet = null
                viewModel.shareDocumentViaEmail(targetDoc)
            },
            onCompress = {
                docForOptionsSheet = null
                executeToolWithDocument(ToolActionType.COMPRESS, targetDoc)
            },
            onLockToggle = {
                docForOptionsSheet = null
                viewModel.togglePrivateVault(targetDoc.id)
                Toast.makeText(context, if (targetDoc.isPrivateVault) "दस्तावेज़ अनलॉक किया गया" else "दस्तावेज़ सुरक्षित वॉल्ट में लॉक किया गया 🔒", Toast.LENGTH_SHORT).show()
            },
            onDelete = {
                docForOptionsSheet = null
                viewModel.deleteDocument(targetDoc.id)
                Toast.makeText(context, "दस्तावेज़ हटाया गया", Toast.LENGTH_SHORT).show()
            },
            onSaveToCloud = {
                docForOptionsSheet = null
                Toast.makeText(context, "☁️ '${targetDoc.title}' क्लाउड बैकअप में सहेजा गया!", Toast.LENGTH_SHORT).show()
            },
            onSaveToGallery = {
                docForOptionsSheet = null
                viewModel.saveDocumentToGallery(targetDoc) { success ->
                    val msg = if (success) "फ़ोटो एल्बम / गैलरी में सहेजा गया! 🖼️" else "सहेजने में विफल"
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            },
            onManualEdit = {
                docForOptionsSheet = null
                onViewDocument(targetDoc)
            },
            onBatchEdit = {
                docForOptionsSheet = null
                onNavigateToScanEditor()
            },
            onMove = {
                docForOptionsSheet = null
                Toast.makeText(context, "फ़ोल्डर में स्थानांतरित किया गया 📁", Toast.LENGTH_SHORT).show()
            },
            onCollage = {
                docForOptionsSheet = null
                Toast.makeText(context, "कोलाज / मल्टी-साइड तैयार किया जा रहा है...", Toast.LENGTH_SHORT).show()
            },
            onToggleFavourite = {
                docForOptionsSheet = null
                viewModel.toggleStarred(targetDoc.id)
                Toast.makeText(context, if (targetDoc.isStarred) "तारांकित से हटाया गया" else "तारांकित में जोड़ा गया ⭐", Toast.LENGTH_SHORT).show()
            },
            onTogglePin = {
                docForOptionsSheet = null
                Toast.makeText(context, "दस्तावेज़ शीर्ष पर पिन किया गया 📌", Toast.LENGTH_SHORT).show()
            },
            onOcrText = {
                docForOptionsSheet = null
                onNavigateToOcrDigitizer(false)
            },
            onCopyDocument = {
                docForOptionsSheet = null
                viewModel.duplicateDocument(targetDoc) {
                    Toast.makeText(context, "दस्तावेज़ की प्रतिलिपि बनाई गई 📋", Toast.LENGTH_SHORT).show()
                }
            },
            onSplit = {
                docForOptionsSheet = null
                selectedDocumentForOrganizer = targetDoc
                showPdfOrganizerDialog = true
            },
            onRename = {
                docForOptionsSheet = null
                docToRename = targetDoc
                renameInputText = targetDoc.title
                showRenameDialog = true
            },
            onTags = {
                docForOptionsSheet = null
                Toast.makeText(context, "टैग्स अपडेट किए गए 🏷️", Toast.LENGTH_SHORT).show()
            },
            onAddToHomeScreen = {
                docForOptionsSheet = null
                Toast.makeText(context, "होम स्क्रीन पर शॉर्टकट जोड़ा गया! 📱", Toast.LENGTH_SHORT).show()
            },
            onDateTimeSetting = {
                docForOptionsSheet = null
                Toast.makeText(context, "दिनांक और समय सेटिंग अपडेट की गई 🕒", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Rename Dialog
    if (showRenameDialog && docToRename != null) {
        val target = docToRename!!
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("दस्तावेज़ का नाम बदलें") },
            text = {
                OutlinedTextField(
                    value = renameInputText,
                    onValueChange = { renameInputText = it },
                    label = { Text("नया नाम") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameInputText.isNotBlank()) {
                            viewModel.renameDocument(target.id, renameInputText.trim())
                            showRenameDialog = false
                            docToRename = null
                            Toast.makeText(context, "नाम बदला गया!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("सहेजें (Save)")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

@Composable
fun QuickActionButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 4.dp)
    ) {
        Surface(
            color = color.copy(alpha = 0.15f),
            shape = CircleShape,
            modifier = Modifier.size(44.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun DocumentCardItem(
    doc: ScannedDocument,
    onClick: () -> Unit,
    onToggleVault: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onWatermark: () -> Unit = {},
    onQuiz: () -> Unit = {},
    onAudioNote: () -> Unit = {},
    onPodcast: () -> Unit = {},
    onToggleStarred: () -> Unit = {}
) {
    var showMenu by remember { mutableStateOf(false) }

    val category = doc.categoryEnum
    val cardBadgeColor = when (category) {
        DocumentCategory.WORD -> WordBlue
        DocumentCategory.EXCEL -> ExcelGreen
        DocumentCategory.POWERPOINT -> PptOrange
        DocumentCategory.PDF -> PdfRed
        else -> TealAccent
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = cardBadgeColor,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when (category) {
                            DocumentCategory.WORD -> Icons.Default.Description
                            DocumentCategory.EXCEL -> Icons.Default.TableChart
                            DocumentCategory.POWERPOINT -> Icons.Default.Slideshow
                            else -> Icons.Default.Description
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = doc.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = cardBadgeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = category.labelEnglish,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = cardBadgeColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${doc.pageCount} पन्ने • ${doc.fileSizeFormatted} • ${doc.formattedDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { onToggleStarred() },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (doc.isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Starred",
                        tint = if (doc.isStarred) Color(0xFFFFD700) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu")
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("देखें / खोलें") },
                            onClick = {
                                showMenu = false
                                onClick()
                            },
                            leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text(if (doc.isStarred) "तारांकित से हटाएं (Unstar)" else "स्टार जोड़ें (Star Document)") },
                            onClick = {
                                showMenu = false
                                onToggleStarred()
                            },
                            leadingIcon = {
                                Icon(
                                    if (doc.isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = null,
                                    tint = Color(0xFFFFD700)
                                )
                            }
                        )
                    DropdownMenuItem(
                        text = { Text("शेयर करें (Share)") },
                        onClick = {
                            showMenu = false
                            onShare()
                        },
                        leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) }
                    )
                    DropdownMenuItem(
                        text = { Text("वाटरमार्क जोड़ें (Watermark)") },
                        onClick = {
                            showMenu = false
                            onWatermark()
                        },
                        leadingIcon = { Icon(Icons.Default.Approval, contentDescription = null, tint = VaultAmber) }
                    )
                    DropdownMenuItem(
                        text = { Text("AI क्विज़ जनरेटर (Quiz)") },
                        onClick = {
                            showMenu = false
                            onQuiz()
                        },
                        leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = EmeraldGreen) }
                    )
                    DropdownMenuItem(
                        text = { Text("वॉइस नोट जोड़ें (Audio Note)") },
                        onClick = {
                            showMenu = false
                            onAudioNote()
                        },
                        leadingIcon = { Icon(Icons.Default.Mic, contentDescription = null, tint = PptOrange) }
                    )
                    DropdownMenuItem(
                        text = { Text("पॉडकस्ट ऑडियो मोड (Podcast)") },
                        onClick = {
                            showMenu = false
                            onPodcast()
                        },
                        leadingIcon = { Icon(Icons.Default.Headphones, contentDescription = null, tint = TealAccent) }
                    )
                    DropdownMenuItem(
                        text = { Text(if (doc.isPrivateVault) "वॉल्ट से निकालें" else "सुरक्षित वॉल्ट में भेजें") },
                        onClick = {
                            showMenu = false
                            onToggleVault()
                        },
                        leadingIcon = {
                            Icon(
                                if (doc.isPrivateVault) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = null,
                                tint = VaultAmber
                            )
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("हटाएं (Delete)", color = MaterialTheme.colorScheme.error) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                    )
                }
            }
        }
    }
}
}

@Composable
fun FilesTabContent(
    onRequestScan: () -> Unit,
    onPickPhotos: () -> Unit,
    onOpenFile: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
            .padding(16.dp)
    ) {
        Text(
            text = "Files",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column {
                AcrobatFileSourceRow(
                    icon = Icons.Default.Folder,
                    label = "On this device",
                    onClick = onRequestScan
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.PhotoLibrary,
                    label = "Photos",
                    onClick = onPickPhotos
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Cloud,
                    label = "Adobe cloud storage",
                    onClick = onOpenFile
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.CameraAlt,
                    label = "Adobe Scan",
                    onClick = onRequestScan
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Cloud,
                    label = "Google Drive",
                    onClick = onOpenFile
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Cloud,
                    label = "OneDrive",
                    onClick = onOpenFile
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Cloud,
                    label = "Dropbox",
                    onClick = onOpenFile
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Mail,
                    label = "PDFs from emails",
                    onClick = onRequestScan
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.FolderOpen,
                    label = "Browse more files",
                    onClick = onOpenFile
                )
            }
        }
    }
}

@Composable
fun AcrobatFileSourceRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color(0xFFFA0F00),
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = Icons.Default.KeyboardArrowRight,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun ToolsTabContent(
    onScan: () -> Unit,
    onOpenFile: () -> Unit,
    onPhotosToPdf: () -> Unit,
    onIdCard: () -> Unit,
    onMerge: () -> Unit,
    onOcr: () -> Unit,
    onRepair: () -> Unit,
    onCompare: () -> Unit,
    onMetaAi: () -> Unit,
    onEditPdf: () -> Unit = {},
    onCompress: () -> Unit = {},
    onTemplateCreator: () -> Unit = {},
    onConvertToImages: () -> Unit = {},
    onOrganizePages: () -> Unit = {},
    onTranslate: () -> Unit = {},
    onHandwriting: () -> Unit = {},
    onOmr: () -> Unit = {},
    onFormula: () -> Unit = {},
    onPodcast: () -> Unit = {},
    onQuiz: () -> Unit = {},
    onWatermark: () -> Unit = {},
    onAudioNote: () -> Unit = {},
    onProtect: () -> Unit = {},
    onQrScanner: () -> Unit = {},
    onTrash: () -> Unit = {},
    onLanguageSettings: () -> Unit = {},
    onBlankPdf: () -> Unit = {},
    onSwitchMode: () -> Unit = {},
    onOpenPhotoStudio: (String) -> Unit = {},
    onOpenThreeLineMenu: () -> Unit = {},
    initialTabType: ToolMainType = ToolMainType.PDF
) {
    val context = LocalContext.current

    ILovePortalView(
        initialMainType = initialTabType,
        onSelectPdfTool = { tool ->
            when (tool.id) {
                "merge_pdf", "split_pdf" -> onMerge()
                "organize_pdf", "rotate_pdf" -> onOrganizePages()
                "compress_pdf", "pdf_to_pdfa" -> onCompress()
                "pdf_to_word", "pdf_to_powerpoint", "pdf_to_excel", "word_to_pdf", "powerpoint_to_pdf", "excel_to_pdf" -> onOpenFile()
                "edit_pdf", "sign_pdf" -> onEditPdf()
                "pdf_to_jpg" -> onConvertToImages()
                "jpg_to_pdf", "scan_to_pdf" -> onScan()
                "watermark_pdf", "page_numbers" -> onWatermark()
                "html_to_pdf" -> onBlankPdf()
                "unlock_pdf", "protect_pdf" -> onProtect()
                "repair_pdf" -> onRepair()
                "ocr_pdf" -> onOcr()
                "ai_pdf_intelligence" -> onMetaAi()
                "compare_pdf" -> onCompare()
                "recycle_bin" -> onTrash()
                "qr_scanner" -> onQrScanner()
                else -> onOpenFile()
            }
        },
        onSelectImageTool = { tool ->
            onOpenPhotoStudio(tool.id)
        },
        onSelectWorkflowTool = { tool ->
            when (tool.id) {
                "blank_pdf_canvas" -> onBlankPdf()
                "id_card_2in1" -> onIdCard()
                "invoice_templates" -> onTemplateCreator()
                "gemini_ai_spaces" -> onMetaAi()
                "omr_scanner_tool" -> onOmr()
                "formula_extractor_tool" -> onFormula()
                "handwriting_clean_tool" -> onHandwriting()
                "audio_podcast_tool" -> onPodcast()
                "quiz_flashcard_tool" -> onQuiz()
                else -> onOpenFile()
            }
        },
        onOpenThreeLineMenu = onOpenThreeLineMenu,
        onSwitchMode = onSwitchMode,
        onOpenLanguageSettings = onLanguageSettings
    )
}

@Composable
fun MasterPdfToolActionCard(
    tool: MasterPdfTool,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, tool.accentColor.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = tool.accentColor.copy(alpha = 0.15f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = tool.icon, contentDescription = tool.titleHindi, tint = tool.accentColor, modifier = Modifier.size(22.dp))
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tool.titleHindi,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = tool.suite.badgeColor.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = tool.suite.displayNameHindi,
                            color = tool.suite.badgeColor,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                    if (tool.badge != null) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = tool.accentColor.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = tool.badge,
                                color = tool.accentColor,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Text(
                    text = tool.titleEn,
                    fontSize = 10.sp,
                    color = Color.LightGray.copy(alpha = 0.7f),
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = tool.description,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = Color.DarkGray)
        }
    }
}

@Composable
fun ToolActionCard(
    title: String,
    description: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242424))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = color.copy(alpha = 0.15f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
                }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = description, fontSize = 11.sp, color = Color.Gray)
            }
            Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = Color.Gray)
        }
    }
}

@Composable
fun AcrobatCarouselCard(
    title: String,
    description: String,
    buttonText: String,
    gradientColors: List<Color>,
    icon: ImageVector,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .height(130.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(gradientColors))
                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = description,
                            color = Color(0xFFD0D0E0),
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onAction,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0265DC)),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(buttonText, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AcrobatOutlineToolItem(
    icon: ImageVector,
    label: String,
    hasCrown: Boolean,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    val currentPalette by AppThemeManager.currentPaletteFlow.collectAsStateWithLifecycle()
    var isClickedActive by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val active = isSelected || isClickedActive
    val borderColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) currentPalette.primaryAccent else Color.White,
        label = "outline_border"
    )
    val bgColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) currentPalette.darkSurfaceVariant else Color(0xFF0F0F14),
        label = "outline_bg"
    )
    val iconColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) currentPalette.primaryAccent else Color.White,
        label = "outline_icon"
    )
    val labelColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) currentPalette.primaryAccent else Color(0xFFE0E0EA),
        label = "outline_label"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .clickable {
                isClickedActive = true
                scope.launch {
                    kotlinx.coroutines.delay(350)
                    isClickedActive = false
                }
                onClick()
            }
    ) {
        Box(
            modifier = Modifier.size(54.dp),
            contentAlignment = Alignment.Center
        ) {
            // Crisp White Outline Icon Box with Black Background -> Turns Red on Click
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(bgColor, CircleShape)
                    .border(1.5.dp, borderColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Gold Crown Badge for Premium Acrobat Tools
            if (hasCrown) {
                Surface(
                    color = Color(0xFFFFB300),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(16.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Pro",
                            tint = Color.Black,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            color = labelColor,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 13.sp,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun AcrobatTabHeader(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val currentPalette by AppThemeManager.currentPaletteFlow.collectAsStateWithLifecycle()
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            color = if (isSelected) Color.White else Color(0xFF888898),
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 15.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        if (isSelected) {
            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(2.5.dp)
                    .background(currentPalette.primaryAccent, RoundedCornerShape(2.dp))
            )
        } else {
            Spacer(modifier = Modifier.height(2.5.dp))
        }
    }
}

@Composable
fun AcrobatDocumentListItem(
    doc: ScannedDocument,
    onClick: () -> Unit,
    onOptionsClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF14141A)),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFF262632))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // PDF Document Icon / Page Thumbnail Box
            Surface(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(6.dp)),
                color = Color(0xFF251818)
            ) {
                AcrobatPdfLogoBadge()
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Title & Subtitle Info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = doc.title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "PDF • ${doc.fileSizeFormatted} • ${doc.pageCount} pgs",
                        color = Color(0xFF888898),
                        fontSize = 11.sp
                    )
                    if (doc.isStarred) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Starred",
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            // 3-Dots Button -> Opens Authentic DocumentOptionsBottomSheet (Screenshots 6 & 7)
            IconButton(
                onClick = onOptionsClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = Color.LightGray,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun AcrobatPdfLogoBadge() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE5252A)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.PictureAsPdf,
            contentDescription = "PDF",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
        )
    }
}

enum class ToolActionType(val titleHindi: String, val titleEnglish: String) {
    WATERMARK("वाटरमार्क व स्टैम्प (Watermark & Stamp)", "Watermark & Stamp"),
    CONVERT_TO_IMAGES("PDF से इमेज कनवर्टर (PDF to Images)", "PDF to Images Converter"),
    ORGANIZE_PAGES("पन्ने व्यवस्थित करें (Organize Pages)", "Organize & Rotate Pages"),
    TRANSLATE("दस्तावेज़ अनुवाद (AI Document Translator)", "AI Document Translator"),
    PODCAST("AI पॉडकास्ट ऑडियो (AI Podcast Mode)", "AI Podcast Mode"),
    QUIZ("क्विज़ व फ्लैशकार्ड्स (AI Quiz & Flashcards)", "AI Quiz & Flashcards"),
    AUDIO_NOTE("वॉइस नोट जोड़ें (Voice Notes)", "Voice Notes & Audio"),
    PROTECT("पासवर्ड सुरक्षा (Set Password / Protect)", "Password Protection"),
    COMPRESS("कंप्रेस PDF (Compress PDF)", "Compress PDF"),
    READ_ALOUD("बोलकर पढ़ें (Read Aloud & TTS)", "Read Aloud & TTS"),
    EXPORT_SHARE("शेयर व एक्सपोर्ट (Share & Export)", "Share & Export PDF"),
    EDIT_PDF("PDF एडिट करें (Edit PDF)", "Edit PDF")
}

