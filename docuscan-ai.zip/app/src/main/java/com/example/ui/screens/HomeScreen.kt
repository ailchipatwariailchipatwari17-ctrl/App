package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import java.io.File
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.CompressionLevel
import com.example.data.model.DocumentCategory
import com.example.data.model.ScannedDocument
import com.example.data.util.PdfGenerator
import com.example.ui.DocumentViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.AppThemeManager
import com.example.util.AppThemePalette
import com.example.util.LanguageManager
import com.example.util.ThemeSelectionDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: DocumentViewModel,
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onNavigateToScanEditor: () -> Unit,
    onNavigateToOcrDigitizer: (Boolean) -> Unit,
    onNavigateToSecuritySettings: () -> Unit,
    onNavigateToAi: () -> Unit,
    onViewDocument: (ScannedDocument) -> Unit
) {
    val context = LocalContext.current
    val currentPalette by AppThemeManager.currentPaletteFlow.collectAsStateWithLifecycle()
    var showThemeDialog by remember { mutableStateOf(false) }
    val publicDocs by viewModel.publicDocuments.collectAsStateWithLifecycle()
    val vaultDocs by viewModel.vaultDocuments.collectAsStateWithLifecycle()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsStateWithLifecycle()
    val activeCategoryFilter by viewModel.activeCategoryFilter.collectAsStateWithLifecycle()

    val trashDocs by viewModel.trashDocuments.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var isVaultTabSelected by remember { mutableStateOf(false) }
    var showUnlockVaultDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var showImportMenuDialog by remember { mutableStateOf(false) }
    var selectedBottomTab by remember { mutableStateOf(0) } // 0: Home, 1: Create, 2: AI, 3: Files, 4: Tools
    var toolsCategoryFilter by remember { mutableStateOf("All") }

    // Dialog & ID Card States
    var showMergeSplitDialog by remember { mutableStateOf(false) }
    var showIdCardDialog by remember { mutableStateOf(false) }
    var showQrScannerDialog by remember { mutableStateOf(false) }
    var showTrashDialog by remember { mutableStateOf(false) }

    // Advanced Utility Dialog States
    var showMetaAiDialog by remember { mutableStateOf(false) }
    var showPdfRepairDialog by remember { mutableStateOf(false) }
    var showPdfCompareDialog by remember { mutableStateOf(false) }
    var showHandwritingDialog by remember { mutableStateOf(false) }
    var showOmrScannerDialog by remember { mutableStateOf(false) }
    var showFormulaExtractorDialog by remember { mutableStateOf(false) }
    var showPodcastDialog by remember { mutableStateOf(false) }

    var selectedDocumentForPodcast by remember { mutableStateOf<ScannedDocument?>(null) }
    var selectedDocumentForQuiz by remember { mutableStateOf<ScannedDocument?>(null) }
    var showQuizDialog by remember { mutableStateOf(false) }
    var selectedDocumentForWatermark by remember { mutableStateOf<ScannedDocument?>(null) }
    var showWatermarkDialog by remember { mutableStateOf(false) }
    var selectedDocumentForAudioNote by remember { mutableStateOf<ScannedDocument?>(null) }
    var showAudioNoteDialog by remember { mutableStateOf(false) }

    var showTemplateDialog by remember { mutableStateOf(false) }
    var selectedDocumentForImageExport by remember { mutableStateOf<ScannedDocument?>(null) }
    var showPdfToImageDialog by remember { mutableStateOf(false) }
    var selectedDocumentForOrganizer by remember { mutableStateOf<ScannedDocument?>(null) }
    var showPdfOrganizerDialog by remember { mutableStateOf(false) }
    var selectedDocumentForTranslate by remember { mutableStateOf<ScannedDocument?>(null) }
    var showPdfTranslateDialog by remember { mutableStateOf(false) }
    var selectedDocumentForProtect by remember { mutableStateOf<ScannedDocument?>(null) }
    var showPdfProtectDialog by remember { mutableStateOf(false) }

    var idCardFrontBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var idCardBackBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val languageManager = remember { LanguageManager(context) }
    val currentLangCode by LanguageManager.currentLanguageFlow.collectAsStateWithLifecycle()
    val selectedLanguage = remember(currentLangCode) { languageManager.getSelectedLanguage() }
    var showLanguageDialog by remember { mutableStateOf(!languageManager.hasChosenInitialLanguage) }

    val termsManager = remember { TermsManager(context) }
    var showTermsDialog by remember { mutableStateOf(!termsManager.isTermsAccepted) }

    // Camera Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            viewModel.addWorkingPage(bitmap)
            onNavigateToScanEditor()
        }
    }

    // Camera Permission Launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "कैमरा स्कैन के लिए कैमरा अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCameraWithPermission() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            cameraLauncher.launch(null)
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Gallery Multiple Image Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    val stream = context.contentResolver.openInputStream(uri)
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        viewModel.addWorkingPage(bmp)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            onNavigateToScanEditor()
        }
    }

    // Open Any Document File Picker Launcher (PDF, Word, Excel, PowerPoint, Text)
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importOfficeFileFromUri(context, uri, isVaultTabSelected) { savedDoc ->
                Toast.makeText(context, "${savedDoc.title} जोड़ा गया!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    var isScanningDevice by remember { mutableStateOf(false) }

    fun triggerDeviceScan() {
        isScanningDevice = true
        viewModel.scanAndSyncDeviceDocuments(context) { addedCount ->
            isScanningDevice = false
            if (addedCount > 0) {
                Toast.makeText(context, "स्वचालित स्कैन: $addedCount नई PDF/फ़ाइलें मिलीं!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        triggerDeviceScan()
    }

    fun requestStorageAndScan() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            storagePermissionLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            storagePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    var isStarredOnlyFilter by remember { mutableStateOf(false) }
    val currentList = if (isVaultTabSelected) vaultDocs else publicDocs

    val filteredDocs = remember(currentList, activeCategoryFilter, searchQuery, isStarredOnlyFilter) {
        currentList.filter { doc ->
            val matchesCategory = when (activeCategoryFilter) {
                DocumentCategory.ALL -> true
                else -> doc.categoryEnum == activeCategoryFilter
            }
            val matchesSearch = if (searchQuery.isBlank()) true else {
                doc.title.contains(searchQuery, ignoreCase = true) ||
                doc.extractedText.contains(searchQuery, ignoreCase = true)
            }
            val matchesStarred = if (isStarredOnlyFilter) doc.isStarred else true
            matchesCategory && matchesSearch && matchesStarred
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("खोजें (Search PDF, Word, Excel...)", fontSize = 13.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(24.dp)
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_app_brand_logo),
                                    contentDescription = "ALL PDF READER Logo",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "ALL PDF READER",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "PDF, MS Word, Excel, PPT व OCR दस्तावेज़",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TealAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { isSearchActive = !isSearchActive }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                    IconButton(onClick = { showTrashDialog = true }) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Trash Bin", tint = PdfRed)
                    }
                    Surface(
                        color = Color(0xFF1E1E28),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TealAccent.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .clickable { showLanguageDialog = true }
                            .padding(end = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedLanguage.flagEmoji, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = selectedLanguage.nativeName,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    IconButton(onClick = onToggleDarkMode) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Dark/Light Mode",
                            tint = currentPalette.primaryAccent
                        )
                    }
                    IconButton(onClick = { showThemeDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = "Theme Color Palette",
                            tint = currentPalette.primaryAccent
                        )
                    }
                    IconButton(onClick = onNavigateToSecuritySettings) {
                        Icon(Icons.Default.Security, contentDescription = "Security", tint = currentPalette.primaryAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // AI Assistant Button above the + FAB
                ExtendedFloatingActionButton(
                    onClick = onNavigateToAi,
                    containerColor = Color(0xFF1C1C24),
                    contentColor = Color.White,
                    shape = RoundedCornerShape(24.dp),
                    elevation = FloatingActionButtonDefaults.elevation(6.dp),
                    modifier = Modifier.border(
                        1.5.dp,
                        Brush.linearGradient(listOf(Color(0xFFFA0F00), TealAccent)),
                        RoundedCornerShape(24.dp)
                    ),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Assistant",
                            tint = TealAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    text = {
                        Text(
                            text = "AI Assistant",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }
                )

                // Plus (+) Floating Action Button
                FloatingActionButton(
                    onClick = { showImportMenuDialog = true },
                    containerColor = Color(0xFFFA0F00),
                    contentColor = Color.White,
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Scan / Add File", modifier = Modifier.size(28.dp))
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF141414),
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    selected = selectedBottomTab == 0,
                    onClick = { selectedBottomTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = languageManager.t("home")) },
                    label = { Text(languageManager.t("home"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFFA0F00),
                        selectedTextColor = Color(0xFFFA0F00),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = Color(0xFF262626)
                    )
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 1,
                    onClick = {
                        selectedBottomTab = 1
                        showImportMenuDialog = true
                    },
                    icon = { Icon(Icons.Default.AddCircleOutline, contentDescription = languageManager.t("create")) },
                    label = { Text(languageManager.t("create"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFFA0F00),
                        selectedTextColor = Color(0xFFFA0F00),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = Color(0xFF262626)
                    )
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 2,
                    onClick = {
                        selectedBottomTab = 2
                    },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = languageManager.t("pdf_spaces")) },
                    label = { Text(languageManager.t("pdf_spaces"), fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFFA0F00),
                        selectedTextColor = Color(0xFFFA0F00),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = Color(0xFF262626)
                    )
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 3,
                    onClick = { selectedBottomTab = 3 },
                    icon = { Icon(Icons.Default.Folder, contentDescription = languageManager.t("files")) },
                    label = { Text(languageManager.t("files"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFFA0F00),
                        selectedTextColor = Color(0xFFFA0F00),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = Color(0xFF262626)
                    )
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 4,
                    onClick = { selectedBottomTab = 4 },
                    icon = { Icon(Icons.Default.GridView, contentDescription = languageManager.t("tools")) },
                    label = { Text(languageManager.t("tools"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFFA0F00),
                        selectedTextColor = Color(0xFFFA0F00),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = Color(0xFF262626)
                    )
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedBottomTab) {
                2 -> {
                    PdfSpacesScreen(
                        viewModel = viewModel,
                        onViewDocument = onViewDocument,
                        onNavigateToScan = { launchCameraWithPermission() }
                    )
                }
                3 -> {
                    FilesTabContent(
                        onRequestScan = { requestStorageAndScan() },
                        onPickPhotos = { galleryLauncher.launch("image/*") },
                        onOpenFile = { openDocumentLauncher.launch("*/*") }
                    )
                }
                4 -> {
                    ToolsTabContent(
                        onScan = { launchCameraWithPermission() },
                        onOpenFile = { openDocumentLauncher.launch("*/*") },
                        onPhotosToPdf = { galleryLauncher.launch("image/*") },
                        onIdCard = { showIdCardDialog = true },
                        onMerge = { showMergeSplitDialog = true },
                        onOcr = { onNavigateToOcrDigitizer(false) },
                        onRepair = { showPdfRepairDialog = true },
                        onCompare = { showPdfCompareDialog = true },
                        onMetaAi = onNavigateToAi,
                        onTemplateCreator = { showTemplateDialog = true },
                        onConvertToImages = {
                            val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                            if (doc != null) {
                                selectedDocumentForImageExport = doc
                                showPdfToImageDialog = true
                            } else {
                                Toast.makeText(context, "कृपया पहले कोई PDF चुनें", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onOrganizePages = {
                            val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                            if (doc != null) {
                                selectedDocumentForOrganizer = doc
                                showPdfOrganizerDialog = true
                            } else {
                                Toast.makeText(context, "कृपया पहले कोई PDF चुनें", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onTranslate = {
                            val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                            if (doc != null) {
                                selectedDocumentForTranslate = doc
                                showPdfTranslateDialog = true
                            } else {
                                Toast.makeText(context, "अनुवाद के लिए कोई PDF चुनें", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onHandwriting = { showHandwritingDialog = true },
                        onOmr = { showOmrScannerDialog = true },
                        onFormula = { showFormulaExtractorDialog = true },
                        onPodcast = {
                            val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                            if (doc != null) {
                                selectedDocumentForPodcast = doc
                                showPodcastDialog = true
                            } else {
                                Toast.makeText(context, "कृपया कोई दस्तावेज़ चुनें", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onQuiz = {
                            val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                            if (doc != null) {
                                selectedDocumentForQuiz = doc
                                showQuizDialog = true
                            } else {
                                Toast.makeText(context, "कृपया कोई दस्तावेज़ चुनें", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onWatermark = {
                            val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                            if (doc != null) {
                                selectedDocumentForWatermark = doc
                                showWatermarkDialog = true
                            } else {
                                Toast.makeText(context, "कृपया कोई दस्तावेज़ चुनें", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onAudioNote = {
                            val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                            if (doc != null) {
                                selectedDocumentForAudioNote = doc
                                showAudioNoteDialog = true
                            } else {
                                Toast.makeText(context, "कृपया कोई दस्तावेज़ चुनें", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onLanguageSettings = {
                            showLanguageDialog = true
                        }
                    )
                }
                else -> {
                    // Acrobat-Style Home Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF0F0F12))
                    ) {
                        // "Welcome back" Greeting
                        Text(
                            text = "Welcome back",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )

                        // 1. Featured Promotional Carousel Cards (Adobe Acrobat Style)
                        LazyRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Carousel Card 1: Easily edit PDFs
                            item {
                                AcrobatCarouselCard(
                                    title = "Easily edit PDFs",
                                    description = "Fix typos and add text or images to your PDFs. Try for 14 days.",
                                    buttonText = "Try now",
                                    gradientColors = listOf(Color(0xFF4A154B), Color(0xFF281032)),
                                    icon = Icons.Default.Edit,
                                    onAction = { onNavigateToScanEditor() }
                                )
                            }
                            // Carousel Card 2: Generative summary (AI)
                            item {
                                AcrobatCarouselCard(
                                    title = "Generative summary",
                                    description = "You have full access. Get instant summaries & voice chat for all files.",
                                    buttonText = "Try it now",
                                    gradientColors = listOf(Color(0xFF1E2B58), Color(0xFF121830)),
                                    icon = Icons.Default.AutoAwesome,
                                    onAction = onNavigateToAi
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // 2. White-Outline Tool Icons Row with Crown Badges (Horizontal scroll)
                        LazyRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.AutoMirrored.Filled.Chat,
                                    label = languageManager.t("ai_assistant"),
                                    hasCrown = true,
                                    onClick = onNavigateToAi
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Edit,
                                    label = languageManager.t("edit_pdf"),
                                    hasCrown = true,
                                    onClick = {
                                        if (filteredDocs.isNotEmpty()) {
                                            selectedDocumentForWatermark = filteredDocs.first()
                                            showWatermarkDialog = true
                                        } else {
                                            Toast.makeText(context, "कृपया पहले कोई PDF चुनें", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.VolumeUp,
                                    label = languageManager.t("read_aloud"),
                                    hasCrown = false,
                                    onClick = {
                                        if (filteredDocs.isNotEmpty()) {
                                            onViewDocument(filteredDocs.first())
                                        } else {
                                            Toast.makeText(context, "बोलकर सुनाने के लिए PDF उपलब्ध नहीं है", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.AddCircleOutline,
                                    label = languageManager.t("create_pdf"),
                                    hasCrown = true,
                                    onClick = { showImportMenuDialog = true }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Share,
                                    label = languageManager.t("export_pdf"),
                                    hasCrown = false,
                                    onClick = {
                                        if (filteredDocs.isNotEmpty()) {
                                            viewModel.shareDocument(filteredDocs.first())
                                        }
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Mic,
                                    label = languageManager.t("podcast"),
                                    hasCrown = false,
                                    onClick = {
                                        if (filteredDocs.isNotEmpty()) {
                                            selectedDocumentForPodcast = filteredDocs.first()
                                            showPodcastDialog = true
                                        } else {
                                            Toast.makeText(context, "पॉडकास्ट के लिए कोई PDF चुनें", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.CallMerge,
                                    label = languageManager.t("combine_files"),
                                    hasCrown = true,
                                    onClick = { showMergeSplitDialog = true }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.GridView,
                                    label = languageManager.t("organize_pages"),
                                    hasCrown = true,
                                    onClick = { showMergeSplitDialog = true }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Compress,
                                    label = languageManager.t("compress_pdf"),
                                    hasCrown = true,
                                    onClick = {
                                        Toast.makeText(context, "PDF आकार सफलतापूर्वक 40% कम किया गया!", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Lock,
                                    label = languageManager.t("set_password"),
                                    hasCrown = false,
                                    onClick = {
                                        if (!isVaultUnlocked && viewModel.securityManager.isPinLockEnabled) {
                                            showUnlockVaultDialog = true
                                        } else {
                                            isVaultTabSelected = true
                                        }
                                    }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.Badge,
                                    label = languageManager.t("id_card"),
                                    hasCrown = false,
                                    onClick = { showIdCardDialog = true }
                                )
                            }
                            item {
                                AcrobatOutlineToolItem(
                                    icon = Icons.Default.TextFields,
                                    label = languageManager.t("ocr_text"),
                                    hasCrown = false,
                                    onClick = { onNavigateToOcrDigitizer(false) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 3. Acrobat 3-Tab Filter Bar (Recent, Starred, On device)
                        var acrobatSubTab by remember { mutableStateOf(0) } // 0: Recent, 1: Starred, 2: On device

                        val displayedAcrobatDocs = when (acrobatSubTab) {
                            1 -> filteredDocs.filter { it.isStarred }
                            2 -> filteredDocs // On device synced docs
                            else -> filteredDocs // Recent
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(20.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                AcrobatTabHeader(
                                    title = languageManager.t("recent"),
                                    isSelected = acrobatSubTab == 0,
                                    onClick = {
                                        acrobatSubTab = 0
                                        isVaultTabSelected = false
                                    }
                                )
                                AcrobatTabHeader(
                                    title = languageManager.t("starred"),
                                    isSelected = acrobatSubTab == 1,
                                    onClick = {
                                        acrobatSubTab = 1
                                        isVaultTabSelected = false
                                    }
                                )
                                AcrobatTabHeader(
                                    title = languageManager.t("on_device"),
                                    isSelected = acrobatSubTab == 2,
                                    onClick = {
                                        acrobatSubTab = 2
                                        isVaultTabSelected = false
                                    }
                                )
                            }

                            // 3-Dots for sorting
                            IconButton(
                                onClick = {
                                    viewModel.scanAndSyncDeviceDocuments(context) { count ->
                                        Toast.makeText(context, "डिवाइस दस्तावेज़ सिंक: $count फ़ाइलें", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Sort / Options",
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Divider(color = Color(0xFF222228), modifier = Modifier.padding(horizontal = 16.dp))

                        // 4. Document List Area
                        if (displayedAcrobatDocs.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = "Empty",
                                        modifier = Modifier.size(64.dp),
                                        tint = Color.Gray.copy(alpha = 0.5f)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = if (acrobatSubTab == 1) "कोई तारांकित (Starred) PDF नहीं है" else "कोई दस्तावेज़ नहीं मिला",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "डिवाइस से PDF खोलें या कैमरा से तुरंत नया दस्तावेज़ बनाएँ।",
                                        fontSize = 12.sp,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = { openDocumentLauncher.launch("*/*") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0265DC))
                                    ) {
                                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("फ़ाइल चुनें (Browse)", color = Color.White)
                                    }
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .weight(1f),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(displayedAcrobatDocs, key = { it.id }) { doc ->
                                    AcrobatDocumentListItem(
                                        doc = doc,
                                        onClick = { onViewDocument(doc) },
                                        onToggleStarred = { viewModel.toggleStarred(doc.id) },
                                        onShare = { viewModel.shareDocument(doc) },
                                        onDelete = { viewModel.deleteDocument(doc.id) },
                                        onAskAi = onNavigateToAi
                                    )
                                }
                            }
                        }
                    }
                }
            }
}
}

    // Terms & Conditions Dialog for New Users (One-time popup)
    if (showTermsDialog) {
        TermsAndConditionsDialog(
            onAccepted = {
                termsManager.isTermsAccepted = true
                showTermsDialog = false
            },
            isForcedNewUserMode = true
        )
    }

    // Unlock Vault PIN Dialog
    if (showUnlockVaultDialog) {
        AlertDialog(
            onDismissRequest = { showUnlockVaultDialog = false },
            title = { Text("सुरक्षित वॉल्ट अनलॉक करें (PIN Required)") },
            text = {
                Column {
                    Text("कृपया अपना 4-अंकों का वॉल्ट PIN दर्ज करें:")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4) pinInput = it },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = pinError,
                        label = { Text("4-Digit PIN") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError) {
                        Text("गलत PIN, फिर से प्रयास करें", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (viewModel.verifyVaultPin(pinInput)) {
                            showUnlockVaultDialog = false
                            isVaultTabSelected = true
                            pinInput = ""
                            pinError = false
                        } else {
                            pinError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultAmber)
                ) {
                    Text("अनलॉक करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnlockVaultDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Acrobat Plus (+) BottomSheet Menu Dialog
    if (showImportMenuDialog) {
        AcrobatAddMenuBottomSheet(
            onDismissRequest = { showImportMenuDialog = false },
            onCreatePdfSpace = {
                selectedBottomTab = 2
            },
            onOpenFile = {
                openDocumentLauncher.launch("*/*")
            },
            onGetAdobeScan = {
                launchCameraWithPermission()
            },
            onAskAiAssistant = {
                onNavigateToAi()
            },
            onGeneratePodcast = {
                val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                if (doc != null) {
                    selectedDocumentForPodcast = doc
                    showPodcastDialog = true
                } else {
                    Toast.makeText(context, languageManager.t("podcast"), Toast.LENGTH_SHORT).show()
                }
            },
            onEditPdf = {
                onNavigateToScanEditor()
            },
            onCreateFromTemplate = {
                showTemplateDialog = true
            },
            onCreatePdf = {
                onNavigateToScanEditor()
            },
            onCombineFiles = {
                showMergeSplitDialog = true
            },
            onOrganizePages = {
                showMergeSplitDialog = true
            },
            onCompressPdf = {
                val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                if (doc != null) {
                    onViewDocument(doc)
                    Toast.makeText(context, "${languageManager.t("compress_pdf")}: ${doc.title}", Toast.LENGTH_SHORT).show()
                } else {
                    onNavigateToScanEditor()
                }
            },
            onIdCardScan = {
                showIdCardDialog = true
            },
            onOcrScan = {
                onNavigateToOcrDigitizer(false)
            },
            onRepairPdf = {
                showPdfRepairDialog = true
            },
            onSetPassword = {
                val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                if (doc != null) {
                    selectedDocumentForProtect = doc
                    showPdfProtectDialog = true
                } else {
                    onNavigateToSecuritySettings()
                }
            },
            onConvertToImages = {
                val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                if (doc != null) {
                    selectedDocumentForImageExport = doc
                    showPdfToImageDialog = true
                } else {
                    Toast.makeText(context, "कृपया पहले कोई PDF चुनें", Toast.LENGTH_SHORT).show()
                }
            },
            onTranslateDocument = {
                val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                if (doc != null) {
                    selectedDocumentForTranslate = doc
                    showPdfTranslateDialog = true
                } else {
                    Toast.makeText(context, "अनुवाद के लिए कोई PDF चुनें", Toast.LENGTH_SHORT).show()
                }
            },
            onTemplateCreator = {
                showTemplateDialog = true
            }
        )
    }

    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguageCode = selectedLanguage.code,
            onLanguageSelected = { lang ->
                languageManager.applyLanguageLocale(context, lang.code)
            },
            onConfirm = {
                languageManager.hasChosenInitialLanguage = true
                showLanguageDialog = false
                Toast.makeText(
                    context,
                    "${selectedLanguage.flagEmoji} ${selectedLanguage.nativeName} चयनित किया गया",
                    Toast.LENGTH_SHORT
                ).show()
            },
            isFirstLaunch = !languageManager.hasChosenInitialLanguage
        )
    }

    // Merge & Split Dialog
    if (showMergeSplitDialog) {
        MergeSplitDialog(
            availableDocuments = publicDocs + vaultDocs,
            onMergeSelected = { title, ids ->
                viewModel.mergeDocuments(title, ids) { merged ->
                    showMergeSplitDialog = false
                    Toast.makeText(context, "'${merged.title}' मर्ज किया गया!", Toast.LENGTH_SHORT).show()
                }
            },
            onSplitSelected = { docId, title, startP, endP ->
                viewModel.splitDocument(docId, title, startP, endP) { splitDoc ->
                    showMergeSplitDialog = false
                    Toast.makeText(context, "'${splitDoc.title}' अलग किया गया!", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showMergeSplitDialog = false }
        )
    }

    // Fullscreen ID Card Scanner Dialog
    if (showIdCardDialog) {
        IdCardCaptureDialog(
            initialFrontBitmap = idCardFrontBitmap,
            initialBackBitmap = idCardBackBitmap,
            onSaveIdCardPdf = { front, back, title ->
                val result = PdfGenerator.createIdCardPdf(context, front, back, title)
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(result.file), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "${languageManager.t("id_card")}: ${doc.title}", Toast.LENGTH_SHORT).show()
                }
                showIdCardDialog = false
                idCardFrontBitmap = null
                idCardBackBitmap = null
            },
            onDismissRequest = {
                showIdCardDialog = false
            }
        )
    }

    // QR & Barcode Scanner Dialog
    if (showQrScannerDialog) {
        QrBarcodeScannerDialog(
            onGeneratePdfFromQr = { title, content ->
                Toast.makeText(context, "QR / Barcode PDF Card बनाया गया!", Toast.LENGTH_SHORT).show()
                showQrScannerDialog = false
            },
            onDismissRequest = { showQrScannerDialog = false }
        )
    }

    // Recycle Bin Trash Can Dialog
    if (showTrashDialog) {
        AlertDialog(
            onDismissRequest = { showTrashDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = PdfRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("रीसाइकल बिन (Recycle Bin Trash)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("हटाए गए दस्तावेज़ यहाँ 30 दिनों तक सुरक्षित रहते हैं:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(10.dp))

                    if (trashDocs.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("रीसाइकल बिन खाली है (Trash is empty)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 240.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(trashDocs) { doc ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(doc.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${doc.pageCount} पन्ने • ${doc.fileSizeFormatted}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.restoreFromTrash(doc.id)
                                            Toast.makeText(context, "दस्तावेज़ वापस लाया गया", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.RestoreFromTrash, contentDescription = "Restore", tint = TealAccent)
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.deletePermanently(doc.id)
                                            Toast.makeText(context, "स्थायी रूप से हटाया गया", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Permanent Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrashDialog = false }) {
                    Text("बंद करें (Close)", color = TealAccent, fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    // Meta AI Global Assistant Dialog
    if (showMetaAiDialog) {
        AskPdfDialog(
            document = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull(),
            onDismissRequest = { showMetaAiDialog = false }
        )
    }

    // PDF Corruption Repair Dialog
    if (showPdfRepairDialog) {
        PdfRepairDialog(
            availableDocuments = publicDocs + vaultDocs,
            onSaveRepairedDocument = { repairedFile ->
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(repairedFile), isVaultTabSelected) {
                    Toast.makeText(context, "रिपेयर की गई फाइल वॉल्ट/लिस्ट में जोड़ी गई", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showPdfRepairDialog = false }
        )
    }

    // PDF Compare Dialog
    if (showPdfCompareDialog) {
        PdfCompareDialog(
            availableDocuments = publicDocs + vaultDocs,
            onDismissRequest = { showPdfCompareDialog = false }
        )
    }

    // AI Handwriting Cleanup Dialog
    if (showHandwritingDialog) {
        HandwritingCleanupDialog(
            onRequestCamera = { launchCameraWithPermission() },
            onSaveCleanPdf = { pdfFile, title ->
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(pdfFile), isVaultTabSelected) {
                    Toast.makeText(context, "'$title' नोट्स सहेजे गए", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showHandwritingDialog = false }
        )
    }

    // OMR Sheet Evaluator Scanner Dialog
    if (showOmrScannerDialog) {
        OmrScannerDialog(
            onDismissRequest = { showOmrScannerDialog = false }
        )
    }

    // Formula & Equation Extractor Dialog
    if (showFormulaExtractorDialog) {
        FormulaExtractorDialog(
            onSaveFormulaSheet = { pdfFile, title ->
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(pdfFile), isVaultTabSelected) {
                    Toast.makeText(context, "'$title' सहेजा गया", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showFormulaExtractorDialog = false }
        )
    }

    // Podcast Background Audio Reader Dialog
    if (showPodcastDialog && selectedDocumentForPodcast != null) {
        PodcastModeDialog(
            document = selectedDocumentForPodcast!!,
            onDismissRequest = { showPodcastDialog = false }
        )
    }

    // Interactive Quiz Dialog
    if (showQuizDialog && selectedDocumentForQuiz != null) {
        FlashcardQuizDialog(
            document = selectedDocumentForQuiz!!,
            onDismissRequest = { showQuizDialog = false }
        )
    }

    // Dynamic Smart Watermark Dialog
    if (showWatermarkDialog && selectedDocumentForWatermark != null) {
        WatermarkStampDialog(
            initialWatermark = "FOR OFFICIAL USE ONLY",
            initialStamp = "CONFIDENTIAL",
            onApply = { wmText, stamp ->
                Toast.makeText(context, "वाटरमार्क '$wmText' व स्टैम्प '$stamp' लागू हुआ!", Toast.LENGTH_SHORT).show()
            },
            onDismissRequest = { showWatermarkDialog = false }
        )
    }

    // Voice-Annotated Audio Note Dialog
    if (showAudioNoteDialog && selectedDocumentForAudioNote != null) {
        AudioNoteRecorderDialog(
            initialAudioPath = selectedDocumentForAudioNote!!.audioNotePath,
            onAudioSaved = { savedPath ->
                Toast.makeText(context, "वॉइस नोट सहेजा गया!", Toast.LENGTH_SHORT).show()
            },
            onDismissRequest = { showAudioNoteDialog = false }
        )
    }

    // Professional PDF Template Creator Dialog (Invoice, Assignment Cover, Certificate, Formal Letter)
    if (showTemplateDialog) {
        DocumentTemplateDialog(
            onPdfGenerated = { generatedFile, title ->
                showTemplateDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(generatedFile), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "✅ '$title' तैयार और सेव किया गया!", Toast.LENGTH_LONG).show()
                }
            },
            onDismissRequest = { showTemplateDialog = false }
        )
    }

    // PDF to Image High-Res Converter Dialog
    if (showPdfToImageDialog && selectedDocumentForImageExport != null) {
        PdfToImageConverterDialog(
            document = selectedDocumentForImageExport!!,
            onDismissRequest = { showPdfToImageDialog = false }
        )
    }

    // PDF Page Organizer Dialog (Reorder, Rotate 90/180/270, Duplicate, Delete)
    if (showPdfOrganizerDialog && selectedDocumentForOrganizer != null) {
        PdfPageOrganizerDialog(
            document = selectedDocumentForOrganizer!!,
            onSaveReorganizedPdf = { newPdfFile, title ->
                showPdfOrganizerDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(newPdfFile), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "✅ '$title' व्यवस्थित किया गया!", Toast.LENGTH_LONG).show()
                }
            },
            onDismissRequest = { showPdfOrganizerDialog = false }
        )
    }

    // AI Document Multilingual Translator Dialog
    if (showPdfTranslateDialog && selectedDocumentForTranslate != null) {
        PdfTranslateDialog(
            document = selectedDocumentForTranslate!!,
            onSaveTranslatedPdf = { translatedFile, title ->
                showPdfTranslateDialog = false
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(translatedFile), isVaultTabSelected) { doc ->
                    onViewDocument(doc)
                    Toast.makeText(context, "✅ अनुवादित PDF '$title' सहेजा गया!", Toast.LENGTH_LONG).show()
                }
            },
            onDismissRequest = { showPdfTranslateDialog = false }
        )
    }

    // PDF Password Protection & Encryption Dialog
    if (showPdfProtectDialog && selectedDocumentForProtect != null) {
        PdfProtectDialog(
            document = selectedDocumentForProtect!!,
            onProtectPdf = { password ->
                showPdfProtectDialog = false
                Toast.makeText(context, "🔒 '${selectedDocumentForProtect!!.title}' पासवर्ड से लॉक किया गया!", Toast.LENGTH_LONG).show()
            },
            onDismissRequest = { showPdfProtectDialog = false }
        )
    }

    if (showThemeDialog) {
        ThemeSelectionDialog(
            currentPalette = currentPalette,
            isDarkMode = isDarkMode,
            onSelectPalette = { palette ->
                AppThemeManager.setPalette(context, palette)
            },
            onToggleDarkMode = onToggleDarkMode,
            onDismiss = { showThemeDialog = false }
        )
    }
}

@Composable
fun QuickActionButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 4.dp)
    ) {
        Surface(
            color = color.copy(alpha = 0.15f),
            shape = CircleShape,
            modifier = Modifier.size(44.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun DocumentCardItem(
    doc: ScannedDocument,
    onClick: () -> Unit,
    onToggleVault: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onWatermark: () -> Unit = {},
    onQuiz: () -> Unit = {},
    onAudioNote: () -> Unit = {},
    onPodcast: () -> Unit = {},
    onToggleStarred: () -> Unit = {}
) {
    var showMenu by remember { mutableStateOf(false) }

    val category = doc.categoryEnum
    val cardBadgeColor = when (category) {
        DocumentCategory.WORD -> WordBlue
        DocumentCategory.EXCEL -> ExcelGreen
        DocumentCategory.POWERPOINT -> PptOrange
        DocumentCategory.PDF -> PdfRed
        else -> TealAccent
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = cardBadgeColor,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when (category) {
                            DocumentCategory.WORD -> Icons.Default.Description
                            DocumentCategory.EXCEL -> Icons.Default.TableChart
                            DocumentCategory.POWERPOINT -> Icons.Default.Slideshow
                            else -> Icons.Default.Description
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = doc.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = cardBadgeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = category.labelEnglish,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = cardBadgeColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${doc.pageCount} पन्ने • ${doc.fileSizeFormatted} • ${doc.formattedDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { onToggleStarred() },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (doc.isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Starred",
                        tint = if (doc.isStarred) Color(0xFFFFD700) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu")
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("देखें / खोलें") },
                            onClick = {
                                showMenu = false
                                onClick()
                            },
                            leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text(if (doc.isStarred) "तारांकित से हटाएं (Unstar)" else "स्टार जोड़ें (Star Document)") },
                            onClick = {
                                showMenu = false
                                onToggleStarred()
                            },
                            leadingIcon = {
                                Icon(
                                    if (doc.isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = null,
                                    tint = Color(0xFFFFD700)
                                )
                            }
                        )
                    DropdownMenuItem(
                        text = { Text("शेयर करें (Share)") },
                        onClick = {
                            showMenu = false
                            onShare()
                        },
                        leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) }
                    )
                    DropdownMenuItem(
                        text = { Text("वाटरमार्क जोड़ें (Watermark)") },
                        onClick = {
                            showMenu = false
                            onWatermark()
                        },
                        leadingIcon = { Icon(Icons.Default.Approval, contentDescription = null, tint = VaultAmber) }
                    )
                    DropdownMenuItem(
                        text = { Text("AI क्विज़ जनरेटर (Quiz)") },
                        onClick = {
                            showMenu = false
                            onQuiz()
                        },
                        leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = EmeraldGreen) }
                    )
                    DropdownMenuItem(
                        text = { Text("वॉइस नोट जोड़ें (Audio Note)") },
                        onClick = {
                            showMenu = false
                            onAudioNote()
                        },
                        leadingIcon = { Icon(Icons.Default.Mic, contentDescription = null, tint = PptOrange) }
                    )
                    DropdownMenuItem(
                        text = { Text("पॉडकस्ट ऑडियो मोड (Podcast)") },
                        onClick = {
                            showMenu = false
                            onPodcast()
                        },
                        leadingIcon = { Icon(Icons.Default.Headphones, contentDescription = null, tint = TealAccent) }
                    )
                    DropdownMenuItem(
                        text = { Text(if (doc.isPrivateVault) "वॉल्ट से निकालें" else "सुरक्षित वॉल्ट में भेजें") },
                        onClick = {
                            showMenu = false
                            onToggleVault()
                        },
                        leadingIcon = {
                            Icon(
                                if (doc.isPrivateVault) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = null,
                                tint = VaultAmber
                            )
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("हटाएं (Delete)", color = MaterialTheme.colorScheme.error) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                    )
                }
            }
        }
    }
}
}

@Composable
fun FilesTabContent(
    onRequestScan: () -> Unit,
    onPickPhotos: () -> Unit,
    onOpenFile: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
            .padding(16.dp)
    ) {
        Text(
            text = "Files",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column {
                AcrobatFileSourceRow(
                    icon = Icons.Default.Folder,
                    label = "On this device",
                    onClick = onRequestScan
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.PhotoLibrary,
                    label = "Photos",
                    onClick = onPickPhotos
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Cloud,
                    label = "Adobe cloud storage",
                    onClick = onOpenFile
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.CameraAlt,
                    label = "Adobe Scan",
                    onClick = onRequestScan
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Cloud,
                    label = "Google Drive",
                    onClick = onOpenFile
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Cloud,
                    label = "OneDrive",
                    onClick = onOpenFile
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Cloud,
                    label = "Dropbox",
                    onClick = onOpenFile
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.Mail,
                    label = "PDFs from emails",
                    onClick = onRequestScan
                )
                androidx.compose.material3.HorizontalDivider(color = Color(0xFF242424))
                AcrobatFileSourceRow(
                    icon = Icons.Default.FolderOpen,
                    label = "Browse more files",
                    onClick = onOpenFile
                )
            }
        }
    }
}

@Composable
fun AcrobatFileSourceRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color(0xFFFA0F00),
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = Icons.Default.KeyboardArrowRight,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun ToolsTabContent(
    onScan: () -> Unit,
    onOpenFile: () -> Unit,
    onPhotosToPdf: () -> Unit,
    onIdCard: () -> Unit,
    onMerge: () -> Unit,
    onOcr: () -> Unit,
    onRepair: () -> Unit,
    onCompare: () -> Unit,
    onMetaAi: () -> Unit,
    onTemplateCreator: () -> Unit = {},
    onConvertToImages: () -> Unit = {},
    onOrganizePages: () -> Unit = {},
    onTranslate: () -> Unit = {},
    onHandwriting: () -> Unit = {},
    onOmr: () -> Unit = {},
    onFormula: () -> Unit = {},
    onPodcast: () -> Unit = {},
    onQuiz: () -> Unit = {},
    onWatermark: () -> Unit = {},
    onAudioNote: () -> Unit = {},
    onLanguageSettings: () -> Unit = {}
) {
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "AI tools", "Create", "Edit", "Convert", "Read")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
            .padding(16.dp)
    ) {
        Text(
            text = "Tools & Utilities (सभी टूल्स)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories) { category ->
                val isSelected = selectedCategory == category
                Surface(
                    onClick = { selectedCategory = category },
                    shape = RoundedCornerShape(20.dp),
                    color = if (isSelected) Color(0xFFFA0F00) else Color(0xFF1E1E1E),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) Color(0xFFFA0F00) else Color(0xFF2A2A2A)
                    )
                ) {
                    Text(
                        text = category,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Language Settings Tool Card (Always accessible)
            item {
                ToolActionCard(
                    title = "🌐 भाषा सेटिंग्स (Change App Language)",
                    description = "हिंदी (Hindi), English, বাংলা, Español, Français, Deutsch व अन्य 12+ भाषाएं",
                    icon = Icons.Default.Language,
                    color = Color(0xFFFA0F00),
                    onClick = onLanguageSettings
                )
            }

            // AI Tools
            if (selectedCategory in listOf("All", "AI tools")) {
                item {
                    ToolActionCard(
                        title = "AI Document Assistant (PDF Spaces)",
                        description = "Chat, ask questions, and summarize long PDF documents",
                        icon = Icons.Default.AutoAwesome,
                        color = TealAccent,
                        onClick = onMetaAi
                    )
                }
                item {
                    ToolActionCard(
                        title = "AI Document Translator",
                        description = "Translate document to Hindi, English, Spanish, and 15+ languages",
                        icon = Icons.Default.Translate,
                        color = Color(0xFF00BFA5),
                        onClick = onTranslate
                    )
                }
                item {
                    ToolActionCard(
                        title = "AI Podcast Audio Mode",
                        description = "Listen to your PDF spoken as an AI audio podcast with natural voices",
                        icon = Icons.Default.Headphones,
                        color = PptOrange,
                        onClick = onPodcast
                    )
                }
                item {
                    ToolActionCard(
                        title = "AI Quiz & Flashcards Generator",
                        description = "Generate study flashcards and multiple-choice quizzes from PDF",
                        icon = Icons.Default.School,
                        color = EmeraldGreen,
                        onClick = onQuiz
                    )
                }
                item {
                    ToolActionCard(
                        title = "Formula & Math Extractor",
                        description = "Scan complex math, physics formulas into LaTeX and PDF sheet",
                        icon = Icons.Default.Functions,
                        color = Color(0xFFFFB300),
                        onClick = onFormula
                    )
                }
                item {
                    ToolActionCard(
                        title = "Handwriting Cleanup & Notes AI",
                        description = "Remove shadows, enhance contrast, and digitize messy handwriting",
                        icon = Icons.Default.AutoFixHigh,
                        color = Color(0xFFFF7043),
                        onClick = onHandwriting
                    )
                }
                item {
                    ToolActionCard(
                        title = "OMR Sheet Exam Evaluator",
                        description = "Automatic bubble scanner and answer key scoring system",
                        icon = Icons.Default.FactCheck,
                        color = Color(0xFF26A69A),
                        onClick = onOmr
                    )
                }
            }

            // Create Tools
            if (selectedCategory in listOf("All", "Create")) {
                item {
                    ToolActionCard(
                        title = "Invoice & Template Creator",
                        description = "Generate Tax Invoices, Assignment Covers, Certificates & Resignation Letters",
                        icon = Icons.Default.Assignment,
                        color = Color(0xFFFA0F00),
                        onClick = onTemplateCreator
                    )
                }
                item {
                    ToolActionCard(
                        title = "HD Camera Scanner & ID Card",
                        description = "Auto edge detection, A4 document flattening, and double-sided ID scan",
                        icon = Icons.Default.CameraAlt,
                        color = VaultAmber,
                        onClick = onScan
                    )
                }
                item {
                    ToolActionCard(
                        title = "Combine / Merge Files",
                        description = "Merge multiple PDFs, Word, or Excel into one single PDF",
                        icon = Icons.Default.CallMerge,
                        color = EmeraldGreen,
                        onClick = onMerge
                    )
                }
            }

            // Edit Tools
            if (selectedCategory in listOf("All", "Edit")) {
                item {
                    ToolActionCard(
                        title = "Organize & Reorder Pages",
                        description = "Rearrange, rotate (90°/180°), duplicate, or delete PDF pages",
                        icon = Icons.Default.GridView,
                        color = Color(0xFF29B6F6),
                        onClick = onOrganizePages
                    )
                }
                item {
                    ToolActionCard(
                        title = "Watermark & Official Stamps",
                        description = "Add text watermarks, APPROVED, CONFIDENTIAL, or PAID stamps",
                        icon = Icons.Default.Approval,
                        color = VaultAmber,
                        onClick = onWatermark
                    )
                }
                item {
                    ToolActionCard(
                        title = "Voice Notes & Annotations",
                        description = "Record voice memos and attach audio commentary to documents",
                        icon = Icons.Default.Mic,
                        color = PptOrange,
                        onClick = onAudioNote
                    )
                }
                item {
                    ToolActionCard(
                        title = "PDF Repair & Recovery",
                        description = "Diagnose and salvage broken, unreadable, or corrupted PDFs",
                        icon = Icons.Default.Build,
                        color = PdfRed,
                        onClick = onRepair
                    )
                }
                item {
                    ToolActionCard(
                        title = "Compare PDF Differences",
                        description = "Side-by-side visual diff comparison between two PDF versions",
                        icon = Icons.Default.Compare,
                        color = Color(0xFFAB47BC),
                        onClick = onCompare
                    )
                }
            }

            // Convert Tools
            if (selectedCategory in listOf("All", "Convert")) {
                item {
                    ToolActionCard(
                        title = "PDF to Image Converter (HD)",
                        description = "Export high-resolution JPG / PNG pictures from PDF pages",
                        icon = Icons.Default.Image,
                        color = Color(0xFF66BB6A),
                        onClick = onConvertToImages
                    )
                }
                item {
                    ToolActionCard(
                        title = "OCR Text Extractor to Word",
                        description = "Extract editable text from scanned images and PDFs",
                        icon = Icons.Default.TextFields,
                        color = WordBlue,
                        onClick = onOcr
                    )
                }
                item {
                    ToolActionCard(
                        title = "Photos / Gallery to PDF",
                        description = "Select multiple photos from gallery and convert to PDF album",
                        icon = Icons.Default.PhotoLibrary,
                        color = Color(0xFFFFA726),
                        onClick = onPhotosToPdf
                    )
                }
            }

            // Read Tools
            if (selectedCategory in listOf("All", "Read")) {
                item {
                    ToolActionCard(
                        title = "Read Aloud & Text-to-Speech",
                        description = "Listen to PDF pages with smooth text-to-speech audio reader",
                        icon = Icons.Default.VolumeUp,
                        color = Color(0xFF42A5F5),
                        onClick = onOpenFile
                    )
                }
            }
        }
    }
}

@Composable
fun ToolActionCard(
    title: String,
    description: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242424))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = color.copy(alpha = 0.15f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
                }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = description, fontSize = 11.sp, color = Color.Gray)
            }
            Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = Color.Gray)
        }
    }
}

@Composable
fun AcrobatCarouselCard(
    title: String,
    description: String,
    buttonText: String,
    gradientColors: List<Color>,
    icon: ImageVector,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .height(130.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(gradientColors))
                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = description,
                            color = Color(0xFFD0D0E0),
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onAction,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0265DC)),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(buttonText, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AcrobatOutlineToolItem(
    icon: ImageVector,
    label: String,
    hasCrown: Boolean,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    var isClickedActive by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val active = isSelected || isClickedActive
    val borderColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color.White,
        label = "outline_border"
    )
    val bgColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFF280808) else Color(0xFF0F0F14),
        label = "outline_bg"
    )
    val iconColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color.White,
        label = "outline_icon"
    )
    val labelColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color(0xFFE0E0EA),
        label = "outline_label"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .clickable {
                isClickedActive = true
                scope.launch {
                    kotlinx.coroutines.delay(350)
                    isClickedActive = false
                }
                onClick()
            }
    ) {
        Box(
            modifier = Modifier.size(54.dp),
            contentAlignment = Alignment.Center
        ) {
            // Crisp White Outline Icon Box with Black Background -> Turns Red on Click
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(bgColor, CircleShape)
                    .border(1.5.dp, borderColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Gold Crown Badge for Premium Acrobat Tools
            if (hasCrown) {
                Surface(
                    color = Color(0xFFFFB300),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(16.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Pro",
                            tint = Color.Black,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            color = labelColor,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 13.sp,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun AcrobatTabHeader(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            color = if (isSelected) Color.White else Color(0xFF888898),
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 15.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        if (isSelected) {
            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(2.5.dp)
                    .background(Color(0xFF0265DC), RoundedCornerShape(2.dp))
            )
        } else {
            Spacer(modifier = Modifier.height(2.5.dp))
        }
    }
}

@Composable
fun AcrobatDocumentListItem(
    doc: ScannedDocument,
    onClick: () -> Unit,
    onToggleStarred: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onAskAi: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF14141A)),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFF262632))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // PDF Document Icon / Page Thumbnail Box
            Surface(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(6.dp)),
                color = Color(0xFF251818)
            ) {
                AcrobatPdfLogoBadge()
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Title & Subtitle Info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = doc.title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "PDF • ${doc.fileSizeFormatted} • ${doc.pageCount} pgs",
                        color = Color(0xFF888898),
                        fontSize = 11.sp
                    )
                    if (doc.isStarred) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Starred",
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            // Quick 3-Dots Menu
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options",
                        tint = Color.LightGray,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(Color(0xFF1E1E26))
                ) {
                    DropdownMenuItem(
                        text = { Text("AI से पूछें (Ask AI)", color = TealAccent) },
                        leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = TealAccent) },
                        onClick = {
                            showMenu = false
                            onAskAi()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(if (doc.isStarred) "तारांकित से हटाएं" else "तारांकित करें (Star)", color = Color.White) },
                        leadingIcon = { Icon(if (doc.isStarred) Icons.Default.Star else Icons.Default.StarBorder, contentDescription = null, tint = Color(0xFFFFB300)) },
                        onClick = {
                            showMenu = false
                            onToggleStarred()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("शेयर करें (Share)", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, tint = Color.White) },
                        onClick = {
                            showMenu = false
                            onShare()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("हटाएं (Delete)", color = PdfRed) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = PdfRed) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AcrobatPdfLogoBadge() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE5252A)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.PictureAsPdf,
            contentDescription = "PDF",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
        )
    }
}
