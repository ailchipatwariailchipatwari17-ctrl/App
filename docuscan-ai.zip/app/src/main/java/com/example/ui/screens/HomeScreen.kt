package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import com.example.ui.components.LanguageSelectionDialog
import com.example.util.LanguageManager
import com.example.util.AppLanguage
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CallMerge
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Approval
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Mic
import com.example.ui.components.IdCardCaptureDialog
import com.example.ui.components.MergeSplitDialog
import com.example.ui.components.QrBarcodeScannerDialog
import com.example.ui.components.PdfRepairDialog
import com.example.ui.components.PdfCompareDialog
import com.example.ui.components.HandwritingCleanupDialog
import com.example.ui.components.OmrScannerDialog
import com.example.ui.components.FormulaExtractorDialog
import com.example.ui.components.PodcastModeDialog
import com.example.ui.components.FlashcardQuizDialog
import com.example.ui.components.WatermarkStampDialog
import com.example.ui.components.AudioNoteRecorderDialog
import com.example.ui.components.AskPdfDialog
import com.example.ui.components.TermsAndConditionsDialog
import com.example.ui.components.TermsManager
import com.example.data.util.PdfGenerator
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DocumentCategory
import com.example.data.model.ScannedDocument
import com.example.ui.DocumentViewModel
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.ExcelGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.PptOrange
import com.example.ui.theme.TealAccent
import com.example.ui.theme.VaultAmber
import com.example.ui.theme.WordBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: DocumentViewModel,
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onNavigateToScanEditor: () -> Unit,
    onNavigateToOcrDigitizer: (Boolean) -> Unit,
    onNavigateToSecuritySettings: () -> Unit,
    onViewDocument: (ScannedDocument) -> Unit
) {
    val context = LocalContext.current
    val publicDocs by viewModel.publicDocuments.collectAsStateWithLifecycle()
    val vaultDocs by viewModel.vaultDocuments.collectAsStateWithLifecycle()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsStateWithLifecycle()
    val activeCategoryFilter by viewModel.activeCategoryFilter.collectAsStateWithLifecycle()

    val trashDocs by viewModel.trashDocuments.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var isVaultTabSelected by remember { mutableStateOf(false) }
    var showUnlockVaultDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var showImportMenuDialog by remember { mutableStateOf(false) }

    // Dialog & ID Card States
    var showMergeSplitDialog by remember { mutableStateOf(false) }
    var showIdCardDialog by remember { mutableStateOf(false) }
    var showQrScannerDialog by remember { mutableStateOf(false) }
    var showTrashDialog by remember { mutableStateOf(false) }

    // Advanced Utility Dialog States
    var showMetaAiDialog by remember { mutableStateOf(false) }
    var showPdfRepairDialog by remember { mutableStateOf(false) }
    var showPdfCompareDialog by remember { mutableStateOf(false) }
    var showHandwritingDialog by remember { mutableStateOf(false) }
    var showOmrScannerDialog by remember { mutableStateOf(false) }
    var showFormulaExtractorDialog by remember { mutableStateOf(false) }
    var showPodcastDialog by remember { mutableStateOf(false) }

    var selectedDocumentForPodcast by remember { mutableStateOf<ScannedDocument?>(null) }
    var selectedDocumentForQuiz by remember { mutableStateOf<ScannedDocument?>(null) }
    var showQuizDialog by remember { mutableStateOf(false) }
    var selectedDocumentForWatermark by remember { mutableStateOf<ScannedDocument?>(null) }
    var showWatermarkDialog by remember { mutableStateOf(false) }
    var selectedDocumentForAudioNote by remember { mutableStateOf<ScannedDocument?>(null) }
    var showAudioNoteDialog by remember { mutableStateOf(false) }

    var idCardFrontBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var idCardBackBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isCapturingFrontForId by remember { mutableStateOf(true) }

    // ID Card Photo Launcher
    val idCardCameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            if (isCapturingFrontForId) {
                idCardFrontBitmap = bitmap
            } else {
                idCardBackBitmap = bitmap
            }
            showIdCardDialog = true
        }
    }

    val languageManager = remember { LanguageManager(context) }
    var selectedLanguage by remember { mutableStateOf(languageManager.getSelectedLanguage()) }
    var showLanguageDialog by remember { mutableStateOf(false) }

    val termsManager = remember { TermsManager(context) }
    var showTermsDialog by remember { mutableStateOf(!termsManager.isTermsAccepted) }

    // Camera Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            viewModel.addWorkingPage(bitmap)
            onNavigateToScanEditor()
        }
    }

    // Camera Permission Launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch()
        } else {
            Toast.makeText(context, "कैमरा स्कैन के लिए कैमरा अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCameraWithPermission() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            cameraLauncher.launch()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Gallery Multiple Image Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    val stream = context.contentResolver.openInputStream(uri)
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        viewModel.addWorkingPage(bmp)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            onNavigateToScanEditor()
        }
    }

    // Open Any Document File Picker Launcher (PDF, Word, Excel, PowerPoint, Text)
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importOfficeFileFromUri(context, uri, isVaultTabSelected) { savedDoc ->
                Toast.makeText(context, "${savedDoc.title} जोड़ा गया!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val currentList = if (isVaultTabSelected) vaultDocs else publicDocs

    val filteredDocs = currentList.filter { doc ->
        val matchesCategory = when (activeCategoryFilter) {
            DocumentCategory.ALL -> true
            else -> doc.categoryEnum == activeCategoryFilter
        }
        val matchesSearch = doc.title.contains(searchQuery, ignoreCase = true) ||
                doc.extractedText.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("खोजें (Search PDF, Word, Excel...)", fontSize = 13.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(24.dp)
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.app_logo_1786276705423),
                                contentDescription = "ALL PDF Logo",
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "ALL PDF",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "PDF, MS Word, Excel, PPT व OCR दस्तावेज़",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TealAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { isSearchActive = !isSearchActive }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                    IconButton(onClick = { showTrashDialog = true }) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Trash Bin", tint = PdfRed)
                    }
                    IconButton(onClick = { showLanguageDialog = true }) {
                        Icon(Icons.Default.Language, contentDescription = "Language Select", tint = TealAccent)
                    }
                    IconButton(onClick = onToggleDarkMode) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Dark/Light Mode",
                            tint = TealAccent
                        )
                    }
                    IconButton(onClick = onNavigateToSecuritySettings) {
                        Icon(Icons.Default.Security, contentDescription = "Security", tint = TealAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // WhatsApp-Style Meta AI Floating Button
                FloatingActionButton(
                    onClick = { showMetaAiDialog = true },
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = TealAccent,
                    shape = CircleShape,
                    modifier = Modifier.size(50.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Meta AI Assistant",
                        tint = TealAccent,
                        modifier = Modifier.size(26.dp)
                    )
                }

                FloatingActionButton(
                    onClick = { showImportMenuDialog = true },
                    containerColor = TealAccent,
                    contentColor = Color.White,
                    shape = CircleShape
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Scan / Add File", modifier = Modifier.size(28.dp))
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Category Filter Bar (All, PDF, Word, Excel, PowerPoint, Private Vault)
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(DocumentCategory.entries.toTypedArray()) { category ->
                    val isSelected = !isVaultTabSelected && activeCategoryFilter == category
                    val chipColor = when (category) {
                        DocumentCategory.WORD -> WordBlue
                        DocumentCategory.EXCEL -> ExcelGreen
                        DocumentCategory.POWERPOINT -> PptOrange
                        DocumentCategory.PDF -> PdfRed
                        else -> TealAccent
                    }

                    Surface(
                        onClick = {
                            isVaultTabSelected = false
                            viewModel.setCategoryFilter(category)
                        },
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) chipColor else MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) chipColor else MaterialTheme.colorScheme.outlineVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = category.labelHindi,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Private Vault Tab Chip
                item {
                    val isSelected = isVaultTabSelected
                    Surface(
                        onClick = {
                            if (!isVaultUnlocked && viewModel.securityManager.isPinLockEnabled) {
                                showUnlockVaultDialog = true
                            } else {
                                isVaultTabSelected = true
                            }
                        },
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) VaultAmber else MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, VaultAmber)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isVaultUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = "Vault",
                                tint = if (isSelected) Color.White else VaultAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "सुरक्षित वॉल्ट (${vaultDocs.size})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // High Contrast Quick Hub Bar (2 Rows)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        QuickActionButton(
                            icon = Icons.Default.CameraAlt,
                            label = "कैमरा स्कैन",
                            color = TealAccent,
                            onClick = { launchCameraWithPermission() }
                        )
                        QuickActionButton(
                            icon = Icons.Default.FolderOpen,
                            label = "फाइल खोलें",
                            color = WordBlue,
                            onClick = { openDocumentLauncher.launch("*/*") }
                        )
                        QuickActionButton(
                            icon = Icons.Default.Badge,
                            label = "आईडी कार्ड A4",
                            color = VaultAmber,
                            onClick = { showIdCardDialog = true }
                        )
                        QuickActionButton(
                            icon = Icons.Default.TextFields,
                            label = "ओसीआर (OCR)",
                            color = PptOrange,
                            onClick = { onNavigateToOcrDigitizer(false) }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        QuickActionButton(
                            icon = Icons.Default.CallMerge,
                            label = "मर्ज / स्प्लिट",
                            color = EmeraldGreen,
                            onClick = { showMergeSplitDialog = true }
                        )
                        QuickActionButton(
                            icon = Icons.Default.QrCodeScanner,
                            label = "QR स्कैनर",
                            color = WordBlue,
                            onClick = { showQrScannerDialog = true }
                        )
                        QuickActionButton(
                            icon = Icons.Default.PhotoLibrary,
                            label = "फोटो से PDF",
                            color = TealAccent,
                            onClick = { galleryLauncher.launch("image/*") }
                        )
                        QuickActionButton(
                            icon = Icons.Default.DeleteSweep,
                            label = "रीसाइकल बिन",
                            color = PdfRed,
                            onClick = { showTrashDialog = true }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Document List Area
            if (isVaultTabSelected && !isVaultUnlocked && viewModel.securityManager.isPinLockEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Lock, contentDescription = "Locked", modifier = Modifier.size(64.dp), tint = VaultAmber)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("सुरक्षित वॉल्ट लॉक है", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { showUnlockVaultDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = VaultAmber)
                        ) {
                            Text("PIN डालकर अनलॉक करें")
                        }
                    }
                }
            } else if (filteredDocs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = "Empty",
                            modifier = Modifier.size(72.dp),
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isVaultTabSelected) "सुरक्षित वॉल्ट में कोई फाइल नहीं है" else "कोई दस्तावेज नहीं मिला",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "कैमरा से स्कैन करें या MS Word, Excel, PowerPoint, PDF फाइल खोलें।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { openDocumentLauncher.launch("*/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = WordBlue)
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = "Import File")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("डिवाइस से फाइल चुनें")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredDocs, key = { it.id }) { doc ->
                        DocumentCardItem(
                            doc = doc,
                            onClick = { onViewDocument(doc) },
                            onToggleVault = { viewModel.toggleDocumentVault(doc) },
                            onDelete = { viewModel.deleteDocument(doc.id) },
                            onShare = { viewModel.shareDocument(doc) },
                            onWatermark = {
                                selectedDocumentForWatermark = doc
                                showWatermarkDialog = true
                            },
                            onQuiz = {
                                selectedDocumentForQuiz = doc
                                showQuizDialog = true
                            },
                            onAudioNote = {
                                selectedDocumentForAudioNote = doc
                                showAudioNoteDialog = true
                            },
                            onPodcast = {
                                selectedDocumentForPodcast = doc
                                showPodcastDialog = true
                            }
                        )
                    }
                }
            }
        }
    }

    // Terms & Conditions Dialog for New Users (One-time popup)
    if (showTermsDialog) {
        TermsAndConditionsDialog(
            onAccepted = { showTermsDialog = false },
            isForcedNewUserMode = true
        )
    }

    // Unlock Vault PIN Dialog
    if (showUnlockVaultDialog) {
        AlertDialog(
            onDismissRequest = { showUnlockVaultDialog = false },
            title = { Text("सुरक्षित वॉल्ट अनलॉक करें (PIN Required)") },
            text = {
                Column {
                    Text("कृपया अपना 4-अंकों का वॉल्ट PIN दर्ज करें:")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4) pinInput = it },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = pinError,
                        label = { Text("4-Digit PIN") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError) {
                        Text("गलत PIN, फिर से प्रयास करें", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (viewModel.verifyVaultPin(pinInput)) {
                            showUnlockVaultDialog = false
                            isVaultTabSelected = true
                            pinInput = ""
                            pinError = false
                        } else {
                            pinError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultAmber)
                ) {
                    Text("अनलॉक करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnlockVaultDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Import / Scan Quick Menu Dialog
    if (showImportMenuDialog) {
        AlertDialog(
            onDismissRequest = { showImportMenuDialog = false },
            title = { Text("नया दस्तावेज या MS Office फाइल खोलें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            showImportMenuDialog = false
                            launchCameraWithPermission()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Scan")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("कैमरा फोटो से स्कैन करें (Scan Document)")
                    }

                    Button(
                        onClick = {
                            showImportMenuDialog = false
                            openDocumentLauncher.launch("*/*")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = WordBlue)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "Open Office")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("MS Word, Excel, PPT, PDF फाइल खोलें")
                    }

                    Button(
                        onClick = {
                            showImportMenuDialog = false
                            galleryLauncher.launch("image/*")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = "Gallery")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("गैलरी से फोटो चुनकर PDF बनाएं")
                    }

                    Text(
                        text = "अन्य टूल्स (PDF Utilities & Tools):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                showIdCardDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = VaultAmber),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ID कार्ड A4", fontSize = 10.sp)
                        }

                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                showMergeSplitDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.CallMerge, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("मर्ज / स्प्लिट", fontSize = 10.sp)
                        }

                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                showPdfRepairDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = PdfRed),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PDF रिपेयर", fontSize = 10.sp)
                        }

                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                showPdfCompareDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = WordBlue),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.Compare, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("तुलना (Diff)", fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                showHandwritingDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = PptOrange),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("हैंडराइटिंग", fontSize = 10.sp)
                        }

                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                showOmrScannerDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("OMR शीट", fontSize = 10.sp)
                        }

                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                showFormulaExtractorDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = VaultAmber),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.Functions, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("फॉर्मूला शीट", fontSize = 10.sp)
                        }

                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                val doc = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull()
                                if (doc != null) {
                                    selectedDocumentForPodcast = doc
                                    showPodcastDialog = true
                                } else {
                                    Toast.makeText(context, "सुनने के लिए कोई फाइल नहीं है", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.Headphones, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("पॉडकास्ट", fontSize = 10.sp)
                        }
                    }

                    Text(
                        text = "डेमो MS Office फाइल बनाएं (Sample Testing):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                viewModel.createSampleOfficeDoc(context, DocumentCategory.WORD)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = WordBlue),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Text("Word", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                viewModel.createSampleOfficeDoc(context, DocumentCategory.EXCEL)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = ExcelGreen),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Text("Excel", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                showImportMenuDialog = false
                                viewModel.createSampleOfficeDoc(context, DocumentCategory.POWERPOINT)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = PptOrange),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Text("PPT", fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showImportMenuDialog = false }) {
                    Text("बंद करें")
                }
            }
        )
    }

    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguageCode = selectedLanguage.code,
            onLanguageSelected = { lang ->
                languageManager.applyLanguageLocale(context, lang.code)
                selectedLanguage = lang
                showLanguageDialog = false
                Toast.makeText(
                    context,
                    "${lang.flagEmoji} ${lang.nativeName} (${lang.displayName}) भाषा चुनी गई!",
                    Toast.LENGTH_SHORT
                ).show()
            },
            onDismissRequest = { showLanguageDialog = false }
        )
    }

    // Merge & Split Dialog
    if (showMergeSplitDialog) {
        MergeSplitDialog(
            availableDocuments = publicDocs + vaultDocs,
            onMergeSelected = { title, ids ->
                viewModel.mergeDocuments(title, ids) { merged ->
                    showMergeSplitDialog = false
                    Toast.makeText(context, "'${merged.title}' मर्ज किया गया!", Toast.LENGTH_SHORT).show()
                }
            },
            onSplitSelected = { docId, title, startP, endP ->
                viewModel.splitDocument(docId, title, startP, endP) { splitDoc ->
                    showMergeSplitDialog = false
                    Toast.makeText(context, "'${splitDoc.title}' अलग किया गया!", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showMergeSplitDialog = false }
        )
    }

    // ID Card Scanner Dialog
    if (showIdCardDialog) {
        IdCardCaptureDialog(
            frontBitmap = idCardFrontBitmap,
            backBitmap = idCardBackBitmap,
            onRequestFrontCapture = {
                showIdCardDialog = false
                isCapturingFrontForId = true
                idCardCameraLauncher.launch()
            },
            onRequestBackCapture = {
                showIdCardDialog = false
                isCapturingFrontForId = false
                idCardCameraLauncher.launch()
            },
            onSaveIdCardPdf = { title ->
                val f = idCardFrontBitmap
                val b = idCardBackBitmap
                if (f != null || b != null) {
                    val front = f ?: Bitmap.createBitmap(400, 250, Bitmap.Config.ARGB_8888)
                    val back = b ?: Bitmap.createBitmap(400, 250, Bitmap.Config.ARGB_8888)

                    val result = PdfGenerator.createIdCardPdf(context, front, back, title)
                    viewModel.importOfficeFileFromUri(context, Uri.fromFile(result.file), isVaultTabSelected) {
                        Toast.makeText(context, "ID कार्ड A4 PDF तैयार है!", Toast.LENGTH_SHORT).show()
                    }
                }
                showIdCardDialog = false
                idCardFrontBitmap = null
                idCardBackBitmap = null
            },
            onDismissRequest = {
                showIdCardDialog = false
            }
        )
    }

    // QR & Barcode Scanner Dialog
    if (showQrScannerDialog) {
        QrBarcodeScannerDialog(
            onGeneratePdfFromQr = { title, content ->
                Toast.makeText(context, "QR / Barcode PDF Card बनाया गया!", Toast.LENGTH_SHORT).show()
                showQrScannerDialog = false
            },
            onDismissRequest = { showQrScannerDialog = false }
        )
    }

    // Recycle Bin Trash Can Dialog
    if (showTrashDialog) {
        AlertDialog(
            onDismissRequest = { showTrashDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = PdfRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("रीसाइकल बिन (Recycle Bin Trash)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("हटाए गए दस्तावेज़ यहाँ 30 दिनों तक सुरक्षित रहते हैं:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(10.dp))

                    if (trashDocs.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("रीसाइकल बिन खाली है (Trash is empty)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 240.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(trashDocs) { doc ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(doc.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${doc.pageCount} पन्ने • ${doc.fileSizeFormatted}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.restoreFromTrash(doc.id)
                                            Toast.makeText(context, "दस्तावेज़ वापस लाया गया", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.RestoreFromTrash, contentDescription = "Restore", tint = TealAccent)
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.deletePermanently(doc.id)
                                            Toast.makeText(context, "स्थायी रूप से हटाया गया", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Permanent Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrashDialog = false }) {
                    Text("बंद करें (Close)", color = TealAccent, fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    // Meta AI Global Assistant Dialog
    if (showMetaAiDialog) {
        AskPdfDialog(
            document = publicDocs.firstOrNull() ?: vaultDocs.firstOrNull(),
            onDismissRequest = { showMetaAiDialog = false }
        )
    }

    // PDF Corruption Repair Dialog
    if (showPdfRepairDialog) {
        PdfRepairDialog(
            availableDocuments = publicDocs + vaultDocs,
            onSaveRepairedDocument = { repairedFile ->
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(repairedFile), isVaultTabSelected) {
                    Toast.makeText(context, "रिपेयर की गई फाइल वॉल्ट/लिस्ट में जोड़ी गई", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showPdfRepairDialog = false }
        )
    }

    // PDF Compare Dialog
    if (showPdfCompareDialog) {
        PdfCompareDialog(
            availableDocuments = publicDocs + vaultDocs,
            onDismissRequest = { showPdfCompareDialog = false }
        )
    }

    // AI Handwriting Cleanup Dialog
    if (showHandwritingDialog) {
        HandwritingCleanupDialog(
            onRequestCamera = { launchCameraWithPermission() },
            onSaveCleanPdf = { pdfFile, title ->
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(pdfFile), isVaultTabSelected) {
                    Toast.makeText(context, "'$title' नोट्स सहेजे गए", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showHandwritingDialog = false }
        )
    }

    // OMR Sheet Evaluator Scanner Dialog
    if (showOmrScannerDialog) {
        OmrScannerDialog(
            onDismissRequest = { showOmrScannerDialog = false }
        )
    }

    // Formula & Equation Extractor Dialog
    if (showFormulaExtractorDialog) {
        FormulaExtractorDialog(
            onSaveFormulaSheet = { pdfFile, title ->
                viewModel.importOfficeFileFromUri(context, Uri.fromFile(pdfFile), isVaultTabSelected) {
                    Toast.makeText(context, "'$title' सहेजा गया", Toast.LENGTH_SHORT).show()
                }
            },
            onDismissRequest = { showFormulaExtractorDialog = false }
        )
    }

    // Podcast Background Audio Reader Dialog
    if (showPodcastDialog && selectedDocumentForPodcast != null) {
        PodcastModeDialog(
            document = selectedDocumentForPodcast!!,
            onDismissRequest = { showPodcastDialog = false }
        )
    }

    // Interactive Quiz Dialog
    if (showQuizDialog && selectedDocumentForQuiz != null) {
        FlashcardQuizDialog(
            document = selectedDocumentForQuiz!!,
            onDismissRequest = { showQuizDialog = false }
        )
    }

    // Dynamic Smart Watermark Dialog
    if (showWatermarkDialog && selectedDocumentForWatermark != null) {
        WatermarkStampDialog(
            initialWatermark = "FOR OFFICIAL USE ONLY",
            initialStamp = "CONFIDENTIAL",
            onApply = { wmText, stamp ->
                Toast.makeText(context, "वाटरमार्क '$wmText' व स्टैम्प '$stamp' लागू हुआ!", Toast.LENGTH_SHORT).show()
            },
            onDismissRequest = { showWatermarkDialog = false }
        )
    }

    // Voice-Annotated Audio Note Dialog
    if (showAudioNoteDialog && selectedDocumentForAudioNote != null) {
        AudioNoteRecorderDialog(
            initialAudioPath = selectedDocumentForAudioNote!!.audioNotePath,
            onAudioSaved = { savedPath ->
                Toast.makeText(context, "वॉइस नोट सहेजा गया!", Toast.LENGTH_SHORT).show()
            },
            onDismissRequest = { showAudioNoteDialog = false }
        )
    }
}

@Composable
fun QuickActionButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 4.dp)
    ) {
        Surface(
            color = color.copy(alpha = 0.15f),
            shape = CircleShape,
            modifier = Modifier.size(44.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun DocumentCardItem(
    doc: ScannedDocument,
    onClick: () -> Unit,
    onToggleVault: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onWatermark: () -> Unit = {},
    onQuiz: () -> Unit = {},
    onAudioNote: () -> Unit = {},
    onPodcast: () -> Unit = {}
) {
    var showMenu by remember { mutableStateOf(false) }

    val category = doc.categoryEnum
    val cardBadgeColor = when (category) {
        DocumentCategory.WORD -> WordBlue
        DocumentCategory.EXCEL -> ExcelGreen
        DocumentCategory.POWERPOINT -> PptOrange
        DocumentCategory.PDF -> PdfRed
        else -> TealAccent
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = cardBadgeColor,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when (category) {
                            DocumentCategory.WORD -> Icons.Default.Description
                            DocumentCategory.EXCEL -> Icons.Default.TableChart
                            DocumentCategory.POWERPOINT -> Icons.Default.Slideshow
                            else -> Icons.Default.Description
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = doc.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = cardBadgeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = category.labelEnglish,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = cardBadgeColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${doc.pageCount} पन्ने • ${doc.fileSizeFormatted} • ${doc.formattedDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menu")
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("देखें / खोलें") },
                        onClick = {
                            showMenu = false
                            onClick()
                        },
                        leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) }
                    )
                    DropdownMenuItem(
                        text = { Text("शेयर करें (Share)") },
                        onClick = {
                            showMenu = false
                            onShare()
                        },
                        leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) }
                    )
                    DropdownMenuItem(
                        text = { Text("वाटरमार्क जोड़ें (Watermark)") },
                        onClick = {
                            showMenu = false
                            onWatermark()
                        },
                        leadingIcon = { Icon(Icons.Default.Approval, contentDescription = null, tint = VaultAmber) }
                    )
                    DropdownMenuItem(
                        text = { Text("AI क्विज़ जनरेटर (Quiz)") },
                        onClick = {
                            showMenu = false
                            onQuiz()
                        },
                        leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = EmeraldGreen) }
                    )
                    DropdownMenuItem(
                        text = { Text("वॉइस नोट जोड़ें (Audio Note)") },
                        onClick = {
                            showMenu = false
                            onAudioNote()
                        },
                        leadingIcon = { Icon(Icons.Default.Mic, contentDescription = null, tint = PptOrange) }
                    )
                    DropdownMenuItem(
                        text = { Text("पॉडकस्ट ऑडियो मोड (Podcast)") },
                        onClick = {
                            showMenu = false
                            onPodcast()
                        },
                        leadingIcon = { Icon(Icons.Default.Headphones, contentDescription = null, tint = TealAccent) }
                    )
                    DropdownMenuItem(
                        text = { Text(if (doc.isPrivateVault) "वॉल्ट से निकालें" else "सुरक्षित वॉल्ट में भेजें") },
                        onClick = {
                            showMenu = false
                            onToggleVault()
                        },
                        leadingIcon = {
                            Icon(
                                if (doc.isPrivateVault) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = null,
                                tint = VaultAmber
                            )
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("हटाएं (Delete)", color = MaterialTheme.colorScheme.error) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                    )
                }
            }
        }
    }
}
