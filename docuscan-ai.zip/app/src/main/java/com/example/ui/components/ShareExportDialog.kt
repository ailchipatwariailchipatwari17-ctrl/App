package com.example.ui.components

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument

enum class ExportFormat {
    PDF,
    IMAGE_JPG
}

enum class PdfPageSizeOption(val label: String) {
    A4("A4 (210 × 297 mm)"),
    LETTER("Letter (8.5 × 11 in)"),
    LEGAL("Legal (8.5 × 14 in)"),
    ORIGINAL("Fit to Page Image")
}

/**
 * Authentic Share & Export Sheet matching Screenshot 1:
 * - Document thumbnail & title with edit pencil
 * - Format Switcher [ PDF ] | [ IMAGE(JPG) ]
 * - Enable Password Protection (Toggle)
 * - Searchable PDF with OCR Text (Toggle)
 * - Create Long Image (Toggle)
 * - Create ZIP File (Toggle)
 * - PDF Page Size (A4 selector)
 * - Size info with direct "Compress Now" action link
 * - Cancel / Share buttons
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareExportDialog(
    doc: ScannedDocument,
    thumbnailBitmap: Bitmap? = null,
    onDismiss: () -> Unit,
    onCompressRequested: () -> Unit,
    onRenameTitle: (String) -> Unit,
    onShareConfirmed: (
        format: ExportFormat,
        isPasswordProtected: Boolean,
        password: String,
        isSearchablePdf: Boolean,
        isLongImage: Boolean,
        isZipFile: Boolean,
        pageSize: PdfPageSizeOption
    ) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var currentTitle by remember { mutableStateOf(doc.title) }
    var isEditingTitle by remember { mutableStateOf(false) }

    var selectedFormat by remember { mutableStateOf(ExportFormat.PDF) }
    var isPasswordEnabled by remember { mutableStateOf(doc.isPrivateVault) }
    var passwordInput by remember { mutableStateOf("") }
    var isSearchablePdf by remember { mutableStateOf(doc.extractedText.isNotBlank()) }
    var isLongImage by remember { mutableStateOf(false) }
    var isZipFile by remember { mutableStateOf(false) }

    var selectedPageSize by remember { mutableStateOf(PdfPageSizeOption.A4) }
    var showPageSizeDropdown by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF161619),
        contentColor = Color.White,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // 1. Header with Thumbnail, Title & Edit Pencil (Screenshot 1)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Thumbnail Box
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(Color(0xFF22222A), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF383844), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (thumbnailBitmap != null) {
                        Image(
                            bitmap = thumbnailBitmap.asImageBitmap(),
                            contentDescription = "Thumb",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = if (selectedFormat == ExportFormat.PDF) Icons.Default.PictureAsPdf else Icons.Default.Image,
                            contentDescription = null,
                            tint = if (selectedFormat == ExportFormat.PDF) Color(0xFFFA0F00) else Color(0xFF00A2E8),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    if (isEditingTitle) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = currentTitle,
                                onValueChange = { currentTitle = it },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFF00A2E8),
                                    unfocusedBorderColor = Color(0xFF383844)
                                )
                            )
                            IconButton(onClick = {
                                isEditingTitle = false
                                onRenameTitle(currentTitle)
                            }) {
                                Icon(Icons.Default.Check, contentDescription = "Save", tint = Color(0xFF00A2E8))
                            }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Doc Name",
                                tint = Color(0xFF00A2E8),
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { isEditingTitle = true }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "${doc.pageCount} Files | ${doc.fileSizeFormatted}",
                        fontSize = 12.sp,
                        color = Color(0xFF9E9EA8)
                    )
                }
            }

            HorizontalDivider(
                color = Color(0xFF26262E),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // 2. Format Switcher Segmented Control [ PDF ] | [ IMAGE (JPG) ] (Screenshot 1)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .background(Color(0xFF0E0E12), RoundedCornerShape(22.dp))
                    .border(1.dp, Color(0xFF262630), RoundedCornerShape(22.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // PDF Option
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .background(
                            if (selectedFormat == ExportFormat.PDF) Color(0xFF00A2E8) else Color.Transparent,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedFormat = ExportFormat.PDF },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "PDF",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (selectedFormat == ExportFormat.PDF) Color.White else Color(0xFF9E9EA8)
                    )
                }

                // IMAGE(JPG) Option
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .background(
                            if (selectedFormat == ExportFormat.IMAGE_JPG) Color(0xFF00A2E8) else Color.Transparent,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedFormat = ExportFormat.IMAGE_JPG },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "IMAGE (JPG)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (selectedFormat == ExportFormat.IMAGE_JPG) Color.White else Color(0xFF9E9EA8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Option Toggles (Screenshot 1)

            // Option 1: Enable Password Protection
            ShareOptionToggleRow(
                title = "Enable Password Protection",
                subtitle = if (isPasswordEnabled) "Document is encrypted with pin/password" else "No password needed",
                isChecked = isPasswordEnabled,
                onCheckedChange = { isPasswordEnabled = it }
            )

            AnimatedVisibility(visible = isPasswordEnabled) {
                Column(modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)) {
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Enter Document Password", fontSize = 12.sp, color = Color(0xFFA0A0AB)) },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF00A2E8), modifier = Modifier.size(16.dp)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00A2E8),
                            unfocusedBorderColor = Color(0xFF383844)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Option 2: Searchable PDF with OCR Text
            if (selectedFormat == ExportFormat.PDF) {
                ShareOptionToggleRow(
                    title = "Searchable PDF with OCR Text",
                    subtitle = "Embed selectable, searchable Hindi & English OCR text",
                    isChecked = isSearchablePdf,
                    onCheckedChange = { isSearchablePdf = it }
                )
            }

            // Option 3: Create Long Image
            ShareOptionToggleRow(
                title = "Create Long Image",
                subtitle = "Merge all scan pages into a single vertical scrollable image",
                isChecked = isLongImage,
                onCheckedChange = { isLongImage = it }
            )

            // Option 4: Create ZIP File
            ShareOptionToggleRow(
                title = "Create ZIP File",
                subtitle = "Compress high-resolution document assets into an archive",
                isChecked = isZipFile,
                onCheckedChange = { isZipFile = it }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 4. PDF Page Size Selector (Screenshot 1)
            if (selectedFormat == ExportFormat.PDF) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PDF Page Size",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    )

                    Box {
                        Row(
                            modifier = Modifier
                                .background(Color(0xFF22222A), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF3A3A48), RoundedCornerShape(8.dp))
                                .clickable { showPageSizeDropdown = true }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedPageSize.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00A2E8)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Select size",
                                tint = Color(0xFF00A2E8),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showPageSizeDropdown,
                            onDismissRequest = { showPageSizeDropdown = false },
                            modifier = Modifier.background(Color(0xFF1E1E26))
                        ) {
                            PdfPageSizeOption.values().forEach { sizeOpt ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = sizeOpt.label,
                                            fontWeight = if (selectedPageSize == sizeOpt) FontWeight.Bold else FontWeight.Normal,
                                            color = if (selectedPageSize == sizeOpt) Color(0xFF00A2E8) else Color.White
                                        )
                                    },
                                    onClick = {
                                        selectedPageSize = sizeOpt
                                        showPageSizeDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 5. Size info with direct "Compress Now" action link (Screenshot 1)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0E0E12), RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Size: ${doc.fileSizeFormatted}",
                    fontSize = 12.sp,
                    color = Color(0xFFA0A0AB),
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = "Compress Now",
                    fontSize = 12.sp,
                    color = Color(0xFF00A2E8),
                    fontWeight = FontWeight.Bold,
                    textDecoration = TextDecoration.Underline,
                    modifier = Modifier.clickable {
                        onDismiss()
                        onCompressRequested()
                    }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 6. Bottom Action Buttons: [ CANCEL ] and [ SHARE ] (Screenshot 1)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // CANCEL Button (Outlined)
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF383846)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color(0xFF14141A),
                        contentColor = Color(0xFFA0A0AB)
                    )
                ) {
                    Text(
                        text = "CANCEL",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFFA0A0AB)
                    )
                }

                // SHARE Button (Teal / Cyan Filled)
                Button(
                    onClick = {
                        onShareConfirmed(
                            selectedFormat,
                            isPasswordEnabled,
                            passwordInput,
                            isSearchablePdf,
                            isLongImage,
                            isZipFile,
                            selectedPageSize
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00A2E8),
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.size(18.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SHARE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun ShareOptionToggleRow(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!isChecked) }
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = Color(0xFF888894),
                lineHeight = 13.sp
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF00A2E8),
                uncheckedThumbColor = Color(0xFF888898),
                uncheckedTrackColor = Color(0xFF22222A)
            ),
            modifier = Modifier.size(width = 38.dp, height = 24.dp)
        )
    }
}
