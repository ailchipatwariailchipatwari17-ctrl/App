package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ScanFilter
import com.example.data.model.ScannedDocument
import com.example.data.util.ImageProcessor
import com.example.ui.DocumentViewModel
import com.example.ui.components.EdgeCropOverlay
import com.example.ui.components.ShareExportDialog
import com.example.ui.components.SignaturePadDialog
import com.example.ui.components.WatermarkStampDialog
import com.example.util.AppThemeManager
import com.example.util.LanguageManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanEditorScreen(
    viewModel: DocumentViewModel,
    onBack: () -> Unit,
    onNavigateToCamera: () -> Unit,
    onSavedAndShared: ((ScannedDocument) -> Unit)? = null,
    onNavigateToOcr: (Boolean) -> Unit
) {
    val currentPalette by AppThemeManager.currentPaletteFlow.collectAsStateWithLifecycle()
    val workingPages by viewModel.workingPages.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val edgeCornerPoints by viewModel.edgeCornerPoints.collectAsStateWithLifecycle()
    val showCropAfterCapture by viewModel.showCropAfterCapture.collectAsStateWithLifecycle()

    var isCropMode by remember { mutableStateOf(true) }
    var activePageIndex by remember { mutableIntStateOf(0) }
    var docTitle by remember {
        mutableStateOf("DocScanner_${SimpleDateFormat("dd-MMM-yyyy_hh-mm_a", Locale.getDefault()).format(Date())}")
    }
    var showRenameDialog by remember { mutableStateOf(false) }
    var tempRenameText by remember { mutableStateOf("") }
    var filterDropdownExpanded by remember { mutableStateOf(false) }
    var isSavingPdf by remember { mutableStateOf(false) }

    var showSignatureDialog by remember { mutableStateOf(false) }
    var showWatermarkDialog by remember { mutableStateOf(false) }
    var watermarkText by remember { mutableStateOf("") }

    var newlySavedDocForShare by remember { mutableStateOf<ScannedDocument?>(null) }
    var showShareSheet by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val languageManager = remember { LanguageManager(context) }
    val scope = rememberCoroutineScope()

    // Gallery Multiple Image Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<android.net.Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    val stream = context.contentResolver.openInputStream(uri)
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        viewModel.addWorkingPage(bmp)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            isCropMode = true
        }
    }

    // Save and launch share helper
    fun finalizeAndShareDocument() {
        if (isSavingPdf) return
        isSavingPdf = true
        // Apply current crop before saving if in crop mode
        if (workingPages.isNotEmpty() && activePageIndex in workingPages.indices && isCropMode) {
            viewModel.applyCropToCurrentPage(activePageIndex)
        }

        viewModel.convertToPdfAndSave(docTitle, false) { savedDoc ->
            isSavingPdf = false
            newlySavedDocForShare = savedDoc
            showShareSheet = true
            Toast.makeText(context, "दस्तावेज़ तैयार हो गया! 📄", Toast.LENGTH_SHORT).show()
        }
    }

    // EMPTY WORKSPACE STATE -> Doc Scanner Initial Hub
    if (workingPages.isEmpty()) {
        Scaffold(
            containerColor = Color(0xFF0A0A0E),
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = languageManager.t("create_pdf"),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF121218))
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF14141C)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282834))
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(Color(0xFF0F0F14), CircleShape)
                                .border(1.8.dp, Color(0xFF00C2FF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(32.dp),
                                tint = Color(0xFF00C2FF)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = languageManager.t("create_pdf"),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "HD Camera Scanner, 8-Point Crop & Multi-page PDF Creator",
                            fontSize = 12.sp,
                            color = Color(0xFF9E9EA8),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(28.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(24.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AcrobatOutlineActionItem(
                                icon = Icons.Default.CameraAlt,
                                label = languageManager.t("camera_scan"),
                                isSelected = true,
                                onClick = onNavigateToCamera
                            )

                            AcrobatOutlineActionItem(
                                icon = Icons.Default.PhotoLibrary,
                                label = languageManager.t("gallery_pick"),
                                onClick = { galleryLauncher.launch("image/*") }
                            )
                        }
                    }
                }
            }
        }
        return
    }

    val safeIndex = activePageIndex.coerceIn(0, (workingPages.size - 1).coerceAtLeast(0))
    val activeBitmap = workingPages.getOrElse(safeIndex) { workingPages[0] }
    val filteredPreviewBitmap = remember(activeBitmap, selectedFilter) {
        ImageProcessor.applyFilter(activeBitmap, selectedFilter)
    }

    // Initialize 8-point crop overlay corners if needed
    LaunchedEffect(activeBitmap) {
        if (edgeCornerPoints.isEmpty() || edgeCornerPoints.size < 4) {
            viewModel.resetCropToFree()
        }
    }

    // ---------------------------------------------------------------------
    // PHASE A: 8-POINT CROP OVERLAY SCREEN (Doc Scanner Boundary Adjustment)
    // ---------------------------------------------------------------------
    if (isCropMode) {
        Scaffold(
            containerColor = Color(0xFF000000), // Pure Black canvas
            topBar = {
                TopAppBar(
                    title = {
                        Column(
                            modifier = Modifier.clickable {
                                tempRenameText = docTitle
                                showRenameDialog = true
                            }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = docTitle,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.Edit, contentDescription = "Rename", tint = Color(0xFF00C2FF), modifier = Modifier.size(14.dp))
                            }
                            Text(
                                text = "Crop (${activePageIndex + 1}/${workingPages.size})",
                                fontSize = 11.sp,
                                color = Color(0xFF00C2FF),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            if (activePageIndex > 0) {
                                activePageIndex--
                            } else {
                                onNavigateToCamera()
                            }
                        }) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                    },
                    actions = {
                        // Full Selection / No Crop
                        IconButton(onClick = {
                            viewModel.resetCropToFree()
                            Toast.makeText(context, "Full document selected", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(
                                Icons.Default.CropFree,
                                contentDescription = "Full Page",
                                tint = Color(0xFF00C2FF)
                            )
                        }

                        // Done / Review Document button
                        TextButton(
                            onClick = {
                                viewModel.applyCropToCurrentPage(activePageIndex)
                                isCropMode = false
                            }
                        ) {
                            Text(
                                text = "समीक्षा करें ✓",
                                color = Color(0xFF00E676),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF101014))
                )
            },
            bottomBar = {
                // Bottom Action Bar: [ RETAKE ] and [ CONTINUE ]
                Surface(
                    color = Color(0xFF0D0D10),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E26))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // RETAKE Button
                        OutlinedButton(
                            onClick = {
                                viewModel.removeWorkingPage(activePageIndex)
                                onNavigateToCamera()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF00C2FF)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFF14141A),
                                contentColor = Color(0xFF00C2FF)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Retake",
                                modifier = Modifier.size(18.dp),
                                tint = Color(0xFF00C2FF)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "RETAKE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF00C2FF)
                            )
                        }

                        // CONTINUE Button -> Advances to next page or finishes crop
                        Button(
                            onClick = {
                                viewModel.applyCropToCurrentPage(activePageIndex)

                                if (activePageIndex < workingPages.size - 1) {
                                    activePageIndex++
                                    viewModel.resetCropToFree()
                                } else {
                                    // All pages cropped -> switch to Document Review & Filter Screen
                                    isCropMode = false
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF00C2FF),
                                contentColor = Color.White
                            ),
                            enabled = !isSavingPdf
                        ) {
                            Text(
                                text = if (activePageIndex < workingPages.size - 1) "CONTINUE (${activePageIndex + 1}/${workingPages.size})" else "CONTINUE ✓",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Multi-Page Horizontal Strip
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0E0E12))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    itemsIndexed(workingPages) { index, bmp ->
                        val isSelected = index == activePageIndex
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color(0xFF00C2FF) else Color(0xFF2E2E38),
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .clickable { activePageIndex = index },
                            contentAlignment = Alignment.TopEnd
                        ) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Page $index",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(topEnd = 4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("${index + 1}", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(
                                onClick = {
                                    viewModel.removeWorkingPage(index)
                                    activePageIndex = activePageIndex.coerceAtMost((workingPages.size - 2).coerceAtLeast(0))
                                },
                                modifier = Modifier.size(18.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete Page",
                                    tint = Color.Red,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }

                    // Add Next Photo Thumbnail Card (+ और फोटो जोड़ें)
                    item {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .background(Color(0xFF14141C), RoundedCornerShape(6.dp))
                                .border(1.dp, Color(0xFF00C2FF).copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .clickable { onNavigateToCamera() },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.AddAPhoto, contentDescription = "Add Page", tint = Color(0xFF00C2FF), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("+ जोड़ें", color = Color(0xFF00C2FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 1. Image Canvas with 8-Point Crop Overlay
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                        .background(Color(0xFF000000))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = filteredPreviewBitmap.asImageBitmap(),
                        contentDescription = "Page Preview",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )

                    // 8-Point Draggable Crop Overlay
                    EdgeCropOverlay(
                        normalizedPoints = if (edgeCornerPoints.size >= 4) edgeCornerPoints else listOf(
                            PointF(0.05f, 0.05f),
                            PointF(0.95f, 0.05f),
                            PointF(0.95f, 0.95f),
                            PointF(0.05f, 0.95f)
                        ),
                        imageWidth = filteredPreviewBitmap.width.toFloat(),
                        imageHeight = filteredPreviewBitmap.height.toFloat(),
                        onPointMoved = { index, newNormX, newNormY ->
                            viewModel.updateCornerPoint(index, newNormX, newNormY)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 2. Info Text: "ℹ Drag the points to adjust the borders."
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFFA0A0AB),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Drag the points to adjust the borders.",
                        fontSize = 12.sp,
                        color = Color(0xFFD0D0D8),
                        fontWeight = FontWeight.Normal
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 3. Current Filter Dropdown: "CURRENT FILTER : [ MAGIC COLOR ▾ ]"
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Text(
                        text = "CURRENT FILTER : ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8E8E98)
                    )

                    Box {
                        Row(
                            modifier = Modifier
                                .clickable { filterDropdownExpanded = true }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedFilter.titleEnglish.uppercase(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00C2FF)
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Dropdown",
                                tint = Color(0xFF00C2FF),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = filterDropdownExpanded,
                            onDismissRequest = { filterDropdownExpanded = false },
                            modifier = Modifier.background(Color(0xFF1E1E26))
                        ) {
                            ScanFilter.values().forEach { filter ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = filter.titleEnglish.uppercase(),
                                            fontWeight = if (selectedFilter == filter) FontWeight.Bold else FontWeight.Normal,
                                            color = if (selectedFilter == filter) Color(0xFF00C2FF) else Color.White
                                        )
                                    },
                                    onClick = {
                                        viewModel.setFilter(filter)
                                        filterDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // 4. Middle Action Row: Rotate, Crop Free, Doc Name
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Rotate Button
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            viewModel.rotateCurrentPage(activePageIndex)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.RotateRight,
                            contentDescription = "Rotate",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Rotate",
                            fontSize = 12.sp,
                            color = Color(0xFFE0E0E8),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Crop Free Button
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            viewModel.resetCropToFree()
                            Toast.makeText(context, "Crop bounds free", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.CropFree,
                            contentDescription = "Crop free",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Crop free",
                            fontSize = 12.sp,
                            color = Color(0xFFE0E0E8),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Doc Name Button
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            tempRenameText = docTitle
                            showRenameDialog = true
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Doc Name",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Doc Name",
                            fontSize = 12.sp,
                            color = Color(0xFFE0E0E8),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 5. Setting Toggle Option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .clickable {
                            viewModel.setShowCropAfterCapture(!showCropAfterCapture)
                        },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = Color(0xFF888898),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Show crop screen after every capture.",
                        fontSize = 12.sp,
                        color = Color(0xFF00C2FF),
                        textDecoration = TextDecoration.Underline,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Switch(
                        checked = showCropAfterCapture,
                        onCheckedChange = { viewModel.setShowCropAfterCapture(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF00C2FF),
                            uncheckedThumbColor = Color(0xFF888898),
                            uncheckedTrackColor = Color(0xFF22222A)
                        ),
                        modifier = Modifier.size(width = 38.dp, height = 24.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    } else {
        // ---------------------------------------------------------------------
        // PHASE B: SCANNED DOCUMENT REVIEW & FILTER SCREEN (Doc Scanner Viewer)
        // ---------------------------------------------------------------------
        Scaffold(
            containerColor = Color(0xFF0D0D12),
            topBar = {
                TopAppBar(
                    title = {
                        Column(
                            modifier = Modifier.clickable {
                                tempRenameText = docTitle
                                showRenameDialog = true
                            }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = docTitle,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.Edit, contentDescription = "Rename", tint = Color(0xFF00C2FF), modifier = Modifier.size(14.dp))
                            }
                            Text(
                                text = "Page ${activePageIndex + 1} of ${workingPages.size}",
                                fontSize = 11.sp,
                                color = Color(0xFF00C2FF),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { isCropMode = true }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Crop", tint = Color.White)
                        }
                    },
                    actions = {
                        // Share Icon
                        IconButton(onClick = { finalizeAndShareDocument() }) {
                            Icon(Icons.Default.Share, contentDescription = "Share", tint = Color(0xFF00C2FF))
                        }

                        // Save / Share Text Button
                        TextButton(
                            onClick = { finalizeAndShareDocument() },
                            enabled = !isSavingPdf
                        ) {
                            Text(
                                text = "शेयर / सेव करें",
                                color = Color(0xFF00E676),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF14141C))
                )
            },
            bottomBar = {
                // Bottom Tools & Share Bar (Doc Scanner style)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF121218))
                        .navigationBarsPadding()
                ) {
                    // Doc Scanner Tool Bar Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. Add Page (Camera)
                        DocScannerBottomToolItem(
                            icon = Icons.Default.AddAPhoto,
                            label = "Add Page",
                            onClick = onNavigateToCamera
                        )

                        // 2. Re-crop (Back to 8-Point Overlay)
                        DocScannerBottomToolItem(
                            icon = Icons.Default.Crop,
                            label = "Crop",
                            onClick = { isCropMode = true }
                        )

                        // 3. Rotate
                        DocScannerBottomToolItem(
                            icon = Icons.AutoMirrored.Filled.RotateRight,
                            label = "Rotate",
                            onClick = { viewModel.rotateCurrentPage(activePageIndex) }
                        )

                        // 4. OCR
                        DocScannerBottomToolItem(
                            icon = Icons.Default.TextFields,
                            label = "OCR Text",
                            onClick = { onNavigateToOcr(false) }
                        )

                        // 5. Signature
                        DocScannerBottomToolItem(
                            icon = Icons.Default.Create,
                            label = "Signature",
                            onClick = { showSignatureDialog = true }
                        )

                        // 6. Watermark
                        DocScannerBottomToolItem(
                            icon = Icons.Default.WaterDrop,
                            label = "Watermark",
                            onClick = { showWatermarkDialog = true }
                        )

                        // 7. Delete Page
                        DocScannerBottomToolItem(
                            icon = Icons.Default.Delete,
                            label = "Delete",
                            iconTint = Color(0xFFFF5252),
                            onClick = {
                                viewModel.removeWorkingPage(activePageIndex)
                                activePageIndex = activePageIndex.coerceAtMost((workingPages.size - 2).coerceAtLeast(0))
                            }
                        )
                    }

                    // Main Big Action Buttons (Share PDF & Save)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { finalizeAndShareDocument() },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF00C2FF)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFF181822),
                                contentColor = Color(0xFF00C2FF)
                            )
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF00C2FF))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SAVE TO STORAGE", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF00C2FF))
                        }

                        Button(
                            onClick = { finalizeAndShareDocument() },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF00C2FF),
                                contentColor = Color.White
                            ),
                            enabled = !isSavingPdf
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SHARE PDF / JPG", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Multi-Page Thumbnails Strip
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF101016))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    itemsIndexed(workingPages) { index, bmp ->
                        val isSelected = index == activePageIndex
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color(0xFF00C2FF) else Color(0xFF2E2E38),
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .clickable { activePageIndex = index },
                            contentAlignment = Alignment.TopEnd
                        ) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Page $index",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(topEnd = 4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("${index + 1}", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Add Next Photo Card
                    item {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .background(Color(0xFF161622), RoundedCornerShape(6.dp))
                                .border(1.dp, Color(0xFF00C2FF).copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .clickable { onNavigateToCamera() },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.AddAPhoto, contentDescription = "Add Page", tint = Color(0xFF00C2FF), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("+ जोड़ें", color = Color(0xFF00C2FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // High-Resolution Scanned Document Preview
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp)
                        .padding(horizontal = 16.dp)
                        .background(Color(0xFF050508), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF222230), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = filteredPreviewBitmap.asImageBitmap(),
                        contentDescription = "Document Page Preview",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        contentScale = ContentScale.Fit
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Color Filter Strip (Doc Scanner Signature Filters)
                Text(
                    text = "COLOR FILTERS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8E8E98),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(ScanFilter.values()) { _, filter ->
                        val isSelected = selectedFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setFilter(filter) },
                            label = {
                                Text(
                                    text = filter.titleEnglish,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF00C2FF),
                                selectedLabelColor = Color.White,
                                containerColor = Color(0xFF1A1A24),
                                labelColor = Color(0xFFD0D0DC)
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) Color(0xFF00C2FF) else Color(0xFF2E2E3C)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Share Export Bottom Sheet Dialog
    if (showShareSheet && newlySavedDocForShare != null) {
        ShareExportDialog(
            doc = newlySavedDocForShare!!,
            thumbnailBitmap = workingPages.firstOrNull(),
            onDismiss = {
                showShareSheet = false
                onSavedAndShared?.invoke(newlySavedDocForShare!!)
            },
            onCompressRequested = {
                viewModel.shareDocument(newlySavedDocForShare!!)
            },
            onRenameTitle = { newTitle ->
                viewModel.renameDocument(newlySavedDocForShare!!.id, newTitle)
            },
            onShareConfirmed = { format, isPasswordProtected, password, isSearchablePdf, isLongImage, isZipFile, pageSize ->
                showShareSheet = false
                viewModel.shareDocument(newlySavedDocForShare!!)
                onSavedAndShared?.invoke(newlySavedDocForShare!!)
            }
        )
    }

    // Signature Pad Dialog
    if (showSignatureDialog) {
        SignaturePadDialog(
            onDismissRequest = { showSignatureDialog = false },
            onSignatureSaved = { sigBitmap ->
                showSignatureDialog = false
                viewModel.applySignatureToCurrentPage(activePageIndex, sigBitmap)
                Toast.makeText(context, "हस्ताक्षर दस्तावेज़ पर जुड़ गया! ✍️", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Watermark Stamp Dialog
    if (showWatermarkDialog) {
        WatermarkStampDialog(
            initialWatermark = watermarkText,
            initialStamp = "NONE",
            onDismissRequest = { showWatermarkDialog = false },
            onApply = { wmText, stamp ->
                watermarkText = wmText
                showWatermarkDialog = false
                viewModel.applyWatermarkToCurrentPage(activePageIndex, wmText, stamp)
                Toast.makeText(context, "वॉटरमार्क लागू हो गया! 💧", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Rename Document Dialog
    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            containerColor = Color(0xFF1A1A22),
            title = {
                Text(
                    text = "Rename Document",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 18.sp
                )
            },
            text = {
                OutlinedTextField(
                    value = tempRenameText,
                    onValueChange = { tempRenameText = it },
                    label = { Text("Document Name", color = Color(0xFFA0A0AB)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF00C2FF),
                        unfocusedBorderColor = Color(0xFF3E3E4C)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (tempRenameText.isNotBlank()) {
                            docTitle = tempRenameText.trim()
                        }
                        showRenameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C2FF))
                ) {
                    Text("Save", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancel", color = Color(0xFFA0A0AB))
                }
            }
        )
    }
}

@Composable
fun DocScannerBottomToolItem(
    icon: ImageVector,
    label: String,
    iconTint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = iconTint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color(0xFFC8C8D4),
            fontWeight = FontWeight.Medium
        )
    }
}

/**
 * Acrobat Style Outline Action Item:
 * - Logo box: Background Black, Outline White, Icon White
 * - On Click: Turns Selected Theme Palette Accent
 * - Underneath: Single chosen language text
 */
@Composable
fun AcrobatOutlineActionItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    var isClickedActive by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val active = isSelected || isClickedActive
    val borderColor by animateColorAsState(
        targetValue = if (active) Color(0xFF00C2FF) else Color.White,
        label = "border_color"
    )
    val bgColor by animateColorAsState(
        targetValue = if (active) Color(0xFF00283A) else Color(0xFF0F0F14),
        label = "bg_color"
    )
    val iconColor by animateColorAsState(
        targetValue = if (active) Color(0xFF00C2FF) else Color.White,
        label = "icon_color"
    )
    val labelColor by animateColorAsState(
        targetValue = if (active) Color(0xFF00C2FF) else Color(0xFFE0E0EA),
        label = "label_color"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .clickable {
                isClickedActive = true
                scope.launch {
                    kotlinx.coroutines.delay(350)
                    isClickedActive = false
                }
                onClick()
            }
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(bgColor, CircleShape)
                .border(1.5.dp, borderColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(24.dp),
                tint = iconColor
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            color = labelColor,
            textAlign = TextAlign.Center,
            lineHeight = 12.sp,
            maxLines = 2
        )
    }
}
