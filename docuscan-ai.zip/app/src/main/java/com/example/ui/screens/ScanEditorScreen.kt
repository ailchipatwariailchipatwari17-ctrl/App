package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ScanFilter
import com.example.data.util.ImageProcessor
import com.example.ui.DocumentViewModel
import com.example.ui.components.CompressionDialog
import com.example.ui.components.EdgeCropOverlay
import com.example.ui.components.FilterChipSelector
import com.example.ui.theme.PdfRed
import com.example.util.LanguageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanEditorScreen(
    viewModel: DocumentViewModel,
    onBack: () -> Unit,
    onSavedAndShared: () -> Unit,
    onNavigateToOcr: (Boolean) -> Unit
) {
    val workingPages by viewModel.workingPages.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val selectedCompression by viewModel.selectedCompression.collectAsStateWithLifecycle()
    val edgeCornerPoints by viewModel.edgeCornerPoints.collectAsStateWithLifecycle()

    var activePageIndex by remember { mutableIntStateOf(0) }
    var isCropMode by remember { mutableStateOf(false) }
    var docTitle by remember { mutableStateOf("Scan_${System.currentTimeMillis() / 1000}") }
    var isPrivateVault by remember { mutableStateOf(false) }
    var showCompressionDialog by remember { mutableStateOf(false) }
    var isSavingPdf by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val languageManager = remember { LanguageManager(context) }
    val scope = rememberCoroutineScope()

    // Camera Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            viewModel.addWorkingPage(bitmap)
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "कैमरा अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCameraWithPermission() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            cameraLauncher.launch(null)
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Gallery Multiple Image Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<android.net.Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    val stream = context.contentResolver.openInputStream(uri)
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        viewModel.addWorkingPage(bmp)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    // EMPTY WORKSPACE STATE -> Adobe Acrobat Dark Home Theme
    if (workingPages.isEmpty()) {
        Scaffold(
            containerColor = Color(0xFF0A0A0E),
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = languageManager.t("create_pdf"),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF121218))
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF14141C)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282834))
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Acrobat White Outline Logo Icon Box that glows
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(Color(0xFF0F0F14), CircleShape)
                                .border(1.8.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(32.dp),
                                tint = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = languageManager.t("create_pdf"),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "HD Scan, Edge Crop & Multi-page PDF Engine",
                            fontSize = 12.sp,
                            color = Color(0xFF9E9EA8),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(28.dp))

                        // Tools Grid in Acrobat Outline Style
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(24.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AcrobatOutlineActionItem(
                                icon = Icons.Default.CameraAlt,
                                label = languageManager.t("camera_scan"),
                                onClick = { launchCameraWithPermission() }
                            )

                            AcrobatOutlineActionItem(
                                icon = Icons.Default.PhotoLibrary,
                                label = languageManager.t("gallery_pick"),
                                onClick = { galleryLauncher.launch("image/*") }
                            )
                        }
                    }
                }
            }
        }
        return
    }

    val activeBitmap = workingPages.getOrElse(activePageIndex) { workingPages[0] }
    val filteredPreviewBitmap = remember(activeBitmap, selectedFilter) {
        ImageProcessor.applyFilter(activeBitmap, selectedFilter)
    }

    // ACTIVE EDITOR WORKSPACE -> Sleek Dark Acrobat Theme
    Scaffold(
        containerColor = Color(0xFF0A0A0E),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = languageManager.t("create_pdf"),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp
                        )
                        Text(
                            text = "Page ${activePageIndex + 1} of ${workingPages.size}",
                            fontSize = 11.sp,
                            color = Color(0xFFAAAAAA)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    // Quick Action: Add More Photos
                    IconButton(onClick = { galleryLauncher.launch("image/*") }) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = "Add Images", tint = Color.White)
                    }
                    // Quick Action: Camera Capture
                    IconButton(onClick = { launchCameraWithPermission() }) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Camera", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF141418))
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // Document Image Preview Container (Sleek Canvas with Edge Detection)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(Color(0xFF0D0D12))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = filteredPreviewBitmap.asImageBitmap(),
                    contentDescription = "Scan Page Preview",
                    modifier = Modifier
                        .fillMaxSize()
                        .border(1.dp, Color(0xFF22222C), RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Fit
                )

                if (isCropMode) {
                    EdgeCropOverlay(
                        cornerPoints = edgeCornerPoints,
                        onCornerMoved = { index, point ->
                            viewModel.updateCornerPoint(index, point)
                        }
                    )
                }
            }

            // Crop Apply Confirmation Bar
            if (isCropMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1A1A24))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = languageManager.t("crop_edges"),
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Button(
                        onClick = {
                            viewModel.applyCropToCurrentPage(activePageIndex)
                            isCropMode = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFA0F00)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Done Crop", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Apply", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Multi-Page Thumbnails Row
            if (workingPages.size > 1) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF121218))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(workingPages) { index, bmp ->
                        val isSelected = index == activePageIndex
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color(0xFFFA0F00) else Color(0xFF33333F),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { activePageIndex = index },
                            contentAlignment = Alignment.TopEnd
                        ) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Page $index",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            IconButton(
                                onClick = { viewModel.removeWorkingPage(index) },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete Page",
                                    tint = Color.Red,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tools Row (White Outline Logo Icons, Black Background, Turn Red on Click)
            Text(
                text = "TOOLS & EDITING",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF888898),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    AcrobatOutlineActionItem(
                        icon = Icons.Default.Crop,
                        label = languageManager.t("crop_edges"),
                        isSelected = isCropMode,
                        onClick = { isCropMode = !isCropMode }
                    )
                }
                item {
                    AcrobatOutlineActionItem(
                        icon = Icons.Default.RotateRight,
                        label = languageManager.t("rotate"),
                        onClick = { viewModel.rotateCurrentPage(activePageIndex) }
                    )
                }
                item {
                    AcrobatOutlineActionItem(
                        icon = Icons.Default.Compress,
                        label = languageManager.t("compress_pdf"),
                        onClick = { showCompressionDialog = true }
                    )
                }
                item {
                    AcrobatOutlineActionItem(
                        icon = if (isPrivateVault) Icons.Default.Lock else Icons.Default.LockOpen,
                        label = languageManager.t("set_password"),
                        isSelected = isPrivateVault,
                        onClick = { isPrivateVault = !isPrivateVault }
                    )
                }
                item {
                    AcrobatOutlineActionItem(
                        icon = Icons.Default.TextFields,
                        label = languageManager.t("ocr_text"),
                        onClick = {
                            viewModel.performOcrOnImage(filteredPreviewBitmap, false)
                            onNavigateToOcr(false)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Selector Bar
            FilterChipSelector(
                selectedFilter = selectedFilter,
                onFilterSelected = { viewModel.setFilter(it) },
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Create PDF & Export Card (Dark Theme matching Home Screen)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14141C)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282836))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = docTitle,
                        onValueChange = { docTitle = it },
                        label = { Text("PDF Title", color = Color(0xFFAAAAAA)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFA0F00),
                            unfocusedBorderColor = Color(0xFF3A3A4A)
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { showCompressionDialog = true }
                        ) {
                            Icon(Icons.Default.Compress, contentDescription = "Compression", tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(languageManager.t("compress_pdf"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(selectedCompression.labelHindi, fontSize = 10.sp, color = Color(0xFFFA0F00))
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isPrivateVault) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = "Vault",
                                tint = if (isPrivateVault) Color(0xFFFA0F00) else Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(languageManager.t("set_password"), fontSize = 12.sp, color = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = isPrivateVault,
                                onCheckedChange = { isPrivateVault = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFFA0F00)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Primary Create PDF & Share Button (Acrobat Red #FA0F00)
                    Button(
                        onClick = {
                            if (isSavingPdf) return@Button
                            isSavingPdf = true
                            viewModel.convertToPdfAndSave(docTitle, isPrivateVault) { savedDoc ->
                                isSavingPdf = false
                                viewModel.shareDocument(savedDoc)
                                onSavedAndShared()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFA0F00)),
                        shape = RoundedCornerShape(24.dp),
                        enabled = !isSavingPdf
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "PDF Share", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSavingPdf) "Saving..." else languageManager.t("share_pdf"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showCompressionDialog) {
        CompressionDialog(
            currentLevel = selectedCompression,
            onLevelSelected = {
                viewModel.setCompression(it)
                showCompressionDialog = false
            },
            onDismiss = { showCompressionDialog = false }
        )
    }
}

/**
 * Acrobat Style Outline Action Item:
 * - Logo box: Background Black, Outline White, Icon White
 * - On Click: Turns Adobe Acrobat Red (#FA0F00)
 * - Underneath: Single chosen language text
 */
@Composable
fun AcrobatOutlineActionItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    var isClickedActive by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val active = isSelected || isClickedActive
    val borderColor by animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color.White,
        label = "border_color"
    )
    val bgColor by animateColorAsState(
        targetValue = if (active) Color(0xFF280808) else Color(0xFF0F0F14),
        label = "bg_color"
    )
    val iconColor by animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color.White,
        label = "icon_color"
    )
    val labelColor by animateColorAsState(
        targetValue = if (active) Color(0xFFFA0F00) else Color(0xFFE0E0EA),
        label = "label_color"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .clickable {
                isClickedActive = true
                scope.launch {
                    kotlinx.coroutines.delay(350)
                    isClickedActive = false
                }
                onClick()
            }
    ) {
        Box(
            modifier = Modifier.size(54.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(bgColor, CircleShape)
                    .border(1.5.dp, borderColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            color = labelColor,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 13.sp,
            overflow = TextOverflow.Ellipsis
        )
    }
}
