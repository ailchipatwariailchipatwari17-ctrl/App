package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class PdfAppSuite(val displayNameHindi: String, val displayNameEn: String, val badgeColor: Color, val icon: ImageVector) {
    ALL("सभी टूल्स", "All Tools", Color(0xFFEF4444), Icons.Default.AllInclusive),
    ADOBE("Adobe Acrobat", "Adobe Acrobat", Color(0xFFFA0F00), Icons.Default.PictureAsPdf),
    ILOVEPDF("iLovePDF", "iLovePDF", Color(0xFFEF4444), Icons.Default.Favorite),
    XODO("Xodo", "Xodo", Color(0xFF0284C7), Icons.Default.EditNote),
    FOXIT("Foxit", "Foxit", Color(0xFFF97316), Icons.Default.Description),
    PDFGEAR("PDFgear", "PDFgear", Color(0xFF10B981), Icons.Default.Verified),
    PDF_CREATOR("PDF Creator", "PDF Creator", Color(0xFF8B5CF6), Icons.Default.Draw),
    AI_COPILOT("AI Co-Pilot", "AI Co-Pilot", Color(0xFF6366F1), Icons.Default.AutoAwesome)
}

data class MasterPdfTool(
    val id: String,
    val titleHindi: String,
    val titleEn: String,
    val description: String,
    val suite: PdfAppSuite,
    val category: String, // ORGANIZE, OPTIMIZE, TO_PDF, FROM_PDF, EDIT, SECURITY, AI, CREATE
    val icon: ImageVector,
    val accentColor: Color,
    val isHot: Boolean = false,
    val badge: String? = null
)

object MasterPdfToolsCatalog {
    val allTools: List<MasterPdfTool> = listOf(
        // ==========================================
        // 1. ADOBE ACROBAT READER TOOLS
        // ==========================================
        MasterPdfTool(
            id = "adobe_view",
            titleHindi = "PDF व्यूअर",
            titleEn = "PDF Viewer & Reader",
            description = "क्रिस्टल क्लियर रेंडरिंग, नाइट मोड, लिक्विड मोड और ज़ूम",
            suite = PdfAppSuite.ADOBE,
            category = "EDIT",
            icon = Icons.Default.Visibility,
            accentColor = Color(0xFFFA0F00),
            isHot = true,
            badge = "HD"
        ),
        MasterPdfTool(
            id = "adobe_sign",
            titleHindi = "फिल एंड साइन (E-Sign)",
            titleEn = "Fill & Sign",
            description = "डिजिटल हस्ताक्षर बनाएं, स्टैम्प लगाएं और फॉर्म भरें",
            suite = PdfAppSuite.ADOBE,
            category = "EDIT",
            icon = Icons.Default.Draw,
            accentColor = Color(0xFFFA0F00),
            isHot = true,
            badge = "E-Sign"
        ),
        MasterPdfTool(
            id = "adobe_create",
            titleHindi = "PDF क्रिएटर",
            titleEn = "Create PDF",
            description = "फाइल, इमेज या डॉक्यूमेंट से नया PDF बनाएं",
            suite = PdfAppSuite.ADOBE,
            category = "CREATE",
            icon = Icons.Default.AddCircleOutline,
            accentColor = Color(0xFFE11D48),
            badge = "PRO"
        ),
        MasterPdfTool(
            id = "adobe_protect",
            titleHindi = "पासवर्ड सुरक्षा (Protect)",
            titleEn = "Protect PDF",
            description = "256-bit AES एन्क्रिप्शन से PDF को पासवर्ड लॉक करें",
            suite = PdfAppSuite.ADOBE,
            category = "SECURITY",
            icon = Icons.Default.Lock,
            accentColor = Color(0xFFB91C1C),
            badge = "Security"
        ),
        MasterPdfTool(
            id = "adobe_read_aloud",
            titleHindi = "रीड अलाउड (TTS वॉइस)",
            titleEn = "Read Aloud Voice",
            description = "प्राकृतिक आवाज़ में PDF पन्नों को बोलकर सुनवाने वाला वॉइस रीडर",
            suite = PdfAppSuite.ADOBE,
            category = "EDIT",
            icon = Icons.Default.VolumeUp,
            accentColor = Color(0xFFFA0F00),
            badge = "TTS"
        ),

        // ==========================================
        // 2. iLovePDF SUITE TOOLS
        // ==========================================
        MasterPdfTool(
            id = "ilove_merge",
            titleHindi = "मर्ज PDF (फाइलें जोड़ें)",
            titleEn = "Merge PDF Files",
            description = "2 या अधिक PDF फाइलों को एक ही क्रमबद्ध डॉक्यूमेंट में जोड़ें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "ORGANIZE",
            icon = Icons.Default.MergeType,
            accentColor = Color(0xFFEF4444),
            isHot = true,
            badge = "Popular"
        ),
        MasterPdfTool(
            id = "ilove_split",
            titleHindi = "स्प्लिट PDF (पेज अलग करें)",
            titleEn = "Split PDF Pages",
            description = "पेजों को अलग करें या कस्टम पेज रेंज में PDF काटें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "ORGANIZE",
            icon = Icons.Default.CallSplit,
            accentColor = Color(0xFFF97316),
            isHot = true,
            badge = "Split"
        ),
        MasterPdfTool(
            id = "ilove_compress",
            titleHindi = "कम्प्रेस PDF (साइज़ घटाएं)",
            titleEn = "Compress PDF",
            description = "क्वालिटी बनाए रखते हुए साइज़ 90% तक कम करें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "OPTIMIZE",
            icon = Icons.Default.Compress,
            accentColor = Color(0xFF10B981),
            isHot = true,
            badge = "Fast"
        ),
        MasterPdfTool(
            id = "ilove_img_to_pdf",
            titleHindi = "इमेज ➔ PDF (JPG/PNG)",
            titleEn = "Image to PDF",
            description = "गैलरी की तस्वीरों व स्कैन फोटो को तुरंत PDF में बदलें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "TO_PDF",
            icon = Icons.Default.Image,
            accentColor = Color(0xFF3B82F6),
            isHot = true,
            badge = "Convert"
        ),
        MasterPdfTool(
            id = "ilove_pdf_to_word",
            titleHindi = "PDF ➔ Word (.docx)",
            titleEn = "PDF to Word Converter",
            description = "PDF को एडिटेबल Word डॉक्यूमेंट में बदलें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "FROM_PDF",
            icon = Icons.Default.Article,
            accentColor = Color(0xFF2563EB),
            badge = "Word"
        ),
        MasterPdfTool(
            id = "ilove_pdf_to_excel",
            titleHindi = "PDF ➔ Excel (.xlsx)",
            titleEn = "PDF to Excel Converter",
            description = "टेबल व स्प्रेडशीट डेटा को सीधे Excel शीट में निकालें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "FROM_PDF",
            icon = Icons.Default.TableChart,
            accentColor = Color(0xFF16A34A),
            badge = "Excel"
        ),
        MasterPdfTool(
            id = "ilove_pdf_to_jpg",
            titleHindi = "PDF ➔ इमेज (JPG/PNG)",
            titleEn = "PDF to JPG Extractor",
            description = "PDF के सभी पेजों को हाई-रिज़ॉल्यूशन फोटो में एक्सपोर्ट करें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "FROM_PDF",
            icon = Icons.Default.PhotoLibrary,
            accentColor = Color(0xFFE11D48),
            isHot = true,
            badge = "Images"
        ),
        MasterPdfTool(
            id = "ilove_organize",
            titleHindi = "पेज रीऑर्डर व रोटेट",
            titleEn = "Organize & Reorder Pages",
            description = "पेजों को ड्रैग-ड्रॉप से आगे-पीछे करें, घुमाएं व हटाएं",
            suite = PdfAppSuite.ILOVEPDF,
            category = "ORGANIZE",
            icon = Icons.Default.AutoStories,
            accentColor = Color(0xFFEAB308),
            badge = "Organize"
        ),
        MasterPdfTool(
            id = "ilove_watermark",
            titleHindi = "वॉटरमार्क व स्टैम्प",
            titleEn = "Add Watermark & Stamp",
            description = "कस्टम टेक्स्ट, कॉपीराइट व लोगो वॉटरमार्क जोड़ें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "EDIT",
            icon = Icons.Default.BrandingWatermark,
            accentColor = Color(0xFFEC4899),
            badge = "Watermark"
        ),
        MasterPdfTool(
            id = "ilove_repair",
            titleHindi = "रिपेयर PDF (डैमेज फाइल ठीक करें)",
            titleEn = "Repair Damaged PDF",
            description = "खराब या करप्ट हुई PDF फाइल को तुरंत ठीक व रिकवर करें",
            suite = PdfAppSuite.ILOVEPDF,
            category = "OPTIMIZE",
            icon = Icons.Default.Build,
            accentColor = Color(0xFF06B6D4),
            badge = "Fix"
        ),
        MasterPdfTool(
            id = "ilove_ocr",
            titleHindi = "OCR टेक्स्ट स्कैनर",
            titleEn = "OCR Text Recognition",
            description = "स्कैन डॉक्यूमेंट को सर्च करने और टेक्स्ट कॉपी करने योग्य बनाएं",
            suite = PdfAppSuite.ILOVEPDF,
            category = "OPTIMIZE",
            icon = Icons.Default.DocumentScanner,
            accentColor = Color(0xFF0EA5E9),
            isHot = true,
            badge = "OCR"
        ),

        // ==========================================
        // 3. XODO PDF READER & EDITOR TOOLS
        // ==========================================
        MasterPdfTool(
            id = "xodo_notes_pen",
            titleHindi = "फ्रीहैंड पेन व ड्रॉइंग",
            titleEn = "Freehand Pen & Ink",
            description = "स्मूथ पेंसिल, ब्रश, पेन, स्ट्रोक साइज व कलर्स से नोट्स लिखें",
            suite = PdfAppSuite.XODO,
            category = "EDIT",
            icon = Icons.Default.Brush,
            accentColor = Color(0xFF0284C7),
            isHot = true,
            badge = "Draw"
        ),
        MasterPdfTool(
            id = "xodo_highlighter",
            titleHindi = "टेक्स्ट हाइलाइटर",
            titleEn = "Highlighter & Markup",
            description = "नियॉन कलर्स से जरूरी पंक्तियों को हाइलाइट, अंडरलाइन व स्ट्राइकथ्रू करें",
            suite = PdfAppSuite.XODO,
            category = "EDIT",
            icon = Icons.Default.Highlight,
            accentColor = Color(0xFFFBBF24),
            badge = "Markup"
        ),
        MasterPdfTool(
            id = "xodo_shapes",
            titleHindi = "शेप्स, बॉक्सेस व एरो",
            titleEn = "Shapes, Boxes & Arrows",
            description = "रेक्टैंगल, सर्कल, तीर और लाइन मार्कअप सीधे PDF पर बनाएं",
            suite = PdfAppSuite.XODO,
            category = "EDIT",
            icon = Icons.Default.Category,
            accentColor = Color(0xFF06B6D4),
            badge = "Shapes"
        ),
        MasterPdfTool(
            id = "xodo_audio_note",
            titleHindi = "वॉइस ऑडियो नोट",
            titleEn = "Voice Audio Notes",
            description = "PDF के किसी भी पन्ने पर अपनी आवाज़ में ऑडियो नोट्स रिकॉर्ड करके जोड़ें",
            suite = PdfAppSuite.XODO,
            category = "EDIT",
            icon = Icons.Default.Mic,
            accentColor = Color(0xFF9333EA),
            isHot = true,
            badge = "Voice"
        ),
        MasterPdfTool(
            id = "xodo_blank_notepad",
            titleHindi = "स्क्रैचपैड व नोट्स कैनवास",
            titleEn = "Blank Scratchpad Canvas",
            description = "तुरंत नए ब्लैंक पेज पर नोट्स बनाएं और PDF एक्सपोर्ट करें",
            suite = PdfAppSuite.XODO,
            category = "CREATE",
            icon = Icons.Default.NoteAlt,
            accentColor = Color(0xFF38BDF8),
            badge = "Notes"
        ),

        // ==========================================
        // 4. FOXIT PDF EDITOR TOOLS
        // ==========================================
        MasterPdfTool(
            id = "foxit_blank_creator",
            titleHindi = "ब्लैंक डॉक्यूमेंट क्रिएटर",
            titleEn = "Blank Canvas Builder",
            description = "A4/Letter, सादा, लाइनदार, ग्रिड, डॉटेड व डार्क मोड पेपर चुनें",
            suite = PdfAppSuite.FOXIT,
            category = "CREATE",
            icon = Icons.Default.PostAdd,
            accentColor = Color(0xFFF97316),
            isHot = true,
            badge = "Canvas"
        ),
        MasterPdfTool(
            id = "foxit_cam_scan",
            titleHindi = "HD कैमरा स्कैनर",
            titleEn = "HD Camera Scanner",
            description = "ऑटो-एज डिटेक्शन, शैडो रिमूवल और शार्प फिल्टर से डॉक्यूमेंट स्कैन करें",
            suite = PdfAppSuite.FOXIT,
            category = "CREATE",
            icon = Icons.Default.CameraAlt,
            accentColor = Color(0xFFFB923C),
            badge = "Scan"
        ),
        MasterPdfTool(
            id = "foxit_id_card",
            titleHindi = "ID कार्ड 2-इन-1 स्कैनर",
            titleEn = "2-in-1 ID Card Scan",
            description = "आधार कार्ड / ड्राइविंग लाइसेंस / पैन कार्ड का फ्रंट व बैक एक A4 पेज पर",
            suite = PdfAppSuite.FOXIT,
            category = "CREATE",
            icon = Icons.Default.Badge,
            accentColor = Color(0xFFEA580C),
            isHot = true,
            badge = "ID Card"
        ),
        MasterPdfTool(
            id = "foxit_form_edit",
            titleHindi = "फॉर्म फिलर व टेक्स्ट बॉक्स",
            titleEn = "Form Filling & Textbox Tool",
            description = "PDF में नए टेक्स्ट बॉक्स, चेकबॉक्स व फॉर्म फील्ड जोड़ें",
            suite = PdfAppSuite.FOXIT,
            category = "EDIT",
            icon = Icons.Default.DynamicForm,
            accentColor = Color(0xFFD97706),
            badge = "Forms"
        ),

        // ==========================================
        // 5. PDFGEAR (100% NO-WATERMARK SUITE)
        // ==========================================
        MasterPdfTool(
            id = "pdfgear_no_watermark",
            titleHindi = "100% बिना वॉटरमार्क PDF",
            titleEn = "No-Watermark PDF Engine",
            description = "सभी टूल्स बिल्कुल फ्री, बिना किसी छिपे वॉटरमार्क या लोगो के",
            suite = PdfAppSuite.PDFGEAR,
            category = "OPTIMIZE",
            icon = Icons.Default.Verified,
            accentColor = Color(0xFF10B981),
            isHot = true,
            badge = "No Watermark"
        ),
        MasterPdfTool(
            id = "pdfgear_compare",
            titleHindi = "PDF तुलना (Compare)",
            titleEn = "Compare 2 PDFs",
            description = "दो PDF फाइलों को साथ रखकर अंतर व बदलाव हाइलाइट करें",
            suite = PdfAppSuite.PDFGEAR,
            category = "SECURITY",
            icon = Icons.Default.Compare,
            accentColor = Color(0xFF059669),
            isHot = true,
            badge = "Compare"
        ),
        MasterPdfTool(
            id = "pdfgear_batch_compress",
            titleHindi = "बैच कम्प्रेसर",
            titleEn = "Fast Batch Compress",
            description = "फाइलों को बिना क्वालिटी खोए तुरंत कम्प्रेस करें",
            suite = PdfAppSuite.PDFGEAR,
            category = "OPTIMIZE",
            icon = Icons.Default.Speed,
            accentColor = Color(0xFF14B8A6),
            badge = "Batch"
        ),
        MasterPdfTool(
            id = "pdfgear_txt_extract",
            titleHindi = "टेक्स्ट एक्सट्रैक्टर",
            titleEn = "Text & Data Extractor",
            description = "पूरे डॉक्यूमेंट का सारा टेक्स्ट एक क्लिक में निकालें",
            suite = PdfAppSuite.PDFGEAR,
            category = "FROM_PDF",
            icon = Icons.Default.TextFields,
            accentColor = Color(0xFF0D9488),
            badge = "Extract"
        ),

        // ==========================================
        // 6. PDF CREATOR & DESIGNER PRO (PHONE CANVAS)
        // ==========================================
        MasterPdfTool(
            id = "creator_zero_design",
            titleHindi = "ज़ीरो से नया PDF डिज़ाइन",
            titleEn = "Design PDF from Scratch",
            description = "सीधे फोन पर कस्टम कैनवास, फॉन्ट, मार्जिन, बॉर्डर व कलर डिज़ाइन करें",
            suite = PdfAppSuite.PDF_CREATOR,
            category = "CREATE",
            icon = Icons.Default.DesignServices,
            accentColor = Color(0xFF8B5CF6),
            isHot = true,
            badge = "Designer"
        ),
        MasterPdfTool(
            id = "creator_templates",
            titleHindi = "इनवॉइस, रिज्यूमे व टेम्पलेट्स",
            titleEn = "Invoice & Resume Templates",
            description = "टैक्स इनवॉइस, असाइनमेंट कवर, रिज्यूमे व सर्टिफिकेट्स 1-क्लिक में बनाएं",
            suite = PdfAppSuite.PDF_CREATOR,
            category = "CREATE",
            icon = Icons.Default.ReceiptLong,
            accentColor = Color(0xFF7C3AED),
            isHot = true,
            badge = "Templates"
        ),
        MasterPdfTool(
            id = "creator_custom_sizes",
            titleHindi = "कस्टम पेपर साइज़ (A4, Legal, A5)",
            titleEn = "Custom Paper Dimensions",
            description = "A4, Letter, Legal, A5, विजिटिंग कार्ड व कस्टम मिलीमीटर साइज़ चुनें",
            suite = PdfAppSuite.PDF_CREATOR,
            category = "CREATE",
            icon = Icons.Default.AspectRatio,
            accentColor = Color(0xFFA855F7),
            badge = "Page Sizes"
        ),

        // ==========================================
        // 7. GEMINI AI CO-PILOT TOOLS
        // ==========================================
        MasterPdfTool(
            id = "ai_chat_summary",
            titleHindi = "AI PDF चैट व सारांश",
            titleEn = "AI Document Chat & Summary",
            description = "100+ पन्नों का सेकंडों में सारांश निकालें और सवाल पूछें",
            suite = PdfAppSuite.AI_COPILOT,
            category = "AI",
            icon = Icons.Default.AutoAwesome,
            accentColor = Color(0xFF6366F1),
            isHot = true,
            badge = "AI Co-Pilot"
        ),
        MasterPdfTool(
            id = "ai_translator",
            titleHindi = "AI बहुभाषी PDF अनुवाद",
            titleEn = "AI Multi-Language Translate",
            description = "दस्तावेज़ को हिंदी, अंग्रेज़ी, बांग्ला, स्पैनिश समेत 50+ भाषाओं में बदलें",
            suite = PdfAppSuite.AI_COPILOT,
            category = "AI",
            icon = Icons.Default.Translate,
            accentColor = Color(0xFF38BDF8),
            isHot = true,
            badge = "Translate"
        ),
        MasterPdfTool(
            id = "ai_podcast_audio",
            titleHindi = "AI ऑडियो पॉडकास्ट रीडर",
            titleEn = "AI Voice Podcast Reader",
            description = "पूरे PDF को नैचुरल वॉयस में पॉडकास्ट की तरह सुनें",
            suite = PdfAppSuite.AI_COPILOT,
            category = "AI",
            icon = Icons.Default.Headphones,
            accentColor = Color(0xFFF43F5E),
            isHot = true,
            badge = "Podcast"
        ),
        MasterPdfTool(
            id = "ai_quiz_generator",
            titleHindi = "AI क्विज़ व स्टडी फ्लैशकार्ड्स",
            titleEn = "AI Exam Quiz & Flashcards",
            description = "डॉक्यूमेंट से ऑटोमैटिक MCQs, टेस्ट पेपर व रिवीजन नोट्स बनाएं",
            suite = PdfAppSuite.AI_COPILOT,
            category = "AI",
            icon = Icons.Default.School,
            accentColor = Color(0xFF10B981),
            badge = "Quiz"
        ),
        MasterPdfTool(
            id = "ai_formula_extractor",
            titleHindi = "AI फॉर्मूला व मैथ्स स्कैनर",
            titleEn = "Formula & LaTeX Extractor",
            description = "गणित व साइंस के फॉर्मूलों को स्कैन कर LaTeX में कनवर्ट करें",
            suite = PdfAppSuite.AI_COPILOT,
            category = "AI",
            icon = Icons.Default.Functions,
            accentColor = Color(0xFFFFB300),
            badge = "Math"
        ),
        MasterPdfTool(
            id = "ai_handwriting_clean",
            titleHindi = "AI हैंडराइटिंग क्लीनअप",
            titleEn = "Handwriting Cleanup AI",
            description = "हाथ से लिखे पुराने नोट्स से परछाईं हटाएं व लिखावट साफ करें",
            suite = PdfAppSuite.AI_COPILOT,
            category = "AI",
            icon = Icons.Default.AutoFixHigh,
            accentColor = Color(0xFFFF7043),
            badge = "Clean"
        )
    )
}
