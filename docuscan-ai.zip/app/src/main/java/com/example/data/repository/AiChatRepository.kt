package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AiChatSession
import com.example.data.model.AiMessage
import com.example.data.model.AiModelType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class AiChatRepository(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("ai_chat_store", Context.MODE_PRIVATE)

    private val _sessions = MutableStateFlow<List<AiChatSession>>(emptyList())
    val sessions: StateFlow<List<AiChatSession>> = _sessions.asStateFlow()

    private val _currentMessages = MutableStateFlow<List<AiMessage>>(emptyList())
    val currentMessages: StateFlow<List<AiMessage>> = _currentMessages.asStateFlow()

    companion object {
        fun isCorruptedOrBoilerplate(text: String): Boolean {
            val t = text.lowercase()
            return t.contains("आपके द्वारा पूछे गए विषय") ||
                   t.contains("गणितीय गणना व विश्लेषण") ||
                   t.contains("math engine") ||
                   t.contains("सुझाव: आप मुझसे फ़ोटो") ||
                   t.contains("सुझाव: आप मुझसे") ||
                   t.contains("### 💡 ai उत्तर") ||
                   t.contains("### 🔢") ||
                   t.contains("docuscan super ultra ai") ||
                   t.contains("मध्य पुरा पाषाण") ||
                   t.contains("संक्षिप्त सारांश") ||
                   t.contains("संक्षिप्त आंसर") ||
                   t.contains("व्यावहारिक उदाहरण") ||
                   t.contains("विस्तृत व्याख्या")
        }
    }

    init {
        loadSessions()
    }

    private fun loadSessions() {
        val jsonStr = prefs.getString("chat_sessions_list", null)
        if (jsonStr.isNullOrBlank()) {
            _sessions.value = emptyList()
        } else {
            try {
                val array = JSONArray(jsonStr)
                val list = mutableListOf<AiChatSession>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val id = obj.getString("id")
                    val title = obj.getString("title")
                    val preview = obj.optString("previewText", "")
                    if (id == "default_welcome_session" || isCorruptedOrBoilerplate(title) || isCorruptedOrBoilerplate(preview)) {
                        continue
                    }
                    list.add(
                        AiChatSession(
                            id = id,
                            title = title,
                            modelType = try { AiModelType.valueOf(obj.getString("modelType")) } catch (e: Exception) { AiModelType.GEMINI },
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis()),
                            previewText = preview,
                            messageCount = obj.optInt("messageCount", 0)
                        )
                    )
                }
                _sessions.value = list.sortedByDescending { it.updatedAt }
                saveSessionsToPrefs(list)
            } catch (e: Exception) {
                e.printStackTrace()
                _sessions.value = emptyList()
            }
        }
    }

    private fun saveInitialSampleMessages(sessionId: String) {
        // No sample messages needed
    }

    private fun saveSessionsToPrefs(list: List<AiChatSession>) {
        val array = JSONArray()
        list.forEach { session ->
            val obj = JSONObject()
            obj.put("id", session.id)
            obj.put("title", session.title)
            obj.put("modelType", session.modelType.name)
            obj.put("createdAt", session.createdAt)
            obj.put("updatedAt", session.updatedAt)
            obj.put("previewText", session.previewText)
            obj.put("messageCount", session.messageCount)
            array.put(obj)
        }
        prefs.edit().putString("chat_sessions_list", array.toString()).apply()
    }

    suspend fun createNewSession(title: String = "New Chat", modelType: AiModelType = AiModelType.GEMINI): AiChatSession = withContext(Dispatchers.IO) {
        val newSession = AiChatSession(
            title = title,
            modelType = modelType,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            previewText = "नया चैट सत्र प्रारंभ...",
            messageCount = 1
        )
        val currentList = _sessions.value.toMutableList()
        currentList.add(0, newSession)
        saveSessionsToPrefs(currentList)
        _sessions.value = currentList

        // Add welcome message
        val welcomeMsg = AiMessage(
            sessionId = newSession.id,
            sender = modelType.displayName,
            text = when (modelType) {
                AiModelType.GEMINI -> "नमस्ते! मैं Google Gemini 2.5 Flash हूँ ✨। आप मुझसे दस्तावेज़, सारांश, अनुवाद या कोई भी प्रश्न पूछ सकते हैं।"
                AiModelType.GEMINI_PRO -> "नमस्ते! मैं Google Gemini 2.5 Pro हूँ 🚀। मैं जटिल तार्किक विश्लेषण, कोडिंग और गहन दस्तावेज़ सारांश के लिए तैयार हूँ।"
                AiModelType.GEMINI_ADVANCED -> "नमस्ते! मैं Google Gemini Advanced हूँ 💎। उच्च क्षमता और उन्नत बहुआयामी विश्लेषण के लिए मैं तैयार हूँ।"
                AiModelType.CHATGPT -> "Hello! I am ChatGPT 🤖. How can I assist you with your reading, writing, or analysis today?"
                AiModelType.APP_ASSISTANT -> "नमस्ते! मैं DocuScan App Assistant हूँ 📱। मैं आपको इस ऐप के सभी टूल्स (PDF Edit, Scan, OCR, Merge) का उपयोग करने में मदद करूँगा।"
            },
            isUser = false,
            modelUsed = modelType
        )
        saveMessagesForSession(newSession.id, listOf(welcomeMsg))
        _currentMessages.value = listOf(welcomeMsg)
        newSession
    }

    suspend fun loadMessages(sessionId: String): List<AiMessage> = withContext(Dispatchers.IO) {
        val jsonStr = prefs.getString("messages_$sessionId", null)
        val list = mutableListOf<AiMessage>()
        if (!jsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val text = obj.getString("text")
                    // Filter out any corrupted or repetitive boilerplate AI response
                    if (isCorruptedOrBoilerplate(text)) {
                        continue
                    }
                    list.add(
                        AiMessage(
                            id = obj.getString("id"),
                            sessionId = sessionId,
                            sender = obj.getString("sender"),
                            text = text,
                            isUser = obj.getBoolean("isUser"),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            attachedImagePath = obj.optString("attachedImagePath").takeIf { !it.isNullOrBlank() },
                            attachedFileName = obj.optString("attachedFileName").takeIf { !it.isNullOrBlank() },
                            modelUsed = try { AiModelType.valueOf(obj.getString("modelUsed")) } catch (e: Exception) { null }
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        if (list.isEmpty()) {
            val cleanWelcome = AiMessage(
                sessionId = sessionId,
                sender = "Google Gemini 2.5 Flash",
                text = "नमस्ते! मैं आपका AI असिस्टेंट हूँ ✨। आप मुझसे कुछ भी पूछ सकते हैं — सामान्य बातचीत, ज्ञान, कोडिंग या कोई भी सवाल।",
                isUser = false,
                modelUsed = AiModelType.GEMINI
            )
            list.add(cleanWelcome)
            saveMessagesForSession(sessionId, list)
        }
        _currentMessages.value = list
        list
    }

    private fun saveMessagesForSession(sessionId: String, messages: List<AiMessage>) {
        val array = JSONArray()
        messages.forEach { msg ->
            val obj = JSONObject()
            obj.put("id", msg.id)
            obj.put("sessionId", msg.sessionId)
            obj.put("sender", msg.sender)
            obj.put("text", msg.text)
            obj.put("isUser", msg.isUser)
            obj.put("timestamp", msg.timestamp)
            obj.put("attachedImagePath", msg.attachedImagePath ?: "")
            obj.put("attachedFileName", msg.attachedFileName ?: "")
            obj.put("modelUsed", msg.modelUsed?.name ?: "")
            array.put(obj)
        }
        prefs.edit().putString("messages_$sessionId", array.toString()).apply()
    }

    suspend fun addMessage(message: AiMessage) = withContext(Dispatchers.IO) {
        val current = _currentMessages.value.toMutableList()
        current.add(message)
        _currentMessages.value = current
        saveMessagesForSession(message.sessionId, current)

        // Update session preview & timestamp & title if first user message
        val currentSessions = _sessions.value.toMutableList()
        val sessionIndex = currentSessions.indexOfFirst { it.id == message.sessionId }
        if (sessionIndex >= 0) {
            val oldSession = currentSessions[sessionIndex]
            val updatedTitle = if (oldSession.title == "New Chat" && message.isUser) {
                message.text.take(30).trim()
            } else {
                oldSession.title
            }
            val updatedSession = oldSession.copy(
                title = updatedTitle,
                updatedAt = System.currentTimeMillis(),
                previewText = message.text.take(50),
                messageCount = current.size
            )
            currentSessions[sessionIndex] = updatedSession
            val sorted = currentSessions.sortedByDescending { it.updatedAt }
            saveSessionsToPrefs(sorted)
            _sessions.value = sorted
        }
    }

    suspend fun deleteSessions(sessionIds: Set<String>) = withContext(Dispatchers.IO) {
        val editor = prefs.edit()
        sessionIds.forEach { id ->
            editor.remove("messages_$id")
        }
        val remaining = _sessions.value.filterNot { sessionIds.contains(it.id) }
        saveSessionsToPrefs(remaining)
        _sessions.value = remaining
        editor.apply()
    }

    suspend fun deleteSingleSession(sessionId: String) = withContext(Dispatchers.IO) {
        deleteSessions(setOf(sessionId))
    }

    suspend fun clearCurrentSession(sessionId: String, modelType: AiModelType = AiModelType.GEMINI): List<AiMessage> = withContext(Dispatchers.IO) {
        val cleanWelcome = AiMessage(
            sessionId = sessionId,
            sender = modelType.displayName,
            text = "नमस्ते! मैं आपका AI असिस्टेंट हूँ ✨। चैट इतिहास साफ़ कर दिया गया है। आप मुझसे कोई भी नया सवाल पूछ सकते हैं।",
            isUser = false,
            modelUsed = modelType
        )
        val list = listOf(cleanWelcome)
        saveMessagesForSession(sessionId, list)
        _currentMessages.value = list

        val currentSessions = _sessions.value.toMutableList()
        val sessionIndex = currentSessions.indexOfFirst { it.id == sessionId }
        if (sessionIndex >= 0) {
            val old = currentSessions[sessionIndex]
            val updated = old.copy(
                updatedAt = System.currentTimeMillis(),
                previewText = "नया चैट...",
                messageCount = 1
            )
            currentSessions[sessionIndex] = updated
            saveSessionsToPrefs(currentSessions)
            _sessions.value = currentSessions
        }
        list
    }

    suspend fun clearAllSessions() = withContext(Dispatchers.IO) {
        val editor = prefs.edit()
        _sessions.value.forEach { session ->
            editor.remove("messages_${session.id}")
        }
        editor.remove("chat_sessions_list")
        editor.apply()
        _sessions.value = emptyList()
        _currentMessages.value = emptyList()
    }
}
