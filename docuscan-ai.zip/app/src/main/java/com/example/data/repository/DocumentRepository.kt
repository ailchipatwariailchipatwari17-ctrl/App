package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.data.database.DocumentDao
import com.example.data.model.CompressionLevel
import com.example.data.model.DocumentPage
import com.example.data.model.ScanFilter
import com.example.data.model.ScannedDocument
import com.example.data.util.ImageProcessor
import com.example.data.util.PdfGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class DocumentRepository(
    private val context: Context,
    private val dao: DocumentDao
) {
    val publicDocuments: Flow<List<ScannedDocument>> = dao.getAllPublicDocuments()
    val vaultDocuments: Flow<List<ScannedDocument>> = dao.getAllVaultDocuments()
    val trashDocuments: Flow<List<ScannedDocument>> = dao.getAllTrashDocuments()

    suspend fun getDocumentById(id: Long): ScannedDocument? = dao.getDocumentById(id)

    suspend fun getPagesForDocument(docId: Long): List<DocumentPage> = dao.getPagesForDocument(docId)

    /**
     * Converts a list of captured/selected image bitmaps into a PDF, compresses it, and saves to database.
     */
    suspend fun saveDocumentWithPages(
        title: String,
        bitmaps: List<Bitmap>,
        filter: ScanFilter,
        compressionLevel: CompressionLevel,
        isPrivateVault: Boolean = false,
        tags: String = "",
        watermarkText: String = "",
        stampText: String = ""
    ): ScannedDocument = withContext(Dispatchers.IO) {
        // Apply chosen filter to each page bitmap
        val filteredBitmaps = bitmaps.map { raw ->
            ImageProcessor.applyFilter(raw, filter)
        }

        // Generate compressed PDF file
        val pdfResult = PdfGenerator.createPdf(
            context = context,
            pageBitmaps = filteredBitmaps,
            documentTitle = title,
            compressionLevel = compressionLevel
        )

        val docEntity = ScannedDocument(
            title = title.ifBlank { "Scan_${System.currentTimeMillis()}" },
            pdfFilePath = pdfResult.file.absolutePath,
            pageCount = pdfResult.pageCount,
            fileSizeFormatted = pdfResult.fileSizeFormatted,
            fileSizeBytes = pdfResult.fileSizeBytes,
            compressionLevel = compressionLevel.name,
            isPrivateVault = isPrivateVault,
            tags = tags,
            watermarkText = watermarkText,
            stampText = stampText
        )

        val docId = dao.insertDocument(docEntity)

        // Save individual page image assets for editor preview
        val imgDir = File(context.filesDir, "page_images").apply { mkdirs() }
        val pageEntities = filteredBitmaps.mapIndexed { idx, bmp ->
            val pageFile = File(imgDir, "doc_${docId}_page_${idx}.jpg")
            FileOutputStream(pageFile).use { out ->
                bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
            }
            DocumentPage(
                documentId = docId,
                pageIndex = idx,
                imagePath = pageFile.absolutePath,
                filterName = filter.name
            )
        }

        dao.insertPages(pageEntities)

        return@withContext docEntity.copy(id = docId)
    }

    suspend fun saveImportedDocument(
        title: String,
        filePath: String,
        fileSizeBytes: Long,
        fileSizeFormatted: String,
        category: com.example.data.model.DocumentCategory,
        extractedText: String,
        isPrivateVault: Boolean = false,
        tags: String = ""
    ): ScannedDocument = withContext(Dispatchers.IO) {
        // Prevent duplicate entries when same file/PDF is opened multiple times
        val existingDoc = dao.findExistingDocument(filePath, title)
        if (existingDoc != null && !existingDoc.isTrash) {
            return@withContext existingDoc
        }

        val docEntity = ScannedDocument(
            title = title,
            pdfFilePath = filePath,
            pageCount = when (category) {
                com.example.data.model.DocumentCategory.POWERPOINT -> 8
                com.example.data.model.DocumentCategory.EXCEL -> 3
                com.example.data.model.DocumentCategory.WORD -> 4
                else -> 1
            },
            fileSizeFormatted = fileSizeFormatted,
            fileSizeBytes = fileSizeBytes,
            compressionLevel = CompressionLevel.LOW.name,
            isPrivateVault = isPrivateVault,
            extractedText = extractedText,
            fileCategory = category.name,
            tags = tags
        )
        val docId = dao.insertDocument(docEntity)
        return@withContext docEntity.copy(id = docId)
    }

    suspend fun saveImportedDocumentsBatch(
        docs: List<ScannedDocument>
    ): List<Long> = withContext(Dispatchers.IO) {
        if (docs.isEmpty()) return@withContext emptyList()
        dao.insertDocuments(docs)
    }

    suspend fun moveToTrash(id: Long) = dao.moveToTrash(id)

    suspend fun restoreFromTrash(id: Long) = dao.restoreFromTrash(id)

    suspend fun deleteDocumentPermanently(id: Long) = withContext(Dispatchers.IO) {
        val doc = dao.getDocumentById(id)
        if (doc != null) {
            val file = File(doc.pdfFilePath)
            if (file.exists()) file.delete()
        }
        dao.deleteDocumentWithPages(id)
    }

    suspend fun updateVaultStatus(id: Long, isVault: Boolean) = dao.updateVaultStatus(id, isVault)

    suspend fun updateStarredStatus(id: Long, isStarred: Boolean) = dao.updateStarredStatus(id, isStarred)

    suspend fun updateExtractedText(id: Long, text: String) = dao.updateExtractedText(id, text)

    suspend fun updateTags(id: Long, tags: String) = dao.updateTags(id, tags)

    suspend fun updateAiSummary(id: Long, summary: String) = dao.updateAiSummary(id, summary)

    suspend fun updateWatermarkAndStamp(id: Long, watermark: String, stamp: String) = dao.updateWatermarkAndStamp(id, watermark, stamp)

    suspend fun updateTitle(id: Long, newTitle: String) = dao.updateTitle(id, newTitle)

    suspend fun updateAudioNote(id: Long, audioPath: String) = dao.updateAudioNote(id, audioPath)

    /**
     * Merges multiple documents into a single new document.
     */
    suspend fun mergeDocuments(newTitle: String, sourceDocIds: List<Long>): ScannedDocument = withContext(Dispatchers.IO) {
        val allBitmaps = mutableListOf<Bitmap>()
        sourceDocIds.forEach { id ->
            val pages = dao.getPagesForDocument(id)
            pages.forEach { p ->
                val bmp = BitmapFactory.decodeFile(p.imagePath)
                if (bmp != null) allBitmaps.add(bmp)
            }
        }

        if (allBitmaps.isEmpty()) {
            // Placeholder bitmap if page images missing
            val sample = Bitmap.createBitmap(595, 842, Bitmap.Config.ARGB_8888)
            allBitmaps.add(sample)
        }

        saveDocumentWithPages(
            title = newTitle.ifBlank { "Merged_PDF_${System.currentTimeMillis()}" },
            bitmaps = allBitmaps,
            filter = ScanFilter.ORIGINAL,
            compressionLevel = CompressionLevel.LOW,
            tags = "#Merged"
        )
    }

    /**
     * Splits a document by page range into a new document.
     */
    suspend fun splitDocument(sourceDocId: Long, newTitle: String, startPage: Int, endPage: Int): ScannedDocument = withContext(Dispatchers.IO) {
        val pages = dao.getPagesForDocument(sourceDocId)
        val selectedPages = pages.filter { it.pageIndex in (startPage - 1)..(endPage - 1) }
        val splitBitmaps = selectedPages.mapNotNull { p ->
            BitmapFactory.decodeFile(p.imagePath)
        }

        val finalBitmaps = if (splitBitmaps.isNotEmpty()) splitBitmaps else {
            listOf(Bitmap.createBitmap(595, 842, Bitmap.Config.ARGB_8888))
        }

        saveDocumentWithPages(
            title = newTitle.ifBlank { "Split_Pages_${startPage}_to_${endPage}" },
            bitmaps = finalBitmaps,
            filter = ScanFilter.ORIGINAL,
            compressionLevel = CompressionLevel.LOW,
            tags = "#Split"
        )
    }
}
