package com.example.data.model

import java.util.UUID

enum class AiModelType(val displayName: String, val subtitle: String) {
    GEMINI("Gemini Flash", "तेज़ और सटीक AI (Fast & Efficient)"),
    GEMINI_PRO("Gemini Pro", "गहन समझ और विश्लेषण (Deep Reasoning)"),
    GEMINI_ADVANCED("Gemini Advanced", "विशेषज्ञ तर्क और कोडिंग (Pro Developer)"),
    CHATGPT("ChatGPT 4o", "ओपनएआई संवाद व कोड"),
    APP_ASSISTANT("Doc Assistant", "दस्तावेज़ और ऐप सहायता")
}

data class AiChatSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val modelType: AiModelType = AiModelType.GEMINI,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val previewText: String = "",
    val messageCount: Int = 0
)

data class AiMessage(
    val id: String = UUID.randomUUID().toString(),
    val sessionId: String,
    val sender: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val attachedImagePath: String? = null,
    val attachedFileName: String? = null,
    val modelUsed: AiModelType? = null
)
