package com.example.data.model

import java.util.UUID

enum class AiModelType(val displayName: String, val subtitle: String) {
    GEMINI("Google (Gemini AI)", "गूगल जेमिनी मॉडल"),
    CHATGPT("ChatGPT", "ओपनएआई संवाद मॉडल"),
    APP_ASSISTANT("App Assistant", "ऐप जानकारी व सहायता")
}

data class AiChatSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val modelType: AiModelType = AiModelType.GEMINI,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val previewText: String = "",
    val messageCount: Int = 0
)

data class AiMessage(
    val id: String = UUID.randomUUID().toString(),
    val sessionId: String,
    val sender: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val attachedImagePath: String? = null,
    val attachedFileName: String? = null,
    val modelUsed: AiModelType? = null
)
