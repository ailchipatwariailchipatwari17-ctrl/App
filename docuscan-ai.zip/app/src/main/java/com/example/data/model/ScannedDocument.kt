package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CompressionLevel(val labelHindi: String, val labelEnglish: String, val quality: Int) {
    LOW("कम संपीड़न (उच्च गुणवत्ता)", "Low Compression (High Quality)", 90),
    MEDIUM("मध्यम (संतुलित)", "Medium Compression (Balanced)", 65),
    HIGH("उच्च संपीड़न (छोटा आकार)", "High Compression (Small Size)", 35)
}

enum class ScanFilter(val titleHindi: String, val titleEnglish: String) {
    VIVID_LIGHT("विविड लाइट (Vivid Light)", "VIVID LIGHT"),
    MAGIC_COLOR("जादुई रंग (Magic Color)", "MAGIC COLOR"),
    ORIGINAL("मूल फोटो (Original)", "ORIGINAL"),
    BLACK_WHITE("ब्लैक & वाइट (B&W)", "B&W"),
    COLOR("कलर (Color)", "COLOR"),
    GRAYSCALE("ग्रेस्केल (Grayscale)", "GRAYSCALE"),
    BRIGHTEN("चमकदार (Lighten)", "LIGHTEN")
}

enum class DocumentCategory(val labelHindi: String, val labelEnglish: String, val extension: String) {
    ALL("सभी दस्तावेज (All)", "All Documents", ""),
    PDF("पीडीएफ (PDF)", "PDF", "pdf"),
    WORD("एमएस वर्ड (Word)", "MS Word", "doc"),
    EXCEL("एमएस एक्सेल (Excel)", "MS Excel", "xls"),
    POWERPOINT("पावरपॉइंट (PPT)", "MS PowerPoint", "ppt"),
    TXT("टेक्स्ट (Text)", "Text", "txt")
}

@Entity(tableName = "scanned_documents")
data class ScannedDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val pdfFilePath: String,
    val pageCount: Int,
    val fileSizeFormatted: String,
    val fileSizeBytes: Long,
    val compressionLevel: String,
    val isPrivateVault: Boolean = false,
    val extractedText: String = "",
    val fileCategory: String = DocumentCategory.PDF.name,
    val createdAt: Long = System.currentTimeMillis(),
    val isTrash: Boolean = false,
    val deletedAt: Long = 0,
    val tags: String = "", // Comma-separated tags e.g. "#Exams,#Bills"
    val audioNotePath: String = "",
    val aiSummary: String = "",
    val watermarkText: String = "",
    val stampText: String = "", // APPROVED, CONFIDENTIAL, PAID, SEAL
    val signaturePath: String = "",
    val isStarred: Boolean = false
) {
    val tagList: List<String>
        get() = tags.split(",").map { it.trim() }.filter { it.isNotBlank() }

    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            return sdf.format(Date(createdAt))
        }

    val categoryEnum: DocumentCategory
        get() = try {
            DocumentCategory.valueOf(fileCategory)
        } catch (e: Exception) {
            when {
                pdfFilePath.endsWith(".docx", ignoreCase = true) || pdfFilePath.endsWith(".doc", ignoreCase = true) -> DocumentCategory.WORD
                pdfFilePath.endsWith(".xlsx", ignoreCase = true) || pdfFilePath.endsWith(".xls", ignoreCase = true) -> DocumentCategory.EXCEL
                pdfFilePath.endsWith(".pptx", ignoreCase = true) || pdfFilePath.endsWith(".ppt", ignoreCase = true) -> DocumentCategory.POWERPOINT
                pdfFilePath.endsWith(".txt", ignoreCase = true) -> DocumentCategory.TXT
                else -> DocumentCategory.PDF
            }
        }
}

@Entity(tableName = "document_pages")
data class DocumentPage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: Long,
    val pageIndex: Int,
    val imagePath: String,
    val filterName: String = ScanFilter.MAGIC_COLOR.name,
    val rotationDegrees: Int = 0
)
