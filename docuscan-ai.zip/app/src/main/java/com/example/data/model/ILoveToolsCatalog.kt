package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class ToolMainType {
    PDF,
    IMAGE,
    WORKFLOW
}

data class ILoveToolItem(
    val id: String,
    val titleHindi: String,
    val titleEn: String,
    val descriptionHindi: String,
    val descriptionEn: String,
    val toolType: ToolMainType,
    val category: String, // OPTIMIZE, CREATE, MODIFY, CONVERT, EDIT, SECURITY, ORGANIZE, AI
    val icon: ImageVector,
    val iconBgColor: Color,
    val isNew: Boolean = false,
    val badge: String? = null
)

object ILoveToolsCatalog {

    // =========================================================================
    // 1. iLovePDF COMPLETE SUITE (Screenshot 1 Exact Tools)
    // =========================================================================
    val pdfTools: List<ILoveToolItem> = listOf(
        ILoveToolItem(
            id = "merge_pdf",
            titleHindi = "मर्ज PDF",
            titleEn = "Merge PDF",
            descriptionHindi = "PDF फाइलों को अपनी पसंद के क्रम में आसानी से एक साथ जोड़ें।",
            descriptionEn = "Combine PDFs in the order you want with the easiest PDF merger available.",
            toolType = ToolMainType.PDF,
            category = "ORGANIZE",
            icon = Icons.Default.MergeType,
            iconBgColor = Color(0xFFEF4444)
        ),
        ILoveToolItem(
            id = "split_pdf",
            titleHindi = "स्प्लिट PDF",
            titleEn = "Split PDF",
            descriptionHindi = "एक या अधिक पेजों को अलग करें और स्वतंत्र PDF फाइलों में बदलें।",
            descriptionEn = "Separate one page or a whole set for easy conversion into independent PDF files.",
            toolType = ToolMainType.PDF,
            category = "ORGANIZE",
            icon = Icons.Default.CallSplit,
            iconBgColor = Color(0xFFF97316)
        ),
        ILoveToolItem(
            id = "compress_pdf",
            titleHindi = "कंप्रेस PDF",
            titleEn = "Compress PDF",
            descriptionHindi = "अधिकतम PDF गुणवत्ता बनाए रखते हुए फाइल का साइज़ 90% तक कम करें।",
            descriptionEn = "Reduce file size while optimizing for maximal PDF quality.",
            toolType = ToolMainType.PDF,
            category = "OPTIMIZE",
            icon = Icons.Default.Compress,
            iconBgColor = Color(0xFF10B981)
        ),
        ILoveToolItem(
            id = "pdf_to_word",
            titleHindi = "PDF से Word",
            titleEn = "PDF to Word",
            descriptionHindi = "PDF फाइलों को आसानी से एडिट करने योग्य DOCX डॉक्यूमेंट में बदलें।",
            descriptionEn = "Easily convert your PDF files into easy to edit DOC and DOCX documents.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.Article,
            iconBgColor = Color(0xFF3B82F6)
        ),
        ILoveToolItem(
            id = "pdf_to_powerpoint",
            titleHindi = "PDF से PowerPoint",
            titleEn = "PDF to PowerPoint",
            descriptionHindi = "अपनी PDF फाइलों को आसानी से एडिट करने योग्य PPTX स्लाइड में बदलें।",
            descriptionEn = "Turn your PDF files into easy to edit PPT and PPTX slideshows.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.Slideshow,
            iconBgColor = Color(0xFFEA580C)
        ),
        ILoveToolItem(
            id = "pdf_to_excel",
            titleHindi = "PDF से Excel",
            titleEn = "PDF to Excel",
            descriptionHindi = "कुछ ही सेकंडों में PDF से डेटा निकालें और स्प्रेडशीट में बदलें।",
            descriptionEn = "Pull data straight from PDFs into Excel spreadsheets in a few short seconds.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.TableChart,
            iconBgColor = Color(0xFF059669)
        ),
        ILoveToolItem(
            id = "word_to_pdf",
            titleHindi = "Word से PDF",
            titleEn = "Word to PDF",
            descriptionHindi = "DOC और DOCX फाइलों को कुछ सेकंड में सुरक्षित PDF में बदलें।",
            descriptionEn = "Make DOC and DOCX files easy to read by converting them to PDF.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.Description,
            iconBgColor = Color(0xFF2563EB)
        ),
        ILoveToolItem(
            id = "powerpoint_to_pdf",
            titleHindi = "PowerPoint से PDF",
            titleEn = "PowerPoint to PDF",
            descriptionHindi = "PPT और PPTX प्रेजेंटेशन को पढ़ने और शेयर करने योग्य PDF में बदलें।",
            descriptionEn = "Make PPT and PPTX slideshows easy to view by converting them to PDF.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.CoPresent,
            iconBgColor = Color(0xFFDC2626)
        ),
        ILoveToolItem(
            id = "excel_to_pdf",
            titleHindi = "Excel से PDF",
            titleEn = "Excel to PDF",
            descriptionHindi = "EXCEL स्प्रेडशीट को आसानी से पढ़ने योग्य PDF शीट में बदलें।",
            descriptionEn = "Make EXCEL spreadsheets easy to read by converting them to PDF.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.GridOn,
            iconBgColor = Color(0xFF16A34A)
        ),
        ILoveToolItem(
            id = "edit_pdf",
            titleHindi = "एडिट PDF",
            titleEn = "Edit PDF",
            descriptionHindi = "टेक्स्ट, इमेज, शेप्स या फ्रीहैंड एनोटेशन जोड़ें और फॉन्ट व रंग बदलें।",
            descriptionEn = "Add text, images, shapes or freehand annotations to a PDF document.",
            toolType = ToolMainType.PDF,
            category = "EDIT",
            icon = Icons.Default.EditNote,
            iconBgColor = Color(0xFFDB2777)
        ),
        ILoveToolItem(
            id = "pdf_to_jpg",
            titleHindi = "PDF से JPG",
            titleEn = "PDF to JPG",
            descriptionHindi = "हर PDF पेज को उच्च गुणवत्ता वाली JPG इमेज में बदलें।",
            descriptionEn = "Convert each PDF page into a JPG or extract all images contained in a PDF.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.Image,
            iconBgColor = Color(0xFFEAB308)
        ),
        ILoveToolItem(
            id = "jpg_to_pdf",
            titleHindi = "JPG से PDF",
            titleEn = "JPG to PDF",
            descriptionHindi = "JPG/PNG तस्वीरों को सेकंडों में PDF में बदलें। मार्जिन व ओरिएंटेशन एडजस्ट करें।",
            descriptionEn = "Convert JPG images to PDF in seconds. Easily adjust orientation and margins.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.PictureAsPdf,
            iconBgColor = Color(0xFFCA8A04)
        ),
        ILoveToolItem(
            id = "sign_pdf",
            titleHindi = "साइन PDF (E-Sign)",
            titleEn = "Sign PDF",
            descriptionHindi = "स्वयं हस्ताक्षर करें या दूसरों से इलेक्ट्रॉनिक हस्ताक्षर प्राप्त करें।",
            descriptionEn = "Sign yourself or request electronic signatures from others.",
            toolType = ToolMainType.PDF,
            category = "EDIT",
            icon = Icons.Default.Draw,
            iconBgColor = Color(0xFF0284C7)
        ),
        ILoveToolItem(
            id = "watermark_pdf",
            titleHindi = "वॉटरमार्क लगाएं",
            titleEn = "Watermark",
            descriptionHindi = "PDF पर अपनी पसंद की स्थिति, पारदर्शिता और फॉन्ट में टेक्स्ट या इमेज स्टैम्प लगाएं।",
            descriptionEn = "Stamp an image or text over your PDF in seconds. Choose typography and position.",
            toolType = ToolMainType.PDF,
            category = "EDIT",
            icon = Icons.Default.BrandingWatermark,
            iconBgColor = Color(0xFFA855F7)
        ),
        ILoveToolItem(
            id = "rotate_pdf",
            titleHindi = "रोटेट PDF",
            titleEn = "Rotate PDF",
            descriptionHindi = "पेजों को 90° या 180° घुमाएं और ओरिएंटेशन ठीक करें।",
            descriptionEn = "Rotate your PDFs the way you need them. Rotate multiple PDFs at once!",
            toolType = ToolMainType.PDF,
            category = "ORGANIZE",
            icon = Icons.Default.RotateRight,
            iconBgColor = Color(0xFFC026D3)
        ),
        ILoveToolItem(
            id = "html_to_pdf",
            titleHindi = "HTML से PDF",
            titleEn = "HTML to PDF",
            descriptionHindi = "वेबपेज को PDF में बदलें। URL कॉपी-पेस्ट करें और एक क्लिक में कन्वर्ट करें।",
            descriptionEn = "Convert webpages in HTML to PDF. Copy and paste the URL and convert with a click.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.Code,
            iconBgColor = Color(0xFFF59E0B)
        ),
        ILoveToolItem(
            id = "unlock_pdf",
            titleHindi = "अनलॉक PDF",
            titleEn = "Unlock PDF",
            descriptionHindi = "पासवर्ड सुरक्षा हटाएं और PDF को स्वतंत्र रूप से उपयोग करें।",
            descriptionEn = "Remove PDF password security, giving you the freedom to use your PDFs.",
            toolType = ToolMainType.PDF,
            category = "SECURITY",
            icon = Icons.Default.LockOpen,
            iconBgColor = Color(0xFF2563EB)
        ),
        ILoveToolItem(
            id = "protect_pdf",
            titleHindi = "सुरक्षित PDF (पासवर्ड लगाएं)",
            titleEn = "Protect PDF",
            descriptionHindi = "मजबूत पासवर्ड और 256-bit AES एन्क्रिप्शन से अनाधिकृत एक्सेस रोकें।",
            descriptionEn = "Protect PDF files with a password. Encrypt PDF documents to prevent unauthorized access.",
            toolType = ToolMainType.PDF,
            category = "SECURITY",
            icon = Icons.Default.Shield,
            iconBgColor = Color(0xFF0284C7)
        ),
        ILoveToolItem(
            id = "organize_pdf",
            titleHindi = "ऑर्गेनाइज़ PDF",
            titleEn = "Organize PDF",
            descriptionHindi = "पेजों को क्रमबद्ध करें, हटाएं या नए पेज जोड़ें।",
            descriptionEn = "Sort pages of your PDF file however you like. Delete or add PDF pages.",
            toolType = ToolMainType.PDF,
            category = "ORGANIZE",
            icon = Icons.Default.ViewAgenda,
            iconBgColor = Color(0xFFEA580C)
        ),
        ILoveToolItem(
            id = "pdf_to_pdfa",
            titleHindi = "PDF से PDF/A",
            titleEn = "PDF to PDF/A",
            descriptionHindi = "दीर्घकालिक डिजिटल दस्तावेज़ संरक्षण के लिए ISO-मानकीकृत PDF/A में बदलें।",
            descriptionEn = "Transform your PDF to PDF/A, the ISO-standardized version for long-term archiving.",
            toolType = ToolMainType.PDF,
            category = "CONVERT",
            icon = Icons.Default.VerifiedUser,
            iconBgColor = Color(0xFF475569)
        ),
        ILoveToolItem(
            id = "repair_pdf",
            titleHindi = "रिपेयर PDF",
            titleEn = "Repair PDF",
            descriptionHindi = "करप्ट या डैमेज PDF को ठीक करें और डेटा रिकवर करें।",
            descriptionEn = "Repair a damaged PDF and recover data from corrupt PDF files.",
            toolType = ToolMainType.PDF,
            category = "OPTIMIZE",
            icon = Icons.Default.Build,
            iconBgColor = Color(0xFF84CC16)
        ),
        ILoveToolItem(
            id = "page_numbers",
            titleHindi = "पेज नंबर डालें",
            titleEn = "Page numbers",
            descriptionHindi = "PDF में हेडर या फुटर में कस्टम पेज नंबर और दिनांक जोड़ें।",
            descriptionEn = "Add page numbers into PDFs with ease. Choose positions, dimensions and typography.",
            toolType = ToolMainType.PDF,
            category = "EDIT",
            icon = Icons.Default.FormatListNumbered,
            iconBgColor = Color(0xFF9333EA)
        ),
        ILoveToolItem(
            id = "scan_to_pdf",
            titleHindi = "स्कैन से PDF",
            titleEn = "Scan to PDF",
            descriptionHindi = "मोबाइल कैमरे से दस्तावेज़ स्कैन करें और क्रिस्टल क्लियर PDF बनाएं।",
            descriptionEn = "Capture document scans from your mobile device and send them instantly to PDF.",
            toolType = ToolMainType.PDF,
            category = "CREATE",
            icon = Icons.Default.DocumentScanner,
            iconBgColor = Color(0xFFF97316)
        ),
        ILoveToolItem(
            id = "ocr_pdf",
            titleHindi = "OCR PDF (टेक्स्ट निकालें)",
            titleEn = "OCR PDF",
            descriptionHindi = "स्कैन की गई PDF को सर्च व कॉपी करने योग्य टेक्स्ट डॉक्यूमेंट में बदलें।",
            descriptionEn = "Easily convert scanned PDF into searchable and selectable documents.",
            toolType = ToolMainType.PDF,
            category = "OPTIMIZE",
            icon = Icons.Default.FontDownload,
            iconBgColor = Color(0xFF10B981)
        ),
        ILoveToolItem(
            id = "ai_pdf_intelligence",
            titleHindi = "AI सारांश व प्रश्नोत्तरी",
            titleEn = "PDF Intelligence AI",
            descriptionHindi = "Gemini AI से पूरे PDF का तुरंत सारांश, Q&A और अनुवाद प्राप्त करें।",
            descriptionEn = "Summarize, ask questions and extract instant insights from PDFs using AI.",
            toolType = ToolMainType.PDF,
            category = "AI",
            icon = Icons.Default.AutoAwesome,
            iconBgColor = Color(0xFF8B5CF6),
            isNew = true,
            badge = "New!"
        )
    )

    // =========================================================================
    // 2. iLoveIMG COMPLETE SUITE (Screenshot 2 & 3 Exact Tools - फोटो एडिट)
    // =========================================================================
    val imageTools: List<ILoveToolItem> = listOf(
        ILoveToolItem(
            id = "compress_image",
            titleHindi = "इमेज को कंप्रेस करें",
            titleEn = "Compress IMAGE",
            descriptionHindi = "स्टोरेज के लिए जगह बचाते हुए और गुणवत्ता बनाए रखते हुए JPG, PNG, SVG और GIFs को कंप्रेस करें।",
            descriptionEn = "Compress JPG, PNG, SVG or GIFs with the best quality and compression.",
            toolType = ToolMainType.IMAGE,
            category = "OPTIMIZE",
            icon = Icons.Default.Compress,
            iconBgColor = Color(0xFF10B981)
        ),
        ILoveToolItem(
            id = "resize_image",
            titleHindi = "इमेज को रीसाइज़ करें",
            titleEn = "Resize IMAGE",
            descriptionHindi = "अपने आयाम को प्रतिशत या पिक्सेल द्वारा सेट करें, और अपनी JPG, PNG, SVG और GIF छवियों को रीसाइज़ करें।",
            descriptionEn = "Define your dimensions, by percentages or pixel, and resize JPG, PNG, SVG or GIF images.",
            toolType = ToolMainType.IMAGE,
            category = "MODIFY",
            icon = Icons.Default.PhotoSizeSelectLarge,
            iconBgColor = Color(0xFF06B6D4)
        ),
        ILoveToolItem(
            id = "crop_image",
            titleHindi = "इमेज को क्रॉप करें",
            titleEn = "Crop IMAGE",
            descriptionHindi = "आसानी से JPG, PNG, या GIF क्रॉप करें; अपने आयत को परिभाषित करने के लिए पिक्सेल चुनें या दृश्य संपादक का उपयोग करें।",
            descriptionEn = "Crop JPG, PNG or GIFs with ease; Choose pixels to define your rectangle or use our visual editor.",
            toolType = ToolMainType.IMAGE,
            category = "MODIFY",
            icon = Icons.Default.Crop,
            iconBgColor = Color(0xFF0284C7)
        ),
        ILoveToolItem(
            id = "convert_to_jpg",
            titleHindi = "JPG में कनवर्ट करें",
            titleEn = "Convert to JPG",
            descriptionHindi = "एक साथ कई PNG, GIF, TIF, PSD, SVG, WEBP, HEIC, or RAW फ़ॉर्मेट की छवियों को आसानी से JPG में बदलें।",
            descriptionEn = "Turn PNG, GIF, TIF, PSD, SVG, WEBP, HEIC or RAW format images to JPG in bulk with ease.",
            toolType = ToolMainType.IMAGE,
            category = "CONVERT",
            icon = Icons.Default.Image,
            iconBgColor = Color(0xFFFBBF24)
        ),
        ILoveToolItem(
            id = "convert_from_jpg",
            titleHindi = "JPG से कनवर्ट करें",
            titleEn = "Convert from JPG",
            descriptionHindi = "JPG छवियों को PNG या GIF में बदलें। सेकंडों में एक एनिमेटेड GIF बनाने के लिए कई JPGs चुनें!",
            descriptionEn = "Turn JPG images to PNG and GIF. Choose several JPGs to create an animated GIF in seconds!",
            toolType = ToolMainType.IMAGE,
            category = "CONVERT",
            icon = Icons.Default.Collections,
            iconBgColor = Color(0xFFF59E0B)
        ),
        ILoveToolItem(
            id = "photo_editor",
            titleHindi = "फोटो संपादक",
            titleEn = "Photo editor",
            descriptionHindi = "टेक्स्ट, इफेक्ट्स, फ्रेम या स्टिकर के साथ अपनी तस्वीरों को सजाएं। आपकी छवि आवश्यकताओं के लिए सरल संपादन उपकरण।",
            descriptionEn = "Spice up your pictures with text, effects, frames or stickers. Simple editing tools for your image needs.",
            toolType = ToolMainType.IMAGE,
            category = "CREATE",
            icon = Icons.Default.Edit,
            iconBgColor = Color(0xFFEC4899)
        ),
        ILoveToolItem(
            id = "upscale_image",
            titleHindi = "छवि अपस्केल करें",
            titleEn = "Upscale Image",
            descriptionHindi = "हाई-रेज़ॉल्यूशन के साथ अपनी छवियों को बड़ा करें। क्वालिटी को बनाए रखते हुए आसानी से अपनी JPG और PNG छवियों का साइज़ बढ़ाएं।",
            descriptionEn = "Enlarge your images with high resolution. Easily increase the size of your JPG and PNG images while maintaining visual quality.",
            toolType = ToolMainType.IMAGE,
            category = "OPTIMIZE",
            icon = Icons.Default.AutoFixHigh,
            iconBgColor = Color(0xFF10B981),
            isNew = true,
            badge = "नया!"
        ),
        ILoveToolItem(
            id = "remove_background",
            titleHindi = "बैकग्राउंड हटाएं",
            titleEn = "Remove background",
            descriptionHindi = "उच्च सटीकता के साथ छवि के बैकग्राउंड को तुरंत हटाएं। छवियों में तुरंत वस्तुओं का पता लगाएं और बैकग्राउंड को आसानी से हटाएं।",
            descriptionEn = "Quickly remove image backgrounds with high accuracy. Instantly detect objects and cut out backgrounds with ease.",
            toolType = ToolMainType.IMAGE,
            category = "OPTIMIZE",
            icon = Icons.Default.HideImage,
            iconBgColor = Color(0xFF22C55E),
            isNew = true,
            badge = "नया!"
        ),
        ILoveToolItem(
            id = "watermark_image",
            titleHindi = "छवि वॉटरमार्क करें",
            titleEn = "Watermark IMAGE",
            descriptionHindi = "सेकंडों में अपनी छवियों पर एक छवि या पाठ मुद्रित करें। टाइपोग्राफी, पारदर्शिता और स्थिति चुनें।",
            descriptionEn = "Stamp an image or text over your images in seconds. Choose typography, transparency and position.",
            toolType = ToolMainType.IMAGE,
            category = "SECURITY",
            icon = Icons.Default.BrandingWatermark,
            iconBgColor = Color(0xFF3B82F6)
        ),
        ILoveToolItem(
            id = "meme_generator",
            titleHindi = "मीम जनरेटर",
            titleEn = "Meme generator",
            descriptionHindi = "एक सरल कदम के साथ अपने मीम ऑनलाइन बनाएं। मीम छवियों को कैप्शन करें या कस्टम मीम बनाने के लिए अपनी तस्वीरें अपलोड करें।",
            descriptionEn = "Create your memes online with ease. Caption meme images or upload your pictures to make custom memes.",
            toolType = ToolMainType.IMAGE,
            category = "CREATE",
            icon = Icons.Default.SentimentVerySatisfied,
            iconBgColor = Color(0xFFA855F7)
        ),
        ILoveToolItem(
            id = "rotate_image",
            titleHindi = "इमेज को रोटेट करें",
            titleEn = "Rotate IMAGE",
            descriptionHindi = "कई इमेजों जैसे JPG, PNG या GIF को एक ही समय में रोटेट करें। केवल लैंडस्केप या पोर्ट्रेट इमेजों को रोटेट करने के लिए चुनें!",
            descriptionEn = "Rotate many images JPG, PNG or GIF at same time. Choose to rotate only landscape or portrait images!",
            toolType = ToolMainType.IMAGE,
            category = "MODIFY",
            icon = Icons.Default.RotateRight,
            iconBgColor = Color(0xFF06B6D4)
        ),
        ILoveToolItem(
            id = "html_to_image",
            titleHindi = "HTML से छवि",
            titleEn = "HTML to IMAGE",
            descriptionHindi = "HTML के वेब पेजों को JPG या SVG में कनवर्ट करें। उस पेज का URL कॉपी और पेस्ट करें जिसे आप कनवर्ट करना चाहते हैं, और उसे एक क्लिक के साथ छवि में कनवर्ट करें।",
            descriptionEn = "Convert webpages in HTML to JPG or SVG. Copy and paste URL and convert to image with a click.",
            toolType = ToolMainType.IMAGE,
            category = "CONVERT",
            icon = Icons.Default.Html,
            iconBgColor = Color(0xFFF59E0B)
        ),
        ILoveToolItem(
            id = "blur_face",
            titleHindi = "चेहरा धुंधला करें",
            titleEn = "Blur face",
            descriptionHindi = "तस्वीरों में चेहरों को आसानी से धुंधला करें। निजी जानकारी छिपाने के लिए आप लाइसेंस प्लेट और अन्य वस्तुओं को भी धुंधला कर सकते हैं।",
            descriptionEn = "Easily blur out faces in photos. You can also blur licence plates and other objects to hide private information.",
            toolType = ToolMainType.IMAGE,
            category = "SECURITY",
            icon = Icons.Default.BlurOn,
            iconBgColor = Color(0xFF0284C7),
            isNew = true,
            badge = "नया!"
        )
    )

    // =========================================================================
    // 3. WORKFLOWS & CREATOR TOOLS (Extra suite tools)
    // =========================================================================
    val workflowTools: List<ILoveToolItem> = listOf(
        ILoveToolItem(
            id = "blank_pdf_canvas",
            titleHindi = "ब्लैंक PDF डिज़ाइनर",
            titleEn = "Blank PDF Designer",
            descriptionHindi = "शून्य से कस्टम साइज़ (A4, A3, Letter) में खाली पेज डिज़ाइन करें।",
            descriptionEn = "Create custom blank PDFs with custom canvas size and zero formatting loss.",
            toolType = ToolMainType.WORKFLOW,
            category = "CREATE",
            icon = Icons.Default.NoteAdd,
            iconBgColor = Color(0xFF8B5CF6)
        ),
        ILoveToolItem(
            id = "id_card_2in1",
            titleHindi = "ID कार्ड 2-इन-1",
            titleEn = "ID Card 2-in-1 Scan",
            descriptionHindi = "आधार या वोटर ID कार्ड के आगे व पीछे के भाग को एक ही A4 पेज पर रखें।",
            descriptionEn = "Scan front and back of ID cards onto a single print-ready sheet.",
            toolType = ToolMainType.WORKFLOW,
            category = "CREATE",
            icon = Icons.Default.Badge,
            iconBgColor = Color(0xFFF97316)
        ),
        ILoveToolItem(
            id = "invoice_templates",
            titleHindi = "इनवॉइस व टेम्प्लेट्स",
            titleEn = "Invoice & Templates",
            descriptionHindi = "जीएसटी इनवॉइस, रसीद, प्रमाण-पत्र और आधिकारिक फॉर्म तुरंत जनरेट करें।",
            descriptionEn = "Ready-to-use business templates, invoices, certificates and formal receipts.",
            toolType = ToolMainType.WORKFLOW,
            category = "CREATE",
            icon = Icons.Default.ReceiptLong,
            iconBgColor = Color(0xFF10B981)
        ),
        ILoveToolItem(
            id = "gemini_ai_spaces",
            titleHindi = "AI को-पायलट स्पेसेज",
            titleEn = "AI Co-Pilot Spaces",
            descriptionHindi = "मल्टी-डॉक्यूमेंट एनालिसिस, ऑडियो पॉडकास्ट और परीक्षा क्विज़ जनरेटर।",
            descriptionEn = "Multi-document insights, auto podcast audio scripts and quiz generator.",
            toolType = ToolMainType.WORKFLOW,
            category = "AI",
            icon = Icons.Default.AutoAwesome,
            iconBgColor = Color(0xFF6366F1),
            isNew = true,
            badge = "PRO"
        )
    )

    fun getAllTools(type: ToolMainType): List<ILoveToolItem> {
        return when (type) {
            ToolMainType.PDF -> pdfTools
            ToolMainType.IMAGE -> imageTools
            ToolMainType.WORKFLOW -> workflowTools
        }
    }
}
