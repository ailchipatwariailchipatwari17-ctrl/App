package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import com.example.util.LanguageManager

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ALL PDF", appName)
  }

  @Test
  fun `verify language manager initializes correctly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val languageManager = LanguageManager(context)
    val selectedLang = languageManager.getSelectedLanguage()
    assertNotNull(selectedLang)
    assertNotNull(languageManager.t("home"))
  }
}
