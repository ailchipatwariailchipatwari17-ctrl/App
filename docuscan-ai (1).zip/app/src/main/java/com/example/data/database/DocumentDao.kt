package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.DocumentPage
import com.example.data.model.ScannedDocument
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {

    @Query("SELECT * FROM scanned_documents WHERE isPrivateVault = 0 AND isTrash = 0 ORDER BY createdAt DESC")
    fun getAllPublicDocuments(): Flow<List<ScannedDocument>>

    @Query("SELECT * FROM scanned_documents WHERE isPrivateVault = 1 AND isTrash = 0 ORDER BY createdAt DESC")
    fun getAllVaultDocuments(): Flow<List<ScannedDocument>>

    @Query("SELECT * FROM scanned_documents WHERE isTrash = 1 ORDER BY deletedAt DESC")
    fun getAllTrashDocuments(): Flow<List<ScannedDocument>>

    @Query("SELECT * FROM scanned_documents WHERE id = :id")
    suspend fun getDocumentById(id: Long): ScannedDocument?

    @Query("SELECT * FROM document_pages WHERE documentId = :docId ORDER BY pageIndex ASC")
    suspend fun getPagesForDocument(docId: Long): List<DocumentPage>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: ScannedDocument): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPages(pages: List<DocumentPage>)

    @Query("DELETE FROM scanned_documents WHERE id = :id")
    suspend fun deleteDocumentById(id: Long)

    @Query("DELETE FROM document_pages WHERE documentId = :docId")
    suspend fun deletePagesForDocument(docId: Long)

    @Transaction
    suspend fun deleteDocumentWithPages(id: Long) {
        deletePagesForDocument(id)
        deleteDocumentById(id)
    }

    @Query("UPDATE scanned_documents SET isPrivateVault = :isVault WHERE id = :id")
    suspend fun updateVaultStatus(id: Long, isVault: Boolean)

    @Query("UPDATE scanned_documents SET extractedText = :text WHERE id = :id")
    suspend fun updateExtractedText(id: Long, text: String)

    @Query("UPDATE scanned_documents SET isTrash = 1, deletedAt = :time WHERE id = :id")
    suspend fun moveToTrash(id: Long, time: Long = System.currentTimeMillis())

    @Query("UPDATE scanned_documents SET isTrash = 0, deletedAt = 0 WHERE id = :id")
    suspend fun restoreFromTrash(id: Long)

    @Query("UPDATE scanned_documents SET tags = :tags WHERE id = :id")
    suspend fun updateTags(id: Long, tags: String)

    @Query("UPDATE scanned_documents SET aiSummary = :summary WHERE id = :id")
    suspend fun updateAiSummary(id: Long, summary: String)

    @Query("UPDATE scanned_documents SET watermarkText = :watermark, stampText = :stamp WHERE id = :id")
    suspend fun updateWatermarkAndStamp(id: Long, watermark: String, stamp: String)

    @Query("UPDATE scanned_documents SET audioNotePath = :audioPath WHERE id = :id")
    suspend fun updateAudioNote(id: Long, audioPath: String)
}
