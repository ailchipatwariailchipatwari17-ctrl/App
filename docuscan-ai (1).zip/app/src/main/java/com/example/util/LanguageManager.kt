package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.LocaleList
import java.util.Locale

data class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val flagEmoji: String
)

class LanguageManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_language_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SELECTED_LANGUAGE = "selected_language_code"

        val SUPPORTED_LANGUAGES = listOf(
            AppLanguage("hi", "Hindi", "हिंदी", "🇮🇳"),
            AppLanguage("en", "English", "English", "🇺🇸"),
            AppLanguage("es", "Spanish", "Español", "🇪🇸"),
            AppLanguage("fr", "French", "Français", "🇫🇷"),
            AppLanguage("de", "German", "Deutsch", "🇩🇪"),
            AppLanguage("ar", "Arabic", "العربية", "🇸🇦"),
            AppLanguage("zh", "Chinese", "中文", "🇨🇳"),
            AppLanguage("ja", "Japanese", "日本語", "🇯🇵"),
            AppLanguage("ru", "Russian", "Русский", "🇷🇺"),
            AppLanguage("pt", "Portuguese", "Português", "🇵🇹"),
            AppLanguage("id", "Indonesian", "Bahasa Indonesia", "🇮🇩"),
            AppLanguage("bn", "Bengali", "বাংলা", "🇧🇩")
        )
    }

    var selectedLanguageCode: String
        get() = prefs.getString(KEY_SELECTED_LANGUAGE, "hi") ?: "hi"
        set(value) = prefs.edit().putString(KEY_SELECTED_LANGUAGE, value).apply()

    fun getSelectedLanguage(): AppLanguage {
        val currentCode = selectedLanguageCode
        return SUPPORTED_LANGUAGES.find { it.code == currentCode } ?: SUPPORTED_LANGUAGES.first()
    }

    fun applyLanguageLocale(context: Context, languageCode: String): Context {
        selectedLanguageCode = languageCode
        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val config = context.resources.configuration
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(LocaleList(locale))
        } else {
            @Suppress("DEPRECATION")
            config.locale = locale
        }

        return context.createConfigurationContext(config)
    }
}
