package com.example.data.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.CompressionLevel
import java.io.File
import java.io.FileOutputStream
import java.text.DecimalFormat

object PdfGenerator {

    data class PdfResult(
        val file: File,
        val pageCount: Int,
        val fileSizeBytes: Long,
        val fileSizeFormatted: String
    )

    /**
     * Generates a PDF file from a list of page Bitmaps with compression support.
     */
    fun createPdf(
        context: Context,
        pageBitmaps: List<Bitmap>,
        documentTitle: String,
        compressionLevel: CompressionLevel
    ): PdfResult {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = documentTitle.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()

        pageBitmaps.forEachIndexed { index, rawBitmap ->
            // Scale and compress bitmap according to compression level
            val scaledBitmap = scaleBitmapForCompression(rawBitmap, compressionLevel)

            // Standard A4 dimensions in PDF points (595 x 842 points)
            val pageWidth = 595
            val pageHeight = 842

            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint().apply { isFilterBitmap = true; isAntiAlias = true }

            // Draw image fitted on A4 canvas
            val destRect = Rect(20, 20, pageWidth - 20, pageHeight - 50)
            canvas.drawBitmap(scaledBitmap, null, destRect, paint)

            // Draw footer page counter & watermark
            val footerPaint = Paint().apply {
                color = android.graphics.Color.GRAY
                textSize = 12f
                isAntiAlias = true
            }
            canvas.drawText("Page ${index + 1} of ${pageBitmaps.size}", 20f, pageHeight - 20f, footerPaint)

            val rightText = "DocuScan AI"
            val textWidth = footerPaint.measureText(rightText)
            canvas.drawText(rightText, pageWidth - 20f - textWidth, pageHeight - 20f, footerPaint)

            pdfDocument.finishPage(page)

            if (scaledBitmap != rawBitmap) {
                scaledBitmap.recycle()
            }
        }

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        val fileSize = pdfFile.length()
        return PdfResult(
            file = pdfFile,
            pageCount = pageBitmaps.size,
            fileSizeBytes = fileSize,
            fileSizeFormatted = formatFileSize(fileSize)
        )
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val formatted = DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble()))
        return "$formatted ${units[digitGroups]}"
    }

    private fun scaleBitmapForCompression(bitmap: Bitmap, level: CompressionLevel): Bitmap {
        val scaleFactor = when (level) {
            CompressionLevel.LOW -> 1.0f
            CompressionLevel.MEDIUM -> 0.75f
            CompressionLevel.HIGH -> 0.50f
        }

        if (scaleFactor == 1.0f) return bitmap

        val newW = (bitmap.width * scaleFactor).toInt().coerceAtLeast(100)
        val newH = (bitmap.height * scaleFactor).toInt().coerceAtLeast(100)

        val scaled = Bitmap.createScaledBitmap(bitmap, newW, newH, true)

        // Compress stream
        val compressedBytes = ImageProcessor.compressBitmapToBytes(scaled, level.quality)
        return BitmapFactory.decodeByteArray(compressedBytes, 0, compressedBytes.size)
    }

    /**
     * Generates an ID Card PDF combining Front and Back photos onto a single A4 page.
     */
    fun createIdCardPdf(
        context: Context,
        frontBitmap: Bitmap,
        backBitmap: Bitmap,
        title: String
    ): PdfResult {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "ID_Card_" + title.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Draw header title
        val headerPaint = Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("आईडी कार्ड स्कैन (ID Card Document)", 40f, 60f, headerPaint)

        val subHeaderPaint = Paint().apply {
            color = android.graphics.Color.GRAY
            textSize = 12f
            isAntiAlias = true
        }
        canvas.drawText("Front & Back Side Verification - Single A4 Page", 40f, 82f, subHeaderPaint)

        val paint = Paint().apply { isFilterBitmap = true; isAntiAlias = true }

        // Front Side Box (Top half)
        val borderPaint = Paint().apply {
            color = android.graphics.Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }

        // Draw Front Side
        val frontLabelPaint = Paint().apply {
            color = android.graphics.Color.BLUE
            textSize = 14f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("सामने का भाग (Front Side):", 40f, 120f, frontLabelPaint)
        val frontRect = Rect(40, 130, pageWidth - 40, 420)
        canvas.drawBitmap(frontBitmap, null, frontRect, paint)
        canvas.drawRect(frontRect, borderPaint)

        // Draw Back Side
        canvas.drawText("पीछे का भाग (Back Side):", 40f, 460f, frontLabelPaint)
        val backRect = Rect(40, 470, pageWidth - 40, 760)
        canvas.drawBitmap(backBitmap, null, backRect, paint)
        canvas.drawRect(backRect, borderPaint)

        // Footer
        canvas.drawText("DocuScan AI Secure ID Vault • Auto Verified", 40f, 810f, subHeaderPaint)

        pdfDocument.finishPage(page)

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        val fileSize = pdfFile.length()
        return PdfResult(
            file = pdfFile,
            pageCount = 1,
            fileSizeBytes = fileSize,
            fileSizeFormatted = formatFileSize(fileSize)
        )
    }

    /**
     * Creates a clean digital PDF for handwritten notes.
     */
    fun createCleanedHandwritingPdf(
        context: Context,
        title: String,
        content: String
    ): File {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "CleanNotes_" + title.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = android.graphics.Color.rgb(230, 81, 0)
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 13f
            isAntiAlias = true
        }

        canvas.drawText(title, 40f, 50f, titlePaint)
        var y = 90f

        content.lines().forEach { line ->
            if (y < 800f) {
                canvas.drawText(line, 40f, y, textPaint)
                y += 22f
            }
        }

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }

    /**
     * Creates a formula sheet PDF for math/physics equations.
     */
    fun createFormulaSheetPdf(
        context: Context,
        title: String,
        content: String
    ): File {
        val pdfDir = File(context.filesDir, "documents_pdf").apply { mkdirs() }
        val safeFileName = "Formulas_" + title.replace(Regex("[^a-zA-Z0-9_]"), "_") + "_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfDir, safeFileName)

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = android.graphics.Color.rgb(255, 143, 0)
            textSize = 22f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 13f
            isAntiAlias = true
        }

        canvas.drawText("⚡ $title (Math & Physics Formulas)", 40f, 50f, titlePaint)
        var y = 95f

        content.lines().forEach { line ->
            if (y < 800f) {
                canvas.drawText(line, 40f, y, textPaint)
                y += 24f
            }
        }

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }

    /**
     * Share PDF file via Android Share Sheet (WhatsApp, Drive, Email, etc.).
     */
    fun sharePdf(context: Context, pdfFile: File, title: String) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, pdfFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "Shared via DocuScan AI: $title")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share PDF Document (पीडीएफ शेयर करें)"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
