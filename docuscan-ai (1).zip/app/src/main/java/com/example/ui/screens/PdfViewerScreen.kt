package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument
import com.example.ui.DocumentViewModel
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

import androidx.compose.material.icons.filled.Approval
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.School
import com.example.ui.components.AskPdfDialog
import com.example.ui.components.AudioNoteRecorderDialog
import com.example.ui.components.FlashcardQuizDialog
import com.example.ui.components.SignaturePadDialog
import com.example.ui.components.WatermarkStampDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerScreen(
    doc: ScannedDocument,
    viewModel: DocumentViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var pdfPagesBitmaps by remember(doc) { mutableStateOf<List<Bitmap>>(emptyList()) }
    var isLoadingPages by remember { mutableStateOf(true) }

    // Dialog states
    var showAskPdfDialog by remember { mutableStateOf(false) }
    var showWatermarkDialog by remember { mutableStateOf(false) }
    var showSignatureDialog by remember { mutableStateOf(false) }
    var showAudioNoteDialog by remember { mutableStateOf(false) }
    var showFlashcardsDialog by remember { mutableStateOf(false) }

    // Render crisp PDF pages using Android's native PdfRenderer
    LaunchedEffect(doc.pdfFilePath) {
        withContext(Dispatchers.IO) {
            val file = File(doc.pdfFilePath)
            if (file.exists() && file.name.endsWith(".pdf", ignoreCase = true)) {
                try {
                    val fileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                    val pdfRenderer = PdfRenderer(fileDescriptor)
                    val rendered = mutableListOf<Bitmap>()

                    for (i in 0 until pdfRenderer.pageCount) {
                        val page = pdfRenderer.openPage(i)
                        // Scale up by 2.5x for razor-sharp, crystal clear non-blurry text rendering
                        val densityScale = 2.5f
                        val width = (page.width * densityScale).toInt()
                        val height = (page.height * densityScale).toInt()

                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        rendered.add(bitmap)
                        page.close()
                    }
                    pdfRenderer.close()
                    fileDescriptor.close()
                    pdfPagesBitmaps = rendered
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            isLoadingPages = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(doc.title, fontWeight = FontWeight.Bold, maxLines = 1, fontSize = 16.sp)
                        Text(
                            text = "${doc.pageCount} Pages • Crisp HD PDF View",
                            fontSize = 11.sp,
                            color = PdfRed,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.generateAiSummary(doc) {
                            showAskPdfDialog = true
                        }
                    }) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Ask PDF AI", tint = TealAccent)
                    }
                    IconButton(onClick = { showWatermarkDialog = true }) {
                        Icon(Icons.Default.Approval, contentDescription = "Watermark", tint = TealAccent)
                    }
                    IconButton(onClick = { viewModel.shareDocument(doc) }) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = PdfRed)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp)
        ) {
            // Feature Quick Action Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { showAskPdfDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ask AI", fontSize = 11.sp)
                }
                Button(
                    onClick = { showSignatureDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Icon(Icons.Default.Create, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("हस्ताक्षर", fontSize = 11.sp)
                }
                Button(
                    onClick = { showAudioNoteDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("वॉइस नोट", fontSize = 11.sp)
                }
                Button(
                    onClick = { showFlashcardsDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                ) {
                    Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("क्विज़", fontSize = 11.sp)
                }
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                if (isLoadingPages) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = PdfRed)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("उच्च गुणवत्ता में PDF पन्ने रेंडर हो रहे हैं...", fontSize = 12.sp)
                        }
                    }
                } else if (pdfPagesBitmaps.isNotEmpty()) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(pdfPagesBitmaps) { index, bmp ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                border = androidx.compose.foundation.BorderStroke(0.5.dp, Color.LightGray)
                            ) {
                                Column {
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = "PDF Page ${index + 1}",
                                        modifier = Modifier.fillMaxWidth(),
                                        contentScale = ContentScale.FillWidth
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.Black.copy(alpha = 0.04f))
                                            .padding(vertical = 4.dp, horizontal = 8.dp),
                                        contentAlignment = Alignment.CenterEnd
                                    ) {
                                        Text(
                                            text = "पृष्ठ ${index + 1} / ${pdfPagesBitmaps.size}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                modifier = Modifier.size(72.dp),
                                tint = PdfRed
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(doc.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "फाइल: ${doc.pdfFilePath}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { viewModel.shareDocument(doc) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share PDF")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("शेयर करें")
                }

                Button(
                    onClick = {
                        viewModel.moveToTrash(doc.id)
                        onBack()
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("रीसाइकल बिन")
                }
            }
        }
    }

    // Dialog Rendering
    if (showAskPdfDialog) {
        AskPdfDialog(
            document = doc,
            initialSummary = doc.aiSummary,
            onDismissRequest = { showAskPdfDialog = false }
        )
    }

    if (showWatermarkDialog) {
        WatermarkStampDialog(
            initialWatermark = doc.watermarkText,
            initialStamp = doc.stampText,
            onApply = { w, s ->
                viewModel.updateWatermarkAndStamp(doc.id, w, s)
            },
            onDismissRequest = { showWatermarkDialog = false }
        )
    }

    if (showSignatureDialog) {
        SignaturePadDialog(
            onSignatureSaved = { bmp ->
                // Saved signature
            },
            onDismissRequest = { showSignatureDialog = false }
        )
    }

    if (showAudioNoteDialog) {
        AudioNoteRecorderDialog(
            initialAudioPath = doc.audioNotePath,
            onAudioSaved = { path ->
                viewModel.updateAudioNote(doc.id, path)
            },
            onDismissRequest = { showAudioNoteDialog = false }
        )
    }

    if (showFlashcardsDialog) {
        FlashcardQuizDialog(
            document = doc,
            onDismissRequest = { showFlashcardsDialog = false }
        )
    }
}
