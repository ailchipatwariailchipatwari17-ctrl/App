package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument
import com.example.ui.theme.TealAccent

@Composable
fun FlashcardQuizDialog(
    document: ScannedDocument,
    onDismissRequest: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Flashcards, 1: Quiz

    // Flashcard State
    var currentCardIndex by remember { mutableIntStateOf(0) }
    var isFlipped by remember { mutableStateOf(false) }

    val flashcards = remember {
        listOf(
            "प्रश्न 1: इस दस्तावेज़ का शीर्षक क्या है?" to "उत्तर: ${document.title}",
            "प्रश्न 2: फाइल श्रेणी (Category) क्या है?" to "उत्तर: ${document.fileCategory} (${document.fileSizeFormatted})",
            "प्रश्न 3: कुल पन्ने (Total Pages) कितने हैं?" to "उत्तर: ${document.pageCount} पन्ने",
            "प्रश्न 4: निर्माण तिथि (Created Date) क्या है?" to "उत्तर: ${document.formattedDate}"
        )
    }

    // Quiz State
    var selectedOption by remember { mutableIntStateOf(-1) }
    var quizAnswered by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(TealAccent.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = "Flashcards Quiz",
                    tint = TealAccent,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "स्टडी कार्ड्स व क्विज (Flashcards & Quiz)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("फ़्लैशकार्ड्स") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("एमसीक्यू क्विज़") }
                    )
                }
            }
        },
        text = {
            if (selectedTab == 0) {
                // FLASHCARDS
                val card = flashcards[currentCardIndex]
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clickable { isFlipped = !isFlipped },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isFlipped) TealAccent.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = if (isFlipped) card.second else card.first,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (isFlipped) TealAccent else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("(कार्ड पलटने के लिए क्लिक करें / Tap card to flip answer)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                if (currentCardIndex > 0) {
                                    currentCardIndex--
                                    isFlipped = false
                                }
                            },
                            enabled = currentCardIndex > 0
                        ) {
                            Text("पिछला")
                        }
                        Text("${currentCardIndex + 1} / ${flashcards.size}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                        Button(
                            onClick = {
                                if (currentCardIndex < flashcards.size - 1) {
                                    currentCardIndex++
                                    isFlipped = false
                                }
                            },
                            enabled = currentCardIndex < flashcards.size - 1
                        ) {
                            Text("अगला")
                        }
                    }
                }
            } else {
                // QUIZ
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Q. '${document.title}' फाइल किस प्रकार की है?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val options = listOf(
                        "ए) ${document.fileCategory} डॉक्यूमेंट",
                        "बी) ऑडियो सॉन्ग एमपी3",
                        "सी) सिस्टम कर्नल फाइल",
                        "डी) अनकम्प्रेस्ड रो वीडियो"
                    )

                    options.forEachIndexed { idx, opt ->
                        val isSelected = selectedOption == idx
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    when {
                                        quizAnswered && idx == 0 -> Color(0xFF4CAF50).copy(alpha = 0.2f)
                                        isSelected -> TealAccent.copy(alpha = 0.15f)
                                        else -> MaterialTheme.colorScheme.surfaceVariant
                                    }
                                )
                                .border(
                                    1.dp,
                                    if (quizAnswered && idx == 0) Color(0xFF4CAF50) else if (isSelected) TealAccent else Color.Transparent,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    selectedOption = idx
                                    quizAnswered = true
                                }
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(opt, fontWeight = FontWeight.Medium, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                if (quizAnswered && idx == 0) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50))
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("ठीक है (Done)", color = TealAccent, fontWeight = FontWeight.Bold)
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
