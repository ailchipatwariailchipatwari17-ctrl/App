package com.example.ui.components

import android.content.Context
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument
import com.example.ui.theme.TealAccent
import java.util.Locale

@Composable
fun PodcastModeDialog(
    document: ScannedDocument,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }
    var speechRate by remember { mutableFloatStateOf(1.0f) }
    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        var tts: TextToSpeech? = null
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.ENGLISH
                ttsEngine = tts
            }
        }
        onDispose {
            tts?.stop()
            tts?.shutdown()
        }
    }

    AlertDialog(
        onDismissRequest = {
            ttsEngine?.stop()
            onDismissRequest()
        },
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(TealAccent.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Headphones,
                    contentDescription = "Podcast Audio Mode",
                    tint = TealAccent,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "पॉडकास्ट ऑडियो रीडर (Background PDF Audiobook)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "स्क्रीन बंद होने पर भी पीडीएफ दस्तावेज़ को ऑडियो बुक की तरह सुनते रहें:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = TealAccent.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(document.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("पेज 1 - 5 • बैकग्राउंड ऑडियो रीडिंग सक्रिय", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    speechRate = if (speechRate >= 1.75f) 0.75f else speechRate + 0.25f
                                    ttsEngine?.setSpeechRate(speechRate)
                                    Toast.makeText(context, "स्पीड: ${speechRate}x", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.FastForward, contentDescription = "Speed", tint = TealAccent)
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            IconButton(
                                onClick = {
                                    if (isPlaying) {
                                        ttsEngine?.stop()
                                        isPlaying = false
                                    } else {
                                        val textToRead = "Playing document ${document.title}. Page 1 content reading in background."
                                        ttsEngine?.setSpeechRate(speechRate)
                                        ttsEngine?.speak(textToRead, TextToSpeech.QUEUE_FLUSH, null, "PDF_TTS_ID")
                                        isPlaying = true
                                    }
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(TealAccent, CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play Pause",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Text("${speechRate}x", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TealAccent)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    ttsEngine?.stop()
                    onDismissRequest()
                },
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
            ) {
                Text("ठीक है (Done)", color = Color.White)
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
