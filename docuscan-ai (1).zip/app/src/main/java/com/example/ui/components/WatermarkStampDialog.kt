package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Approval
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TealAccent

@Composable
fun WatermarkStampDialog(
    initialWatermark: String,
    initialStamp: String,
    onApply: (watermark: String, stamp: String) -> Unit,
    onDismissRequest: () -> Unit
) {
    var watermarkText by remember { mutableStateOf(initialWatermark) }
    var selectedStamp by remember { mutableStateOf(initialStamp) }

    val presetStamps = listOf("APPROVED", "CONFIDENTIAL", "PAID", "VERIFIED", "DRAFT", "NONE")

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(TealAccent.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Approval,
                    contentDescription = "Watermark Stamp",
                    tint = TealAccent,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "वाटरमार्क व डिजिटल स्टैम्प (Watermark & Stamp)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "1. वाटरमार्क टेक्स्ट (Watermark Text):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = watermarkText,
                    onValueChange = { watermarkText = it },
                    placeholder = { Text("जैसे: Confidential, My Company, Rakesh Tech") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "2. डिजिटल सील/स्टैम्प चुनें (Digital Stamp Seal):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presetStamps.take(3).forEach { stamp ->
                        val isSelected = selectedStamp == stamp
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) TealAccent.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
                                .border(if (isSelected) 1.5.dp else 0.dp, if (isSelected) TealAccent else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable { selectedStamp = if (stamp == "NONE") "" else stamp }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stamp,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (isSelected) TealAccent else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presetStamps.drop(3).forEach { stamp ->
                        val isSelected = selectedStamp == stamp || (stamp == "NONE" && selectedStamp.isEmpty())
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) TealAccent.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
                                .border(if (isSelected) 1.5.dp else 0.dp, if (isSelected) TealAccent else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable { selectedStamp = if (stamp == "NONE") "" else stamp }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stamp,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (isSelected) TealAccent else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onApply(watermarkText, selectedStamp)
                    onDismissRequest()
                },
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
            ) {
                Text("लागू करें (Apply Watermark)", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("रद्द करें")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
