package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import com.example.util.PdfRepairHelper
import com.example.util.PdfRepairResult
import java.io.File

@Composable
fun PdfRepairDialog(
    availableDocuments: List<ScannedDocument>,
    onSaveRepairedDocument: (repairedFile: File) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    var selectedDoc by remember { mutableStateOf<ScannedDocument?>(availableDocuments.firstOrNull()) }
    var isRepairing by remember { mutableStateOf(false) }
    var repairResult by remember { mutableStateOf<PdfRepairResult?>(null) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(PdfRed.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = "PDF Repair",
                    tint = PdfRed,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "PDF फिक्स व रिपेयर (PDF Corruption Repair)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "क्षतिग्रस्त (Corrupted / Unopenable) पीडीएफ फाइलों का हेडर, EOF ट्रेलर्स व ऑब्जेक्ट स्ट्रीम्स ठीक करें:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (availableDocuments.isEmpty()) {
                    Text("कोई फाइल उपलब्ध नहीं है।", color = PdfRed, fontSize = 13.sp)
                } else if (repairResult == null) {
                    Text("फाइल चुनें जिसे रिपेयर करना है:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    selectedDoc?.let { doc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                                .border(1.dp, TealAccent, RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, tint = TealAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(doc.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("${doc.pageCount} पन्ने • ${doc.fileSizeFormatted}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isRepairing) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = PdfRed)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("स्कैनिंग व रिपेयर जारी है...", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                } else {
                    // Show Repair Report
                    val res = repairResult!!
                    if (res.isSuccess) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("सफलतापूर्वक रिपेयर किया गया!", fontWeight = FontWeight.Bold, color = EmeraldGreen, fontSize = 14.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("• रिकवर पन्ने (Pages Recovered): ${res.pagesRecovered}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("की गई सुधार प्रक्रिया (Fixes Applied):", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                                .background(EmeraldGreen.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            res.fixesApplied.forEach { fix ->
                                Text("✔ $fix", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = PdfRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("रिपेयर विफल रहा", fontWeight = FontWeight.Bold, color = PdfRed, fontSize = 14.sp)
                        }
                        Text(res.errorMessage ?: "अज्ञात त्रुटि", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = {
            if (repairResult == null) {
                Button(
                    onClick = {
                        selectedDoc?.let { doc ->
                            isRepairing = true
                            val file = File(doc.pdfFilePath)
                            val res = PdfRepairHelper.repairPdf(context, file)
                            isRepairing = false
                            repairResult = res
                        }
                    },
                    enabled = selectedDoc != null && !isRepairing,
                    colors = ButtonDefaults.buttonColors(containerColor = PdfRed)
                ) {
                    Text("रिपेयर शुरू करें (Start Repair)", color = Color.White)
                }
            } else if (repairResult?.isSuccess == true) {
                Button(
                    onClick = {
                        repairResult?.repairedFile?.let { file ->
                            onSaveRepairedDocument(file)
                        }
                        onDismissRequest()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Text("सहेजें (Save & Open)", color = Color.White)
                }
            } else {
                TextButton(onClick = { repairResult = null }) {
                    Text("पुनः प्रयास करें")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("बंद करें")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
