package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.util.ImageProcessor
import com.example.ui.DocumentViewModel
import com.example.ui.components.CompressionDialog
import com.example.ui.components.EdgeCropOverlay
import com.example.ui.components.FilterChipSelector
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.TealAccent
import com.example.ui.theme.VaultAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanEditorScreen(
    viewModel: DocumentViewModel,
    onBack: () -> Unit,
    onSavedAndShared: () -> Unit,
    onNavigateToOcr: (Boolean) -> Unit
) {
    val workingPages by viewModel.workingPages.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val selectedCompression by viewModel.selectedCompression.collectAsStateWithLifecycle()
    val edgeCornerPoints by viewModel.edgeCornerPoints.collectAsStateWithLifecycle()

    var activePageIndex by remember { mutableIntStateOf(0) }
    var isCropMode by remember { mutableStateOf(false) }
    var docTitle by remember { mutableStateOf("Scan_${System.currentTimeMillis() / 1000}") }
    var isPrivateVault by remember { mutableStateOf(false) }
    var showCompressionDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current

    // Camera Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            viewModel.addWorkingPage(bitmap)
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch()
        } else {
            Toast.makeText(context, "कैमरा अनुमति आवश्यक है", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCameraWithPermission() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            cameraLauncher.launch()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Gallery Multiple Image Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<android.net.Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    val stream = context.contentResolver.openInputStream(uri)
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        viewModel.addWorkingPage(bmp)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    if (workingPages.isEmpty()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("दस्तावेज एडिटर", style = MaterialTheme.typography.titleMedium) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = TealAccent
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "कोई स्कैन पृष्ठ चयनित नहीं है",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "एडिटर में सम्पादित करने के लिए फोटो खींचें या गैलरी से चुनें।",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { launchCameraWithPermission() },
                            colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Camera")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("कैमरा स्कैन")
                        }
                        Button(
                            onClick = { galleryLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = "Gallery")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("गैलरी से चुनें")
                        }
                    }
                }
            }
        }
        return
    }

    val activeBitmap = workingPages.getOrElse(activePageIndex) { workingPages[0] }
    val filteredPreviewBitmap = remember(activeBitmap, selectedFilter) {
        ImageProcessor.applyFilter(activeBitmap, selectedFilter)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("दस्तावेज एडिटर & एज डिटेक्शन", style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { isCropMode = !isCropMode }) {
                        Icon(
                            imageVector = Icons.Default.Crop,
                            contentDescription = "Crop Edges",
                            tint = if (isCropMode) TealAccent else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { viewModel.rotateCurrentPage(activePageIndex) }) {
                        Icon(Icons.Default.RotateRight, contentDescription = "Rotate")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Document Image Preview with optional EdgeCropOverlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black.copy(alpha = 0.05f)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = filteredPreviewBitmap.asImageBitmap(),
                    contentDescription = "Scan Page Preview",
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentScale = ContentScale.Fit
                )

                if (isCropMode) {
                    EdgeCropOverlay(
                        cornerPoints = edgeCornerPoints,
                        onCornerMoved = { index, point ->
                            viewModel.updateCornerPoint(index, point)
                        }
                    )
                }
            }

            // Crop Action Confirm Bar if crop mode active
            if (isCropMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TealAccent.copy(alpha = 0.15f))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "किनारों को सही जगह पर खींचें (Drag corners)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Button(
                        onClick = {
                            viewModel.applyCropToCurrentPage(activePageIndex)
                            isCropMode = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Done Crop")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("एज क्रॉप लागू करें")
                    }
                }
            }

            // Filter Bar
            FilterChipSelector(
                selectedFilter = selectedFilter,
                onFilterSelected = { viewModel.setFilter(it) },
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Multiple Pages Thumbnail Bar
            if (workingPages.size > 1) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(workingPages) { index, bmp ->
                        val isSelected = index == activePageIndex
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) TealAccent else Color.Gray,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { activePageIndex = index },
                            contentAlignment = Alignment.TopEnd
                        ) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Page $index",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            IconButton(
                                onClick = { viewModel.removeWorkingPage(index) },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete Page",
                                    tint = Color.Red
                                )
                            }
                        }
                    }
                }
            }

            // Document Details & Actions Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = docTitle,
                        onValueChange = { docTitle = it },
                        label = { Text("पीडीएफ शीर्षक (Document Title)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { showCompressionDialog = true }
                        ) {
                            Icon(Icons.Default.Compress, contentDescription = "Compression", tint = TealAccent)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("कंप्रेशन लेवल", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(selectedCompression.labelHindi, fontSize = 10.sp, color = TealAccent)
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = "Vault", tint = VaultAmber)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("सुरक्षित वॉल्ट", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Switch(
                                checked = isPrivateVault,
                                onCheckedChange = { isPrivateVault = it }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // OCR and PDF Save Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.performOcrOnImage(filteredPreviewBitmap, false)
                                onNavigateToOcr(false)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.TextFields, contentDescription = "OCR")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ओसीआर (OCR)")
                        }

                        Button(
                            onClick = {
                                viewModel.performOcrOnImage(filteredPreviewBitmap, true)
                                onNavigateToOcr(true)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = VaultAmber)
                        ) {
                            Text("कंप्यूटर फॉन्ट")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            viewModel.convertToPdfAndSave(docTitle, isPrivateVault) { savedDoc ->
                                viewModel.shareDocument(savedDoc)
                                onSavedAndShared()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "PDF Share")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("PDF बनाएं और शेयर करें", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showCompressionDialog) {
        CompressionDialog(
            currentLevel = selectedCompression,
            onLevelSelected = {
                viewModel.setCompression(it)
                showCompressionDialog = false
            },
            onDismiss = { showCompressionDialog = false }
        )
    }
}
