package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument
import com.example.data.util.GeminiOcrHelper
import com.example.ui.theme.TealAccent
import com.example.ui.theme.WordBlue
import kotlinx.coroutines.launch

data class ChatMessage(val sender: String, val message: String, val isUser: Boolean)

@Composable
fun AskPdfDialog(
    document: ScannedDocument? = null,
    initialSummary: String = "",
    onDismissRequest: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var userQuestion by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }

    val docTitle = document?.title ?: "Meta AI (WhatsApp Style PDF Assistant)"

    val chatMessages = remember {
        mutableStateListOf(
            ChatMessage(
                "Meta AI",
                if (document != null)
                    "नमस्ते! मैं आपके दस्तावेज़ '${document.title}' से सम्बंधित प्रश्नों के उत्तर दे सकता हूँ। आप क्या पूछना चाहते हैं?"
                else
                    "नमस्ते! मैं आपका DocuScan Meta AI असिस्टेंट हूँ 🤖✨। आप मुझसे किसी भी पीडीएफ का सारांश, सवाल, अनुवाद, मैथ फॉर्मूला या नोट्स पूछ सकते हैं!",
                false
            )
        )
    }

    if (initialSummary.isNotBlank()) {
        chatMessages.add(ChatMessage("Meta AI", "📋 **AI Summary (सारांश):**\n$initialSummary", false))
    }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(TealAccent.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Ask PDF AI",
                    tint = TealAccent,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (document != null) "Ask PDF AI" else "DocuScan Meta AI (AI चैट)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = docTitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 260.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(chatMessages) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (msg.isUser) TealAccent
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = msg.message,
                                    fontSize = 13.sp,
                                    color = if (msg.isUser) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                if (isThinking) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = TealAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Meta AI सोच रहा है...", fontSize = 12.sp, color = TealAccent)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = userQuestion,
                        onValueChange = { userQuestion = it },
                        placeholder = { Text("जैसे: पीडीएफ का सारांश बताएं...", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            if (userQuestion.isNotBlank() && !isThinking) {
                                val q = userQuestion
                                chatMessages.add(ChatMessage("You", q, true))
                                userQuestion = ""
                                isThinking = true

                                coroutineScope.launch {
                                    val aiReply = GeminiOcrHelper.askGeminiAi(q, docTitle)
                                    chatMessages.add(ChatMessage("Meta AI", aiReply, false))
                                    isThinking = false
                                }
                            }
                        },
                        enabled = !isThinking,
                        modifier = Modifier
                            .background(TealAccent, shape = CircleShape)
                            .size(44.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("बंद करें (Close)", color = TealAccent, fontWeight = FontWeight.Bold)
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
