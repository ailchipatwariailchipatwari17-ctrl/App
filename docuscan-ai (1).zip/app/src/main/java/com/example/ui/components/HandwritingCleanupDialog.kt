package com.example.ui.components

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Create
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.util.PdfGenerator
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PptOrange
import com.example.ui.theme.TealAccent
import java.io.File

@Composable
fun HandwritingCleanupDialog(
    onRequestCamera: () -> Unit,
    onSaveCleanPdf: (pdfFile: File, title: String) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    var titleText by remember { mutableStateOf("AI Clean Handwritten Notes") }
    var rawNotesText by remember {
        mutableStateOf(
            "• पाठ 1: प्रकाश का परावर्तन (Reflection of Light)\n" +
            "  1. आपतन कोण (Angle of Incidence) = परावर्तन कोण (Angle of Reflection)\n" +
            "  2. अवतल दर्पण (Concave Mirror): वास्तविक और उल्टा प्रतिबिंब बनाता है।\n" +
            "  3. लेंस सूत्र (Lens Formula): 1/f = 1/v - 1/u\n\n" +
            "• मुख्य निष्कर्ष (Key Conclusion):\n" +
            "  - प्रकाश निर्वात में 3 × 10^8 m/s की गति से चलता है।"
        )
    }
    var isProcessing by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(PptOrange.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoFixHigh,
                    contentDescription = "Handwriting Clean-up",
                    tint = PptOrange,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "हैंडराइटिंग टू डिजिटल नोट्स (AI Handwriting Clean-up)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "हस्तलिखित (Handwritten) रफ कॉपी की फोटो को साफ़ और सुंदर डिजिटल टाइपसेट पीडीएफ नोट्स में बदलें:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    label = { Text("नोट्स का शीर्षक (Title)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("डिजिटल नोट्स प्रिव्यू (Extracted Digital Text):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = rawNotesText,
                    onValueChange = { rawNotesText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    placeholder = { Text("हस्तलिखित नोट्स का टेक्स्ट यहाँ दिखेगा...") }
                )

                if (isProcessing) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = PptOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI हैंडराइटिंग क्लीनिंग जारी है...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    isProcessing = true
                    val file = PdfGenerator.createCleanedHandwritingPdf(context, titleText, rawNotesText)
                    isProcessing = false
                    onSaveCleanPdf(file, titleText)
                    Toast.makeText(context, "क्लीन डिजिटल पीडीएफ नोट्स तैयार हैं!", Toast.LENGTH_SHORT).show()
                    onDismissRequest()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PptOrange)
            ) {
                Text("डिजिटल PDF बनाएं (Generate Clean PDF)", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("रद्द करें")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
