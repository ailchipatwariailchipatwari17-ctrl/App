package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallMerge
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument
import com.example.ui.theme.TealAccent

@Composable
fun MergeSplitDialog(
    availableDocuments: List<ScannedDocument>,
    onMergeSelected: (String, List<Long>) -> Unit,
    onSplitSelected: (Long, String, Int, Int) -> Unit,
    onDismissRequest: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Merge, 1: Split

    // Merge State
    var mergeTitle by remember { mutableStateOf("Merged_Doc_${System.currentTimeMillis() % 10000}") }
    val selectedDocIds = remember { mutableStateListOf<Long>() }

    // Split State
    var selectedDocForSplit by remember { mutableStateOf(availableDocuments.firstOrNull()) }
    var splitTitle by remember { mutableStateOf("Split_Pages") }
    var startPageText by remember { mutableStateOf("1") }
    var endPageText by remember { mutableStateOf("2") }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = {
            Column {
                Text(
                    text = "पीडीएफ मर्ज व स्प्लिट (Merge & Split PDF)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CallMerge, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                                Text("मर्ज (Combine)")
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CallSplit, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                                Text("स्प्लिट (Separate)")
                            }
                        }
                    )
                }
            }
        },
        text = {
            if (selectedTab == 0) {
                // MERGE VIEW
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = mergeTitle,
                        onValueChange = { mergeTitle = it },
                        label = { Text("नया मर्ज पीडीएफ नाम (New Title)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "जोड़ने के लिए पीडीएफ चुनें (Select 2 or more PDFs):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(availableDocuments) { doc ->
                            val isChecked = selectedDocIds.contains(doc.id)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (isChecked) TealAccent.copy(alpha = 0.12f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                    )
                                    .clickable {
                                        if (isChecked) selectedDocIds.remove(doc.id)
                                        else selectedDocIds.add(doc.id)
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { check ->
                                        if (check) selectedDocIds.add(doc.id)
                                        else selectedDocIds.remove(doc.id)
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = TealAccent)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(doc.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("${doc.pageCount} पन्ने • ${doc.fileSizeFormatted}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            } else {
                // SPLIT VIEW
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("स्प्लिट करने के लिए दस्तावेज चुनें:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 140.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(availableDocuments) { doc ->
                            val isSelected = selectedDocForSplit?.id == doc.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) TealAccent.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                    .border(if (isSelected) 1.dp else 0.dp, if (isSelected) TealAccent else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable { selectedDocForSplit = doc }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(doc.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                if (isSelected) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = TealAccent)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = splitTitle,
                        onValueChange = { splitTitle = it },
                        label = { Text("नया स्प्लिट फाइल नाम") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = startPageText,
                            onValueChange = { startPageText = it },
                            label = { Text("शुरुआती पन्ना") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = endPageText,
                            onValueChange = { endPageText = it },
                            label = { Text("अंतिम पन्ना") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedTab == 0) {
                        if (selectedDocIds.size >= 2) {
                            onMergeSelected(mergeTitle, selectedDocIds.toList())
                        }
                    } else {
                        val doc = selectedDocForSplit
                        val startP = startPageText.toIntOrNull() ?: 1
                        val endP = endPageText.toIntOrNull() ?: 1
                        if (doc != null) {
                            onSplitSelected(doc.id, splitTitle, startP, endP)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
            ) {
                Text(if (selectedTab == 0) "मर्ज करें (${selectedDocIds.size})" else "अलग / स्प्लिट करें", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("रद्द करें (Cancel)")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
