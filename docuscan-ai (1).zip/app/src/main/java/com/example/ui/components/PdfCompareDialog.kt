package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Difference
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScannedDocument
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import com.example.ui.theme.WordBlue

@Composable
fun PdfCompareDialog(
    availableDocuments: List<ScannedDocument>,
    onDismissRequest: () -> Unit
) {
    var doc1 by remember { mutableStateOf<ScannedDocument?>(availableDocuments.getOrNull(0)) }
    var doc2 by remember { mutableStateOf<ScannedDocument?>(availableDocuments.getOrNull(1) ?: availableDocuments.getOrNull(0)) }
    var showComparisonResult by remember { mutableStateOf(false) }

    val mockDifferences = remember(doc1, doc2) {
        listOf(
            Triple("पेज 1: पैरा 2", "Doc1: कुल बजट ₹50,000 स्वीकृत।", "Doc2: कुल बजट ₹75,000 संशोधित (Changed)."),
            Triple("पेज 2: नियम 4", "Doc1: अंतिम तिथि 15 अगस्त 2026।", "Doc2: अंतिम तिथि 31 अगस्त 2026 तक बढ़ाई गई।"),
            Triple("पेज 3: हस्ताक्षर", "Doc1: हस्ताक्षरित नहीं है।", "Doc2: डिजिटल स्टैम्प से हस्ताक्षरित (Verified).")
        )
    }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(WordBlue.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Compare,
                    contentDescription = "PDF Compare",
                    tint = WordBlue,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "PDF तुलना (Side-by-Side PDF Compare)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "दो समान पीडीएफ फाइलों के बीच के अंतरों (Differences) को ऑटोमैटिक लाल व हरे रंग में हाइलाइट करें:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (!showComparisonResult) {
                    // Document Selection UI
                    Text("1. पहला दस्तावेज़ (Document A):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    doc1?.let { d ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = WordBlue.copy(alpha = 0.1f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(d.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(10.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("2. दूसरा दस्तावेज़ (Document B):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    doc2?.let { d ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = TealAccent.copy(alpha = 0.1f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(d.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(10.dp))
                        }
                    }
                } else {
                    // Comparison Result Side-by-Side View
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("अंतर विश्लेषण (Found 3 Differences)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PdfRed)
                        Icon(Icons.Default.Difference, contentDescription = null, tint = PdfRed)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.height(200.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(mockDifferences) { idx, diff ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(diff.first, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = WordBlue)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("A: ${diff.second}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("B: ${diff.third}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PdfRed)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!showComparisonResult) {
                Button(
                    onClick = { showComparisonResult = true },
                    colors = ButtonDefaults.buttonColors(containerColor = WordBlue)
                ) {
                    Text("तुलना करें (Compare PDFs)", color = Color.White)
                }
            } else {
                TextButton(onClick = { showComparisonResult = false }) {
                    Text("वापस बदलें")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("बंद करें")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
