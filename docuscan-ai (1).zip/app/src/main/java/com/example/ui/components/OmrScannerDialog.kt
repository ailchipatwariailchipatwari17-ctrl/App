package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TealAccent
import com.example.ui.theme.VaultAmber

@Composable
fun OmrScannerDialog(
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    var isEvaluated by remember { mutableStateOf(false) }

    // Mock Answer Key vs Student OMR Fills
    val answerKey = remember { listOf("A", "B", "C", "D", "A", "C", "B", "A", "D", "C") }
    val studentFills = remember { listOf("A", "B", "C", "A", "A", "C", "B", "A", "D", "D") }

    val totalQuestions = answerKey.size
    val correctCount = answerKey.zip(studentFills).count { it.first == it.second }
    val wrongCount = totalQuestions - correctCount
    val scorePercentage = (correctCount.toFloat() / totalQuestions * 100).toInt()

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(EmeraldGreen.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.FactCheck,
                    contentDescription = "OMR Scanner",
                    tint = EmeraldGreen,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "OMR शीट इवैल्यूएटर (OMR Sheet Evaluator)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "उत्तर कुंजी (Answer Key) और विद्यार्थी ओएमआर शीट की स्कैन फोटो जांच कर तुरंत परिणाम प्राप्त करें:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (!isEvaluated) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("मापदंड (Evaluation Setup):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("• कुल प्रश्न: 10 MCQ", fontSize = 11.sp)
                            Text("• नेगेटिव मार्किंग: 0.25 अं अंक", fontSize = 11.sp)
                            Text("• आंसर की टाइप: सेट-A (10 Qs)", fontSize = 11.sp)
                        }
                    }
                } else {
                    // Result Summary Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = EmeraldGreen.copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("कुल स्कोर: $correctCount / $totalQuestions", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = EmeraldGreen)
                                Text("सफलता दर: $scorePercentage%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                if (scorePercentage >= 60) "PASSED 🎉" else "NEEDS IMPROVEMENT",
                                fontWeight = FontWeight.Bold,
                                color = if (scorePercentage >= 60) EmeraldGreen else PdfRed,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("विस्तृत उत्तर मिलान (Detailed Sheet Review):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        answerKey.take(5).forEachIndexed { idx, correct ->
                            val student = studentFills[idx]
                            val isRight = correct == student
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        if (isRight) EmeraldGreen.copy(alpha = 0.1f) else PdfRed.copy(alpha = 0.1f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Q${idx + 1}: ", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("उत्तर: $student | सही: $correct", fontSize = 11.sp, modifier = Modifier.weight(1f))
                                Icon(
                                    imageVector = if (isRight) Icons.Default.Check else Icons.Default.Close,
                                    contentDescription = null,
                                    tint = if (isRight) EmeraldGreen else PdfRed,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!isEvaluated) {
                Button(
                    onClick = { isEvaluated = true },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Text("ओएमआर शीट जांचें (Evaluate Sheet)", color = Color.White)
                }
            } else {
                Button(
                    onClick = {
                        Toast.makeText(context, "OMR रिपोर्ट कार्ड डाउनलोड हुआ!", Toast.LENGTH_SHORT).show()
                        onDismissRequest()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Text("रिपोर्ट PDF सहेजें (Save Scorecard)", color = Color.White)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("बंद करें")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
