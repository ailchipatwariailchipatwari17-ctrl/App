package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.util.PdfGenerator
import com.example.ui.theme.TealAccent
import com.example.ui.theme.VaultAmber
import java.io.File

@Composable
fun FormulaExtractorDialog(
    onSaveFormulaSheet: (pdfFile: File, title: String) -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    var isExtracted by remember { mutableStateOf(false) }

    val extractedFormulas = remember {
        listOf(
            "गणित (Mathematics): x = (-b ± √(b² - 4ac)) / 2a",
            "त्रिकोणमिति (Trigonometry): sin²θ + cos²θ = 1",
            "भौतिकी (Physics): E = mc²  |  F = m × a",
            "गति समीकरण (Kinematics): v = u + at  |  s = ut + ½at²",
            "रसायन विज्ञान (Chemistry): PV = nRT  (आदर्श गैस नियम)"
        )
    }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(VaultAmber.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Functions,
                    contentDescription = "Formula Extractor",
                    tint = VaultAmber,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "फॉर्मूला व समीकरण एक्सट्रैक्टर (Formula Sheet Generator)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "स्टडी पीडीएफ में से गणित, भौतिकी और रसायन शास्त्र के सभी सूत्रों व समीकरणों को पहचानकर अलग फॉर्मूला शीट बनाएं:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (!isExtracted) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("स्कैन मोड (Extraction Mode):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("• गणितीय सूत्र पहचान (Math / LaTeX Engine)", fontSize = 11.sp)
                            Text("• भौतिकी व रसायन रासायनिक समीकरण", fontSize = 11.sp)
                            Text("• एक-क्लिक 'Formula Sheet PDF' आउटपुट", fontSize = 11.sp)
                        }
                    }
                } else {
                    Text("पहचाने गए फॉर्मूले (Extracted Formulas List):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(
                        modifier = Modifier.height(160.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(extractedFormulas) { form ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = VaultAmber.copy(alpha = 0.15f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(form, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!isExtracted) {
                Button(
                    onClick = { isExtracted = true },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultAmber)
                ) {
                    Text("फॉर्मूले एक्सट्रैक्ट करें (Extract Formulas)", color = Color.White)
                }
            } else {
                Button(
                    onClick = {
                        val content = extractedFormulas.joinToString("\n\n• ")
                        val file = PdfGenerator.createFormulaSheetPdf(context, "Formula Sheet", content)
                        onSaveFormulaSheet(file, "Math Physics Formula Sheet")
                        Toast.makeText(context, "फॉर्मूला शीट PDF तैयार है!", Toast.LENGTH_SHORT).show()
                        onDismissRequest()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultAmber)
                ) {
                    Text("फॉर्मूला शीट PDF सहेजें (Save PDF)", color = Color.White)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("बंद करें")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
